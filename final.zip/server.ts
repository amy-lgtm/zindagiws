import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import crypto from 'crypto';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import {
  serverDb,
  SYSTEM_ADMIN_ROLE,
  StoredUserRecord,
  StoredCase,
  StoredEvidence,
  StoredReferenceSample,
  StoredDeepfakeAnalysis,
  StoredPublicReport,
  StoredChainOfCustodyEvent
} from './serverDb';
import helmet from 'helmet';
import {
  hashPassword,
  verifyPassword,
  validatePasswordStrength,
  issueJwtToken,
  verifyJwtToken,
  signCanonicalPayload,
  verifyCanonicalPayload,
  computeCustodyBlockHash,
  verifyCustodyChain,
  generateTotpSecret,
  buildTotpUri,
  verifyTotpCode,
  verifyTotpCodeWithStep,
  generateRecoveryCodes,
  hashRecoveryCode,
  validateAudioBufferAndFilename,
  isSmtpConfigured,
  sendSmtpEmail,
  JwtSessionClaims
} from './serverSecurity';
import {
  getRegisteredModelsStatus,
  extractServerAudioDsp,
  runDeepfakeAdaptersIsolated,
  evaluateDisguiseWithServerDsp
} from './serverAiAdapters';
import { deriveNormalizedWav } from './src/utils/audioDsp';
import { evaluateVoiceConditionHypotheses } from './src/utils/audioDsp';

dotenv.config();

const PORT = Number(process.env.PORT) || 3000;
const MAX_AUDIO_BYTES = 50 * 1024 * 1024; // 50 MB

const NON_ADMIN_ROLES = [
  'Lead Forensic Analyst',
  'Forensic Examiner / Expert Witness',
  'Prosecutor / Legal Reviewer'
] as const;

const ALL_ROLES = [
  'Lead Forensic Analyst',
  'Forensic Examiner / Expert Witness',
  'Prosecutor / Legal Reviewer',
  SYSTEM_ADMIN_ROLE
] as const;

interface AuthenticatedRequest extends Request {
  authUser?: StoredUserRecord;
  authClaims?: JwtSessionClaims;
  authToken?: string;
}

// Constant-time dummy scrypt hash used when an account does not exist (A7)
const DUMMY_PASSWORD_SALT = crypto.randomBytes(16).toString('hex');
const DUMMY_PASSWORD_HASH = hashPassword('DummyFallbackPassword#99123', DUMMY_PASSWORD_SALT);

// NFR-31: In-process bounded async audio analysis job queue
interface AnalysisJobRecord {
  jobId: string;
  caseId: string;
  evidenceId: string;
  requestedBy: string;
  status: 'QUEUED' | 'PROCESSING' | 'COMPLETED' | 'FAILED';
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
  statusCode?: number;
  error?: string;
  result?: Record<string, any>;
}
const analysisJobs = new Map<string, AnalysisJobRecord>();
const MAX_ANALYSIS_JOBS = 500;

function saveAnalysisJob(job: AnalysisJobRecord): void {
  if (!analysisJobs.has(job.jobId) && analysisJobs.size >= MAX_ANALYSIS_JOBS) {
    const oldestKey = analysisJobs.keys().next().value;
    if (oldestKey) analysisJobs.delete(oldestKey);
  }
  analysisJobs.set(job.jobId, job);
}

// -------------------------------------------------------------
// Rate Limiters & Security Helpers
// -------------------------------------------------------------
interface RateBucket {
  timestamps: number[];
}

function getClientIp(req: Request): string {
  const raw = req.ip || req.socket?.remoteAddress || '127.0.0.1';
  return String(raw).replace(/^::ffff:/, '');
}

function createRateLimiter(
  maxRequests: number,
  windowMs: number,
  bucketPrefix: string,
  options?: { keyByEmail?: boolean; maxIpRequests?: number }
) {
  const rateBuckets = new Map<string, RateBucket>();
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = getClientIp(req);
    const now = Date.now();
    const emailPart =
      options?.keyByEmail && typeof req.body?.email === 'string' && req.body.email.trim()
        ? req.body.email.trim().toLowerCase()
        : '';

    if (options?.maxIpRequests) {
      const ipKey = `${bucketPrefix}:ip:${ip}`;
      const ipBucket = rateBuckets.get(ipKey) || { timestamps: [] };
      ipBucket.timestamps = ipBucket.timestamps.filter((t) => now - t < windowMs);
      if (ipBucket.timestamps.length >= options.maxIpRequests) {
        res.status(429).json({
          error: 'Rate limit exceeded. Please wait before retrying this security-sensitive request.'
        });
        return;
      }
      ipBucket.timestamps.push(now);
      rateBuckets.set(ipKey, ipBucket);
    }

    const key = emailPart ? `${bucketPrefix}:${ip}:${emailPart}` : `${bucketPrefix}:${ip}`;
    const bucket = rateBuckets.get(key) || { timestamps: [] };
    bucket.timestamps = bucket.timestamps.filter((t) => now - t < windowMs);
    if (bucket.timestamps.length >= maxRequests) {
      res.status(429).json({
        error: 'Rate limit exceeded. Please wait before retrying this security-sensitive request.'
      });
      return;
    }
    bucket.timestamps.push(now);
    rateBuckets.set(key, bucket);
    next();
  };
}

function sha256String(str: string): string {
  return crypto.createHash('sha256').update(str).digest('hex');
}

function sha256Buffer(buf: Buffer): string {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

function isValidEmailFormat(email: string): boolean {
  return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email);
}

function nowUtcString(): string {
  return new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
}

const SESSION_COOKIE_NAME = 'alfadetect_session';

function parseCookieHeader(header: string | undefined): Record<string, string> {
  const cookies: Record<string, string> = {};
  if (!header) return cookies;
  for (const part of header.split(';')) {
    const eqIdx = part.indexOf('=');
    if (eqIdx <= 0) continue;
    const key = part.slice(0, eqIdx).trim();
    const rawVal = part.slice(eqIdx + 1).trim();
    if (!key) continue;
    try {
      cookies[key] = decodeURIComponent(rawVal);
    } catch {
      cookies[key] = rawVal;
    }
  }
  return cookies;
}

function extractSessionToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.slice(7).trim();
    if (token) return token;
  }
  const cookies = parseCookieHeader(req.headers.cookie);
  return cookies[SESSION_COOKIE_NAME] || null;
}

function getSessionPolicy(): { sessionTtlMinutes: number; idleLockMinutes: number } {
  const cfg = serverDb.getSystemConfig();
  const sessionTtlMinutes = Math.max(5, Math.min(1440, Math.round(Number(cfg.sessionTtlMinutes) || 480)));
  const idleLockMinutes = Math.max(1, Math.min(120, Math.round(Number(cfg.idleLockMinutes) || 5)));
  return { sessionTtlMinutes, idleLockMinutes };
}

function setSessionCookie(req: Request, res: Response, token: string, ttlSeconds: number): void {
  const isHttps = Boolean(
    req.secure ||
      String(req.headers['x-forwarded-proto'] || '').toLowerCase() === 'https' ||
      process.env.NODE_ENV === 'production'
  );
  res.cookie(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'strict',
    secure: isHttps,
    path: '/',
    maxAge: ttlSeconds * 1000
  });
}

function clearSessionCookie(req: Request, res: Response): void {
  const isHttps = Boolean(
    req.secure ||
      String(req.headers['x-forwarded-proto'] || '').toLowerCase() === 'https' ||
      process.env.NODE_ENV === 'production'
  );
  res.clearCookie(SESSION_COOKIE_NAME, {
    httpOnly: true,
    sameSite: 'strict',
    secure: isHttps,
    path: '/'
  });
}

function generateTemporaryPassword(): string {
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const lower = 'abcdefghijkmnopqrstuvwxyz';
  const digits = '23456789';
  const special = '!@#$%^&*-_+=';
  const all = upper + lower + digits + special;
  const chars = [
    upper[crypto.randomInt(upper.length)],
    lower[crypto.randomInt(lower.length)],
    digits[crypto.randomInt(digits.length)],
    special[crypto.randomInt(special.length)]
  ];
  while (chars.length < 16) {
    chars.push(all[crypto.randomInt(all.length)]);
  }
  for (let i = chars.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1);
    const tmp = chars[i];
    chars[i] = chars[j];
    chars[j] = tmp;
  }
  return chars.join('');
}

function sanitizeUser(u: StoredUserRecord) {
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
    requestedRole: u.requestedRole || u.role,
    agency: u.agency,
    department: u.department,
    avatar: u.avatar,
    status: u.status,
    casesCount: u.casesCount,
    phone: u.phone,
    securityClearance: u.securityClearance || u.role,
    certificationId: u.certificationId,
    rejectionReason: u.rejectionReason,
    reviewedBy: u.reviewedBy,
    reviewedAt: u.reviewedAt,
    createdAt: u.createdAt,
    lastLoginAt: u.lastLoginAt,
    twoFactorEnabled: Boolean(u.twoFactorEnabled),
    twoFactorMethod: u.twoFactorMethod || 'NONE',
    mustChangePassword: Boolean(u.mustChangePassword),
    themePreference: u.themePreference || 'light',
    notificationPreferences: u.notificationPreferences
  };
}

function verifyTotpWithReplayGuard(
  user: StoredUserRecord,
  candidateCode: string
): { ok: boolean; error?: string } {
  const secret = serverDb.getDecryptedTotpSecret(user, false);
  if (!secret) {
    return { ok: false, error: 'TOTP secret unavailable for this account.' };
  }
  const check = verifyTotpCodeWithStep(secret, String(candidateCode || '').trim());
  if (!check.valid || check.timeStep === undefined) {
    return { ok: false, error: 'Invalid 6-digit TOTP verification code.' };
  }
  if (typeof user.lastTotpStep === 'number' && check.timeStep <= user.lastTotpStep) {
    return { ok: false, error: 'TOTP code already used. Wait for the next 30-second authenticator window.' };
  }
  serverDb.updateUser(user.id, { lastTotpStep: check.timeStep });
  return { ok: true };
}

function canAccessCase(user: StoredUserRecord, caseObj: StoredCase): boolean {
  if (user.role === SYSTEM_ADMIN_ROLE) {
    return false; // Separation of duties: Admin manages users/policies, never raw case evidence
  }
  const emailLower = user.email.toLowerCase();
  const createdByMatch =
    (caseObj.createdBy || '').toLowerCase() === emailLower ||
    caseObj.createdBy === user.id;
  const assignedMatch = Array.isArray(caseObj.assignedUserIds)
    ? caseObj.assignedUserIds.includes(user.id)
    : false;
  return createdByMatch || assignedMatch;
}

function getAccessibleCasesForUser(user: StoredUserRecord, includeArchived = false): StoredCase[] {
  const all = serverDb.getCases(includeArchived);
  if (user.role === SYSTEM_ADMIN_ROLE) {
    return [];
  }
  return all.filter((c) => canAccessCase(user, c));
}

function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') return null;
  return new GoogleGenAI({ apiKey });
}

function writeAudit(
  req: Request,
  user: string,
  action: 'VIEW' | 'WRITE' | 'SIGN' | 'UPLOAD' | 'VERIFY' | 'LOGIN' | 'CONFIG' | 'DELETE',
  resource: string,
  status: 'SUCCESS' | 'FAILED',
  details?: string,
  role?: string
) {
  return serverDb.addAuditLog({
    id: `AUD-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
    timestamp: nowUtcString(),
    user,
    action,
    resource,
    ipAddress: getClientIp(req),
    status,
    details,
    role
  });
}

function appendSignedCustodyEvent(params: {
  req: Request;
  caseId: string;
  evidenceId?: string;
  title: string;
  actorRole: 'System' | 'Lead Analyst' | 'Automated' | 'Expert' | 'Legal';
  status: 'VERIFIED' | 'PENDING';
  userName: string;
  hashAtEvent?: string;
  details?: string;
}): StoredChainOfCustodyEvent {
  const existing = serverDb.getChainOfCustody(params.caseId);
  const last = existing.length > 0 ? existing[existing.length - 1] : null;
  const prevBlockHash = last ? last.blockHash : '0'.repeat(64);
  const eventNumber = last ? last.eventNumber + 1 : 1;
  const id = `COC-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
  const timestamp = nowUtcString();

  const blockHash = computeCustodyBlockHash(prevBlockHash, {
    id,
    caseId: params.caseId,
    evidenceId: params.evidenceId,
    eventNumber,
    title: params.title,
    actorRole: params.actorRole,
    timestamp,
    userName: params.userName,
    hashAtEvent: params.hashAtEvent
  });

  const sig = signCanonicalPayload({
    id,
    caseId: params.caseId,
    evidenceId: params.evidenceId,
    eventNumber,
    title: params.title,
    timestamp,
    blockHash
  });

  return serverDb.addChainOfCustodyEvent({
    id,
    caseId: params.caseId,
    evidenceId: params.evidenceId,
    eventNumber,
    title: params.title,
    actorRole: params.actorRole,
    status: params.status,
    timestamp,
    userName: params.userName,
    ipAddress: getClientIp(params.req),
    digitalSignature: sig.signatureDisplay,
    prevBlockHash,
    blockHash,
    payloadHash: sig.payloadHash,
    hashAtEvent: params.hashAtEvent,
    details: params.details
  });
}

function sanitizeEvidenceMetadata(e: StoredEvidence) {
  const { audioData: _omit, storageFilename: _sf, ...meta } = e;
  const hasAudio = Boolean(e.storageFilename || e.audioData);
  return {
    ...meta,
    hasAudioData: hasAudio,
    audioUrl: hasAudio ? `/api/evidence/${e.id}/audio` : e.audioUrl
  };
}

function sanitizeReferenceMetadata(r: StoredReferenceSample) {
  const { audioData: _omit, storageFilename: _sf, ...meta } = r;
  const hasAudio = Boolean(r.storageFilename || r.audioData);
  return {
    ...meta,
    hasAudioData: hasAudio,
    audioUrl: hasAudio ? `/api/references/${r.id}/audio` : undefined
  };
}

function verifyStoredEvidenceIntegrity(
  req: Request,
  user: StoredUserRecord,
  ev: StoredEvidence
): { ok: boolean; buffer: Buffer | null; tampered?: boolean; computedHash?: string; reason?: string } {
  const readRes = serverDb.readAudioBufferWithStatus(ev);
  const buf = readRes.buffer;

  if (!buf) {
    if (readRes.tampered) {
      serverDb.updateEvidence(ev.id, {
        isIntegrityVerified: false,
        status: 'Failed',
        verifiedBy: user.email,
        verificationDate: nowUtcString()
      });
      appendSignedCustodyEvent({
        req,
        caseId: ev.caseId,
        evidenceId: ev.id,
        title: 'Cryptographic AES-256-GCM Ciphertext MISMATCH_ALERT',
        actorRole: 'System',
        status: 'PENDING',
        userName: user.email,
        details: 'Stored encrypted evidence failed AES-256-GCM authentication tag verification (ciphertext tampered).'
      });
      writeAudit(
        req,
        user.email,
        'VERIFY',
        `Evidence Ciphertext Tamper Detected: ${ev.filename} (${ev.id})`,
        'FAILED',
        'AES-256-GCM authentication failed',
        user.role
      );
      serverDb.addNotification({
        id: `NOTIF-TAMPER-${Date.now()}`,
        title: 'CRITICAL: Encrypted Evidence Tamper Alert',
        description: `Evidence ${ev.filename} (${ev.id}) in Case ${ev.caseId} failed AES-256-GCM authentication. Downstream processing halted.`,
        timestamp: 'Just now',
        read: false,
        severity: 'critical',
        caseId: ev.caseId,
        targetRole: SYSTEM_ADMIN_ROLE
      });
      return {
        ok: false,
        buffer: null,
        tampered: true,
        reason: 'Evidence Integrity Violation: AES-256-GCM encrypted bitstream failed authentication check. Downstream action blocked.'
      };
    }
    return {
      ok: false,
      buffer: null,
      reason: 'Stored evidence audio bitstream could not be located on the enclave disk.'
    };
  }

  const computedHash = sha256Buffer(buf);
  if (computedHash.toLowerCase() !== ev.sha256Hash.toLowerCase() || ev.status === 'Failed') {
    serverDb.updateEvidence(ev.id, {
      isIntegrityVerified: false,
      status: 'Failed',
      verifiedBy: user.email,
      verificationDate: nowUtcString()
    });
    appendSignedCustodyEvent({
      req,
      caseId: ev.caseId,
      evidenceId: ev.id,
      title: 'Cryptographic SHA-256 Integrity MISMATCH_ALERT',
      actorRole: 'System',
      status: 'PENDING',
      userName: user.email,
      hashAtEvent: computedHash,
      details: `Tamper/corruption detected: live hash ${computedHash.slice(0, 16)}... differs from registered ${ev.sha256Hash.slice(0, 16)}...`
    });
    writeAudit(
      req,
      user.email,
      'VERIFY',
      `Evidence Integrity Mismatch Detected: ${ev.filename} (${ev.id})`,
      'FAILED',
      `Expected ${ev.sha256Hash.slice(0, 16)}... | Live ${computedHash.slice(0, 16)}...`,
      user.role
    );
    serverDb.addNotification({
      id: `NOTIF-TAMPER-${Date.now()}`,
      title: 'CRITICAL: Evidence Integrity Mismatch',
      description: `Evidence ${ev.filename} (${ev.id}) in Case ${ev.caseId} failed live SHA-256 verification. Downstream processing halted.`,
      timestamp: 'Just now',
      read: false,
      severity: 'critical',
      caseId: ev.caseId,
      targetRole: SYSTEM_ADMIN_ROLE
    });
    return {
      ok: false,
      buffer: buf,
      tampered: true,
      computedHash,
      reason: `Evidence Integrity Violation: live SHA-256 (${computedHash.slice(0, 16)}...) mismatches registered baseline (${ev.sha256Hash.slice(0, 16)}...). Downstream action blocked.`
    };
  }
  return { ok: true, buffer: buf, computedHash };
}

function verifyReferenceIntegrity(ref: StoredReferenceSample): { ok: boolean; buffer: Buffer | null; tampered?: boolean; computedHash?: string } {
  const readRes = serverDb.readAudioBufferWithStatus(ref);
  if (!readRes.buffer) return { ok: false, buffer: null, tampered: readRes.tampered };
  const computedHash = sha256Buffer(readRes.buffer);
  return {
    ok: computedHash.toLowerCase() === ref.sha256Hash.toLowerCase(),
    buffer: readRes.buffer,
    computedHash
  };
}

function buildPublicReportCanonicalPayload(rec: {
  reportId: string;
  caseId: string;
  evidenceId: string;
  evidenceSha256: string;
  verdict: string;
  leadAnalyst: string;
  expertWitness: string;
  signedAt: string;
}) {
  return {
    reportId: rec.reportId,
    caseId: rec.caseId,
    evidenceId: rec.evidenceId,
    evidenceSha256: rec.evidenceSha256,
    verdict: rec.verdict,
    leadAnalyst: rec.leadAnalyst,
    expertWitness: rec.expertWitness,
    signedAt: rec.signedAt
  };
}

// -------------------------------------------------------------
// Application Factory
// -------------------------------------------------------------
export function createApp() {
  const app = express();
  app.set('trust proxy', process.env.ALFADETECT_TRUST_PROXY === 'true' ? 1 : false);

  const strictFraming = process.env.ALFADETECT_STRICT_FRAME_ANCESTORS === 'true';
  const frameAncestorsList = strictFraming
    ? ["'self'"]
    : [
        "'self'",
        'https://aistudio.google.com',
        'https://*.google.com',
        'https://*.googleusercontent.com',
        'https://*.usercontent.goog'
      ];

  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'", "'unsafe-inline'"],
          styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
          fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
          imgSrc: ["'self'", 'data:', 'blob:'],
          mediaSrc: ["'self'", 'blob:'],
          connectSrc: ["'self'", 'ws:', 'wss:'],
          objectSrc: ["'none'"],
          frameAncestors: frameAncestorsList,
          ...(process.env.NODE_ENV === 'production' ? {} : { upgradeInsecureRequests: null })
        }
      },
      xFrameOptions: false,
      crossOriginOpenerPolicy: false,
      crossOriginResourcePolicy: false,
      crossOriginEmbedderPolicy: false,
      hsts: process.env.NODE_ENV === 'production' ? { maxAge: 31536000, includeSubDomains: true } : false,
      referrerPolicy: { policy: 'no-referrer' }
    })
  );

  // Additional Security & Cache Headers
  app.use((req, res, next) => {
    res.setHeader('Permissions-Policy', 'microphone=(self), camera=(), geolocation=()');
    if (req.path.startsWith('/api/')) {
      res.setHeader('Cache-Control', 'no-store');
    }
    next();
  });

  // Conditional JSON Body Size Limits (50mb ONLY for audio base64 intake routes, 1mb globally)
  const largeJsonParser = express.json({ limit: '50mb' });
  const defaultJsonParser = express.json({ limit: '1mb' });
  app.use((req, res, next) => {
    const p = req.path;
    const isLargeUploadRoute =
      p === '/api/evidence/upload' ||
      p === '/api/evidence/verify-hash' ||
      /^\/api\/cases\/[^/]+\/references$/.test(p);
    const parser = isLargeUploadRoute ? largeJsonParser : defaultJsonParser;
    parser(req, res, (err: any) => {
      if (err) {
        if (err.type === 'entity.too.large' || err.status === 413) {
          res.status(413).json({ error: 'Request payload exceeds maximum allowed size limit.' });
          return;
        }
        res.status(400).json({ error: 'Malformed JSON request body.' });
        return;
      }
      next();
    });
  });

  const strictAuthLimiter = createRateLimiter(25, 60 * 1000, 'strict-auth', {
    keyByEmail: true,
    maxIpRequests: 200
  });
  const forgotResetLimiter = createRateLimiter(10, 60 * 1000, 'forgot-reset', {
    keyByEmail: true,
    maxIpRequests: 30
  });
  const apiLimiter = createRateLimiter(300, 60 * 1000, 'api');
  const publicLimiter = createRateLimiter(60, 60 * 1000, 'public');

  app.use('/api/', apiLimiter);
  app.use('/api/public', publicLimiter);

  const failed2faAttemptsByJti = new Map<string, number>();
  const pending2faLoginModeByJti = new Map<string, 'user' | 'admin'>();

  const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: MAX_AUDIO_BYTES }
  });

  function optionalAudioMultipart(fieldNames: string[] = ['audio', 'file']) {
    return (req: Request, res: Response, next: NextFunction) => {
      const ct = (req.headers['content-type'] || '').toLowerCase();
      if (!ct.includes('multipart/form-data')) {
        next();
        return;
      }
      upload.fields(fieldNames.map((name) => ({ name, maxCount: 1 })))(req, res, (err: any) => {
        if (err) {
          if (err.code === 'LIMIT_FILE_SIZE') {
            res.status(413).json({ error: 'Audio file exceeds maximum size limit (50 MB).' });
            return;
          }
          res.status(400).json({ error: `Multipart upload error: ${err.message || 'Invalid form payload'}` });
          return;
        }
        next();
      });
    };
  }

  function extractUploadedFileFromReq(req: Request, fieldName?: string): { buffer: Buffer; filename: string } | null {
    const filesObj = (req as any).files as Record<string, Express.Multer.File[]> | undefined;
    if (filesObj) {
      if (fieldName && filesObj[fieldName]?.[0]) {
        const f = filesObj[fieldName][0];
        return { buffer: f.buffer, filename: f.originalname };
      }
      for (const key of ['audio', 'file']) {
        if (filesObj[key]?.[0]) {
          const f = filesObj[key][0];
          return { buffer: f.buffer, filename: f.originalname };
        }
      }
    }
    return null;
  }

  const PASSWORD_CHANGE_EXEMPT_PATHS = new Set([
    '/api/auth/me',
    '/api/auth/logout',
    '/api/settings/password',
    '/api/settings/2fa/status',
    '/api/settings/2fa/setup',
    '/api/settings/2fa/verify'
  ]);

  const TWO_FACTOR_ENROLLMENT_EXEMPT_PATHS = new Set([
    '/api/auth/me',
    '/api/auth/logout',
    '/api/settings/2fa/status',
    '/api/settings/2fa/setup',
    '/api/settings/2fa/verify'
  ]);

  // Auth Middleware (Bearer or HttpOnly cookie + JWT typ + Revocation + TokenVersion + Active Status + Forced Rotation/2FA)
  function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    const token = extractSessionToken(req);
    if (!token) {
      res.status(401).json({ error: 'Unauthorized: Missing or expired session token.' });
      return;
    }
    const claims = verifyJwtToken(token);
    if (!claims || claims.typ !== 'session') {
      res.status(401).json({ error: 'Unauthorized: Invalid, wrong-purpose, or expired session token.' });
      return;
    }
    if (serverDb.isTokenRevoked(claims.jti)) {
      res.status(401).json({ error: 'Unauthorized: Session token has been explicitly revoked.' });
      return;
    }

    const user = serverDb.getUserById(claims.sub) || serverDb.getUserByEmail(claims.email);
    if (!user) {
      res.status(401).json({ error: 'Unauthorized: User account no longer exists.' });
      return;
    }
    if (user.tokenVersion !== claims.tv) {
      res.status(401).json({ error: 'Unauthorized: Session superseded by security change. Please sign in again.' });
      return;
    }
    if (user.status !== 'active') {
      res.status(403).json({
        error: `Access Revoked: Account status is '${user.status}'. Administrator approval or reactivation required.`,
        accountStatus: user.status
      });
      return;
    }
    if (user.mustChangePassword && !PASSWORD_CHANGE_EXEMPT_PATHS.has(req.path)) {
      res.status(403).json({
        error: 'Password rotation required before accessing forensic enclave resources.',
        code: 'PASSWORD_CHANGE_REQUIRED',
        mustChangePassword: true
      });
      return;
    }

    const sysConfig = serverDb.getSystemConfig();
    if (sysConfig.enforceTwoFactor && !user.twoFactorEnabled && !TWO_FACTOR_ENROLLMENT_EXEMPT_PATHS.has(req.path)) {
      res.status(403).json({
        error: 'Two-factor authentication enrollment is mandatory under current system security policy. Complete TOTP setup before accessing enclave resources.',
        code: 'TWO_FACTOR_ENROLLMENT_REQUIRED',
        twoFactorEnrollmentRequired: true
      });
      return;
    }

    req.authUser = user;
    req.authClaims = claims;
    req.authToken = token;
    next();
  }

  function requireRole(allowedRoles: string[]) {
    return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
      const user = req.authUser;
      if (!user || !allowedRoles.includes(user.role)) {
        res.status(403).json({
          error: `Forbidden: Access requires one of [${allowedRoles.join(', ')}]. Current role: ${user?.role || 'Unauthenticated'}`
        });
        return;
      }
      next();
    };
  }

  // -------------------------------------------------------------
  // 1. Health & First-Run Single-Admin Setup
  // -------------------------------------------------------------
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'online',
      system: 'ALFADetect Forensic Audio Enclave Server',
      platform: 'ALFADetect',
      timestamp: new Date().toISOString(),
      version: '5.0.0-HARDENED',
      initialized: serverDb.hasSystemAdmin(),
      smtpConfigured: isSmtpConfigured(),
      geminiConfigured: Boolean(getGeminiClient())
    });
  });

  app.get('/api/setup/status', (_req, res) => {
    const admins = serverDb.getActiveSystemAdmins();
    res.json({
      initialized: admins.length > 0,
      needsAdminSetup: admins.length === 0,
      requiresInitToken: Boolean(process.env.ADMIN_INIT_TOKEN?.trim()),
      adminCount: admins.length,
      totalUsers: serverDb.getUsers().length,
      smtpConfigured: isSmtpConfigured()
    });
  });

  app.post('/api/setup/init-admin', strictAuthLimiter, (req, res) => {
    if (serverDb.hasSystemAdmin()) {
      writeAudit(req, req.body?.email || 'unknown', 'CONFIG', 'Blocked Duplicate Initial Admin Bootstrap Attempt', 'FAILED');
      res.status(409).json({
        error: 'System Security Administrator already exists. Initial bootstrap is permanently locked under single-administrator policy.'
      });
      return;
    }

    const requiredToken = process.env.ADMIN_INIT_TOKEN?.trim();
    if (requiredToken) {
      const supplied = String(req.body?.initToken || '');
      const bufA = Buffer.from(requiredToken, 'utf8');
      const bufB = Buffer.from(supplied, 'utf8');
      if (bufA.length !== bufB.length || !crypto.timingSafeEqual(bufA, bufB)) {
        writeAudit(req, req.body?.email || 'unknown', 'CONFIG', 'Invalid ADMIN_INIT_TOKEN During Bootstrap', 'FAILED');
        res.status(403).json({ error: 'Invalid or missing administrator initialization token.' });
        return;
      }
    }

    const { name, email, password, agency, department } = req.body || {};
    if (!name || !email || !password) {
      res.status(400).json({ error: 'Full Name, Email Address, and Password are required.' });
      return;
    }
    const normalizedEmail = String(email).trim().toLowerCase();
    if (!isValidEmailFormat(normalizedEmail)) {
      res.status(400).json({ error: 'Please provide a valid institutional email address.' });
      return;
    }
    const pwCheck = validatePasswordStrength(password, normalizedEmail);
    if (!pwCheck.valid) {
      res.status(400).json({ error: pwCheck.error });
      return;
    }
    if (serverDb.getUserByEmail(normalizedEmail)) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const salt = crypto.randomBytes(16).toString('hex');
    const passwordHash = hashPassword(password, salt);
    const nowStr = nowUtcString();
    const adminUser = serverDb.createUser({
      id: `USR-ADM-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
      name: String(name).trim(),
      email: normalizedEmail,
      passwordHash,
      salt,
      role: SYSTEM_ADMIN_ROLE,
      requestedRole: SYSTEM_ADMIN_ROLE,
      agency: agency ? String(agency).trim() : 'ALFADetect Security Operations',
      department: department ? String(department).trim() : 'Information Security & Governance',
      avatar: String(name).trim().charAt(0).toUpperCase() || 'A',
      status: 'active',
      casesCount: 0,
      securityClearance: 'System Security Administrator (Sole Authority)',
      createdAt: nowStr,
      reviewedAt: nowStr,
      reviewedBy: 'First-Run Enclave Bootstrap',
      tokenVersion: 1,
      twoFactorEnabled: false,
      twoFactorMethod: 'NONE',
      themePreference: 'light'
    });

    writeAudit(
      req,
      adminUser.email,
      'CONFIG',
      `Sole System Security Administrator Provisioned (${adminUser.email})`,
      'SUCCESS',
      'First-run bootstrap completed and locked',
      SYSTEM_ADMIN_ROLE
    );

    res.status(201).json({
      success: true,
      message: 'Sole System Security Administrator account initialized. Please sign in with your credentials.',
      user: sanitizeUser(adminUser)
    });
  });

  // -------------------------------------------------------------
  // 2. Authentication, Pending Approval, Lockout & 2FA TOTP
  // -------------------------------------------------------------
  function commitPendingUserAccount(params: {
    req: Request;
    name: string;
    email: string;
    passwordHash: string;
    salt: string;
    requestedRole: string;
    agency: string;
    department?: string;
    securityClearance?: string;
    certificationId?: string;
  }): StoredUserRecord {
    const userId = `USR-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
    const nowStr = nowUtcString();

    const newUser = serverDb.createUser({
      id: userId,
      name: params.name.trim(),
      email: params.email,
      passwordHash: params.passwordHash,
      salt: params.salt,
      role: params.requestedRole,
      requestedRole: params.requestedRole,
      agency: params.agency || 'National Forensics Institute',
      department: params.department ? String(params.department).trim() : undefined,
      avatar: params.name.trim().charAt(0).toUpperCase() || 'U',
      status: 'pending',
      casesCount: 0,
      securityClearance: params.securityClearance || 'Pending Admin Verification',
      certificationId: params.certificationId || `CFCE-${crypto.randomInt(1000, 9999)}`,
      createdAt: nowStr,
      tokenVersion: 1,
      twoFactorEnabled: false,
      twoFactorMethod: 'NONE',
      themePreference: 'light'
    });

    serverDb.addNotification({
      id: `NOTIF-REG-${Date.now()}`,
      title: 'New Account Pending Admin Approval',
      description: `${newUser.name} (${newUser.email}) requested access as ${newUser.requestedRole} from ${newUser.agency}. Review required in Administration.`,
      timestamp: 'Just now',
      read: false,
      severity: 'warning',
      targetRole: SYSTEM_ADMIN_ROLE
    });

    writeAudit(
      params.req,
      newUser.email,
      'CONFIG',
      `Registration Submitted (Pending Admin Approval): ${newUser.name} (${newUser.email})`,
      'SUCCESS',
      `Requested Role: ${newUser.requestedRole} | Agency: ${newUser.agency} | Status: pending`
    );

    return newUser;
  }

  app.post('/api/auth/register', strictAuthLimiter, async (req, res) => {
    const { name, email, password, role, agency, department, securityClearance, certificationId } = req.body || {};

    if (!name || !email || !password) {
      res.status(400).json({ error: 'Full Name, Email Address, and Password are required.' });
      return;
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    if (!isValidEmailFormat(normalizedEmail)) {
      res.status(400).json({ error: 'Invalid email format. Please provide a valid institutional email address.' });
      return;
    }

    const pwCheck = validatePasswordStrength(password, normalizedEmail);
    if (!pwCheck.valid) {
      res.status(400).json({ error: pwCheck.error });
      return;
    }

    const requestedRole = String(role || 'Forensic Examiner / Expert Witness').trim();
    if (requestedRole === SYSTEM_ADMIN_ROLE) {
      writeAudit(
        req,
        normalizedEmail,
        'CONFIG',
        'Blocked Public System Security Administrator Registration Attempt',
        'FAILED',
        `Privilege escalation attempt rejected for ${normalizedEmail}`
      );
      res.status(403).json({
        error:
          'Security Policy Violation: Public registration for System Security Administrator is prohibited. Strictly one System Security Administrator may exist.'
      });
      return;
    }

    if (!(NON_ADMIN_ROLES as readonly string[]).includes(requestedRole)) {
      res.status(400).json({ error: 'Invalid requested role selection.' });
      return;
    }

    const existingUser = serverDb.getUserByEmail(normalizedEmail);
    if (existingUser) {
      if (existingUser.status === 'pending') {
        res.status(409).json({
          error: 'An application for this email address is already pending Administrator approval.',
          accountStatus: 'pending'
        });
        return;
      }
      res.status(409).json({ error: 'An account with this email address already exists in the enclave registry.' });
      return;
    }

    const userSalt = crypto.randomBytes(16).toString('hex');
    const passwordHash = hashPassword(password, userSalt);

    // If SMTP is not configured, save directly with status: 'pending' (never bypass admin approval!)
    if (!isSmtpConfigured()) {
      const newUser = commitPendingUserAccount({
        req,
        name: String(name),
        email: normalizedEmail,
        passwordHash,
        salt: userSalt,
        requestedRole,
        agency: String(agency || 'National Forensics Institute'),
        department: department ? String(department) : undefined,
        securityClearance,
        certificationId
      });

      res.status(202).json({
        status: 'PENDING_ADMIN_APPROVAL',
        emailDeliveryConfigured: false,
        accountStatus: 'pending',
        message: 'Account created. Waiting for administrator approval.',
        user: sanitizeUser(newUser)
      });
      return;
    }

    // SMTP IS configured -> send real verification OTP via nodemailer before creating pending user
    const otpCode = crypto.randomInt(100000, 999999).toString();
    const otpHash = sha256String(otpCode + userSalt);
    const dispatch = await sendSmtpEmail({
      to: normalizedEmail,
      subject: 'ALFADetect — Verify Your Registration Email',
      text: `Your ALFADetect registration verification code is: ${otpCode}. This code expires in 10 minutes. Note: After email verification, your account still requires System Security Administrator approval before sign-in.`,
      html: `<p>Your ALFADetect registration verification code is: <strong>${otpCode}</strong>.</p><p>This code expires in 10 minutes. Note: After verifying your email, your account still requires <strong>System Security Administrator approval</strong> before access is granted.</p>`
    });

    if (!dispatch.sent) {
      writeAudit(req, normalizedEmail, 'CONFIG', 'Registration Email OTP Dispatch Failed', 'FAILED', dispatch.error);
      res.status(503).json({
        error: `Email delivery unavailable (${dispatch.error || 'SMTP send failed'}). Cannot send verification OTP.`,
        emailDeliveryConfigured: true
      });
      return;
    }

    const nowTs = Date.now();
    serverDb.savePendingRegistration({
      email: normalizedEmail,
      name: String(name).trim(),
      agency: String(agency || 'National Forensics Institute').trim(),
      department: department ? String(department).trim() : undefined,
      role: requestedRole,
      certificationId: certificationId ? String(certificationId).trim() : undefined,
      passwordHash,
      salt: userSalt,
      otpHash,
      expiresAt: nowTs + 10 * 60 * 1000,
      createdAt: nowTs,
      failedAttempts: 0,
      resendCount: 0,
      lastResendAt: nowTs
    });

    writeAudit(
      req,
      normalizedEmail,
      'LOGIN',
      `Registration Email Verification OTP Dispatched via SMTP: ${normalizedEmail}`,
      'SUCCESS',
      `Requested Role: ${requestedRole}`
    );

    res.json({
      status: 'REGISTRATION_OTP_SENT',
      email: normalizedEmail,
      name: String(name).trim(),
      emailDeliveryConfigured: true,
      message: 'A 6-digit verification code has been emailed to your address via SMTP.'
    });
  });

  app.post('/api/auth/request-otp', strictAuthLimiter, async (req, res) => {
    const { name, email, password, role, agency, department, certificationId } = req.body || {};
    if (!isSmtpConfigured()) {
      res.status(503).json({
        error: 'Email OTP delivery is unavailable: SMTP server is not configured (SMTP_HOST, SMTP_USER, SMTP_PASS required).',
        emailDeliveryConfigured: false
      });
      return;
    }
    // Delegate cleanly to /api/auth/register which now performs honest SMTP OTP when configured
    if (!name || !email || !password) {
      res.status(400).json({ error: 'Name, email, and password are required.' });
      return;
    }
    const normalizedEmail = String(email).trim().toLowerCase();
    if (!isValidEmailFormat(normalizedEmail)) {
      res.status(400).json({ error: 'Invalid email format.' });
      return;
    }
    const pwCheck = validatePasswordStrength(password, normalizedEmail);
    if (!pwCheck.valid) {
      res.status(400).json({ error: pwCheck.error });
      return;
    }
    const requestedRole = String(role || 'Forensic Examiner / Expert Witness').trim();
    if (requestedRole === SYSTEM_ADMIN_ROLE || !(NON_ADMIN_ROLES as readonly string[]).includes(requestedRole)) {
      res.status(403).json({ error: 'Invalid or restricted role requested.' });
      return;
    }
    if (serverDb.getUserByEmail(normalizedEmail)) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }
    const userSalt = crypto.randomBytes(16).toString('hex');
    const otpCode = crypto.randomInt(100000, 999999).toString();
    const dispatch = await sendSmtpEmail({
      to: normalizedEmail,
      subject: 'ALFADetect — Email Verification Code',
      text: `Your verification code is ${otpCode}. Valid for 10 minutes.`,
      html: `<p>Your ALFADetect verification code is <strong>${otpCode}</strong>. Valid for 10 minutes.</p>`
    });
    if (!dispatch.sent) {
      res.status(503).json({ error: `SMTP delivery failed: ${dispatch.error}`, emailDeliveryConfigured: true });
      return;
    }
    const nowTs = Date.now();
    serverDb.savePendingRegistration({
      email: normalizedEmail,
      name: String(name).trim(),
      agency: String(agency || 'National Forensics Institute').trim(),
      department: department ? String(department).trim() : undefined,
      role: requestedRole,
      certificationId: certificationId ? String(certificationId).trim() : undefined,
      passwordHash: hashPassword(password, userSalt),
      salt: userSalt,
      otpHash: sha256String(otpCode + userSalt),
      expiresAt: nowTs + 10 * 60 * 1000,
      createdAt: nowTs,
      failedAttempts: 0,
      resendCount: 0,
      lastResendAt: nowTs
    });
    res.json({ status: 'REGISTRATION_OTP_SENT', email: normalizedEmail, emailDeliveryConfigured: true });
  });

  function handleVerifyRegistrationOtp(req: Request, res: Response) {
    const { email, otp } = req.body || {};
    if (!email || !otp) {
      res.status(400).json({ error: 'Email and OTP verification code are required.' });
      return;
    }
    const normalizedEmail = String(email).trim().toLowerCase();
    const pending = serverDb.getPendingRegistration(normalizedEmail);
    if (!pending) {
      res.status(400).json({ error: 'No pending email verification found for this address.' });
      return;
    }
    if (Date.now() > pending.expiresAt) {
      serverDb.deletePendingRegistration(normalizedEmail);
      res.status(400).json({ error: 'Verification code expired. Please register again.' });
      return;
    }
    const candidateHash = sha256String(String(otp).trim() + pending.salt);
    if (candidateHash !== pending.otpHash) {
      const nextAttempts = (pending.failedAttempts || 0) + 1;
      if (nextAttempts >= 5) {
        serverDb.deletePendingRegistration(normalizedEmail);
        writeAudit(req, normalizedEmail, 'LOGIN', 'Registration Email OTP Revoked After 5 Failed Attempts', 'FAILED');
        res.status(400).json({
          error: 'Maximum OTP verification attempts (5) exceeded. Registration invalidated; please apply again.'
        });
        return;
      }
      serverDb.savePendingRegistration({ ...pending, failedAttempts: nextAttempts });
      writeAudit(req, normalizedEmail, 'LOGIN', 'Registration Email OTP Failed', 'FAILED', `Attempt ${nextAttempts}/5`);
      res.status(400).json({ error: 'Incorrect verification code.' });
      return;
    }

    const newUser = commitPendingUserAccount({
      req,
      name: pending.name,
      email: pending.email,
      passwordHash: pending.passwordHash,
      salt: pending.salt,
      requestedRole: pending.role,
      agency: pending.agency,
      department: pending.department,
      certificationId: pending.certificationId
    });
    serverDb.deletePendingRegistration(normalizedEmail);

    res.status(202).json({
      status: 'PENDING_ADMIN_APPROVAL',
      accountStatus: 'pending',
      message: 'Account created. Waiting for administrator approval.',
      user: sanitizeUser(newUser)
    });
  }

  app.post('/api/auth/verify-registration', strictAuthLimiter, handleVerifyRegistrationOtp);
  app.post('/api/auth/verify-otp-and-register', strictAuthLimiter, handleVerifyRegistrationOtp);

  app.post('/api/auth/resend-otp', strictAuthLimiter, async (req, res) => {
    const { email } = req.body || {};
    if (!email) {
      res.status(400).json({ error: 'Email is required.' });
      return;
    }
    if (!isSmtpConfigured()) {
      res.status(503).json({
        error: 'Email OTP delivery is unavailable: SMTP server is not configured.',
        emailDeliveryConfigured: false
      });
      return;
    }
    const normalizedEmail = String(email).trim().toLowerCase();
    const pending = serverDb.getPendingRegistration(normalizedEmail);
    if (!pending) {
      res.status(404).json({ error: 'No pending registration found for this email address.' });
      return;
    }
    if (pending.lastResendAt && Date.now() - pending.lastResendAt < 60 * 1000) {
      res.status(429).json({ error: 'Please wait 60 seconds before requesting another OTP.' });
      return;
    }
    if ((pending.resendCount || 0) >= 5) {
      res.status(429).json({ error: 'Maximum OTP resend limit (5) reached for this pending registration.' });
      return;
    }
    const otpCode = crypto.randomInt(100000, 999999).toString();
    const dispatch = await sendSmtpEmail({
      to: normalizedEmail,
      subject: 'ALFADetect — Resent Verification Code',
      text: `Your ALFADetect verification code is ${otpCode}. Valid for 10 minutes.`,
      html: `<p>Your ALFADetect verification code is <strong>${otpCode}</strong>. Valid for 10 minutes.</p>`
    });
    if (!dispatch.sent) {
      res.status(503).json({ error: `SMTP delivery failed: ${dispatch.error}` });
      return;
    }
    serverDb.savePendingRegistration({
      ...pending,
      otpHash: sha256String(otpCode + pending.salt),
      expiresAt: Date.now() + 10 * 60 * 1000,
      resendCount: (pending.resendCount || 0) + 1,
      lastResendAt: Date.now()
    });
    res.json({ status: 'OTP_RESENT', message: 'Verification code dispatched via SMTP.' });
  });

  app.post('/api/auth/pending-status', strictAuthLimiter, (req, res) => {
    const { email, password } = req.body || {};
    const normalizedEmail = String(email || '').trim().toLowerCase();
    if (!normalizedEmail || !isValidEmailFormat(normalizedEmail) || !password) {
      res.status(400).json({ error: 'Valid email address and password are required.' });
      return;
    }
    const user = serverDb.getUserByEmail(normalizedEmail);
    const validPassword = user
      ? verifyPassword(String(password), user.salt, user.passwordHash)
      : verifyPassword(String(password), DUMMY_PASSWORD_SALT, DUMMY_PASSWORD_HASH);
    if (!user || !validPassword) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }
    res.json({
      status: user.status,
      requestedRole: user.requestedRole || user.role
    });
  });

  app.post('/api/auth/login', strictAuthLimiter, (req, res) => {
    const { email, password, loginMode } = req.body || {};
    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }
    if (loginMode !== undefined && loginMode !== 'user' && loginMode !== 'admin') {
      res.status(400).json({ error: 'Invalid loginMode specified.' });
      return;
    }
    const normalizedEmail = String(email).trim().toLowerCase();
    const user = serverDb.getUserByEmail(normalizedEmail);

    // Always run scrypt verification before checking account status or loginMode to prevent pre-auth enumeration (A7)
    const validPassword = user
      ? verifyPassword(String(password), user.salt, user.passwordHash)
      : verifyPassword(String(password), DUMMY_PASSWORD_SALT, DUMMY_PASSWORD_HASH);

    if (!user || !validPassword) {
      if (user) {
        const nextCount = (user.failedLoginCount || 0) + 1;
        const lockedUntil = nextCount >= 5 ? Date.now() + 15 * 60 * 1000 : undefined;
        serverDb.updateUser(user.id, {
          failedLoginCount: nextCount,
          lockedUntil
        });
        writeAudit(
          req,
          user.email,
          'LOGIN',
          lockedUntil ? 'Account Locked After 5 Failed Login Attempts' : 'Password Authentication Failed',
          'FAILED',
          `Failed attempt count: ${nextCount}`,
          user.role
        );
        if (lockedUntil) {
          serverDb.addNotification({
            id: `NOTIF-LOCK-${Date.now()}`,
            title: 'Security Alert: Repeated Failed Logins',
            description: `Account ${user.email} triggered temporary 15-minute lockout after 5 consecutive failed sign-in attempts.`,
            timestamp: 'Just now',
            read: false,
            severity: 'critical',
            targetRole: SYSTEM_ADMIN_ROLE
          });
        }
      } else {
        writeAudit(req, normalizedEmail, 'LOGIN', 'Authentication Attempt (Invalid Credentials)', 'FAILED');
      }
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    if (user.lockedUntil && Date.now() < user.lockedUntil) {
      const waitMin = Math.ceil((user.lockedUntil - Date.now()) / 60000);
      writeAudit(req, user.email, 'LOGIN', 'Blocked Login Attempt — Temporary Brute-Force Lockout', 'FAILED');
      res.status(423).json({
        error: `Account temporarily locked due to repeated failed sign-in attempts. Retry in ${waitMin} minute(s) or contact Administration.`
      });
      return;
    }

    if (user.status === 'pending') {
      writeAudit(req, user.email, 'LOGIN', 'Blocked Login Attempt — Account Pending Admin Approval', 'FAILED');
      res.status(403).json({
        error: 'Account Pending Approval: Your registration is awaiting review and role assignment by the System Security Administrator.',
        code: 'PENDING_APPROVAL',
        accountStatus: 'pending',
        requestedRole: user.requestedRole || user.role
      });
      return;
    }

    if (user.status === 'rejected') {
      writeAudit(req, user.email, 'LOGIN', 'Blocked Login Attempt — Account Rejected', 'FAILED', user.rejectionReason);
      res.status(403).json({
        error: `Account Rejected: ${user.rejectionReason || 'Your registration request was declined by the System Security Administrator.'}`,
        code: 'ACCOUNT_REJECTED',
        accountStatus: 'rejected',
        rejectionReason: user.rejectionReason
      });
      return;
    }

    if (user.status !== 'active') {
      writeAudit(req, user.email, 'LOGIN', `Blocked Login Attempt — Account Status: ${user.status}`, 'FAILED');
      res.status(403).json({
        error: `Account ${user.status === 'suspended' ? 'Suspended' : 'Inactive'}: Access to the enclave has been disabled by the System Security Administrator.`,
        code: 'ACCOUNT_SUSPENDED',
        accountStatus: user.status
      });
      return;
    }

    // Role separation on Sign-In vs Administrator Sign-In (checked ONLY after password & status verified)
    if (loginMode === 'admin' && user.role !== SYSTEM_ADMIN_ROLE) {
      writeAudit(
        req,
        user.email,
        'LOGIN',
        'Blocked Non-Administrator Account in Administrator Sign-In Mode',
        'FAILED',
        `Role: ${user.role}`,
        user.role
      );
      res.status(403).json({
        error: 'This sign-in mode is restricted to the System Security Administrator. Use Standard User Sign-In.',
        code: 'ADMIN_MODE_REQUIRED_NON_ADMIN'
      });
      return;
    }
    if (loginMode === 'user' && user.role === SYSTEM_ADMIN_ROLE) {
      writeAudit(
        req,
        user.email,
        'LOGIN',
        'Blocked System Security Administrator in Standard User Sign-In Mode',
        'FAILED',
        undefined,
        user.role
      );
      res.status(403).json({
        error: 'System Security Administrator accounts must sign in using Administrator Sign-In mode.',
        code: 'USE_ADMIN_SIGN_IN'
      });
      return;
    }

    if (user.failedLoginCount || user.lockedUntil) {
      serverDb.updateUser(user.id, { failedLoginCount: 0, lockedUntil: undefined });
    }

    // If user has RFC 6238 TOTP 2FA enabled, issue a 2fa_challenge-typed JWT
    if (user.twoFactorEnabled) {
      const challenge = issueJwtToken({
        userId: user.id,
        email: user.email,
        role: '2FA_CHALLENGE',
        name: user.name,
        tokenVersion: user.tokenVersion,
        typ: '2fa_challenge',
        expiresInSeconds: 5 * 60
      });
      if (loginMode === 'user' || loginMode === 'admin') {
        pending2faLoginModeByJti.set(challenge.jti, loginMode);
      }
      writeAudit(req, user.email, 'LOGIN', 'Password Verified — TOTP 2FA Challenge Issued', 'SUCCESS', undefined, user.role);
      res.json({
        status: 'TWO_FACTOR_REQUIRED',
        requiresTwoFactor: true,
        challengeToken: challenge.token,
        twoFactorMethod: 'TOTP',
        email: user.email,
        name: user.name,
        message: 'Enter your 6-digit Authenticator App TOTP code or a single-use recovery code.'
      });
      return;
    }

    const sysConfig = serverDb.getSystemConfig();
    const sessionPolicy = getSessionPolicy();
    const ttlSeconds = sessionPolicy.sessionTtlMinutes * 60;
    const { token } = issueJwtToken({
      userId: user.id,
      email: user.email,
      role: user.role,
      name: user.name,
      tokenVersion: user.tokenVersion,
      typ: 'session',
      expiresInSeconds: ttlSeconds
    });

    const updatedUser = serverDb.updateUser(user.id, { lastLoginAt: nowUtcString() }) || user;
    setSessionCookie(req, res, token, ttlSeconds);

    writeAudit(req, updatedUser.email, 'LOGIN', 'Enclave JWT Session Established', 'SUCCESS', `Role: ${updatedUser.role}`, updatedUser.role);

    res.json({
      status: 'AUTHENTICATED',
      sessionToken: token,
      twoFactorEnrollmentRequired: Boolean(sysConfig.enforceTwoFactor && !updatedUser.twoFactorEnabled),
      mustChangePassword: Boolean(updatedUser.mustChangePassword),
      sessionPolicy,
      user: sanitizeUser(updatedUser)
    });
  });

  app.post('/api/auth/verify-2fa', strictAuthLimiter, (req, res) => {
    const { challengeToken, code, loginMode } = req.body || {};
    if (!challengeToken || !code) {
      res.status(400).json({ error: 'Challenge token and 6-digit TOTP or recovery code are required.' });
      return;
    }
    const claims = verifyJwtToken(String(challengeToken));
    if (
      !claims ||
      claims.typ !== '2fa_challenge' ||
      claims.role !== '2FA_CHALLENGE' ||
      serverDb.isTokenRevoked(claims.jti)
    ) {
      res.status(401).json({ error: 'Invalid or expired 2FA challenge. Please sign in again.' });
      return;
    }

    const user = serverDb.getUserById(claims.sub);
    if (!user || user.status !== 'active' || user.tokenVersion !== claims.tv) {
      res.status(403).json({ error: 'User account unavailable or session invalidated.' });
      return;
    }

    const enforcedMode = (loginMode === 'user' || loginMode === 'admin' ? loginMode : undefined) || pending2faLoginModeByJti.get(claims.jti);
    if (enforcedMode === 'admin' && user.role !== SYSTEM_ADMIN_ROLE) {
      res.status(403).json({ error: 'This sign-in mode is restricted to the System Security Administrator.', code: 'ADMIN_MODE_REQUIRED_NON_ADMIN' });
      return;
    }
    if (enforcedMode === 'user' && user.role === SYSTEM_ADMIN_ROLE) {
      res.status(403).json({ error: 'System Security Administrator accounts must sign in using Administrator Sign-In mode.', code: 'USE_ADMIN_SIGN_IN' });
      return;
    }

    const trimmedCode = String(code).trim();
    const totpCheck = verifyTotpWithReplayGuard(user, trimmedCode);
    let verified = totpCheck.ok;

    if (!verified && Array.isArray(user.recoveryCodeHashes) && user.recoveryCodeHashes.length > 0) {
      const candHash = hashRecoveryCode(trimmedCode);
      const matchIdx = user.recoveryCodeHashes.indexOf(candHash);
      if (matchIdx >= 0) {
        const updatedCodes = [...user.recoveryCodeHashes];
        updatedCodes.splice(matchIdx, 1);
        serverDb.updateUser(user.id, { recoveryCodeHashes: updatedCodes });
        verified = true;
      }
    }

    if (!verified) {
      const fails = (failed2faAttemptsByJti.get(claims.jti) || 0) + 1;
      if (fails >= 5) {
        failed2faAttemptsByJti.delete(claims.jti);
        pending2faLoginModeByJti.delete(claims.jti);
        serverDb.revokeToken(claims.jti, (claims.exp || 0) * 1000);
        writeAudit(req, user.email, 'LOGIN', 'TOTP 2FA Challenge Revoked After 5 Failed Attempts', 'FAILED', undefined, user.role);
        res.status(401).json({ error: '2FA challenge revoked after 5 failed attempts. Please sign in again.' });
        return;
      }
      failed2faAttemptsByJti.set(claims.jti, fails);
      writeAudit(req, user.email, 'LOGIN', 'TOTP 2FA Verification Failed', 'FAILED', `Attempt ${fails}/5`, user.role);
      res.status(401).json({ error: totpCheck.error || 'Invalid 2FA verification code.' });
      return;
    }

    failed2faAttemptsByJti.delete(claims.jti);
    pending2faLoginModeByJti.delete(claims.jti);
    serverDb.revokeToken(claims.jti, (claims.exp || 0) * 1000);
    const refreshedUser = serverDb.updateUser(user.id, { lastLoginAt: nowUtcString() }) || user;
    const sysConfig = serverDb.getSystemConfig();
    const sessionPolicy = getSessionPolicy();
    const ttlSeconds = sessionPolicy.sessionTtlMinutes * 60;
    const { token } = issueJwtToken({
      userId: refreshedUser.id,
      email: refreshedUser.email,
      role: refreshedUser.role,
      name: refreshedUser.name,
      tokenVersion: refreshedUser.tokenVersion,
      typ: 'session',
      expiresInSeconds: ttlSeconds
    });

    setSessionCookie(req, res, token, ttlSeconds);
    writeAudit(req, refreshedUser.email, 'LOGIN', 'TOTP Multi-Factor Authentication Succeeded', 'SUCCESS', `Role: ${refreshedUser.role}`, refreshedUser.role);

    res.json({
      status: 'AUTHENTICATED',
      sessionToken: token,
      twoFactorEnrollmentRequired: Boolean(sysConfig.enforceTwoFactor && !refreshedUser.twoFactorEnabled),
      mustChangePassword: Boolean(refreshedUser.mustChangePassword),
      sessionPolicy,
      user: sanitizeUser(refreshedUser)
    });
  });

  app.post('/api/auth/forgot-password', forgotResetLimiter, async (req, res) => {
    const emailRaw = String(req.body?.email || '').trim().toLowerCase();
    if (!emailRaw || !isValidEmailFormat(emailRaw)) {
      res.status(400).json({ error: 'Please provide a valid institutional email address.' });
      return;
    }

    if (!isSmtpConfigured()) {
      writeAudit(req, emailRaw, 'CONFIG', 'Password Reset Requested — SMTP Unconfigured', 'FAILED');
      res.status(503).json({
        smtpConfigured: false,
        error:
          'Password reset email delivery is unavailable because SMTP is not configured on this server. Contact your System Security Administrator to reset your password.'
      });
      return;
    }

    const uniformResponse = {
      status: 'RESET_REQUEST_ACCEPTED',
      smtpConfigured: true,
      message: 'If an active account matches that address, password reset instructions have been sent via email.'
    };

    const user = serverDb.getUserByEmail(emailRaw);
    if (!user || user.status !== 'active') {
      writeAudit(req, emailRaw, 'LOGIN', 'Forgot Password Request Processed (Non-Enumerating)', 'SUCCESS');
      res.json(uniformResponse);
      return;
    }

    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = sha256String(rawToken);
    const expiresAt = Date.now() + 15 * 60 * 1000;

    serverDb.createPasswordResetToken({
      id: `RST-${crypto.randomBytes(4).toString('hex').toUpperCase()}`,
      userId: user.id,
      email: user.email,
      tokenHash,
      expiresAt,
      createdAt: Date.now()
    });

    const origin =
      req.headers.origin && typeof req.headers.origin === 'string'
        ? req.headers.origin
        : `${req.protocol}://${req.get('host') || 'localhost:3000'}`;
    const resetUrl = `${origin}/?screen=signin&resetToken=${encodeURIComponent(rawToken)}`;

    const dispatch = await sendSmtpEmail({
      to: user.email,
      subject: 'ALFADetect — Password Reset Request',
      text: `A password reset was requested for your ALFADetect account (${user.email}).\n\nSingle-use reset token (valid for 15 minutes): ${rawToken}\nReset link: ${resetUrl}\n\nIf you did not request this, ignore this message.`,
      html: `<p>A password reset was requested for your ALFADetect account (<strong>${user.email}</strong>).</p><p><strong>Reset Token (valid 15 minutes):</strong> <code>${rawToken}</code></p><p><a href="${resetUrl}">Open ALFADetect Password Reset</a></p><p>If you did not initiate this request, you may safely ignore this email.</p>`
    });

    writeAudit(
      req,
      user.email,
      'CONFIG',
      dispatch.sent ? 'Password Reset Token Dispatched via SMTP' : 'Password Reset SMTP Dispatch Failed',
      dispatch.sent ? 'SUCCESS' : 'FAILED',
      dispatch.error,
      user.role
    );

    res.json(uniformResponse);
  });

  app.post('/api/auth/reset-password', forgotResetLimiter, (req, res) => {
    const { token, newPassword, totpCode } = req.body || {};
    const trimmedToken = String(token || '').trim();
    if (!trimmedToken || !newPassword) {
      res.status(400).json({ error: 'Reset token and new password are required.' });
      return;
    }

    const tokenHash = sha256String(trimmedToken);
    const record = serverDb.getPasswordResetTokenByHash(tokenHash);
    if (!record || Date.now() > record.expiresAt) {
      if (record) {
        serverDb.consumePasswordResetTokensForUser(record.userId, record.email);
      }
      writeAudit(req, record?.email || 'unknown', 'CONFIG', 'Password Reset Denied — Invalid or Expired Token', 'FAILED');
      res.status(400).json({ error: 'Invalid or expired password reset token.' });
      return;
    }

    const user = serverDb.getUserById(record.userId);
    if (!user || user.status !== 'active') {
      serverDb.consumePasswordResetTokensForUser(record.userId, record.email);
      res.status(400).json({ error: 'Invalid or expired password reset token.' });
      return;
    }

    const pwCheck = validatePasswordStrength(String(newPassword), user.email);
    if (!pwCheck.valid) {
      res.status(400).json({ error: pwCheck.error });
      return;
    }

    if (user.twoFactorEnabled) {
      const trimmedCode = String(totpCode || '').trim();
      const totpCheck = verifyTotpWithReplayGuard(user, trimmedCode);
      let twoFactorOk = totpCheck.ok;

      if (!twoFactorOk && Array.isArray(user.recoveryCodeHashes) && user.recoveryCodeHashes.length > 0 && trimmedCode) {
        const candHash = hashRecoveryCode(trimmedCode);
        const matchIdx = user.recoveryCodeHashes.indexOf(candHash);
        if (matchIdx >= 0) {
          const updatedCodes = [...user.recoveryCodeHashes];
          updatedCodes.splice(matchIdx, 1);
          serverDb.updateUser(user.id, { recoveryCodeHashes: updatedCodes });
          twoFactorOk = true;
        }
      }

      if (!twoFactorOk) {
        writeAudit(req, user.email, 'CONFIG', 'Password Reset Denied — 2FA Verification Failed', 'FAILED', totpCheck.error, user.role);
        res.status(401).json({
          error: totpCheck.error || 'Valid 6-digit authenticator TOTP or recovery code is required to complete password reset.',
          requiresTwoFactor: true
        });
        return;
      }
    }

    const newSalt = crypto.randomBytes(16).toString('hex');
    const newHash = hashPassword(String(newPassword), newSalt);
    serverDb.updateUser(user.id, {
      salt: newSalt,
      passwordHash: newHash,
      tokenVersion: (user.tokenVersion || 1) + 1,
      failedLoginCount: 0,
      lockedUntil: undefined,
      mustChangePassword: false
    });
    serverDb.consumePasswordResetTokensForUser(user.id, user.email);

    serverDb.addNotification({
      id: `NOTIF-PWRST-${Date.now()}`,
      title: 'Password Reset Completed',
      description: `Your password was reset on ${nowUtcString()}. All previous sessions have been terminated.`,
      timestamp: 'Just now',
      read: false,
      severity: 'info',
      targetUserId: user.id
    });

    writeAudit(req, user.email, 'CONFIG', 'Password Reset Completed via Recovery Token — Prior Sessions Invalidated', 'SUCCESS', undefined, user.role);

    res.json({
      success: true,
      message: 'Password reset succeeded. All prior sessions have been invalidated; sign in with your new password.'
    });
  });

  app.get('/api/auth/me', requireAuth, (req: AuthenticatedRequest, res) => {
    const sysConfig = serverDb.getSystemConfig();
    const user = req.authUser!;
    res.json({
      authenticated: true,
      twoFactorEnrollmentRequired: Boolean(sysConfig.enforceTwoFactor && !user.twoFactorEnabled),
      mustChangePassword: Boolean(user.mustChangePassword),
      sessionPolicy: getSessionPolicy(),
      user: sanitizeUser(user)
    });
  });

  app.post('/api/auth/reauth', strictAuthLimiter, requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const { password, totpCode } = req.body || {};
    if (!password) {
      res.status(400).json({ error: 'Password is required for credential re-authentication.' });
      return;
    }
    if (!verifyPassword(String(password), user.salt, user.passwordHash)) {
      const nextCount = (user.failedLoginCount || 0) + 1;
      const isLocking = nextCount >= 5;
      const lockedUntil = isLocking ? Date.now() + 15 * 60 * 1000 : undefined;
      serverDb.updateUser(user.id, {
        failedLoginCount: nextCount,
        lockedUntil,
        ...(isLocking ? { tokenVersion: (user.tokenVersion || 1) + 1 } : {})
      });
      writeAudit(
        req,
        user.email,
        'LOGIN',
        isLocking ? 'Account Locked After 5 Failed Re-authentication Attempts' : 'Credential Re-authentication Failed',
        'FAILED',
        `Incorrect password (attempt ${nextCount}/5)`,
        user.role
      );
      if (isLocking) {
        if (req.authClaims?.jti) {
          const expMs = req.authClaims.exp ? req.authClaims.exp * 1000 : Date.now() + 8 * 60 * 60 * 1000;
          serverDb.revokeToken(req.authClaims.jti, expMs);
        }
        clearSessionCookie(req, res);
        serverDb.addNotification({
          id: `NOTIF-REAUTHLOCK-${Date.now()}`,
          title: 'Security Alert: Session Revoked After Re-Auth Failures',
          description: `Account ${user.email} triggered temporary 15-minute lockout after 5 consecutive failed unlock/re-authentication attempts.`,
          timestamp: 'Just now',
          read: false,
          severity: 'critical',
          targetRole: SYSTEM_ADMIN_ROLE
        });
        res.status(423).json({
          lockedOut: true,
          error: 'Account temporarily locked for 15 minutes after 5 consecutive failed re-authentication attempts. Active session revoked.'
        });
        return;
      }
      res.status(401).json({ error: 'Authentication failed: Password incorrect.' });
      return;
    }
    if (user.twoFactorEnabled) {
      const totpCheck = verifyTotpWithReplayGuard(user, String(totpCode || ''));
      if (!totpCheck.ok) {
        writeAudit(req, user.email, 'LOGIN', 'Credential Re-authentication Failed (2FA)', 'FAILED', totpCheck.error, user.role);
        res.status(401).json({ error: totpCheck.error || 'Valid 6-digit TOTP verification code is required.' });
        return;
      }
    }
    if (user.failedLoginCount || user.lockedUntil) {
      serverDb.updateUser(user.id, { failedLoginCount: 0, lockedUntil: undefined });
    }
    writeAudit(req, user.email, 'LOGIN', 'Credential Re-authentication Succeeded', 'SUCCESS', undefined, user.role);
    res.json({ unlocked: true, message: 'Credentials verified successfully.' });
  });

  app.post('/api/auth/logout', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const claims = req.authClaims!;
    const expMs = claims.exp ? claims.exp * 1000 : Date.now() + 8 * 60 * 60 * 1000;
    serverDb.revokeToken(claims.jti, expMs);
    clearSessionCookie(req, res);
    writeAudit(req, user.email, 'LOGIN', 'Operator Session Explicitly Terminated (JWT Revoked)', 'SUCCESS', undefined, user.role);
    res.json({ success: true, message: 'Session token permanently invalidated.' });
  });

  // -------------------------------------------------------------
  // 2B. Administration & Single-Admin Governance (Admin Only)
  // -------------------------------------------------------------
  app.get('/api/users', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), (req, res) => {
    const search = String(req.query.search || '').trim().toLowerCase();
    const roleFilter = String(req.query.role || '').trim();
    const statusFilter = String(req.query.status || '').trim().toLowerCase();

    let list = serverDb.getUsers();
    if (search) {
      list = list.filter(
        (u) =>
          u.name.toLowerCase().includes(search) ||
          u.email.toLowerCase().includes(search) ||
          (u.agency || '').toLowerCase().includes(search) ||
          u.id.toLowerCase().includes(search)
      );
    }
    if (roleFilter && roleFilter !== 'ALL') {
      list = list.filter((u) => u.role === roleFilter);
    }
    if (statusFilter && statusFilter !== 'all') {
      list = list.filter((u) => u.status.toLowerCase() === statusFilter);
    }
    res.json(list.map(sanitizeUser));
  });

  app.get('/api/admin/pending-users', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), (_req, res) => {
    const pending = serverDb
      .getUsers()
      .filter((u) => u.status === 'pending' || u.status === 'rejected')
      .map(sanitizeUser);
    res.json(pending);
  });

  app.get('/api/admin/roles', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), (_req, res) => {
    const users = serverDb.getUsers();
    const summary = (ALL_ROLES as readonly string[]).map((role) => ({
      role,
      activeCount: users.filter((u) => u.role === role && u.status === 'active').length,
      pendingCount: users.filter((u) => u.role === role && u.status === 'pending').length,
      maxAllowed: role === SYSTEM_ADMIN_ROLE ? 1 : null
    }));
    res.json(summary);
  });

  app.post('/api/admin/users', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), (req: AuthenticatedRequest, res) => {
    const admin = req.authUser!;
    const { name, email, password, role, agency, department, certificationId, securityClearance } = req.body || {};

    if (!name || !email || !password || !role) {
      res.status(400).json({ error: 'Name, email, password, and role are required.' });
      return;
    }

    if (role === SYSTEM_ADMIN_ROLE) {
      writeAudit(req, admin.email, 'CONFIG', 'Blocked Add Second System Security Administrator', 'FAILED', undefined, admin.role);
      res.status(403).json({
        error:
          'Single-Administrator Policy Violation: Only ONE active System Security Administrator may exist. Use the audited Administrator Transfer workflow to hand over administrative authority.'
      });
      return;
    }

    if (!(NON_ADMIN_ROLES as readonly string[]).includes(role)) {
      res.status(400).json({ error: 'Invalid non-administrator role specified.' });
      return;
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    if (!isValidEmailFormat(normalizedEmail)) {
      res.status(400).json({ error: 'Invalid email format.' });
      return;
    }
    const pwCheck = validatePasswordStrength(password, normalizedEmail);
    if (!pwCheck.valid) {
      res.status(400).json({ error: pwCheck.error });
      return;
    }
    if (serverDb.getUserByEmail(normalizedEmail)) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const salt = crypto.randomBytes(16).toString('hex');
    const nowStr = nowUtcString();
    const newUser = serverDb.createUser({
      id: `USR-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
      name: String(name).trim(),
      email: normalizedEmail,
      passwordHash: hashPassword(password, salt),
      salt,
      role,
      requestedRole: role,
      agency: agency ? String(agency).trim() : 'Federal Digital Forensics Division',
      department: department ? String(department).trim() : undefined,
      avatar: String(name).trim().charAt(0).toUpperCase() || 'U',
      status: 'active',
      casesCount: 0,
      securityClearance: securityClearance || role,
      certificationId: certificationId || `CFCE-${crypto.randomInt(1000, 9999)}`,
      reviewedBy: admin.email,
      reviewedAt: nowStr,
      createdAt: nowStr,
      tokenVersion: 1,
      twoFactorEnabled: false,
      twoFactorMethod: 'NONE',
      mustChangePassword: true,
      themePreference: 'light'
    });

    writeAudit(
      req,
      admin.email,
      'CONFIG',
      `Administrator Provisioned Active Account: ${newUser.email}`,
      'SUCCESS',
      `Assigned Role: ${newUser.role} | Agency: ${newUser.agency}`,
      admin.role
    );

    res.status(201).json({ success: true, user: sanitizeUser(newUser) });
  });

  app.post('/api/admin/users/:id/approve', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), async (req: AuthenticatedRequest, res) => {
    const admin = req.authUser!;
    const user = serverDb.getUserById(req.params.id);
    if (!user) {
      res.status(404).json({ error: 'User registration record not found.' });
      return;
    }

    const finalRole = req.body?.assignedRole || user.requestedRole || user.role;
    if (finalRole === SYSTEM_ADMIN_ROLE) {
      res.status(403).json({
        error: 'Single-Administrator Policy: Cannot approve an account into System Security Administrator role.'
      });
      return;
    }
    if (!(NON_ADMIN_ROLES as readonly string[]).includes(finalRole)) {
      res.status(400).json({ error: 'Invalid role assignment specified.' });
      return;
    }

    const nowStr = nowUtcString();
    const updated = serverDb.updateUser(user.id, {
      status: 'active',
      role: finalRole,
      securityClearance: finalRole,
      rejectionReason: undefined,
      reviewedBy: admin.email,
      reviewedAt: nowStr
    });

    serverDb.addNotification({
      id: `NOTIF-APP-${Date.now()}`,
      title: 'Registration Approved',
      description: `Account ${user.name} (${user.email}) approved as '${finalRole}' by ${admin.email}.`,
      timestamp: 'Just now',
      read: false,
      severity: 'success',
      targetUserId: user.id
    });

    let emailDispatched = false;
    let emailError: string | undefined;
    if (isSmtpConfigured()) {
      const dispatch = await sendSmtpEmail({
        to: user.email,
        subject: 'ALFADetect — Account Access Approved',
        text: `Your ALFADetect registration has been approved by ${admin.email} with assigned role: ${finalRole}. You may now sign in to the enclave.`,
        html: `<p>Your ALFADetect registration has been <strong>approved</strong> with role <strong>${finalRole}</strong>.</p>`
      });
      emailDispatched = dispatch.sent;
      emailError = dispatch.error;
    }

    writeAudit(
      req,
      admin.email,
      'CONFIG',
      `Registration Approved: ${user.email} -> Active (${finalRole})`,
      'SUCCESS',
      `Requested: ${user.requestedRole || 'N/A'} | Assigned: ${finalRole}`,
      admin.role
    );

    res.json({
      success: true,
      user: sanitizeUser(updated!),
      smtpConfigured: isSmtpConfigured(),
      emailDispatched,
      emailError
    });
  });

  app.post('/api/admin/users/:id/reject', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), async (req: AuthenticatedRequest, res) => {
    const admin = req.authUser!;
    const user = serverDb.getUserById(req.params.id);
    if (!user) {
      res.status(404).json({ error: 'User registration record not found.' });
      return;
    }
    if (user.id === admin.id || user.role === SYSTEM_ADMIN_ROLE) {
      res.status(403).json({ error: 'Cannot reject the active System Security Administrator account.' });
      return;
    }

    const reason = String(req.body?.reason || '').trim();
    if (!reason) {
      res.status(400).json({ error: 'A clear written rejection reason is mandatory.' });
      return;
    }

    const nowStr = nowUtcString();
    const updated = serverDb.updateUser(user.id, {
      status: 'rejected',
      rejectionReason: reason,
      reviewedBy: admin.email,
      reviewedAt: nowStr,
      tokenVersion: (user.tokenVersion || 1) + 1
    });

    let emailDispatched = false;
    let emailError: string | undefined;
    if (isSmtpConfigured()) {
      const dispatch = await sendSmtpEmail({
        to: user.email,
        subject: 'ALFADetect — Registration Request Status Update',
        text: `Your ALFADetect access request was rejected. Reason: ${reason}`,
        html: `<p>Your ALFADetect access request was declined.</p><p><strong>Reason:</strong> ${reason}</p>`
      });
      emailDispatched = dispatch.sent;
      emailError = dispatch.error;
    }

    writeAudit(req, admin.email, 'CONFIG', `Registration Rejected: ${user.email}`, 'SUCCESS', `Reason: ${reason}`, admin.role);

    res.json({
      success: true,
      user: sanitizeUser(updated!),
      smtpConfigured: isSmtpConfigured(),
      emailDispatched,
      emailError
    });
  });

  app.patch('/api/users/:id/role', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), (req: AuthenticatedRequest, res) => {
    const admin = req.authUser!;
    const { role } = req.body || {};
    if (!role || !(ALL_ROLES as readonly string[]).includes(role)) {
      res.status(400).json({ error: 'Invalid role specified.' });
      return;
    }

    const user = serverDb.getUserById(req.params.id);
    if (!user) {
      res.status(404).json({ error: 'User account not found.' });
      return;
    }

    if (role === SYSTEM_ADMIN_ROLE || user.role === SYSTEM_ADMIN_ROLE) {
      res.status(403).json({
        error:
          'Single-Administrator Policy: Cannot promote a second administrator or demote the active administrator directly. Use Administrator Transfer.'
      });
      return;
    }

    const previousRole = user.role;
    const updated = serverDb.updateUser(user.id, {
      role,
      securityClearance: role,
      reviewedBy: admin.email,
      reviewedAt: nowUtcString(),
      tokenVersion: (user.tokenVersion || 1) + 1
    });

    writeAudit(
      req,
      admin.email,
      'CONFIG',
      `Role Updated: ${user.email} (${previousRole} -> ${role})`,
      'SUCCESS',
      'Token version incremented; previous JWT sessions invalidated',
      admin.role
    );

    res.json({ success: true, user: sanitizeUser(updated!) });
  });

  app.patch('/api/users/:id/status', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), (req: AuthenticatedRequest, res) => {
    const admin = req.authUser!;
    const { status } = req.body || {};
    if (!status || !['active', 'pending', 'rejected', 'suspended', 'inactive'].includes(status)) {
      res.status(400).json({ error: 'Invalid account status value.' });
      return;
    }

    const user = serverDb.getUserById(req.params.id);
    if (!user) {
      res.status(404).json({ error: 'User account not found.' });
      return;
    }

    if ((user.id === admin.id || user.role === SYSTEM_ADMIN_ROLE) && status !== 'active') {
      res.status(403).json({ error: 'Sole-Administrator Protection: Cannot suspend or deactivate the active System Security Administrator.' });
      return;
    }

    const prevStatus = user.status;
    const updated = serverDb.updateUser(user.id, {
      status,
      reviewedBy: admin.email,
      reviewedAt: nowUtcString(),
      failedLoginCount: status === 'active' ? 0 : user.failedLoginCount,
      lockedUntil: status === 'active' ? undefined : user.lockedUntil,
      tokenVersion: status !== 'active' ? (user.tokenVersion || 1) + 1 : user.tokenVersion
    });

    writeAudit(
      req,
      admin.email,
      'CONFIG',
      `Account Status Change: ${user.email} (${prevStatus} -> ${status})`,
      'SUCCESS',
      status !== 'active' ? 'All active JWT sessions invalidated immediately' : 'Account activated',
      admin.role
    );

    res.json({ success: true, user: sanitizeUser(updated!) });
  });

  app.post('/api/admin/users/:id/reset-password', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), async (req: AuthenticatedRequest, res) => {
    const admin = req.authUser!;
    const user = serverDb.getUserById(req.params.id);
    if (!user) {
      res.status(404).json({ error: 'User account not found.' });
      return;
    }
    if (user.id === admin.id || user.role === SYSTEM_ADMIN_ROLE) {
      res.status(403).json({
        error: 'Administrator password must be rotated through your personal Account Settings.'
      });
      return;
    }

    const customPw = typeof req.body?.newPassword === 'string' ? req.body.newPassword : '';
    let temporaryPassword = '';
    if (customPw.trim()) {
      const pwCheck = validatePasswordStrength(customPw, user.email);
      if (!pwCheck.valid) {
        res.status(400).json({ error: pwCheck.error });
        return;
      }
      temporaryPassword = customPw;
    } else {
      do {
        temporaryPassword = generateTemporaryPassword();
      } while (!validatePasswordStrength(temporaryPassword, user.email).valid);
    }

    const newSalt = crypto.randomBytes(16).toString('hex');
    const newHash = hashPassword(temporaryPassword, newSalt);
    const updated = serverDb.updateUser(user.id, {
      salt: newSalt,
      passwordHash: newHash,
      mustChangePassword: true,
      failedLoginCount: 0,
      lockedUntil: undefined,
      tokenVersion: (user.tokenVersion || 1) + 1
    })!;

    serverDb.consumePasswordResetTokensForUser(user.id, user.email);
    serverDb.addNotification({
      id: `NOTIF-ADMRST-${Date.now()}`,
      title: 'Administrator Issued Temporary Password',
      description: `Your password was reset by ${admin.email}. Sign in using the temporary credential and rotate it immediately.`,
      timestamp: 'Just now',
      read: false,
      severity: 'warning',
      targetUserId: user.id
    });

    let emailDispatched = false;
    let emailError: string | undefined;
    if (isSmtpConfigured()) {
      const dispatch = await sendSmtpEmail({
        to: user.email,
        subject: 'ALFADetect — Administrator Password Reset Notice',
        text: `Your ALFADetect account password was reset by System Security Administrator ${admin.email}. You are required to set a new password upon next sign-in. Obtain the temporary password securely from your administrator.`,
        html: `<p>Your ALFADetect account password was reset by System Security Administrator <strong>${admin.email}</strong>. Obtain your temporary password securely from your administrator; you will be required to change it immediately on sign-in.</p>`
      });
      emailDispatched = dispatch.sent;
      emailError = dispatch.error;
    }

    writeAudit(
      req,
      admin.email,
      'CONFIG',
      `Administrator Reset User Password (Forced Rotation): ${user.email}`,
      'SUCCESS',
      'mustChangePassword=true; prior sessions invalidated',
      admin.role
    );

    res.json({
      success: true,
      temporaryPassword,
      mustChangePassword: true,
      smtpConfigured: isSmtpConfigured(),
      emailDispatched,
      emailError,
      user: sanitizeUser(updated)
    });
  });

  app.post('/api/admin/users/:id/reset-2fa', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), (req: AuthenticatedRequest, res) => {
    const admin = req.authUser!;
    const { currentPassword, totpCode } = req.body || {};

    if (!currentPassword || !verifyPassword(String(currentPassword), admin.salt, admin.passwordHash)) {
      writeAudit(req, admin.email, 'CONFIG', `Admin Reset 2FA Denied (${req.params.id}): Invalid Password`, 'FAILED', undefined, admin.role);
      res.status(401).json({ error: 'Administrator password verification failed.' });
      return;
    }
    if (admin.twoFactorEnabled) {
      const totpCheck = verifyTotpWithReplayGuard(admin, String(totpCode || ''));
      if (!totpCheck.ok) {
        writeAudit(req, admin.email, 'CONFIG', `Admin Reset 2FA Denied (${req.params.id}): Invalid TOTP`, 'FAILED', totpCheck.error, admin.role);
        res.status(401).json({ error: totpCheck.error || 'Valid 6-digit administrator TOTP code is required.' });
        return;
      }
    }

    const user = serverDb.getUserById(req.params.id);
    if (!user) {
      res.status(404).json({ error: 'User account not found.' });
      return;
    }
    if (user.id === admin.id || user.role === SYSTEM_ADMIN_ROLE) {
      res.status(403).json({
        error: 'Administrator 2FA must be managed through your personal Account Settings.'
      });
      return;
    }

    const updated = serverDb.updateUser(user.id, {
      twoFactorEnabled: false,
      twoFactorMethod: 'NONE',
      totpSecretEnc: undefined,
      pendingTotpSecretEnc: undefined,
      recoveryCodeHashes: undefined,
      lastTotpStep: undefined,
      tokenVersion: (user.tokenVersion || 1) + 1
    })!;

    serverDb.addNotification({
      id: `NOTIF-RST2FA-${Date.now()}`,
      title: 'Two-Factor Authentication Reset by Administrator',
      description: `Your TOTP two-factor configuration was reset by ${admin.email}. Re-enroll an authenticator app in Settings.`,
      timestamp: 'Just now',
      read: false,
      severity: 'warning',
      targetUserId: user.id
    });

    writeAudit(
      req,
      admin.email,
      'CONFIG',
      `Administrator Reset User 2FA Configuration: ${user.email}`,
      'SUCCESS',
      'TOTP secret and recovery codes cleared; prior sessions invalidated',
      admin.role
    );

    res.json({
      success: true,
      user: sanitizeUser(updated)
    });
  });

  app.post('/api/admin/transfer-admin', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), (req: AuthenticatedRequest, res) => {
    const currentAdmin = req.authUser!;
    const { targetUserId, currentPassword, totpCode, demoteCurrentToRole, confirmText } = req.body || {};

    if (confirmText !== 'TRANSFER_SYSTEM_ADMIN') {
      res.status(400).json({ error: 'Confirmation phrase "TRANSFER_SYSTEM_ADMIN" is required.' });
      return;
    }
    if (!targetUserId || !currentPassword) {
      res.status(400).json({ error: 'Target active operator ID and current administrator password are required.' });
      return;
    }
    if (!verifyPassword(currentPassword, currentAdmin.salt, currentAdmin.passwordHash)) {
      writeAudit(req, currentAdmin.email, 'CONFIG', 'Admin Transfer Denied (Invalid Password)', 'FAILED', undefined, currentAdmin.role);
      res.status(401).json({ error: 'Current administrator password is incorrect.' });
      return;
    }
    if (currentAdmin.twoFactorEnabled) {
      const totpCheck = verifyTotpWithReplayGuard(currentAdmin, String(totpCode || ''));
      if (!totpCheck.ok) {
        writeAudit(req, currentAdmin.email, 'CONFIG', 'Admin Transfer Denied (Invalid TOTP)', 'FAILED', totpCheck.error, currentAdmin.role);
        res.status(401).json({
          error: totpCheck.error || 'Valid 6-digit TOTP verification code is required to authorize administrator transfer.'
        });
        return;
      }
    }
    const demoteRole = demoteCurrentToRole || 'Lead Forensic Analyst';
    if (!(NON_ADMIN_ROLES as readonly string[]).includes(demoteRole)) {
      res.status(400).json({ error: 'Invalid post-transfer role selected for outgoing administrator.' });
      return;
    }

    try {
      const { previousAdmin, newAdmin } = serverDb.transferSystemAdmin({
        currentAdminId: currentAdmin.id,
        targetUserId,
        demoteCurrentToRole: demoteRole
      });

      const expMs = req.authClaims?.exp ? req.authClaims.exp * 1000 : Date.now() + 8 * 60 * 60 * 1000;
      if (req.authClaims?.jti) serverDb.revokeToken(req.authClaims.jti, expMs);
      clearSessionCookie(req, res);

      serverDb.addNotification({
        id: `NOTIF-XFER-${Date.now()}`,
        title: 'System Administrator Authority Transferred',
        description: `Sole administrative authority transferred from ${previousAdmin.email} to ${newAdmin.email}.`,
        timestamp: 'Just now',
        read: false,
        severity: 'critical',
        targetUserId: newAdmin.id
      });

      writeAudit(
        req,
        previousAdmin.email,
        'CONFIG',
        `Audited Administrator Transfer: ${previousAdmin.email} -> ${newAdmin.email}`,
        'SUCCESS',
        `Previous admin reassigned to ${demoteRole}; all prior admin & target tokens invalidated.`,
        SYSTEM_ADMIN_ROLE
      );

      res.json({
        success: true,
        message: `Administrative authority transferred to ${newAdmin.name} (${newAdmin.email}). Sign in again with updated credentials.`,
        previousAdmin: sanitizeUser(previousAdmin),
        newAdmin: sanitizeUser(newAdmin)
      });
    } catch (err: any) {
      res.status(400).json({ error: err?.message || 'Administrator transfer failed.' });
    }
  });

  app.post('/api/admin/test-smtp', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), async (req: AuthenticatedRequest, res) => {
    const admin = req.authUser!;
    const recipient = String(req.body?.recipient || admin.email).trim().toLowerCase();
    if (!isValidEmailFormat(recipient)) {
      res.status(400).json({ error: 'Invalid recipient email address.' });
      return;
    }
    const result = await sendSmtpEmail({
      to: recipient,
      subject: 'ALFADetect — SMTP Configuration Test',
      text: `SMTP dispatch verification triggered by ${admin.email} at ${nowUtcString()}.`,
      html: `<p>ALFADetect SMTP configuration test triggered by <strong>${admin.email}</strong> succeeded.</p>`
    });
    writeAudit(
      req,
      admin.email,
      'CONFIG',
      `SMTP Test Dispatch -> ${recipient}`,
      result.sent ? 'SUCCESS' : 'FAILED',
      result.error,
      admin.role
    );
    if (!result.sent) {
      res.status(result.configured ? 502 : 503).json({
        sent: false,
        configured: result.configured,
        error: result.error
      });
      return;
    }
    res.json({ sent: true, configured: true, recipient });
  });

  app.get('/api/admin/activity', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), (req, res) => {
    const search = String(req.query.search || '').trim().toLowerCase();
    const action = String(req.query.action || '').trim().toUpperCase();
    const userFilter = String(req.query.user || '').trim().toLowerCase();
    const limit = Math.min(10000, Math.max(1, Number(req.query.limit) || 200));
    const offset = Math.max(0, Number(req.query.offset) || 0);

    let logs = serverDb.getAuditLogs();
    if (action && action !== 'ALL') {
      logs = logs.filter((l) => l.action === action);
    }
    if (userFilter) {
      logs = logs.filter((l) => l.user.toLowerCase().includes(userFilter));
    }
    if (search) {
      logs = logs.filter(
        (l) =>
          l.user.toLowerCase().includes(search) ||
          l.resource.toLowerCase().includes(search) ||
          (l.details || '').toLowerCase().includes(search) ||
          l.ipAddress.toLowerCase().includes(search)
      );
    }
    res.setHeader('X-Total-Count', String(logs.length));
    res.json(logs.slice(offset, offset + limit));
  });

  app.get('/api/admin/config', requireAuth, (_req, res) => {
    res.json(serverDb.getSystemConfig());
  });

  app.patch('/api/admin/config', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), (req: AuthenticatedRequest, res) => {
    const admin = req.authUser!;
    const {
      verificationThreshold,
      inconclusiveBand,
      minSpeechDurationSec,
      thresholdVersion,
      retentionDaysEvidence,
      retentionDaysLogs,
      enforceTwoFactor,
      enableGeminiAdvisory,
      sessionTtlMinutes,
      idleLockMinutes
    } = req.body || {};

    const updates: Record<string, any> = { updatedBy: admin.email };
    if (verificationThreshold !== undefined) {
      const num = Number(verificationThreshold);
      if (!Number.isFinite(num) || num < 50 || num > 99) {
        res.status(400).json({ error: 'verificationThreshold must be between 50 and 99.' });
        return;
      }
      updates.verificationThreshold = num;
    }
    if (inconclusiveBand !== undefined) {
      const num = Number(inconclusiveBand);
      if (!Number.isFinite(num) || num < 0 || num > 25) {
        res.status(400).json({ error: 'inconclusiveBand must be between 0 and 25.' });
        return;
      }
      updates.inconclusiveBand = num;
    }
    if (minSpeechDurationSec !== undefined) {
      const num = Number(minSpeechDurationSec);
      if (!Number.isFinite(num) || num < 1 || num > 120) {
        res.status(400).json({ error: 'minSpeechDurationSec must be between 1 and 120 seconds.' });
        return;
      }
      updates.minSpeechDurationSec = num;
    }
    if (thresholdVersion !== undefined) {
      const cleanVer = String(thresholdVersion).trim();
      if (!cleanVer) {
        res.status(400).json({ error: 'thresholdVersion cannot be blank.' });
        return;
      }
      updates.thresholdVersion = cleanVer;
    }
    if (retentionDaysEvidence !== undefined) {
      const days = Number(retentionDaysEvidence);
      if (!Number.isFinite(days) || days < 30 || days > 36500) {
        res.status(400).json({ error: 'retentionDaysEvidence must be between 30 and 36500 days.' });
        return;
      }
      updates.retentionDaysEvidence = Math.round(days);
    }
    if (retentionDaysLogs !== undefined) {
      const days = Number(retentionDaysLogs);
      if (!Number.isFinite(days) || days < 365 || days > 36500) {
        res.status(400).json({ error: 'retentionDaysLogs must be between 365 and 36500 days.' });
        return;
      }
      updates.retentionDaysLogs = Math.round(days);
    }
    if (enforceTwoFactor !== undefined) {
      updates.enforceTwoFactor = Boolean(enforceTwoFactor);
    }
    if (enableGeminiAdvisory !== undefined) {
      updates.enableGeminiAdvisory = Boolean(enableGeminiAdvisory);
    }
    if (sessionTtlMinutes !== undefined) {
      const ttlMin = Number(sessionTtlMinutes);
      if (!Number.isFinite(ttlMin) || ttlMin < 5 || ttlMin > 1440) {
        res.status(400).json({ error: 'sessionTtlMinutes must be between 5 and 1440 minutes.' });
        return;
      }
      updates.sessionTtlMinutes = Math.round(ttlMin);
    }
    if (idleLockMinutes !== undefined) {
      const idleMin = Number(idleLockMinutes);
      if (!Number.isFinite(idleMin) || idleMin < 1 || idleMin > 120) {
        res.status(400).json({ error: 'idleLockMinutes must be between 1 and 120 minutes.' });
        return;
      }
      updates.idleLockMinutes = Math.round(idleMin);
    }

    const updated = serverDb.updateSystemConfig(updates);
    writeAudit(
      req,
      admin.email,
      'CONFIG',
      `System Policy Config Updated (${updated.thresholdVersion})`,
      'SUCCESS',
      `Threshold: ${updated.verificationThreshold}% | Band: ±${updated.inconclusiveBand}% | Retention: ${updated.retentionDaysEvidence}d/${updated.retentionDaysLogs}d | Require2FA: ${updated.enforceTwoFactor} | SessionTTL: ${updated.sessionTtlMinutes}m | IdleLock: ${updated.idleLockMinutes}m | GeminiOptIn: ${Boolean(updated.enableGeminiAdvisory)}`,
      admin.role
    );
    res.json(updated);
  });

  // Retention eligibility summary (Admin-only, no raw evidence/synopsis) and Retention-Enforced Case Purge (A4)
  app.get('/api/admin/retention-cases', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), (_req, res) => {
    const sysConfig = serverDb.getSystemConfig();
    const allCases = serverDb.getCases(true);
    const nowMs = Date.now();
    const list = allCases.map((c) => {
      const parsedMs = Date.parse(String(c.updatedDate || c.date || '').replace(' UTC', 'Z'));
      const elapsedDays = Number.isFinite(parsedMs) ? Math.floor((nowMs - parsedMs) / (86400 * 1000)) : 0;
      const statusOk = c.status === 'Archived' || c.status === 'Completed';
      return {
        id: c.id,
        status: c.status,
        date: c.date,
        updatedDate: c.updatedDate,
        elapsedDays,
        retentionDaysRequired: sysConfig.retentionDaysEvidence,
        eligibleForPurge: statusOk && elapsedDays >= sysConfig.retentionDaysEvidence
      };
    });
    res.json(list);
  });

  app.post('/api/admin/cases/:id/purge', requireAuth, requireRole([SYSTEM_ADMIN_ROLE]), (req: AuthenticatedRequest, res) => {
    const admin = req.authUser!;
    const { currentPassword, totpCode, confirmText } = req.body || {};

    if (confirmText !== 'PURGE_ARCHIVED_CASE') {
      res.status(400).json({ error: 'Exact confirmation phrase "PURGE_ARCHIVED_CASE" is required.' });
      return;
    }
    if (!currentPassword || !verifyPassword(String(currentPassword), admin.salt, admin.passwordHash)) {
      writeAudit(req, admin.email, 'DELETE', `Blocked Case Purge (${req.params.id}): Invalid password`, 'FAILED', undefined, admin.role);
      res.status(401).json({ error: 'Administrator password verification failed.' });
      return;
    }
    if (admin.twoFactorEnabled) {
      const totpCheck = verifyTotpWithReplayGuard(admin, String(totpCode || ''));
      if (!totpCheck.ok) {
        writeAudit(req, admin.email, 'DELETE', `Blocked Case Purge (${req.params.id}): Invalid TOTP`, 'FAILED', totpCheck.error, admin.role);
        res.status(401).json({ error: totpCheck.error || 'Valid 6-digit TOTP code required.' });
        return;
      }
    }

    const targetCase = serverDb.getCaseById(req.params.id);
    if (!targetCase) {
      res.status(404).json({ error: 'Case docket not found.' });
      return;
    }
    if (targetCase.status !== 'Archived' && targetCase.status !== 'Completed') {
      res.status(400).json({
        error: `Purge Blocked: Only 'Archived' or 'Completed' cases may be purged (current status: '${targetCase.status}').`
      });
      return;
    }

    const sysConfig = serverDb.getSystemConfig();
    const refTimeMs = Date.parse(String(targetCase.updatedDate || targetCase.date || '').replace(' UTC', 'Z'));
    const elapsedDays = Number.isFinite(refTimeMs) ? (Date.now() - refTimeMs) / (86400 * 1000) : 0;
    if (elapsedDays < sysConfig.retentionDaysEvidence) {
      res.status(403).json({
        error: `Retention Hold Active: Case ${targetCase.id} has elapsed ${Math.floor(elapsedDays)} day(s) against the mandatory ${sysConfig.retentionDaysEvidence}-day evidence retention window.`
      });
      return;
    }

    const purgeStats = serverDb.purgeCaseCompletely(targetCase.id);
    writeAudit(
      req,
      admin.email,
      'DELETE',
      `Tombstone: Case Purged After Retention (${targetCase.id})`,
      'SUCCESS',
      `Retention elapsed: ${Math.floor(elapsedDays)}d >= ${sysConfig.retentionDaysEvidence}d | Evidence files deleted: ${purgeStats.filesRemoved}`,
      admin.role
    );
    res.json({
      success: true,
      purgedCaseId: targetCase.id,
      deletedFiles: purgeStats.filesRemoved,
      message: `Case ${targetCase.id} and ${purgeStats.filesRemoved} stored audio file(s) permanently purged under retention policy.`
    });
  });

  // -------------------------------------------------------------
  // 2C. Account Settings (Profile, Verified Email Change, Password, TOTP 2FA)
  // -------------------------------------------------------------
  app.patch('/api/settings/profile', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const { name, phone, agency, department, themePreference, notificationPreferences } = req.body || {};

    const updates: Partial<StoredUserRecord> = {};
    if (name !== undefined) {
      const trimmed = String(name).trim();
      if (!trimmed) {
        res.status(400).json({ error: 'Full Name cannot be empty.' });
        return;
      }
      updates.name = trimmed;
      updates.avatar = trimmed.charAt(0).toUpperCase() || user.avatar;
    }
    if (phone !== undefined) updates.phone = String(phone).trim();
    if (agency !== undefined && String(agency).trim()) updates.agency = String(agency).trim();
    if (department !== undefined) updates.department = String(department).trim();
    if (themePreference !== undefined) {
      if (!['light', 'dark', 'system'].includes(themePreference)) {
        res.status(400).json({ error: 'themePreference must be light, dark, or system.' });
        return;
      }
      updates.themePreference = themePreference;
    }
    if (notificationPreferences && typeof notificationPreferences === 'object') {
      updates.notificationPreferences = { ...(user.notificationPreferences || {}), ...notificationPreferences };
    }

    const updated = serverDb.updateUser(user.id, updates);
    writeAudit(req, user.email, 'CONFIG', `Profile/Appearance Settings Updated: ${user.email}`, 'SUCCESS', undefined, user.role);
    res.json({ success: true, user: sanitizeUser(updated!) });
  });

  app.post('/api/settings/email-change/request', requireAuth, async (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const { newEmail, currentPassword } = req.body || {};
    if (!newEmail || !currentPassword) {
      res.status(400).json({ error: 'New email address and current password are required.' });
      return;
    }
    if (!verifyPassword(currentPassword, user.salt, user.passwordHash)) {
      res.status(401).json({ error: 'Current password is incorrect.' });
      return;
    }
    const cleanEmail = String(newEmail).trim().toLowerCase();
    if (!isValidEmailFormat(cleanEmail)) {
      res.status(400).json({ error: 'Invalid new email format.' });
      return;
    }
    if (cleanEmail === user.email.toLowerCase()) {
      res.status(400).json({ error: 'New email address matches your current email.' });
      return;
    }
    if (serverDb.getUserByEmail(cleanEmail)) {
      res.status(409).json({ error: 'Another account already uses that email address.' });
      return;
    }
    if (!isSmtpConfigured()) {
      res.status(503).json({
        error: 'Email verification is unavailable: SMTP server is not configured. Contact the System Security Administrator.',
        smtpConfigured: false
      });
      return;
    }

    const code = crypto.randomInt(100000, 999999).toString();
    const dispatch = await sendSmtpEmail({
      to: cleanEmail,
      subject: 'ALFADetect — Verify Your New Email Address',
      text: `Verification code to confirm your ALFADetect email change: ${code}. Valid for 15 minutes.`,
      html: `<p>Your ALFADetect email change verification code is <strong>${code}</strong>. Valid for 15 minutes.</p>`
    });
    if (!dispatch.sent) {
      res.status(503).json({ error: `SMTP delivery failed: ${dispatch.error}`, smtpConfigured: true });
      return;
    }

    serverDb.updateUser(user.id, {
      pendingEmailChange: {
        newEmail: cleanEmail,
        codeHash: sha256String(code + user.salt),
        expiresAt: Date.now() + 15 * 60 * 1000
      }
    });
    writeAudit(req, user.email, 'CONFIG', `Requested Verified Email Change -> ${cleanEmail}`, 'SUCCESS', undefined, user.role);
    res.json({ success: true, message: `Verification code sent to ${cleanEmail}.`, pendingEmail: cleanEmail });
  });

  app.post('/api/settings/email-change/confirm', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const { code } = req.body || {};
    if (!user.pendingEmailChange) {
      res.status(400).json({ error: 'No pending email change request.' });
      return;
    }
    if (Date.now() > user.pendingEmailChange.expiresAt) {
      serverDb.updateUser(user.id, { pendingEmailChange: undefined });
      res.status(400).json({ error: 'Email verification code expired. Please request again.' });
      return;
    }
    if (!code || sha256String(String(code).trim() + user.salt) !== user.pendingEmailChange.codeHash) {
      res.status(400).json({ error: 'Incorrect email verification code.' });
      return;
    }

    const oldEmail = user.email;
    const nextEmail = user.pendingEmailChange.newEmail;
    const nextTv = (user.tokenVersion || 1) + 1;
    const updated = serverDb.updateUser(user.id, {
      email: nextEmail,
      pendingEmailChange: undefined,
      tokenVersion: nextTv
    })!;

    if (req.authClaims?.jti) {
      serverDb.revokeToken(req.authClaims.jti, (req.authClaims.exp || 0) * 1000);
    }
    const ttlSeconds = getSessionPolicy().sessionTtlMinutes * 60;
    const { token: newToken } = issueJwtToken({
      userId: updated.id,
      email: updated.email,
      role: updated.role,
      name: updated.name,
      tokenVersion: updated.tokenVersion,
      typ: 'session',
      expiresInSeconds: ttlSeconds
    });

    setSessionCookie(req, res, newToken, ttlSeconds);
    writeAudit(req, nextEmail, 'CONFIG', `Verified Email Changed: ${oldEmail} -> ${nextEmail}`, 'SUCCESS', undefined, updated.role);
    res.json({ success: true, user: sanitizeUser(updated), newToken });
  });

  app.post('/api/settings/password', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const { currentPassword, newPassword } = req.body || {};
    if (!currentPassword || !newPassword) {
      res.status(400).json({ error: 'Current password and new password are required.' });
      return;
    }
    if (!verifyPassword(currentPassword, user.salt, user.passwordHash)) {
      writeAudit(req, user.email, 'CONFIG', 'Password Rotation Failed — Invalid Current Password', 'FAILED', undefined, user.role);
      res.status(401).json({ error: 'Current password is incorrect.' });
      return;
    }
    const pwCheck = validatePasswordStrength(newPassword, user.email);
    if (!pwCheck.valid) {
      res.status(400).json({ error: pwCheck.error });
      return;
    }

    const newSalt = crypto.randomBytes(16).toString('hex');
    const newHash = hashPassword(newPassword, newSalt);
    const nextTv = (user.tokenVersion || 1) + 1;
    const updated = serverDb.updateUser(user.id, {
      salt: newSalt,
      passwordHash: newHash,
      tokenVersion: nextTv,
      mustChangePassword: false
    })!;

    if (req.authClaims?.jti) {
      serverDb.revokeToken(req.authClaims.jti, (req.authClaims.exp || 0) * 1000);
    }
    const ttlSeconds = getSessionPolicy().sessionTtlMinutes * 60;
    const { token: newToken } = issueJwtToken({
      userId: updated.id,
      email: updated.email,
      role: updated.role,
      name: updated.name,
      tokenVersion: updated.tokenVersion,
      typ: 'session',
      expiresInSeconds: ttlSeconds
    });

    setSessionCookie(req, res, newToken, ttlSeconds);
    writeAudit(req, user.email, 'CONFIG', 'Account Password Rotated (scrypt) — Prior Sessions Invalidated', 'SUCCESS', undefined, user.role);
    res.json({
      success: true,
      message: 'Password updated securely and prior sessions invalidated.',
      newToken,
      user: sanitizeUser(updated)
    });
  });

  app.get('/api/settings/2fa/status', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    res.json({
      enabled: Boolean(user.twoFactorEnabled),
      method: user.twoFactorMethod || 'NONE',
      recoveryCodesRemaining: user.recoveryCodeHashes?.length || 0,
      smtpConfigured: isSmtpConfigured(),
      webAuthnConfigured: false,
      smsOtpConfigured: false
    });
  });

  app.post('/api/settings/2fa/setup', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const secret = generateTotpSecret();
    serverDb.setEncryptedTotpSecret(user.id, secret, true);
    const otpauthUri = buildTotpUri({ secret, email: user.email, issuer: 'ALFADetect' });
    writeAudit(req, user.email, 'CONFIG', 'Generated Pending TOTP 2FA Secret', 'SUCCESS', undefined, user.role);
    res.json({
      secret,
      otpauthUri,
      issuer: 'ALFADetect',
      accountName: user.email
    });
  });

  app.post('/api/settings/2fa/verify', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const code = String(req.body?.code || '').trim();
    const pendingSecret = serverDb.getDecryptedTotpSecret(user, true);
    if (!pendingSecret) {
      res.status(400).json({ error: 'No pending TOTP setup found. Start setup first.' });
      return;
    }
    const check = verifyTotpCodeWithStep(pendingSecret, code);
    if (!check.valid || check.timeStep === undefined) {
      res.status(400).json({ error: 'Invalid 6-digit TOTP verification code. Check device clock synchronization and try again.' });
      return;
    }
    serverDb.setEncryptedTotpSecret(user.id, pendingSecret, false);
    const { plaintextCodes, hashes } = generateRecoveryCodes(8);
    const updated = serverDb.updateUser(user.id, {
      twoFactorEnabled: true,
      twoFactorMethod: 'TOTP',
      recoveryCodeHashes: hashes,
      lastTotpStep: check.timeStep
    })!;
    writeAudit(req, user.email, 'CONFIG', 'TOTP Two-Factor Authentication Enabled', 'SUCCESS', undefined, user.role);
    res.json({
      success: true,
      recoveryCodes: plaintextCodes,
      user: sanitizeUser(updated)
    });
  });

  app.post('/api/settings/2fa/disable', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const { currentPassword, totpCode } = req.body || {};
    if (!user.twoFactorEnabled) {
      res.status(400).json({ error: 'Two-factor authentication is not currently enabled.' });
      return;
    }
    if (!currentPassword || !verifyPassword(currentPassword, user.salt, user.passwordHash)) {
      res.status(401).json({ error: 'Current password is incorrect.' });
      return;
    }
    const trimmed = String(totpCode || '').trim();
    const totpCheck = verifyTotpWithReplayGuard(user, trimmed);
    const okTotp = totpCheck.ok;
    const okRecovery = !okTotp && (user.recoveryCodeHashes?.includes(hashRecoveryCode(trimmed)) || false);
    if (!okTotp && !okRecovery) {
      res.status(401).json({
        error: totpCheck.error || 'Valid 6-digit TOTP code or recovery code is required to disable 2FA.'
      });
      return;
    }

    const updated = serverDb.updateUser(user.id, {
      twoFactorEnabled: false,
      twoFactorMethod: 'NONE',
      totpSecretEnc: undefined,
      pendingTotpSecretEnc: undefined,
      recoveryCodeHashes: undefined,
      lastTotpStep: undefined
    })!;
    writeAudit(req, user.email, 'CONFIG', 'TOTP Two-Factor Authentication Disabled', 'SUCCESS', undefined, user.role);
    res.json({ success: true, user: sanitizeUser(updated) });
  });

  // -------------------------------------------------------------
  // 3. Collaborators List & Case Management (Case-Level ACL Enforced)
  // -------------------------------------------------------------
  app.get('/api/collaborators', requireAuth, requireRole(['Lead Forensic Analyst']), (_req, res) => {
    const collaborators = serverDb
      .getUsers()
      .filter((u) => u.status === 'active' && u.role !== SYSTEM_ADMIN_ROLE)
      .map((u) => ({
        id: u.id,
        name: u.name,
        email: u.email,
        role: u.role,
        agency: u.agency,
        certificationId: u.certificationId
      }));
    res.json(collaborators);
  });

  app.get('/api/cases', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    if (user.role === SYSTEM_ADMIN_ROLE) {
      res.json([]); // Admin is segregated from raw forensic case files
      return;
    }
    const includeArchived = req.query.includeArchived === 'true';
    res.json(getAccessibleCasesForUser(user, includeArchived));
  });

  app.post('/api/cases', requireAuth, requireRole(['Lead Forensic Analyst']), (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const { title, description, priority, agency, analyst, assignedUserIds } = req.body || {};

    if (!title || !String(title).trim()) {
      res.status(400).json({ error: 'Case title is required.' });
      return;
    }

    const caseId = `ALFA-${new Date().getFullYear()}-${crypto.randomInt(1000, 9999)}`;
    const now = nowUtcString();

    const validAssignees = Array.isArray(assignedUserIds)
      ? assignedUserIds
          .map((id: any) => String(id).trim())
          .filter((id: string) => {
            const u = serverDb.getUserById(id);
            return Boolean(u && u.status === 'active' && u.role !== SYSTEM_ADMIN_ROLE);
          })
      : [];

    const newCase = serverDb.createCase({
      id: caseId,
      title: String(title).trim(),
      description: description ? String(description).trim() : 'Forensic acoustic examination docket.',
      status: 'Active',
      verdict: 'INCONCLUSIVE',
      priority: ['Critical', 'High', 'Medium', 'Low'].includes(priority) ? priority : 'High',
      analyst: analyst ? String(analyst).trim() : user.name,
      agency: agency ? String(agency).trim() : user.agency,
      date: new Date().toISOString().slice(0, 10),
      updatedDate: now,
      evidenceCount: 0,
      threatScore: 0,
      createdBy: user.email,
      assignedUserIds: Array.from(new Set([user.id, ...validAssignees]))
    });

    appendSignedCustodyEvent({
      req,
      caseId: newCase.id,
      title: 'Forensic Case Docket Created',
      actorRole: 'Lead Analyst',
      status: 'VERIFIED',
      userName: user.name,
      details: `Case docket '${newCase.title}' opened by ${user.name}`
    });

    writeAudit(req, user.email, 'WRITE', `Created Case Docket: ${newCase.title} (${newCase.id})`, 'SUCCESS', undefined, user.role);

    serverDb.addNotification({
      id: `NOTIF-CASE-${Date.now()}`,
      title: 'New Forensic Docket Opened',
      description: `Case docket ${newCase.id} (${newCase.title}) initialized.`,
      timestamp: 'Just now',
      read: false,
      severity: 'info',
      caseId: newCase.id,
      targetUserId: user.id
    });

    res.status(201).json(newCase);
  });

  app.get('/api/cases/:id', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const c = serverDb.getCaseById(req.params.id);
    if (!c) {
      res.status(404).json({ error: 'Case not found.' });
      return;
    }
    if (!canAccessCase(user, c)) {
      writeAudit(req, user.email, 'VIEW', `Unauthorized Case Access Attempt: ${c.id}`, 'FAILED', undefined, user.role);
      res.status(403).json({ error: `Forbidden: You are not authorized to access Case ${c.id}.` });
      return;
    }
    res.json(c);
  });

  app.patch('/api/cases/:id', requireAuth, requireRole(['Lead Forensic Analyst']), (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const existing = serverDb.getCaseById(req.params.id);
    if (!existing) {
      res.status(404).json({ error: 'Case not found.' });
      return;
    }
    if (!canAccessCase(user, existing)) {
      res.status(403).json({ error: `Forbidden: You are not assigned to Case ${existing.id}.` });
      return;
    }

    const { status, verdict, priority, title, description, assignedUserIds } = req.body || {};
    if (verdict !== undefined) {
      writeAudit(req, user.email, 'WRITE', `Blocked Direct Case Verdict Override on ${existing.id}`, 'FAILED', undefined, user.role);
      res.status(400).json({
        error: 'Case verdict cannot be directly overwritten via case metadata updates; use Forensic Analysis or signed Expert Witness Certification.'
      });
      return;
    }

    const allowedUpdates: Partial<StoredCase> = {};
    if (status && ['Active', 'Under Review', 'Pending Legal', 'Completed', 'Archived'].includes(status)) {
      allowedUpdates.status = status;
    }
    if (priority && ['Critical', 'High', 'Medium', 'Low'].includes(priority)) allowedUpdates.priority = priority;
    if (title) allowedUpdates.title = String(title).trim();
    if (description !== undefined) allowedUpdates.description = String(description).trim();
    if (Array.isArray(assignedUserIds)) {
      allowedUpdates.assignedUserIds = Array.from(
        new Set(
          assignedUserIds
            .map((id: any) => String(id).trim())
            .filter((id: string) => {
              const target = serverDb.getUserById(id);
              return Boolean(target && target.status === 'active' && target.role !== SYSTEM_ADMIN_ROLE);
            })
        )
      );
    }

    const updated = serverDb.updateCase(existing.id, allowedUpdates);
    writeAudit(req, user.email, 'WRITE', `Updated Case Docket: ${existing.id}`, 'SUCCESS', JSON.stringify(allowedUpdates), user.role);
    res.json(updated);
  });

  app.delete('/api/cases/:id', requireAuth, requireRole(['Lead Forensic Analyst']), (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const existing = serverDb.getCaseById(req.params.id);
    if (!existing) {
      res.status(404).json({ error: 'Case not found.' });
      return;
    }
    if (!canAccessCase(user, existing)) {
      res.status(403).json({ error: `Forbidden: You are not assigned to Case ${existing.id}.` });
      return;
    }
    const archived = serverDb.archiveCase(existing.id);
    appendSignedCustodyEvent({
      req,
      caseId: existing.id,
      title: 'Case Docket Archived (Evidence & CoC Preserved)',
      actorRole: 'Lead Analyst',
      status: 'VERIFIED',
      userName: user.name,
      details: `Case ${existing.id} moved to Archived status under evidence retention controls.`
    });
    writeAudit(req, user.email, 'WRITE', `Archived Case Docket: ${existing.id}`, 'SUCCESS', 'Non-destructive archive', user.role);
    res.json({ success: true, archived: true, case: archived, message: `Case ${existing.id} archived (evidence and chain of custody preserved).` });
  });

  // -------------------------------------------------------------
  // 4. Evidence Management, Multipart 50MB Upload, Magic Bytes & Hash Integrity
  // -------------------------------------------------------------
  app.get('/api/evidence', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    if (user.role === SYSTEM_ADMIN_ROLE) {
      res.json([]);
      return;
    }
    const caseId = req.query.caseId as string | undefined;
    if (caseId) {
      const targetCase = serverDb.getCaseById(caseId);
      if (!targetCase || !canAccessCase(user, targetCase)) {
        res.status(403).json({ error: `Forbidden: Access denied for Case ${caseId}.` });
        return;
      }
      res.json(serverDb.getEvidence(caseId).map(sanitizeEvidenceMetadata));
      return;
    }
    const allowedIds = new Set(getAccessibleCasesForUser(user, true).map((c) => c.id));
    res.json(
      serverDb
        .getEvidence()
        .filter((e) => allowedIds.has(e.caseId))
        .map(sanitizeEvidenceMetadata)
    );
  });

  app.get('/api/cases/:caseId/evidence', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const targetCase = serverDb.getCaseById(req.params.caseId);
    if (!targetCase) {
      res.status(404).json({ error: 'Case not found.' });
      return;
    }
    if (!canAccessCase(user, targetCase)) {
      res.status(403).json({ error: `Forbidden: You are not assigned to Case ${targetCase.id}.` });
      return;
    }
    res.json(serverDb.getEvidence(targetCase.id).map(sanitizeEvidenceMetadata));
  });

  app.get('/api/evidence/:id/audio', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    if (user.role === SYSTEM_ADMIN_ROLE) {
      writeAudit(req, user.email, 'VIEW', `Blocked System Admin Raw Audio Download (${req.params.id})`, 'FAILED', undefined, user.role);
      res.status(403).json({ error: 'Separation of Duties: System Security Administrators cannot access raw forensic evidence audio.' });
      return;
    }
    const ev = serverDb.getEvidenceById(req.params.id);
    if (!ev) {
      res.status(404).json({ error: 'Evidence record not found.' });
      return;
    }
    const targetCase = serverDb.getCaseById(ev.caseId);
    if (!targetCase || !canAccessCase(user, targetCase)) {
      res.status(403).json({ error: 'Forbidden: You do not have case clearance for this evidence file.' });
      return;
    }

    const integrity = verifyStoredEvidenceIntegrity(req, user, ev);
    if (!integrity.ok || !integrity.buffer) {
      res.status(integrity.buffer || integrity.tampered ? 409 : 404).json({ error: integrity.reason || 'Evidence integrity check failed.' });
      return;
    }

    const mimeMap: Record<string, string> = {
      '.wav': 'audio/wav',
      '.mp3': 'audio/mpeg',
      '.flac': 'audio/flac',
      '.m4a': 'audio/mp4',
      '.ogg': 'audio/ogg'
    };
    const ext = path.extname(ev.filename).toLowerCase();
    res.setHeader('Content-Type', ev.mimeType || mimeMap[ext] || 'application/octet-stream');
    res.setHeader('Content-Length', String(integrity.buffer.length));
    res.send(integrity.buffer);
  });

  app.post(
    '/api/evidence/upload',
    requireAuth,
    requireRole(['Lead Forensic Analyst', 'Forensic Examiner / Expert Witness']),
    optionalAudioMultipart(['audio', 'file']),
    (req: AuthenticatedRequest, res) => {
      const user = req.authUser!;
      const uploaded = extractUploadedFileFromReq(req);
      const body = req.body || {};

      const caseId = String(body.caseId || '').trim();
      const rawFilename = uploaded?.filename || String(body.filename || '').trim();

      if (!caseId || !rawFilename) {
        res.status(400).json({ error: 'caseId and audio file/filename are required.' });
        return;
      }

      const targetCase = serverDb.getCaseById(caseId);
      if (!targetCase) {
        res.status(404).json({ error: `Case docket '${caseId}' not found.` });
        return;
      }
      if (!canAccessCase(user, targetCase)) {
        res.status(403).json({ error: `Forbidden: You are not assigned to Case ${caseId}.` });
        return;
      }

      let rawBuffer: Buffer | null = null;
      if (uploaded) {
        rawBuffer = uploaded.buffer;
      } else if (body.audioData && typeof body.audioData === 'string') {
        rawBuffer = Buffer.from(body.audioData, 'base64');
      }

      if (!rawBuffer) {
        res.status(400).json({ error: 'Audio binary upload or base64 payload is required.' });
        return;
      }

      const safeFilename = path.basename(rawFilename);
      const validation = validateAudioBufferAndFilename(rawBuffer, safeFilename);
      if (!validation.valid) {
        writeAudit(req, user.email, 'UPLOAD', `Rejected Invalid Evidence File: ${safeFilename}`, 'FAILED', validation.error, user.role);
        res.status(400).json({ error: validation.error });
        return;
      }

      const sha256Hash = sha256Buffer(rawBuffer);
      const evidenceId = `EV-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
      const storedFile = serverDb.saveAudioFile(evidenceId, safeFilename, rawBuffer);
      const dspProbe = extractServerAudioDsp(rawBuffer);

      const durationDisplay =
        dspProbe.isWavDecoded && dspProbe.durationSec > 0
          ? `${dspProbe.durationSec.toFixed(1)}s`
          : 'Requires client/WAV decode';

      const sampleRateDisplay =
        dspProbe.isWavDecoded && dspProbe.sampleRate > 0
          ? `${dspProbe.sampleRate} Hz`
          : 'Compressed stream';

      const bitDepthDisplay = dspProbe.isWavDecoded
        ? `${dspProbe.bitsPerSample}-bit ${dspProbe.audioFormatCode === 3 ? 'IEEE Float' : 'PCM'}`
        : 'Compressed';

      const channelsDisplay = dspProbe.isWavDecoded
        ? dspProbe.channels === 1
          ? 'Mono'
          : dspProbe.channels === 2
          ? 'Stereo'
          : `${dspProbe.channels}ch`
        : 'Compressed';

      const fileSizeDisplay = `${(rawBuffer.length / (1024 * 1024)).toFixed(2)} MB`;

      const newEvidence = serverDb.createEvidence({
        id: evidenceId,
        caseId,
        filename: safeFilename,
        fileSize: fileSizeDisplay,
        duration: durationDisplay,
        sampleRate: sampleRateDisplay,
        bitDepth: bitDepthDisplay,
        channels: channelsDisplay,
        sha256Hash,
        uploadTimestamp: nowUtcString(),
        status: 'Uploaded',
        storageFilename: storedFile.storageFilename,
        byteSize: storedFile.byteSize,
        mimeType: validation.mimeType,
        detectedFormat: validation.detectedFormat,
        uploadedBy: user.name,
        classification: 'Pending Analysis',
        isIntegrityVerified: true
      });

      appendSignedCustodyEvent({
        req,
        caseId,
        evidenceId,
        title: 'Evidence Ingestion & Bitstream Inscription',
        actorRole: user.role === 'Lead Forensic Analyst' ? 'Lead Analyst' : 'Expert',
        status: 'VERIFIED',
        userName: user.name,
        hashAtEvent: sha256Hash,
        details: `Original intake for ${safeFilename} (${validation.detectedFormat}). SHA-256 computed over ${rawBuffer.length.toLocaleString()} bytes.`
      });

      writeAudit(
        req,
        user.email,
        'UPLOAD',
        `Audio Evidence Ingested: ${safeFilename} (${validation.detectedFormat}, ${sha256Hash.slice(0, 16)}...)`,
        'SUCCESS',
        `Case: ${caseId} | Size: ${rawBuffer.length} bytes`,
        user.role
      );

      res.status(201).json(sanitizeEvidenceMetadata(newEvidence));
    }
  );

  // Non-destructive derived normalized/high-pass working copy (original exhibit & SHA-256 remain untouched)
  app.post(
    '/api/evidence/:id/derive-copy',
    requireAuth,
    requireRole(['Lead Forensic Analyst', 'Forensic Examiner / Expert Witness']),
    (req: AuthenticatedRequest, res) => {
      const user = req.authUser!;
      const parentEv = serverDb.getEvidenceById(req.params.id);
      if (!parentEv) {
        res.status(404).json({ error: 'Source evidence record not found.' });
        return;
      }
      const targetCase = serverDb.getCaseById(parentEv.caseId);
      if (!targetCase || !canAccessCase(user, targetCase)) {
        res.status(403).json({ error: 'Forbidden: You are not assigned to this evidence case docket.' });
        return;
      }

      const integrity = verifyStoredEvidenceIntegrity(req, user, parentEv);
      if (!integrity.ok || !integrity.buffer) {
        res.status(integrity.buffer || integrity.tampered ? 409 : 404).json({
          error: integrity.reason || 'Source evidence failed integrity verification.'
        });
        return;
      }

      const rawHp = req.body?.highPassHz;
      const highPassHz =
        typeof rawHp === 'number' && isFinite(rawHp) ? Math.max(0, Math.min(500, Math.round(rawHp))) : 80;

      const derived = deriveNormalizedWav(integrity.buffer, { highPassHz });
      if (!derived) {
        res.status(422).json({
          error: 'Derived working copy requires a decodable PCM WAV source exhibit.'
        });
        return;
      }

      const derivedId = `EV-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
      const stem = path.basename(parentEv.filename, path.extname(parentEv.filename));
      const derivedFilename = `${stem}_norm_hp${derived.highPassHz}hz.wav`;
      const derivedSha256 = sha256Buffer(derived.wavBuffer);
      const storedFile = serverDb.saveAudioFile(derivedId, derivedFilename, derived.wavBuffer);
      const opLabel = `DC-removal + ${derived.highPassHz}Hz high-pass + -1dBFS peak norm (before ${derived.peakDbBefore} dBFS)`;

      const newDerived = serverDb.createEvidence({
        id: derivedId,
        caseId: parentEv.caseId,
        filename: derivedFilename,
        fileSize: `${(derived.wavBuffer.length / (1024 * 1024)).toFixed(2)} MB`,
        duration: `${derived.durationSec.toFixed(1)}s`,
        sampleRate: `${derived.sampleRate} Hz`,
        bitDepth: '16-bit PCM',
        channels: 'Mono',
        sha256Hash: derivedSha256,
        uploadTimestamp: nowUtcString(),
        status: 'Processed',
        storageFilename: storedFile.storageFilename,
        byteSize: storedFile.byteSize,
        mimeType: 'audio/wav',
        detectedFormat: 'WAV (RIFF/WAVE)',
        uploadedBy: user.name,
        classification: 'Derived Working Copy',
        isIntegrityVerified: true,
        parentEvidenceId: parentEv.id,
        isDerivedCopy: true,
        processingOperation: opLabel
      });

      appendSignedCustodyEvent({
        req,
        caseId: parentEv.caseId,
        evidenceId: derivedId,
        title: `Non-Destructive Derived Copy Created from ${parentEv.id}`,
        actorRole: user.role === 'Lead Forensic Analyst' ? 'Lead Analyst' : 'Expert',
        status: 'VERIFIED',
        userName: user.name,
        hashAtEvent: derivedSha256,
        details: `Parent ${parentEv.id} (${parentEv.sha256Hash.slice(0, 16)}...) preserved intact. Operation: ${opLabel}`
      });

      writeAudit(
        req,
        user.email,
        'WRITE',
        `Derived Working Copy Created: ${derivedId} from ${parentEv.id}`,
        'SUCCESS',
        opLabel,
        user.role
      );

      res.status(201).json(sanitizeEvidenceMetadata(newDerived));
    }
  );

  app.post(
    '/api/evidence/verify-hash',
    requireAuth,
    optionalAudioMultipart(['audio', 'file']),
    (req: AuthenticatedRequest, res) => {
      const user = req.authUser!;
      if (user.role === SYSTEM_ADMIN_ROLE) {
        res.status(403).json({
          error: 'Separation of Duties: System Security Administrator cannot access or verify raw case evidence.'
        });
        return;
      }
      const uploaded = extractUploadedFileFromReq(req);
      const { evidenceId, candidateData, candidateBase64, candidateHash, expectedHash, verifyStoredBitstream } = req.body || {};

      let evidence = evidenceId ? serverDb.getEvidenceById(String(evidenceId)) : undefined;
      if (!evidence && expectedHash) {
        evidence = serverDb.getEvidence().find((e) => e.sha256Hash.toLowerCase() === String(expectedHash).toLowerCase());
      }

      if (evidence) {
        const targetCase = serverDb.getCaseById(evidence.caseId);
        if (!targetCase || !canAccessCase(user, targetCase)) {
          res.status(403).json({ error: 'Forbidden: You are not assigned to this evidence case docket.' });
          return;
        }
      }

      if (!evidence && !expectedHash) {
        res.status(400).json({
          verified: false,
          status: 'TRUSTED_ORIGINAL_UNAVAILABLE',
          error: 'Cannot verify: Trusted original baseline hash is unavailable in evidence repository.'
        });
        return;
      }

      const originalHash = evidence?.sha256Hash || String(expectedHash);
      let computedHash = '';

      if (uploaded) {
        computedHash = sha256Buffer(uploaded.buffer);
      } else if (candidateBase64 && typeof candidateBase64 === 'string') {
        computedHash = sha256Buffer(Buffer.from(candidateBase64, 'base64'));
      } else if (candidateData && typeof candidateData === 'string') {
        computedHash = sha256String(candidateData);
      } else if (candidateHash && typeof candidateHash === 'string') {
        const cleanedHash = candidateHash.trim().toLowerCase();
        if (!/^[a-f0-9]{64}$/.test(cleanedHash)) {
          res.status(400).json({
            verified: false,
            status: 'INVALID_HASH_FORMAT',
            error: 'Invalid candidateHash: must be a 64-character SHA-256 hexadecimal digest.'
          });
          return;
        }
        computedHash = cleanedHash;
      } else if (verifyStoredBitstream && evidence) {
        const readRes = serverDb.readAudioBufferWithStatus(evidence);
        if (!readRes.buffer) {
          if (readRes.tampered) {
            computedHash = 'aes256gcm_authentication_failed';
          } else {
            res.status(404).json({
              verified: false,
              status: 'BITSTREAM_MISSING',
              error: 'Stored evidence audio file is missing on disk.'
            });
            return;
          }
        } else {
          computedHash = sha256Buffer(readRes.buffer);
        }
      } else {
        res.status(400).json({
          verified: false,
          status: 'CANDIDATE_DATA_REQUIRED',
          error: 'Supply candidate audio upload/bytes, candidate hash, or request stored bitstream verification.'
        });
        return;
      }

      const isMatch = computedHash.toLowerCase() === originalHash.toLowerCase();
      if (evidence) {
        serverDb.updateEvidence(evidence.id, {
          isIntegrityVerified: isMatch,
          status: isMatch ? 'Verified' : 'Failed',
          verificationDate: nowUtcString(),
          verifiedBy: user.email
        });

        appendSignedCustodyEvent({
          req,
          caseId: evidence.caseId,
          evidenceId: evidence.id,
          title: isMatch
            ? 'Cryptographic SHA-256 Hash Verification: MATCH_SUCCESS'
            : 'Cryptographic SHA-256 Hash Verification: MISMATCH_ALERT',
          actorRole: 'System',
          status: isMatch ? 'VERIFIED' : 'PENDING',
          userName: user.email,
          hashAtEvent: computedHash,
          details: isMatch
            ? 'Bitstream matches registered original baseline SHA-256.'
            : `CRITICAL ALERT: Computed hash ${computedHash.slice(0, 16)}... deviates from registered ${originalHash.slice(0, 16)}...!`
        });

        if (verifyStoredBitstream && !isMatch) {
          serverDb.addNotification({
            id: `NOTIF-TAMPER-${Date.now()}`,
            title: 'CRITICAL: Stored Evidence Bitstream Mismatch',
            description: `Evidence ${evidence.filename} (${evidence.id}) in Case ${evidence.caseId} failed stored bitstream SHA-256 verification.`,
            timestamp: 'Just now',
            read: false,
            severity: 'critical',
            caseId: evidence.caseId,
            targetRole: SYSTEM_ADMIN_ROLE
          });
        }
      }

      writeAudit(
        req,
        user.email,
        'VERIFY',
        `SHA-256 Check: ${evidence?.filename || 'Evidence Audio'} — ${isMatch ? 'MATCH_SUCCESS' : 'MISMATCH_ALERT'}`,
        isMatch ? 'SUCCESS' : 'FAILED',
        `Original: ${originalHash.slice(0, 16)}... | Computed: ${computedHash.slice(0, 16)}...`,
        user.role
      );

      res.json({
        verified: isMatch,
        status: isMatch ? 'MATCH_SUCCESS' : 'MISMATCH_ALERT',
        originalHash,
        computedHash,
        timestamp: new Date().toISOString()
      });
    }
  );

  // -------------------------------------------------------------
  // 5. AI Pipeline, Deepfake Analysis & Honest Model Status
  // -------------------------------------------------------------
  app.get('/api/ai/models-status', requireAuth, (_req, res) => {
    const models = getRegisteredModelsStatus();
    const sysConfig = serverDb.getSystemConfig();
    const geminiConfigured = Boolean(getGeminiClient());
    const geminiActive = geminiConfigured && Boolean(sysConfig.enableGeminiAdvisory);
    res.json({
      gemini: {
        name: 'Gemini 2.5 Flash Forensics Advisory',
        status: geminiActive ? 'AVAILABLE' : 'NOT_CONFIGURED',
        type: 'Cloud Advisory Engine (Opt-In)',
        description: geminiActive
          ? 'Opt-in cloud advisory active over non-PII physical DSP metrics (never substitutes for binary deepfake weights).'
          : geminiConfigured
          ? 'Configured in environment but DISABLED by system security policy (enableGeminiAdvisory = false).'
          : 'GEMINI_API_KEY not configured.'
      },
      dspEngine: models.acousticDsp,
      cnnVocoder: models.cnnVocoder,
      bilstmTemporal: models.bilstmTemporal,
      wav2vec2: models.wav2vec2,
      ecapaTdnn: models.ecapaTdnn,
      xaiGradCamShap: models.xaiGradCamShap,
      disguiseIllnessClassifier: models.disguiseIllnessClassifier
    });
  });

  app.get('/api/cases/:caseId/analyses', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const targetCase = serverDb.getCaseById(req.params.caseId);
    if (!targetCase) {
      res.status(404).json({ error: 'Case not found.' });
      return;
    }
    if (user.role !== SYSTEM_ADMIN_ROLE && !canAccessCase(user, targetCase)) {
      res.status(403).json({ error: 'Forbidden: Not assigned to this case.' });
      return;
    }
    const allAnalyses = serverDb.getDeepfakeAnalyses(targetCase.id);
    const evFilter = typeof req.query.evidenceId === 'string' ? req.query.evidenceId.trim() : '';
    res.json(evFilter ? allAnalyses.filter((a) => a.evidenceId === evFilter) : allAnalyses);
  });

  async function executeServerAudioAnalysis(params: {
    req: AuthenticatedRequest;
    user: StoredUserRecord;
    targetCase: StoredCase;
    ev: StoredEvidence;
    integrityBuffer: Buffer;
  }): Promise<{ ok: true; payload: Record<string, any> } | { ok: false; statusCode: number; error: string }> {
    const { req, user, targetCase, ev, integrityBuffer } = params;
    const dsp = extractServerAudioDsp(integrityBuffer);
    if (!dsp.isWavDecoded || !dsp.measurements) {
      return {
        ok: false,
        statusCode: 422,
        error:
          'Real PCM WAV decoding required: This audio bitstream cannot be decoded into raw PCM samples for forensic DSP analysis.'
      };
    }
    const extractedMeas = dsp.measurements;

    const adapterResults = await runDeepfakeAdaptersIsolated({
      evidenceId: ev.id,
      sha256Hash: ev.sha256Hash,
      filename: ev.filename,
      measurements: extractedMeas
    });

    const sysConfig = serverDb.getSystemConfig();
    const aiClient = getGeminiClient();
    const geminiOptInEnabled = Boolean(sysConfig.enableGeminiAdvisory);
    let geminiAssessment = '';
    if (aiClient && geminiOptInEnabled) {
      try {
        // Strict prompt hygiene (A12): never send filename or PII externally
        const prompt = `You are a digital forensics acoustic reviewer for ALFADetect.
Summarize the scientific limitations and next verification steps based STRICTLY on these measured DSP parameters (do NOT invent any deepfake probability percentage or verdict):
Mean F0: ${extractedMeas.f0MeanHz} Hz, Jitter: ${extractedMeas.jitterPercent}%, HNR: ${extractedMeas.hnrDb} dB, Spectral Centroid: ${extractedMeas.spectralCentroidHz} Hz, SNR: ${extractedMeas.estimatedSnrDb} dB.
Respond in 2 concise sentences referencing SWGDE and FRE 702 human expert review.`;
        const response = await aiClient.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
        geminiAssessment = (response.text || '').trim();
      } catch {
        geminiAssessment = '';
      }
    }

    const neuralModels = adapterResults.filter((r) => r.category === 'deepfake');
    const availableNeural = neuralModels.filter((m) => m.status === 'AVAILABLE' && typeof m.confidence === 'number');

    let finalVerdict: 'DEEPFAKE' | 'AUTHENTIC' | 'INCONCLUSIVE' = 'INCONCLUSIVE';
    let overallConfidence: number | null = null;
    let status: StoredDeepfakeAnalysis['status'] = 'INCONCLUSIVE';

    if (availableNeural.length > 0) {
      const avgConf = availableNeural.reduce((acc, m) => acc + (m.confidence || 0), 0) / availableNeural.length;
      overallConfidence = +avgConf.toFixed(1);
      const deepCount = availableNeural.filter((m) => m.verdict === 'DEEPFAKE').length;
      const authCount = availableNeural.filter((m) => m.verdict === 'AUTHENTIC').length;
      finalVerdict = deepCount > authCount ? 'DEEPFAKE' : authCount > deepCount ? 'AUTHENTIC' : 'INCONCLUSIVE';
      status = 'COMPLETED';
    }

    const nowIso = new Date().toISOString();
    const analyzedAt = nowUtcString();

    const analysisRecord: StoredDeepfakeAnalysis = {
      id: `ANL-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
      caseId: targetCase.id,
      evidenceId: ev.id,
      filename: ev.filename,
      sha256Hash: ev.sha256Hash,
      analyzedAt,
      analyzedBy: user.email,
      verdict: finalVerdict,
      overallConfidence,
      status,
      note:
        availableNeural.length > 0
          ? 'Remote deepfake inference adapters and local DSP telemetry completed.'
          : 'Physical acoustic DSP metrics extracted. Dedicated neural deepfake classifier weights (CNN, BiLSTM, Wav2Vec2) are MODEL_UNAVAILABLE; verdict remains INCONCLUSIVE pending accredited human examination.',
      pipelineMetrics: {
        spectralCentroidHz: extractedMeas.spectralCentroidHz,
        jitterPercent: extractedMeas.jitterPercent,
        shimmerPercent: extractedMeas.shimmerPercent,
        hnrDb: extractedMeas.hnrDb,
        f0MeanHz: extractedMeas.f0MeanHz,
        speechDurationSec: extractedMeas.speechDurationSec,
        estimatedSnrDb: extractedMeas.estimatedSnrDb
      },
      models: [
        ...adapterResults.map((m) => ({
          key: m.key,
          name: m.name,
          status: m.status === 'ERROR' ? ('MODEL_UNAVAILABLE' as const) : m.status,
          verdict: m.verdict,
          confidence: m.confidence ?? null,
          note: m.note,
          version: m.version
        })),
        {
          key: 'gemini',
          name: 'Gemini 2.5 Flash Advisory Engine',
          status: aiClient && geminiOptInEnabled ? 'AVAILABLE' : 'MODEL_UNAVAILABLE',
          verdict: 'INCONCLUSIVE',
          confidence: null,
          note: !aiClient
            ? 'GEMINI_API_KEY not configured.'
            : geminiOptInEnabled
            ? 'Opt-in advisory rationale active.'
            : 'Disabled by administrator policy (enableGeminiAdvisory = false).'
        }
      ],
      acousticMeasurements: extractedMeas,
      nonBiometricProfile: dsp.nonBiometricProfile || undefined
    };

    serverDb.createDeepfakeAnalysis(analysisRecord);
    serverDb.updateCase(targetCase.id, { status: 'Under Review', verdict: finalVerdict });
    serverDb.updateEvidence(ev.id, { status: 'Processed', classification: 'Pending Expert Validation' });

    appendSignedCustodyEvent({
      req,
      caseId: targetCase.id,
      evidenceId: ev.id,
      title: `Forensic Acoustic Inspection (${finalVerdict})`,
      actorRole: 'Automated',
      status: 'VERIFIED',
      userName: user.name,
      hashAtEvent: ev.sha256Hash,
      details: analysisRecord.note
    });

    writeAudit(req, user.email, 'VERIFY', `Acoustic Analysis: ${analysisRecord.filename} (${finalVerdict})`, 'SUCCESS', analysisRecord.note, user.role);

    const acousticMeasurementsList = [
      { name: 'Mean Fundamental Frequency (F0)', value: `${extractedMeas.f0MeanHz} Hz`, status: 'Measured (non-biometric)' },
      { name: 'Spectral Centroid', value: `${extractedMeas.spectralCentroidHz.toLocaleString()} Hz`, status: 'Measured (non-biometric)' },
      { name: 'Pitch Micro-Jitter', value: `${extractedMeas.jitterPercent}%`, status: 'Measured (non-biometric)' },
      { name: 'Harmonic-to-Noise Ratio (HNR)', value: `${extractedMeas.hnrDb} dB`, status: 'Measured (non-biometric)' },
      { name: 'Estimated Signal-to-Noise (SNR)', value: `${extractedMeas.estimatedSnrDb} dB`, status: 'Measured (non-biometric)' }
    ];

    const registered = getRegisteredModelsStatus();

    return {
      ok: true,
      payload: {
        ...analysisRecord,
        fileName: analysisRecord.filename,
        fileHash: analysisRecord.sha256Hash,
        overallVerdict: analysisRecord.verdict,
        syntheticProbability: overallConfidence,
        authenticProbability: overallConfidence !== null ? +(100 - overallConfidence).toFixed(1) : null,
        threatLevel: finalVerdict === 'DEEPFAKE' ? 'HIGH' : 'REQUIRES_EXPERT_REVIEW',
        modelsStatus: {
          geminiMultimodal: {
            name: 'Gemini 2.5 Flash Forensics',
            status: aiClient && geminiOptInEnabled ? 'AVAILABLE' : 'NOT_CONFIGURED',
            classification: aiClient && geminiOptInEnabled ? 'ADVISORY_ACTIVE' : 'DISABLED_OR_UNAVAILABLE',
            notes: !aiClient
              ? 'GEMINI_API_KEY not configured.'
              : geminiOptInEnabled
              ? 'Opt-in advisory active.'
              : 'Disabled by system policy (enableGeminiAdvisory = false).'
          },
          dspAcousticEngine: registered.acousticDsp,
          cnnMelSpectrogram: registered.cnnVocoder,
          bilstmTemporal: registered.bilstmTemporal,
          wav2vec2Transformer: registered.wav2vec2
        },
        acousticMeasurementsList,
        limitations:
          availableNeural.length > 0
            ? 'External neural inference output combined with DSP telemetry; accredited human verification still mandatory under FRE 702.'
            : 'CNN, BiLSTM, and Wav2Vec2 weights are MODEL_UNAVAILABLE in this environment. No synthetic/authentic probability is fabricated; only measured acoustic DSP telemetry is reported.',
        legalSummary: analysisRecord.note,
        aiAdvisory: geminiAssessment ? `AI advisory, not a finding — ${geminiAssessment}` : null,
        timestamp: nowIso
      }
    };
  }

  app.post(
    '/api/analyze-audio',
    requireAuth,
    requireRole(['Lead Forensic Analyst', 'Forensic Examiner / Expert Witness']),
    async (req: AuthenticatedRequest, res) => {
      const user = req.authUser!;
      const { caseId, evidenceId } = req.body || {};
      const runAsync = req.query.async === 'true' || req.body?.async === true;

      if (!caseId || !evidenceId) {
        res.status(400).json({ error: 'caseId and evidenceId are required for server-authoritative evidence analysis.' });
        return;
      }

      const targetCase = serverDb.getCaseById(String(caseId));
      if (!targetCase) {
        res.status(404).json({ error: 'Case docket not found.' });
        return;
      }
      if (!canAccessCase(user, targetCase)) {
        res.status(403).json({ error: `Forbidden: You are not assigned to Case ${targetCase.id}.` });
        return;
      }

      const ev = serverDb.getEvidenceById(String(evidenceId));
      if (!ev || ev.caseId !== targetCase.id) {
        res.status(404).json({ error: 'Evidence record not found in the specified case docket.' });
        return;
      }

      const integrity = verifyStoredEvidenceIntegrity(req, user, ev);
      if (!integrity.ok || !integrity.buffer) {
        res.status(integrity.buffer || integrity.tampered ? 409 : 404).json({
          error: integrity.reason || 'Evidence integrity verification failed.'
        });
        return;
      }

      if (runAsync) {
        const jobId = `JOB-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
        const job: AnalysisJobRecord = {
          jobId,
          caseId: targetCase.id,
          evidenceId: ev.id,
          requestedBy: user.email,
          status: 'QUEUED',
          createdAt: nowUtcString()
        };
        saveAnalysisJob(job);

        const integrityBuffer = integrity.buffer;
        setImmediate(async () => {
          job.status = 'PROCESSING';
          job.startedAt = nowUtcString();
          try {
            const outcome = await executeServerAudioAnalysis({
              req,
              user,
              targetCase,
              ev,
              integrityBuffer
            });
            job.completedAt = nowUtcString();
            if ('payload' in outcome) {
              job.status = 'COMPLETED';
              job.statusCode = 200;
              job.result = outcome.payload;
            } else {
              job.status = 'FAILED';
              job.statusCode = outcome.statusCode;
              job.error = outcome.error;
            }
          } catch (err: any) {
            job.status = 'FAILED';
            job.statusCode = 500;
            job.completedAt = nowUtcString();
            job.error = err?.message || 'Unexpected asynchronous forensic pipeline failure.';
          }
        });

        res.status(202).json({
          jobId,
          status: job.status,
          caseId: targetCase.id,
          evidenceId: ev.id,
          createdAt: job.createdAt,
          statusUrl: `/api/analysis-jobs/${jobId}`
        });
        return;
      }

      const outcome = await executeServerAudioAnalysis({
        req,
        user,
        targetCase,
        ev,
        integrityBuffer: integrity.buffer
      });
      if ('error' in outcome) {
        res.status(outcome.statusCode).json({ error: outcome.error });
        return;
      }
      res.json(outcome.payload);
    }
  );

  app.get(
    '/api/analysis-jobs/:jobId',
    requireAuth,
    requireRole(['Lead Forensic Analyst', 'Forensic Examiner / Expert Witness', 'Prosecutor / Legal Reviewer']),
    (req: AuthenticatedRequest, res) => {
      const user = req.authUser!;
      const job = analysisJobs.get(String(req.params.jobId || ''));
      if (!job) {
        res.status(404).json({ error: 'Analysis job not found or expired from in-memory worker queue.' });
        return;
      }
      const targetCase = serverDb.getCaseById(job.caseId);
      if (!targetCase || !canAccessCase(user, targetCase)) {
        res.status(403).json({ error: `Forbidden: You are not assigned to Case ${job.caseId}.` });
        return;
      }
      res.json({
        jobId: job.jobId,
        caseId: job.caseId,
        evidenceId: job.evidenceId,
        status: job.status,
        createdAt: job.createdAt,
        startedAt: job.startedAt,
        completedAt: job.completedAt,
        statusCode: job.statusCode,
        error: job.error,
        result: job.result
      });
    }
  );

  // -------------------------------------------------------------
  // 6. Reference Voice Samples & Honest Speaker Verification
  // -------------------------------------------------------------
  app.get('/api/cases/:caseId/references', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const targetCase = serverDb.getCaseById(req.params.caseId);
    if (!targetCase) {
      res.status(404).json({ error: 'Case not found.' });
      return;
    }
    if (user.role !== SYSTEM_ADMIN_ROLE && !canAccessCase(user, targetCase)) {
      res.status(403).json({ error: 'Forbidden: Not assigned to this case.' });
      return;
    }
    res.json(serverDb.getReferences(targetCase.id).map(sanitizeReferenceMetadata));
  });

  app.get('/api/references/:id/audio', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    if (user.role === SYSTEM_ADMIN_ROLE) {
      res.status(403).json({ error: 'Separation of Duties: Administrators cannot download reference voice audio.' });
      return;
    }
    const ref = serverDb.getReferenceById(req.params.id);
    if (!ref) {
      res.status(404).json({ error: 'Reference sample not found.' });
      return;
    }
    const targetCase = serverDb.getCaseById(ref.caseId);
    if (!targetCase || !canAccessCase(user, targetCase)) {
      res.status(403).json({ error: 'Forbidden: Case access denied.' });
      return;
    }
    const integrity = verifyReferenceIntegrity(ref);
    if (!integrity.ok || !integrity.buffer) {
      res.status(integrity.buffer ? 409 : 404).json({ error: 'Reference audio missing or failed SHA-256 integrity verification.' });
      return;
    }
    const ext = path.extname(ref.filename).toLowerCase();
    const mimeMap: Record<string, string> = {
      '.wav': 'audio/wav',
      '.mp3': 'audio/mpeg',
      '.flac': 'audio/flac',
      '.m4a': 'audio/mp4',
      '.ogg': 'audio/ogg'
    };
    res.setHeader('Content-Type', ref.mimeType || mimeMap[ext] || 'application/octet-stream');
    res.setHeader('Content-Length', String(integrity.buffer.length));
    res.send(integrity.buffer);
  });

  app.post(
    '/api/cases/:caseId/references',
    requireAuth,
    requireRole(['Lead Forensic Analyst', 'Forensic Examiner / Expert Witness']),
    optionalAudioMultipart(['audio', 'file']),
    (req: AuthenticatedRequest, res) => {
      const user = req.authUser!;
      const caseId = req.params.caseId;
      const targetCase = serverDb.getCaseById(caseId);
      if (!targetCase) {
        res.status(404).json({ error: 'Case docket not found.' });
        return;
      }
      if (!canAccessCase(user, targetCase)) {
        res.status(403).json({ error: `Forbidden: You are not assigned to Case ${caseId}.` });
        return;
      }

      const uploaded = extractUploadedFileFromReq(req);
      const body = req.body || {};
      const subjectName = String(body.subjectName || '').trim();
      const rawFilename = uploaded?.filename || String(body.filename || '').trim();
      const consentVal =
        body.lawfulConsentDeclared === true ||
        body.lawfulConsentDeclared === 'true';

      if (!subjectName || !rawFilename) {
        res.status(400).json({ error: 'Subject Name and Reference audio file/filename are required.' });
        return;
      }
      if (!consentVal) {
        res.status(400).json({
          error: 'Lawful acquisition/consent declaration is mandatory prior to enrolling a reference voice sample.'
        });
        return;
      }

      const rawBuffer = uploaded ? uploaded.buffer : body.audioData ? Buffer.from(body.audioData, 'base64') : null;
      if (!rawBuffer) {
        res.status(400).json({ error: 'Reference audio binary upload or base64 payload is required.' });
        return;
      }

      const safeFilename = path.basename(rawFilename);
      const validation = validateAudioBufferAndFilename(rawBuffer, safeFilename);
      if (!validation.valid) {
        res.status(400).json({ error: validation.error });
        return;
      }

      const sha256Hash = sha256Buffer(rawBuffer);
      const refId = `REF-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
      const storedFile = serverDb.saveAudioFile(refId, safeFilename, rawBuffer);
      const dspProbe = extractServerAudioDsp(rawBuffer);

      const newRef = serverDb.createReference({
        id: refId,
        caseId,
        subjectName,
        filename: safeFilename,
        fileSize: `${(rawBuffer.length / (1024 * 1024)).toFixed(2)} MB`,
        duration: dspProbe.isWavDecoded && dspProbe.durationSec > 0 ? `${dspProbe.durationSec.toFixed(1)}s` : 'Compressed stream',
        sha256Hash,
        conditionTag: body.conditionTag || 'Normal',
        lawfulConsentDeclared: true,
        consentNotes: String(body.consentNotes || 'Lawful voice exemplar obtained with documented authorization.').trim(),
        uploadedBy: user.name,
        uploadedAt: nowUtcString(),
        storageFilename: storedFile.storageFilename,
        byteSize: storedFile.byteSize,
        mimeType: validation.mimeType,
        detectedFormat: validation.detectedFormat
      });

      writeAudit(req, user.email, 'UPLOAD', `Reference Voice Ingested: ${subjectName} (${safeFilename})`, 'SUCCESS', `SHA-256: ${sha256Hash.slice(0, 16)}...`, user.role);
      res.status(201).json(sanitizeReferenceMetadata(newRef));
    }
  );

  app.get('/api/cases/:caseId/speaker-verifications', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const targetCase = serverDb.getCaseById(req.params.caseId);
    if (!targetCase) {
      res.status(404).json({ error: 'Case not found.' });
      return;
    }
    if (user.role !== SYSTEM_ADMIN_ROLE && !canAccessCase(user, targetCase)) {
      res.status(403).json({ error: 'Forbidden: Not assigned to this case.' });
      return;
    }
    res.json(serverDb.getSpeakerVerifications(targetCase.id));
  });

  app.post(
    '/api/speaker-verification/compare',
    requireAuth,
    requireRole(['Lead Forensic Analyst', 'Forensic Examiner / Expert Witness']),
    async (req: AuthenticatedRequest, res) => {
      const user = req.authUser!;
      const { caseId, evidenceId, referenceId } = req.body || {};
      if (!caseId || !evidenceId || !referenceId) {
        res.status(400).json({ error: 'caseId, evidenceId, and referenceId are required.' });
        return;
      }

      const targetCase = serverDb.getCaseById(caseId);
      if (!targetCase) {
        res.status(404).json({ error: 'Case docket not found.' });
        return;
      }
      if (!canAccessCase(user, targetCase)) {
        res.status(403).json({ error: `Forbidden: You are not assigned to Case ${caseId}.` });
        return;
      }

      const evidence = serverDb.getEvidenceById(evidenceId);
      if (!evidence || evidence.caseId !== caseId) {
        res.status(404).json({ error: 'Questioned evidence record not found in this case.' });
        return;
      }
      const evIntegrity = verifyStoredEvidenceIntegrity(req, user, evidence);
      if (!evIntegrity.ok || !evIntegrity.buffer) {
        res.status(evIntegrity.buffer || evIntegrity.tampered ? 409 : 404).json({
          error: evIntegrity.reason || 'Evidence integrity verification failed.'
        });
        return;
      }

      const reference = serverDb.getReferences(caseId).find((r) => r.id === referenceId);
      if (!reference) {
        res.status(404).json({ error: 'Reference voice sample not found for this case.' });
        return;
      }
      if (!reference.lawfulConsentDeclared) {
        res.status(400).json({ error: 'Compliance Block: Lawful consent declaration required on reference exemplar.' });
        return;
      }
      const refIntegrity = verifyReferenceIntegrity(reference);
      if (!refIntegrity.ok || !refIntegrity.buffer) {
        res.status(409).json({ error: 'Reference sample integrity check failed or binary missing.' });
        return;
      }

      const sysConfig = serverDb.getSystemConfig();
      const evDsp = extractServerAudioDsp(evIntegrity.buffer);
      const refDsp = extractServerAudioDsp(refIntegrity.buffer);

      if (!evDsp.isWavDecoded || !evDsp.measurements || !refDsp.isWavDecoded || !refDsp.measurements) {
        res.status(422).json({
          error:
            'Real PCM WAV decoding required: Both questioned evidence and reference exemplar must decode cleanly into PCM samples on the server.'
        });
        return;
      }

      const f0Delta = +Math.abs(evDsp.measurements.f0MeanHz - refDsp.measurements.f0MeanHz).toFixed(1);
      const spectralDistance = +(Math.abs(evDsp.measurements.spectralCentroidHz - refDsp.measurements.spectralCentroidHz) / 5000).toFixed(2);
      const jitterRatio = +(evDsp.measurements.jitterPercent / (refDsp.measurements.jitterPercent || 0.1)).toFixed(2);
      const hnrDiff = +Math.abs(evDsp.measurements.hnrDb - refDsp.measurements.hnrDb).toFixed(1);
      const speechDurationSeconds = Math.min(evDsp.measurements.speechDurationSec, refDsp.measurements.speechDurationSec);

      // Derive synthetic flag strictly server-side from persisted deepfake analysis on THIS evidence item (A3)
      const evAnalyses = serverDb.getDeepfakeAnalyses(caseId).filter((a) => a.evidenceId === evidenceId);
      const latestEvAnalysis = evAnalyses[0];
      const isSynthetic = latestEvAnalysis?.verdict === 'DEEPFAKE';
      const deepfakeUnevaluatedNote = !latestEvAnalysis
        ? ' Note: Deepfake analysis has not been run yet for this evidence item.'
        : '';

      const speakerServiceUrl = process.env.ALFADETECT_SPEAKER_SERVICE_URL?.trim();
      let verdict: 'Consistent with the same speaker' | 'Not sufficiently consistent with the same speaker' | 'Inconclusive' | 'Model unavailable' =
        speakerServiceUrl ? 'Inconclusive' : 'Model unavailable';
      let similarityScore: number | null = null;
      let decisionNote = '';

      if (speakerServiceUrl) {
        try {
          const remoteRes = await fetch(`${speakerServiceUrl.replace(/\/$/, '')}/compare`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              caseId,
              evidenceSha256: evIntegrity.computedHash,
              referenceSha256: refIntegrity.computedHash
            })
          });
          if (remoteRes.ok) {
            const payload: any = await remoteRes.json();
            if (typeof payload.similarityScore === 'number') {
              similarityScore = +payload.similarityScore.toFixed(1);
              if (isSynthetic) {
                verdict = 'Inconclusive';
                decisionNote = `Synthetic Audio Caveat: External ECAPA-TDNN scored ${similarityScore}%, but evidence exhibits synthetic indicators; identity attribution is prohibited.`;
              } else if (Math.abs(similarityScore - sysConfig.verificationThreshold) <= sysConfig.inconclusiveBand) {
                verdict = 'Inconclusive';
                decisionNote = `Inconclusive (${similarityScore}% within ±${sysConfig.inconclusiveBand}% uncertainty band around ${sysConfig.verificationThreshold}%).`;
              } else if (similarityScore >= sysConfig.verificationThreshold) {
                verdict = 'Consistent with the same speaker';
                decisionNote = `ECAPA-TDNN score ${similarityScore}% >= ${sysConfig.verificationThreshold}% threshold.${deepfakeUnevaluatedNote}`;
              } else {
                verdict = 'Not sufficiently consistent with the same speaker';
                decisionNote = `ECAPA-TDNN score ${similarityScore}% < ${sysConfig.verificationThreshold}% threshold.${deepfakeUnevaluatedNote}`;
              }
            }
          }
        } catch {
          verdict = 'Model unavailable';
          similarityScore = null;
        }
      }

      if (verdict === 'Model unavailable') {
        decisionNote =
          `ECAPA-TDNN neural speaker biometric encoder is NOT_CONFIGURED (Model unavailable). Handcrafted DSP acoustic measurements (F0, jitter, HNR, spectral centroid) are reported strictly as non-biometric measurement telemetry and are NEVER substituted for speaker identity verification.${deepfakeUnevaluatedNote}`;
      }

      const result = serverDb.createSpeakerVerification({
        id: `SPK-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
        caseId,
        evidenceId,
        referenceId,
        subjectName: reference.subjectName,
        verdict,
        similarityScore,
        threshold: sysConfig.verificationThreshold,
        speechDurationSeconds: +speechDurationSeconds.toFixed(2),
        evidenceIsSynthetic: isSynthetic,
        decisionNote,
        modelsUsed: [
          'Acoustic DSP Feature Telemetry (Non-Biometric F0, Jitter, HNR)',
          speakerServiceUrl ? 'ECAPA-TDNN External Speaker Encoder' : 'ECAPA-TDNN Speaker Encoder (MODEL_UNAVAILABLE)'
        ],
        referenceProvenance: `Enrolled Reference: ${reference.filename} (Subject: ${reference.subjectName}, Condition: ${reference.conditionTag})`,
        evidenceSha256: evIntegrity.computedHash,
        referenceSha256: refIntegrity.computedHash,
        limitations:
          'Under SWGDE and FRE 702 standards, acoustic parameters cannot establish speaker identity without calibrated biometric speaker models and accredited forensic phonetician review.',
        acousticComparison:
          f0Delta !== null
            ? {
                f0DeltaHz: f0Delta,
                spectralDistance: spectralDistance ?? 0,
                jitterRatio: jitterRatio ?? 1,
                hnrDifferenceDb: hnrDiff ?? 0
              }
            : undefined,
        analyzedAt: nowUtcString()
      });

      writeAudit(req, user.email, 'VERIFY', `Speaker Comparison (${caseId}): ${verdict}`, 'SUCCESS', decisionNote, user.role);
      res.json({
        ...result,
        measurementType: 'non-biometric measurement' as const
      });
    }
  );

  // -------------------------------------------------------------
  // 7. Voice Condition & Disguise Analysis
  // -------------------------------------------------------------
  app.get('/api/cases/:caseId/voice-disguise', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const targetCase = serverDb.getCaseById(req.params.caseId);
    if (!targetCase) {
      res.status(404).json({ error: 'Case not found.' });
      return;
    }
    if (user.role !== SYSTEM_ADMIN_ROLE && !canAccessCase(user, targetCase)) {
      res.status(403).json({ error: 'Forbidden: Not assigned to this case.' });
      return;
    }
    res.json(serverDb.getVoiceDisguises(targetCase.id));
  });

  app.post(
    '/api/voice-analysis/condition',
    requireAuth,
    requireRole(['Lead Forensic Analyst', 'Forensic Examiner / Expert Witness']),
    (req: AuthenticatedRequest, res) => {
      const user = req.authUser!;
      const { caseId, evidenceId, referenceId, context, expertNotes } = req.body || {};
      if (!caseId || !evidenceId) {
        res.status(400).json({ error: 'caseId and evidenceId are required.' });
        return;
      }
      const targetCase = serverDb.getCaseById(caseId);
      if (!targetCase) {
        res.status(404).json({ error: 'Case not found.' });
        return;
      }
      if (!canAccessCase(user, targetCase)) {
        res.status(403).json({ error: 'Forbidden: Not assigned to this case.' });
        return;
      }

      const evidence = serverDb.getEvidenceById(evidenceId);
      if (!evidence || evidence.caseId !== caseId) {
        res.status(404).json({ error: 'Evidence record not found.' });
        return;
      }
      const integrity = verifyStoredEvidenceIntegrity(req, user, evidence);
      if (!integrity.ok || !integrity.buffer) {
        res.status(integrity.buffer || integrity.tampered ? 409 : 404).json({
          error: integrity.reason || 'Evidence integrity verification failed.'
        });
        return;
      }

      let reference: StoredReferenceSample | undefined;
      let refBuf: Buffer | undefined;
      if (referenceId) {
        reference = serverDb.getReferences(caseId).find((r) => r.id === referenceId);
        if (!reference) {
          res.status(404).json({ error: 'Reference sample not found for this case.' });
          return;
        }
        const refCheck = verifyReferenceIntegrity(reference);
        if (!refCheck.ok || !refCheck.buffer) {
          res.status(409).json({ error: 'Reference audio missing or failed integrity verification.' });
          return;
        }
        refBuf = refCheck.buffer;
      }

      const evalOut = evaluateDisguiseWithServerDsp({
        questionedBuffer: integrity.buffer,
        referenceBuffer: refBuf
      });

      const qMeas = evalOut.qMeas;
      if (!qMeas) {
        res.status(422).json({
          error: 'Audio decoding required: Questioned evidence must be a decodable PCM WAV bitstream for voice condition analysis.'
        });
        return;
      }

      const hypotheses = evaluateVoiceConditionHypotheses(qMeas, evalOut.rMeas || undefined, context);
      const audioQualityStatus: 'Sufficient for analysis' | 'Marginal' | 'Insufficient for analysis' =
        qMeas.speechDurationSec < 2 || qMeas.estimatedSnrDb < 8
          ? 'Insufficient for analysis'
          : qMeas.estimatedSnrDb < 14
          ? 'Marginal'
          : 'Sufficient for analysis';

      const result = serverDb.createVoiceDisguise({
        id: `VDIS-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
        caseId,
        evidenceId,
        questionedFilename: evidence.filename,
        referenceFilename: reference?.filename,
        evidenceSha256: integrity.computedHash,
        audioQualityStatus,
        acousticMeasurements: qMeas,
        referenceMeasurements: evalOut.rMeas || undefined,
        hypotheses,
        overallSummary: `Multi-hypothesis acoustic inspection completed on ${evidence.filename} (${qMeas.speechDurationSec}s voiced, Mean F0 ${qMeas.f0MeanHz} Hz, Jitter ${qMeas.jitterPercent}%, HNR ${qMeas.hnrDb} dB).`,
        scientificLimitations:
          'Acoustic measurements evaluate physical speech signal parameters only. Trained neural vocal pathology/disguise classifiers remain unconfigured; no intent or medical diagnosis is asserted.',
        expertNotes: expertNotes ? String(expertNotes).trim() : undefined,
        analyzedAt: nowUtcString()
      });

      writeAudit(req, user.email, 'VERIFY', `Voice Condition Analysis for Evidence ${evidenceId}`, 'SUCCESS', undefined, user.role);
      res.json(result);
    }
  );

  // -------------------------------------------------------------
  // 8. Chain of Custody, Expert Reviews (Re-Auth + Ed25519) & Legal Reviews
  // -------------------------------------------------------------
  app.get('/api/cases/:caseId/chain-of-custody', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const targetCase = serverDb.getCaseById(req.params.caseId);
    if (!targetCase) {
      res.status(404).json({ error: 'Case not found.' });
      return;
    }
    if (user.role !== SYSTEM_ADMIN_ROLE && !canAccessCase(user, targetCase)) {
      res.status(403).json({ error: 'Forbidden: Not assigned to this case.' });
      return;
    }
    res.json(serverDb.getChainOfCustody(targetCase.id));
  });

  app.get('/api/cases/:caseId/chain-of-custody/verify', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const targetCase = serverDb.getCaseById(req.params.caseId);
    if (!targetCase) {
      res.status(404).json({ error: 'Case not found.' });
      return;
    }
    if (user.role !== SYSTEM_ADMIN_ROLE && !canAccessCase(user, targetCase)) {
      res.status(403).json({ error: 'Forbidden: Not assigned to this case.' });
      return;
    }
    const events = serverDb.getChainOfCustody(targetCase.id);
    const verification = verifyCustodyChain(events);
    res.json(verification);
  });

  app.get('/api/cases/:caseId/expert-reviews', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const targetCase = serverDb.getCaseById(req.params.caseId);
    if (!targetCase) {
      res.status(404).json({ error: 'Case not found.' });
      return;
    }
    if (user.role !== SYSTEM_ADMIN_ROLE && !canAccessCase(user, targetCase)) {
      res.status(403).json({ error: 'Forbidden: Not assigned to this case.' });
      return;
    }
    res.json(serverDb.getExpertReviews(targetCase.id));
  });

  app.post(
    '/api/cases/:caseId/expert-reviews',
    requireAuth,
    requireRole(['Forensic Examiner / Expert Witness', 'Lead Forensic Analyst']),
    (req: AuthenticatedRequest, res) => {
      const user = req.authUser!;
      const caseId = req.params.caseId;
      const targetCase = serverDb.getCaseById(caseId);
      if (!targetCase) {
        res.status(404).json({ error: 'Case not found.' });
        return;
      }
      if (!canAccessCase(user, targetCase)) {
        res.status(403).json({ error: `Forbidden: You are not assigned to Case ${caseId}.` });
        return;
      }

      const { currentPassword, totpCode, status, technicalAssessment, overrideVerdict, overrideReason, checklist } = req.body || {};

      if (!currentPassword) {
        res.status(400).json({ error: 'Password re-authentication is required to sign an expert witness review.' });
        return;
      }
      if (!verifyPassword(currentPassword, user.salt, user.passwordHash)) {
        writeAudit(req, user.email, 'SIGN', `Rejected Expert Signature (Invalid Password) on ${caseId}`, 'FAILED', undefined, user.role);
        res.status(401).json({ error: 'Credential verification failed: Incorrect password.' });
        return;
      }

      let authMethodUsed: 'PASSWORD_REAUTH' | 'PASSWORD_AND_TOTP' = 'PASSWORD_REAUTH';
      if (user.twoFactorEnabled) {
        const totpCheck = verifyTotpWithReplayGuard(user, String(totpCode || ''));
        if (!totpCheck.ok) {
          writeAudit(req, user.email, 'SIGN', `Rejected Expert Signature (Invalid TOTP) on ${caseId}`, 'FAILED', totpCheck.error, user.role);
          res.status(401).json({ error: totpCheck.error || 'Valid 6-digit TOTP authenticator code is required because 2FA is active.' });
          return;
        }
        authMethodUsed = 'PASSWORD_AND_TOTP';
      }

      const assessment = String(technicalAssessment || '').trim();
      if (assessment.length < 10) {
        res.status(400).json({ error: 'Technical Assessment commentary (at least 10 characters) is required.' });
        return;
      }

      if (
        !checklist ||
        !checklist.swgdeStandards ||
        !checklist.chainOfCustodyVerified ||
        !checklist.reproducibleOutputs ||
        !checklist.confidenceIntervalsValid
      ) {
        res.status(400).json({
          error: 'All 4 mandatory SWGDE / FRE 702 verification checklist items must be explicitly confirmed.'
        });
        return;
      }

      const evList = serverDb.getEvidence(caseId);
      if (evList.length === 0) {
        res.status(400).json({ error: 'Cannot sign expert review: Case has zero registered evidence files.' });
        return;
      }
      for (const ev of evList) {
        const check = verifyStoredEvidenceIntegrity(req, user, ev);
        if (!check.ok) {
          res.status(409).json({ error: check.reason || `Evidence ${ev.id} failed SHA-256 verification.` });
          return;
        }
      }

      if (overrideVerdict && overrideVerdict !== targetCase.verdict && (!overrideReason || !String(overrideReason).trim())) {
        res.status(400).json({ error: 'Written justification (overrideReason) is required when changing the case verdict.' });
        return;
      }

      if (overrideVerdict && ['DEEPFAKE', 'AUTHENTIC', 'INCONCLUSIVE'].includes(overrideVerdict)) {
        serverDb.updateCase(caseId, { verdict: overrideVerdict, status: 'Pending Legal' });
      } else {
        serverDb.updateCase(caseId, { status: 'Pending Legal' });
      }

      const signedAt = nowUtcString();
      const reviewId = `EXP-REV-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
      const certId = user.certificationId || `CRED-${user.id}`;
      const sig = signCanonicalPayload({
        reviewId,
        caseId,
        expertUserId: user.id,
        expertEmail: user.email,
        certificationId: certId,
        status: status || 'Approved',
        assessmentSha256: sha256String(assessment),
        signedAt
      });

      const createdReview = serverDb.createExpertReview({
        id: reviewId,
        caseId,
        expertUserId: user.id,
        expertName: user.name,
        email: user.email,
        institution: user.agency,
        certificationId: certId,
        status: status && ['Approved', 'Pending', 'Disputed'].includes(status) ? status : 'Approved',
        technicalAssessment: assessment,
        overrideReason: overrideReason ? String(overrideReason).trim() : undefined,
        checklist: {
          swgdeStandards: Boolean(checklist.swgdeStandards),
          chainOfCustodyVerified: Boolean(checklist.chainOfCustodyVerified),
          reproducibleOutputs: Boolean(checklist.reproducibleOutputs),
          confidenceIntervalsValid: Boolean(checklist.confidenceIntervalsValid),
          acousticSpectralInspected: Boolean(checklist.acousticSpectralInspected)
        },
        digitalSignature: sig.signatureDisplay,
        signedAt,
        authMethodUsed,
        biometricVerified: false,
        biometricScore: null
      });

      appendSignedCustodyEvent({
        req,
        caseId,
        evidenceId: evList[0].id,
        title: `Expert Witness Review Certified (${createdReview.status})`,
        actorRole: 'Expert',
        status: 'VERIFIED',
        userName: user.name,
        hashAtEvent: evList[0].sha256Hash,
        details: `Signed via ${authMethodUsed} by ${user.name} (${certId})`
      });

      writeAudit(req, user.email, 'SIGN', `Expert Review Certified: Case ${caseId} (${reviewId})`, 'SUCCESS', `Auth: ${authMethodUsed} | KeyId: ${sig.keyId}`, user.role);
      res.status(201).json(createdReview);
    }
  );

  // Disabled/Honest Biometric Mock Removal Guard
  app.post('/api/biometrics/*', requireAuth, (_req, res) => {
    res.status(501).json({
      error: 'Simulated optical/vector biometric hardware is disabled. Use credential re-authentication + TOTP 2FA on Expert Witness Certification.'
    });
  });

  app.get('/api/cases/:caseId/legal-review', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const caseId = req.params.caseId;
    const targetCase = serverDb.getCaseById(caseId);
    if (!targetCase) {
      res.status(404).json({ error: 'Case not found.' });
      return;
    }
    if (user.role !== SYSTEM_ADMIN_ROLE && !canAccessCase(user, targetCase)) {
      res.status(403).json({ error: 'Forbidden: Not assigned to this case.' });
      return;
    }

    const existing = serverDb.getLegalReview(caseId);
    if (existing) {
      res.json(existing);
      return;
    }

    const evidence = serverDb.getEvidence(caseId);
    const coc = serverDb.getChainOfCustody(caseId);
    const analyses = serverDb.getDeepfakeAnalyses(caseId);
    const reviews = serverDb.getExpertReviews(caseId);

    const items: Array<{ id: string; label: string; status: 'COMPLETE' | 'PENDING' }> = [
      { id: '1', label: 'Chain of custody documented and cryptographically verified', status: coc.length > 0 && verifyCustodyChain(coc).valid ? 'COMPLETE' : 'PENDING' },
      { id: '2', label: 'Evidence bitstream ingested & hashed (SHA-256)', status: evidence.some((e) => e.isIntegrityVerified && e.status !== 'Failed') ? 'COMPLETE' : 'PENDING' },
      { id: '3', label: 'Acoustic / AI methodology & limitations disclosed', status: analyses.length > 0 ? 'COMPLETE' : 'PENDING' },
      { id: '4', label: 'Accredited expert witness review signed (Ed25519)', status: reviews.some((r) => r.status === 'Approved') ? 'COMPLETE' : 'PENDING' },
      { id: '5', label: 'Daubert / FRE 702 admissibility review', status: 'PENDING' },
      { id: '6', label: 'Judicial chain provenance inspection', status: 'PENDING' }
    ];

    const completed = items.filter((i) => i.status === 'COMPLETE').length;
    res.json({
      caseId,
      legalCounsel: 'Pending Counsel Assignment',
      jurisdiction: 'Federal District Court',
      status: 'UNDER REVIEW',
      readinessProgress: `${completed}/${items.length} Complete`,
      items
    });
  });

  app.post(
    '/api/cases/:caseId/legal-review',
    requireAuth,
    requireRole(['Prosecutor / Legal Reviewer', 'Lead Forensic Analyst']),
    (req: AuthenticatedRequest, res) => {
      const user = req.authUser!;
      const caseId = req.params.caseId;
      const targetCase = serverDb.getCaseById(caseId);
      if (!targetCase) {
        res.status(404).json({ error: 'Case not found.' });
        return;
      }
      if (!canAccessCase(user, targetCase)) {
        res.status(403).json({ error: 'Forbidden: Not assigned to this case.' });
        return;
      }

      const { items, status, jurisdiction, notes } = req.body || {};
      if (!Array.isArray(items) || items.length === 0) {
        res.status(400).json({ error: 'Checklist items array is required.' });
        return;
      }

      const finalStatus = status && ['UNDER REVIEW', 'CERTIFIED', 'REJECTED'].includes(status) ? status : 'UNDER REVIEW';
      if (finalStatus === 'CERTIFIED') {
        const reviews = serverDb.getExpertReviews(caseId);
        if (!reviews.some((r) => r.status === 'Approved')) {
          res.status(400).json({ error: 'Cannot certify legal admissibility until an Expert Witness Review is Approved and signed.' });
          return;
        }
        const cocCheck = verifyCustodyChain(serverDb.getChainOfCustody(caseId));
        if (!cocCheck.valid || cocCheck.checkedCount === 0) {
          res.status(400).json({ error: `Cannot certify legal admissibility: Chain of custody invalid (${cocCheck.reason || 'empty'}).` });
          return;
        }
      }

      const completed = items.filter((i: any) => i.status === 'COMPLETE').length;
      const now = nowUtcString();

      const saved = serverDb.saveLegalReview({
        caseId,
        legalCounsel: user.name,
        jurisdiction: jurisdiction || 'Federal District Court',
        status: finalStatus,
        readinessProgress: `${completed}/${items.length} Complete`,
        items,
        notes: notes ? String(notes).trim() : undefined,
        certifiedAt: finalStatus === 'CERTIFIED' ? now : undefined,
        certifiedBy: finalStatus === 'CERTIFIED' ? user.email : undefined
      });

      if (finalStatus === 'CERTIFIED') {
        serverDb.updateCase(caseId, { status: 'Completed' });
        appendSignedCustodyEvent({
          req,
          caseId,
          title: 'Legal Admissibility Certified (FRE 702 / 902)',
          actorRole: 'Legal',
          status: 'VERIFIED',
          userName: user.name,
          details: `Certified for court admissibility (${saved.jurisdiction})`
        });
      }

      writeAudit(req, user.email, 'SIGN', `Legal Review Saved for Case ${caseId}: ${finalStatus}`, 'SUCCESS', saved.readinessProgress, user.role);
      res.json(saved);
    }
  );

  // -------------------------------------------------------------
  // 9. Report Export & Ed25519 Public Verification Ledger
  // -------------------------------------------------------------
  app.get('/api/cases/:caseId/public-report', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const targetCase = serverDb.getCaseById(req.params.caseId);
    if (!targetCase) {
      res.status(404).json({ error: 'Case not found.' });
      return;
    }
    if (user.role !== SYSTEM_ADMIN_ROLE && !canAccessCase(user, targetCase)) {
      res.status(403).json({ error: 'Forbidden: Not assigned to this case.' });
      return;
    }
    const reports = serverDb.getPublicReports().filter((r) => r.caseId === req.params.caseId);
    const latest = reports.length > 0 ? reports[0] : null;
    res.json({ record: latest });
  });

  app.post('/api/cases/:caseId/report-export', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    if (user.role === SYSTEM_ADMIN_ROLE) {
      res.status(403).json({ error: 'Separation of Duties: System Security Administrators cannot export forensic case reports.' });
      return;
    }

    const caseId = req.params.caseId;
    const targetCase = serverDb.getCaseById(caseId);
    if (!targetCase) {
      res.status(404).json({ error: 'Case docket not found.' });
      return;
    }
    if (!canAccessCase(user, targetCase)) {
      writeAudit(req, user.email, 'WRITE', `Unauthorized Report Export Attempt: ${caseId}`, 'FAILED', undefined, user.role);
      res.status(403).json({ error: `Forbidden: You are not assigned to Case ${caseId}.` });
      return;
    }

    const { format = 'PDF', reportType = 'preliminary' } = req.body || {};
    const evidenceList = serverDb.getEvidence(caseId);
    if (evidenceList.length === 0) {
      res.status(400).json({ error: 'Cannot export forensic report: No evidence files registered on this case.' });
      return;
    }

    // Live SHA-256 recomputation on EVERY evidence record prior to export
    for (const ev of evidenceList) {
      const check = verifyStoredEvidenceIntegrity(req, user, ev);
      if (!check.ok) {
        res.status(409).json({
          error: check.reason || `Cannot export report: Evidence ${ev.filename} failed live SHA-256 verification.`
        });
        return;
      }
    }

    const cocEvents = serverDb.getChainOfCustody(caseId);
    const cocVerify = verifyCustodyChain(cocEvents);
    if (!cocVerify.valid) {
      res.status(409).json({ error: `Cannot export report: Chain of custody integrity broken (${cocVerify.reason}).` });
      return;
    }

    const reviews = serverDb.getExpertReviews(caseId);
    const approvedReview = reviews.find((r) => r.status === 'Approved');
    const legalReview = serverDb.getLegalReview(caseId);

    const isFinal = String(reportType).toLowerCase() === 'final';
    if (isFinal) {
      if (!approvedReview) {
        res.status(400).json({ error: 'Final Forensic Report blocked: An Approved & signed Expert Witness Review is required.' });
        return;
      }
      if (!legalReview || legalReview.status !== 'CERTIFIED') {
        res.status(400).json({ error: 'Final Forensic Report blocked: Legal Admissibility Review must be CERTIFIED first.' });
        return;
      }
    }

    const analyses = serverDb.getDeepfakeAnalyses(caseId);
    const speakerVerifications = serverDb.getSpeakerVerifications(caseId);
    const voiceDisguises = serverDb.getVoiceDisguises(caseId);
    const references = serverDb.getReferences(caseId).map(sanitizeReferenceMetadata);
    const sysConfig = serverDb.getSystemConfig();
    const activeEv = evidenceList[0];

    const signedAt = nowUtcString();
    const reportId = `DSR-${new Date().getFullYear()}-${caseId.replace(/[^A-Z0-9]/g, '').slice(-4)}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
    const verifyToken = `VRF-${caseId.replace(/[^A-Z0-9]/g, '').slice(-4)}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;

    const canonicalPayload = buildPublicReportCanonicalPayload({
      reportId,
      caseId,
      evidenceId: activeEv.id,
      evidenceSha256: activeEv.sha256Hash,
      verdict: targetCase.verdict,
      leadAnalyst: targetCase.analyst,
      expertWitness: approvedReview?.expertName || user.name,
      signedAt
    });
    const sig = signCanonicalPayload(canonicalPayload);

    const publicRecord: StoredPublicReport = {
      token: verifyToken,
      reportId,
      caseId,
      evidenceId: activeEv.id,
      evidenceFilename: activeEv.filename,
      evidenceSha256: activeEv.sha256Hash,
      verdict: targetCase.verdict,
      confidenceScore: analyses[0]?.overallConfidence ?? null,
      leadAnalyst: targetCase.analyst,
      expertWitness: approvedReview?.expertName || `${user.name} (Preliminary Draft)`,
      expertCertificationId: approvedReview?.certificationId || user.certificationId || 'PRELIMINARY',
      signatureMethod: `Ed25519 (${sig.keyId})`,
      biometricVerified: false,
      biometricScore: null,
      biometricTechnology: isFinal ? 'Credential + Enclave Ed25519 Seal' : 'Preliminary Export Seal',
      signedAt,
      digitalSealHash: sig.payloadHash,
      digitalSignature: sig.signatureDisplay,
      revoked: false,
      tampered: false
    };

    serverDb.savePublicReport(publicRecord);

    appendSignedCustodyEvent({
      req,
      caseId,
      evidenceId: activeEv.id,
      title: `Forensic Report Exported (${String(format).toUpperCase()} — ${isFinal ? 'FINAL COURT CERTIFIED' : 'PRELIMINARY'})`,
      actorRole: user.role === 'Lead Forensic Analyst' ? 'Lead Analyst' : user.role === 'Prosecutor / Legal Reviewer' ? 'Legal' : 'Expert',
      status: 'VERIFIED',
      userName: user.name,
      hashAtEvent: activeEv.sha256Hash,
      details: `Report ID: ${reportId} | Verification Token: ${verifyToken}`
    });

    writeAudit(
      req,
      user.email,
      'WRITE',
      `Forensic Report Exported (${String(format).toUpperCase()}) for Case ${caseId}`,
      'SUCCESS',
      `Type: ${reportType} | ReportID: ${reportId} | Token: ${verifyToken}`,
      user.role
    );

    res.json({
      success: true,
      reportId,
      verifyToken,
      digitalSealHash: sig.payloadHash,
      digitalSignature: sig.signatureDisplay,
      signatureMethod: `Ed25519:${sig.keyId}`,
      reportType: isFinal ? 'FINAL' : 'PRELIMINARY',
      manifest: {
        reportId,
        generatedAt: signedAt,
        generatedBy: user.name,
        reportType: isFinal ? 'FINAL CERTIFIED FORENSIC REPORT' : 'PRELIMINARY INVESTIGATIVE REPORT',
        verifyToken,
        digitalSealHash: sig.payloadHash,
        digitalSignature: sig.signatureDisplay,
        case: targetCase,
        evidence: evidenceList.map(sanitizeEvidenceMetadata),
        evidenceLineage: evidenceList.map((e) => ({
          id: e.id,
          filename: e.filename,
          parentEvidenceId: e.parentEvidenceId || null,
          isDerivedCopy: Boolean(e.isDerivedCopy),
          processingOperation: e.processingOperation || null,
          sha256Hash: e.sha256Hash
        })),
        references,
        analyses,
        speakerVerifications,
        voiceDisguises,
        chainOfCustodyVerification: cocVerify,
        chainOfCustody: cocEvents,
        expertReviews: reviews,
        legalReview: legalReview || null,
        modelsStatus: getRegisteredModelsStatus(),
        systemConfig: {
          verificationThreshold: sysConfig.verificationThreshold,
          inconclusiveBand: sysConfig.inconclusiveBand,
          minSpeechDurationSec: sysConfig.minSpeechDurationSec,
          thresholdVersion: sysConfig.thresholdVersion
        },
        scientificLimitations:
          'Probabilistic decision support only — never standalone proof of identity or authorship. All deepfake classification models and biometric speaker encoders remain subject to MODEL_UNAVAILABLE disclosures unless external trained checkpoints are configured. Automated DSP telemetry constitutes non-biometric measurement and never replaces accredited forensic human expert evaluation under SWGDE and Federal Rule of Evidence 702.'
      }
    });
  });

  app.get('/api/public/verify-report/:token', (req, res) => {
    const token = String(req.params.token || '').trim();
    const record = serverDb.getPublicReports().find((r) => r.token === token);

    if (!record) {
      res.status(404).json({
        verified: false,
        status: 'NOT_FOUND',
        error: 'Verification Failed: No exported forensic report matches this verification token in the enclave ledger.'
      });
      return;
    }
    if (record.revoked) {
      res.status(400).json({
        verified: false,
        status: 'REVOKED',
        error: 'Report Revoked: This forensic report was formally revoked by the issuing authority.'
      });
      return;
    }

    let sigOk = false;
    if (record.digitalSignature?.startsWith('Ed25519:')) {
      sigOk = verifyCanonicalPayload(
        buildPublicReportCanonicalPayload({
          reportId: record.reportId,
          caseId: record.caseId,
          evidenceId: record.evidenceId,
          evidenceSha256: record.evidenceSha256,
          verdict: record.verdict,
          leadAnalyst: record.leadAnalyst,
          expertWitness: record.expertWitness,
          signedAt: record.signedAt
        }),
        record.digitalSignature
      );
    }

    let liveEvidenceIntact = true;
    const ev = serverDb.getEvidenceById(record.evidenceId);
    if (ev) {
      const readRes = serverDb.readAudioBufferWithStatus(ev);
      if (readRes.tampered || !readRes.buffer || sha256Buffer(readRes.buffer).toLowerCase() !== record.evidenceSha256.toLowerCase()) {
        liveEvidenceIntact = false;
      }
    }

    if (record.tampered || !sigOk || !liveEvidenceIntact) {
      res.status(400).json({
        verified: false,
        status: 'TAMPERED',
        error: !sigOk
          ? 'Tamper Alert: Ed25519 cryptographic signature failed verification against enclave public key.'
          : 'Tamper Alert: Live evidence audio ciphertext or SHA-256 differs from certified report digest.'
      });
      return;
    }

    res.json({
      verified: true,
      status: 'VERIFIED',
      token: record.token,
      reportId: record.reportId,
      caseId: record.caseId,
      evidenceId: record.evidenceId,
      evidenceFilename: record.evidenceFilename,
      evidenceSha256: record.evidenceSha256,
      verdict: record.verdict,
      confidenceScore: record.confidenceScore !== null ? record.confidenceScore : 'Expert Reviewed / N/A',
      leadAnalyst: record.leadAnalyst,
      expertWitness: record.expertWitness,
      expertCertificationId: record.expertCertificationId,
      signatureMethod: record.signatureMethod,
      biometricVerificationStatus: record.biometricVerified ? 'Hardware Verified' : 'Credential + Ed25519 Enclave Seal',
      biometricScore: record.biometricScore !== null ? `${record.biometricScore}%` : 'N/A',
      biometricTechnology: record.biometricTechnology,
      signedAt: record.signedAt,
      digitalSealHash: record.digitalSealHash,
      verificationTimestamp: nowUtcString()
    });
  });

  // -------------------------------------------------------------
  // 10. Dashboard Stats, Targeted Notifications & Audit Logs
  // -------------------------------------------------------------
  app.get('/api/dashboard/stats', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    if (user.role === SYSTEM_ADMIN_ROLE) {
      const users = serverDb.getUsers();
      res.json({
        totalCases: serverDb.getCases().length,
        activeCases: serverDb.getCases().filter((c) => c.status === 'Active' || c.status === 'Under Review').length,
        deepfakeDetected: 0,
        authenticAudio: 0,
        reportsGenerated: serverDb.getPublicReports().length,
        evidenceVerified: serverDb.getEvidence().filter((e) => e.isIntegrityVerified).length,
        totalUsers: users.length,
        pendingUsers: users.filter((u) => u.status === 'pending').length
      });
      return;
    }
    const accessible = getAccessibleCasesForUser(user);
    res.json(serverDb.getStats(accessible));
  });

  app.get('/api/notifications', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    res.json(serverDb.getNotifications({ id: user.id, email: user.email, role: user.role }));
  });

  app.patch('/api/notifications/:id/read', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const notification = serverDb.getNotificationById(req.params.id);
    if (!notification) {
      res.status(404).json({ error: 'Notification not found.' });
      return;
    }
    const ownsTarget =
      (notification.targetUserId && notification.targetUserId === user.id) ||
      (notification.targetEmail && notification.targetEmail.toLowerCase() === user.email.toLowerCase()) ||
      (notification.targetRole && notification.targetRole === user.role) ||
      (!notification.targetUserId && !notification.targetEmail && !notification.targetRole);

    if (!ownsTarget) {
      res.status(403).json({ error: 'Forbidden: You cannot modify notifications belonging to another operator.' });
      return;
    }
    res.json({ success: serverDb.markNotificationAsRead(req.params.id) });
  });

  app.post('/api/notifications/read-all', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const count = serverDb.markAllNotificationsAsRead({ id: user.id, email: user.email, role: user.role });
    res.json({ success: true, count });
  });

  app.get(
    '/api/audit-logs',
    requireAuth,
    requireRole([SYSTEM_ADMIN_ROLE, 'Lead Forensic Analyst', 'Prosecutor / Legal Reviewer']),
    (req: AuthenticatedRequest, res) => {
      const user = req.authUser!;
      const allLogs = serverDb.getAuditLogs();
      if (user.role === SYSTEM_ADMIN_ROLE) {
        res.json(allLogs);
        return;
      }
      const userEmailLower = user.email.toLowerCase();
      const accessibleCaseIds = getAccessibleCasesForUser(user, true).map((c) => c.id);
      const filtered = allLogs.filter((entry) => {
        if (entry.user.toLowerCase() === userEmailLower) return true;
        const text = `${entry.resource} ${entry.details || ''}`;
        return accessibleCaseIds.some((cid) => text.includes(cid));
      });
      res.json(filtered);
    }
  );

  // Strict JSON 404 catch-all for any unmapped /api/* routes (A10)
  app.all('/api/*', (req, res) => {
    res.status(404).json({ error: `API route not found: ${req.method} ${req.path}` });
  });

  return app;
}

export async function startServer() {
  const app = createApp();
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  return app.listen(PORT, '0.0.0.0', () => {
    console.log(`ALFADetect Forensic Server listening on port ${PORT}`);
  });
}

if (process.env.ALFADETECT_DISABLE_AUTO_LISTEN !== '1') {
  startServer();
}
