import fs from 'fs';
import os from 'os';
import path from 'path';
import http from 'http';
import crypto from 'crypto';
import assert from 'node:assert/strict';

function fileSha256IfExists(filePath: string): string | null {
  if (!fs.existsSync(filePath)) return null;
  const buf = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(buf).digest('hex');
}

function buildSynthesizedWav(durationSec: number = 2.0, sampleRate: number = 16000, f0Hz: number = 155): Buffer {
  const numSamples = Math.floor(durationSec * sampleRate);
  const dataSize = numSamples * 2;
  const buffer = Buffer.alloc(44 + dataSize);

  buffer.write('RIFF', 0);
  buffer.writeUInt32LE(36 + dataSize, 4);
  buffer.write('WAVE', 8);
  buffer.write('fmt ', 12);
  buffer.writeUInt32LE(16, 16); // PCM
  buffer.writeUInt16LE(1, 20);  // linear PCM
  buffer.writeUInt16LE(1, 22);  // mono
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(sampleRate * 2, 28);
  buffer.writeUInt16LE(2, 32);
  buffer.writeUInt16LE(16, 34);
  buffer.write('data', 36);
  buffer.writeUInt32LE(dataSize, 40);

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    const val =
      0.5 * Math.sin(2 * Math.PI * f0Hz * t) +
      0.22 * Math.sin(2 * Math.PI * f0Hz * 2 * t) +
      0.1 * Math.sin(2 * Math.PI * f0Hz * 3 * t);
    const clamped = Math.max(-1, Math.min(1, val));
    buffer.writeInt16LE(Math.round(clamped * 32767), 44 + i * 2);
  }
  return buffer;
}

interface HttpResult {
  status: number;
  data: any;
  text: string;
}

async function apiJson(
  baseUrl: string,
  method: string,
  urlPath: string,
  token?: string,
  body?: unknown,
  extraHeaders: Record<string, string> = {}
): Promise<HttpResult> {
  const headers: Record<string, string> = { ...extraHeaders };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  if (body !== undefined) headers['Content-Type'] = 'application/json';

  const res = await fetch(`${baseUrl}${urlPath}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined
  });
  const text = await res.text();
  let data: any = null;
  try {
    data = JSON.parse(text);
  } catch {
    data = null;
  }
  return { status: res.status, data, text };
}

async function apiMultipart(
  baseUrl: string,
  urlPath: string,
  token: string,
  fields: Record<string, string>,
  file?: { fieldName: string; filename: string; contentType: string; bytes: Buffer }
): Promise<HttpResult> {
  const form = new FormData();
  for (const [k, v] of Object.entries(fields)) {
    form.append(k, v);
  }
  if (file) {
    const blob = new Blob([new Uint8Array(file.bytes)], { type: file.contentType });
    form.append(file.fieldName, blob, file.filename);
  }

  const res = await fetch(`${baseUrl}${urlPath}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: form
  });
  const text = await res.text();
  let data: any = null;
  try {
    data = JSON.parse(text);
  } catch {
    data = null;
  }
  return { status: res.status, data, text };
}

interface TestRecord {
  name: string;
  passed: boolean;
  error?: string;
}

const results: TestRecord[] = [];

async function testCase(name: string, fn: () => Promise<void> | void) {
  try {
    await fn();
    results.push({ name, passed: true });
    console.log(`  [PASS] ${name}`);
  } catch (err: any) {
    results.push({ name, passed: false, error: err?.message || String(err) });
    console.error(`  [FAIL] ${name}: ${err?.message || err}`);
  }
}

async function main() {
  console.log('===================================================================');
  console.log('  ALFADetect — ISOLATED QA, SECURITY & END-TO-END ACCEPTANCE SUITE ');
  console.log('===================================================================\n');

  const realStorePath = path.join(process.cwd(), 'data', 'alfadetect_store.json');
  const realBackupPath = path.join(process.cwd(), 'data', 'alfadetect_store.json.bak');
  const realStoreHashBefore = fileSha256IfExists(realStorePath);
  const realBackupHashBefore = fileSha256IfExists(realBackupPath);

  const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'alfadetect-qa-'));
  const tmpDbPath = path.join(tmpRoot, 'test_store.json');
  const tmpUploadDir = path.join(tmpRoot, 'uploads');
  const tmpKeyDir = path.join(tmpRoot, 'keys');
  fs.mkdirSync(tmpUploadDir, { recursive: true });
  fs.mkdirSync(tmpKeyDir, { recursive: true });

  // Configure strictly isolated environment BEFORE importing server modules
  process.env.ALFADETECT_DISABLE_AUTO_LISTEN = '1';
  process.env.ALFADETECT_DB_PATH = tmpDbPath;
  process.env.ALFADETECT_UPLOAD_DIR = tmpUploadDir;
  process.env.ALFADETECT_KEY_DIR = tmpKeyDir;
  process.env.JWT_SECRET = 'isolated_qa_test_jwt_secret_key_9f8e7d6c5b4a3210';
  process.env.ALFADETECT_MASTER_KEY = 'isolated_qa_master_encryption_key_32_bytes_seed';
  delete process.env.ADMIN_INIT_TOKEN;
  delete process.env.ALFADETECT_AI_SERVICE_URL;
  delete process.env.ALFADETECT_SPEAKER_SERVICE_URL;

  const [rbac, audioDsp, serverDbMod, serverSecMod, serverMod] = await Promise.all([
    import('../src/utils/rbac'),
    import('../src/utils/audioDsp'),
    import('../serverDb'),
    import('../serverSecurity'),
    import('../server')
  ]);

  const { serverDb } = serverDbMod;
  serverDb.reinitializePathsForTest(tmpDbPath, tmpUploadDir);

  const app = serverMod.createApp();
  const httpServer = http.createServer(app);
  await new Promise<void>((resolve) => httpServer.listen(0, '127.0.0.1', resolve));
  const address = httpServer.address();
  assert(address && typeof address === 'object', 'Ephemeral server failed to bind');
  const baseUrl = `http://127.0.0.1:${address.port}`;

  try {
    // ------------------------------------------------------------------
    // SECTION 1: RBAC & DETERMINISTIC DSP VERIFICATION
    // ------------------------------------------------------------------
    console.log('--- SECTION 1: RBAC & DETERMINISTIC DSP ENGINE ---');

    await testCase('1.1 RBAC permission helpers enforce role separation of duties', () => {
      assert.equal(rbac.canCreateCases('Lead Forensic Analyst'), true);
      assert.equal(rbac.canCreateCases('Forensic Examiner / Expert Witness'), false);
      assert.equal(rbac.canCreateCases('System Security Administrator'), false);
      assert.equal(rbac.canManageUsers('System Security Administrator'), true);
      assert.equal(rbac.canManageUsers('Lead Forensic Analyst'), false);
      assert.equal(rbac.canSubmitLegalReview('Prosecutor / Legal Reviewer'), true);
      assert.equal(rbac.isReadOnlyForensics('System Security Administrator'), true);
      assert.equal(rbac.isReadOnlyForensics('Prosecutor / Legal Reviewer'), true);
    });

    await testCase('1.2 Deterministic WAV DSP analyzer extracts real F0/Jitter/HNR from PCM bytes', () => {
      const wav = buildSynthesizedWav(2.0, 16000, 160);
      const decoded = audioDsp.decodeAudioBuffer(wav);
      assert.equal(decoded.isWavDecoded, true);
      assert.equal(decoded.sampleRate, 16000);
      const meas = audioDsp.computeAcousticMeasurements(decoded.samples, decoded.sampleRate);
      assert.ok(meas.f0MeanHz > 140 && meas.f0MeanHz < 180, `Expected F0 near 160Hz, got ${meas.f0MeanHz}`);
      assert.ok(meas.speechDurationSec >= 1.5, 'Expected voiced speech duration >= 1.5s');
    });

    // ------------------------------------------------------------------
    // SECTION 2: SINGLE-ADMIN BOOTSTRAP & GOVERNANCE LOCKS
    // ------------------------------------------------------------------
    console.log('\n--- SECTION 2: SINGLE-ADMIN BOOTSTRAP & PRIVILEGE LOCKS ---');

    let adminToken = '';
    let adminId = '';
    let adminPassword = 'Adm#9xKqP2026!';

    await testCase('2.1 Fresh enclave reports needsAdminSetup=true before bootstrap', async () => {
      const res = await apiJson(baseUrl, 'GET', '/api/setup/status');
      assert.equal(res.status, 200);
      assert.equal(res.data.initialized, false);
      assert.equal(res.data.needsAdminSetup, true);
      assert.equal(res.data.adminCount, 0);
    });

    await testCase('2.2 First-run setup creates sole System Security Administrator and signs in for JWT', async () => {
      const res = await apiJson(baseUrl, 'POST', '/api/setup/init-admin', undefined, {
        name: 'Primary Enclave Admin',
        email: 'admin@enclave.gov',
        password: adminPassword,
        agency: 'Federal Cyber Enclave',
        department: 'Security Operations'
      });
      assert.equal(res.status, 201);
      assert.equal(res.data.user.role, 'System Security Administrator');
      adminId = res.data.user.id;

      const loginRes = await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, {
        email: 'admin@enclave.gov',
        password: adminPassword
      });
      assert.equal(loginRes.status, 200);
      assert.ok(loginRes.data.sessionToken);
      adminToken = loginRes.data.sessionToken;
    });

    await testCase('2.3 Duplicate bootstrap, creating second admin, and promoting to admin are strictly blocked', async () => {
      const dupInit = await apiJson(baseUrl, 'POST', '/api/setup/init-admin', undefined, {
        name: 'Rogue Admin',
        email: 'rogue@enclave.gov',
        password: 'Rg#9xKqP2026!'
      });
      assert.equal(dupInit.status, 409);

      const createSecondAdmin = await apiJson(baseUrl, 'POST', '/api/admin/users', adminToken, {
        name: 'Second Admin Attempt',
        email: 'admin2@enclave.gov',
        password: 'Sec#9xKqP2026!',
        role: 'System Security Administrator'
      });
      assert.equal(createSecondAdmin.status, 403);

      const selfSuspend = await apiJson(baseUrl, 'PATCH', `/api/users/${adminId}/status`, adminToken, {
        status: 'suspended'
      });
      assert.equal(selfSuspend.status, 403);
    });

    // ------------------------------------------------------------------
    // SECTION 3: PENDING APPROVAL WORKFLOW, LOCKOUT & JWT INVALIDATION
    // ------------------------------------------------------------------
    console.log('\n--- SECTION 3: PENDING APPROVAL, LOCKOUT & JWT INVALIDATION ---');

    let leadToken = '';
    let leadId = '';
    let examiner1Id = '';
    let examiner1Token = '';
    let examiner2Id = '';
    let examiner2Token = '';
    let legalId = '';
    let legalToken = '';
    let rejectedUserId = '';

    await testCase('3.1 Self-registration enters pending status and blocks login + protected APIs', async () => {
      const regLead = await apiJson(baseUrl, 'POST', '/api/auth/register', undefined, {
        name: 'Dr. Lead Analyst',
        email: 'lead@lab.gov',
        password: 'Ld#9xKqP2026!',
        role: 'Lead Forensic Analyst',
        agency: 'National Audio Lab'
      });
      assert.equal(regLead.status, 202);
      assert.equal(regLead.data.accountStatus, 'pending');
      leadId = regLead.data.user.id;

      const blockedLogin = await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, {
        email: 'lead@lab.gov',
        password: 'Ld#9xKqP2026!'
      });
      assert.equal(blockedLogin.status, 403);
      assert.equal(blockedLogin.data.accountStatus, 'pending');

      const pendingStatus = await apiJson(baseUrl, 'POST', '/api/auth/pending-status', undefined, {
        email: 'lead@lab.gov',
        password: 'Ld#9xKqP2026!'
      });
      assert.equal(pendingStatus.status, 200);
      assert.equal(pendingStatus.data.status, 'pending');
      assert.equal(pendingStatus.data.rejectionReason, undefined);

      // Register rejected candidate
      const rReject = await apiJson(baseUrl, 'POST', '/api/auth/register', undefined, {
        name: 'Rejected Applicant',
        email: 'reject@lab.gov',
        password: 'Rj#9xKqP2026!',
        role: 'Forensic Examiner / Expert Witness',
        agency: 'External'
      });
      assert.equal(rReject.status, 202);
      rejectedUserId = rReject.data.user.id;
    });

    await testCase('3.2 Admin rejection requires non-blank reason; Admin cannot approve user as Admin', async () => {
      const noReason = await apiJson(baseUrl, 'POST', `/api/admin/users/${rejectedUserId}/reject`, adminToken, {
        reason: '   '
      });
      assert.equal(noReason.status, 400);

      const withReason = await apiJson(baseUrl, 'POST', `/api/admin/users/${rejectedUserId}/reject`, adminToken, {
        reason: 'Unverified agency credentials'
      });
      assert.equal(withReason.status, 200);
      assert.equal(withReason.data.user.status, 'rejected');

      const escalateApprove = await apiJson(baseUrl, 'POST', `/api/admin/users/${leadId}/approve`, adminToken, {
        assignedRole: 'System Security Administrator'
      });
      assert.equal(escalateApprove.status, 403);
    });

    await testCase('3.3 Admin creates/approves forensic team; brute-force 5x lock + logout/suspend JWT revocation work', async () => {
      const approveLead = await apiJson(baseUrl, 'POST', `/api/admin/users/${leadId}/approve`, adminToken, {
        assignedRole: 'Lead Forensic Analyst'
      });
      assert.equal(approveLead.status, 200);

      const ex1 = await apiJson(baseUrl, 'POST', '/api/admin/users', adminToken, {
        name: 'Examiner Assigned',
        email: 'examiner1@lab.gov',
        password: 'Ex1Init#9xKq26!',
        role: 'Forensic Examiner / Expert Witness',
        agency: 'National Audio Lab',
        certificationId: 'CFCE-1001'
      });
      assert.equal(ex1.status, 201);
      examiner1Id = ex1.data.user.id;

      const ex2 = await apiJson(baseUrl, 'POST', '/api/admin/users', adminToken, {
        name: 'Examiner Unassigned',
        email: 'examiner2@lab.gov',
        password: 'Ex2Init#9xKq26!',
        role: 'Forensic Examiner / Expert Witness',
        agency: 'Other Lab',
        certificationId: 'CFCE-2002'
      });
      assert.equal(ex2.status, 201);
      examiner2Id = ex2.data.user.id;

      const leg = await apiJson(baseUrl, 'POST', '/api/admin/users', adminToken, {
        name: 'Counsel Legal',
        email: 'legal@justice.gov',
        password: 'LgInit#9xKq2026!',
        role: 'Prosecutor / Legal Reviewer',
        agency: 'DOJ'
      });
      assert.equal(leg.status, 201);
      legalId = leg.data.user.id;

      // Brute-force lockout on examiner2 (5 wrong attempts -> 6th locked 423)
      for (let i = 0; i < 5; i++) {
        await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, {
          email: 'examiner2@lab.gov',
          password: 'WrongPassword999!'
        }, { 'X-Forwarded-For': `10.0.1.${i + 1}` });
      }
      const lockedRes = await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, {
        email: 'examiner2@lab.gov',
        password: 'Ex2Init#9xKq26!'
      }, { 'X-Forwarded-For': '10.0.1.99' });
      assert.equal(lockedRes.status, 423);

      // Admin unlocks by setting status active
      const unlockRes = await apiJson(baseUrl, 'PATCH', `/api/users/${examiner2Id}/status`, adminToken, { status: 'active' });
      assert.equal(unlockRes.status, 200);

      // Logins succeed for all approved roles; admin-provisioned users rotate initial password before accessing protected endpoints
      leadToken = (await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, { email: 'lead@lab.gov', password: 'Ld#9xKqP2026!' })).data.sessionToken;
      examiner1Token = (await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, { email: 'examiner1@lab.gov', password: 'Ex1Init#9xKq26!' })).data.sessionToken;
      examiner2Token = (await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, { email: 'examiner2@lab.gov', password: 'Ex2Init#9xKq26!' })).data.sessionToken;
      legalToken = (await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, { email: 'legal@justice.gov', password: 'LgInit#9xKq2026!' })).data.sessionToken;
      assert.ok(leadToken && examiner1Token && examiner2Token && legalToken);

      // Verify mustChangePassword gate blocks API access until password is rotated
      const blockedBeforeChange = await apiJson(baseUrl, 'GET', '/api/cases', examiner1Token);
      assert.equal(blockedBeforeChange.status, 403);
      assert.equal(blockedBeforeChange.data.code, 'PASSWORD_CHANGE_REQUIRED');

      const rEx1 = await apiJson(baseUrl, 'POST', '/api/settings/password', examiner1Token, {
        currentPassword: 'Ex1Init#9xKq26!',
        newPassword: 'Ex1Rot#9xKq2026!'
      });
      assert.equal(rEx1.status, 200);
      examiner1Token = rEx1.data.newToken;

      const rEx2 = await apiJson(baseUrl, 'POST', '/api/settings/password', examiner2Token, {
        currentPassword: 'Ex2Init#9xKq26!',
        newPassword: 'Ex2Rot#9xKq2026!'
      });
      assert.equal(rEx2.status, 200);
      examiner2Token = rEx2.data.newToken;

      const rLeg = await apiJson(baseUrl, 'POST', '/api/settings/password', legalToken, {
        currentPassword: 'LgInit#9xKq2026!',
        newPassword: 'LgRot#9xKq2026!'
      });
      assert.equal(rLeg.status, 200);
      legalToken = rLeg.data.newToken;

      // Logout JTI revocation check on a throwaway session
      const tempToken = (await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, { email: 'lead@lab.gov', password: 'Ld#9xKqP2026!' })).data.sessionToken;
      const beforeLogout = await apiJson(baseUrl, 'GET', '/api/auth/me', tempToken);
      assert.equal(beforeLogout.status, 200);
      await apiJson(baseUrl, 'POST', '/api/auth/logout', tempToken);
      const afterLogout = await apiJson(baseUrl, 'GET', '/api/auth/me', tempToken);
      assert.equal(afterLogout.status, 401);
    });

    // ------------------------------------------------------------------
    // SECTION 4: SETTINGS PERSISTENCE, RFC 6238 TOTP 2FA & ADMIN TRANSFER
    // ------------------------------------------------------------------
    console.log('\n--- SECTION 4: SETTINGS, RFC 6238 TOTP 2FA & ADMIN TRANSFER ---');

    let adminTotpSecret = '';

    await testCase('4.1 Settings update persists profile, dark theme, password rotation, and config validation', async () => {
      const profRes = await apiJson(baseUrl, 'PATCH', '/api/settings/profile', leadToken, {
        department: 'DSP Forensic Acoustics',
        themePreference: 'dark'
      });
      assert.equal(profRes.status, 200);
      assert.equal(profRes.data.user.department, 'DSP Forensic Acoustics');
      assert.equal(profRes.data.user.themePreference, 'dark');

      const badConfig = await apiJson(baseUrl, 'PATCH', '/api/admin/config', adminToken, {
        retentionDaysEvidence: 5
      });
      assert.equal(badConfig.status, 400);

      const goodConfig = await apiJson(baseUrl, 'PATCH', '/api/admin/config', adminToken, {
        verificationThreshold: 80,
        retentionDaysEvidence: 1800
      });
      assert.equal(goodConfig.status, 200);
      assert.equal(goodConfig.data.verificationThreshold, 80);

      // Password change rotates token and revokes old JWT
      const pwRes = await apiJson(baseUrl, 'POST', '/api/settings/password', examiner2Token, {
        currentPassword: 'Ex2Rot#9xKq2026!',
        newPassword: 'Ex2New#9xKq2026!'
      });
      assert.equal(pwRes.status, 200);
      assert.ok(pwRes.data.newToken);
      const oldJwtRes = await apiJson(baseUrl, 'GET', '/api/auth/me', examiner2Token);
      assert.equal(oldJwtRes.status, 401);
      examiner2Token = pwRes.data.newToken;
    });

    await testCase('4.2 RFC 6238 TOTP setup, verification, login challenge, recovery code replay protection', async () => {
      const setup = await apiJson(baseUrl, 'POST', '/api/settings/2fa/setup', adminToken);
      assert.equal(setup.status, 200);
      adminTotpSecret = setup.data.secret;
      assert.ok(adminTotpSecret && setup.data.otpauthUri.includes('otpauth://totp/'));

      const validCode = serverSecMod.computeTotpCode(adminTotpSecret, Date.now() - 30_000);
      const verify = await apiJson(baseUrl, 'POST', '/api/settings/2fa/verify', adminToken, { code: validCode });
      assert.equal(verify.status, 200);
      assert.equal(verify.data.recoveryCodes.length, 8);
      const oneRecoveryCode = verify.data.recoveryCodes[0];

      // Fresh login requires 2FA step
      const step1 = await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, {
        email: 'admin@enclave.gov',
        password: adminPassword
      });
      assert.equal(step1.status, 200);
      assert.equal(step1.data.status, 'TWO_FACTOR_REQUIRED');
      assert.ok(step1.data.challengeToken);

      // Redeem recovery code once -> succeeds; second attempt on same code -> rejected
      const step2 = await apiJson(baseUrl, 'POST', '/api/auth/verify-2fa', undefined, {
        challengeToken: step1.data.challengeToken,
        code: oneRecoveryCode
      });
      assert.equal(step2.status, 200);
      assert.ok(step2.data.sessionToken);
      adminToken = step2.data.sessionToken;

      const step1b = await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, {
        email: 'admin@enclave.gov',
        password: adminPassword
      });
      const replayRecovery = await apiJson(baseUrl, 'POST', '/api/auth/verify-2fa', undefined, {
        challengeToken: step1b.data.challengeToken,
        code: oneRecoveryCode
      });
      assert.equal(replayRecovery.status, 401);

      // Re-login with second recovery code or keep second recovery code for 4.3 transfer back
      (globalThis as any).__qaAdminRecovery2 = verify.data.recoveryCodes[1];
    });

    await testCase('4.3 Atomic admin transfer preserves strictly 1 admin and revokes old admin JWT', async () => {
      // Create temporary active operator to receive & return admin authority
      const successorRes = await apiJson(baseUrl, 'POST', '/api/admin/users', adminToken, {
        name: 'Successor Operator',
        email: 'successor@enclave.gov',
        password: 'SucInit#9xKq26!',
        role: 'Lead Forensic Analyst',
        agency: 'Federal Cyber Enclave'
      });
      assert.equal(successorRes.status, 201);
      const successorId = successorRes.data.user.id;

      // Distinct advancing TOTP step from 4.2 verify
      const totpStep0 = serverSecMod.computeTotpCode(adminTotpSecret, Date.now());
      const xfer = await apiJson(baseUrl, 'POST', '/api/admin/transfer-admin', adminToken, {
        targetUserId: successorId,
        currentPassword: adminPassword,
        totpCode: totpStep0,
        demoteCurrentToRole: 'Lead Forensic Analyst',
        confirmText: 'TRANSFER_SYSTEM_ADMIN'
      });
      assert.equal(xfer.status, 200);

      // Old admin token must immediately be revoked (401)
      const oldAdminAccess = await apiJson(baseUrl, 'GET', '/api/users', adminToken);
      assert.equal(oldAdminAccess.status, 401);

      // New sole admin signs in and rotates mandatory initial password
      const newAdminLogin = await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, {
        email: 'successor@enclave.gov',
        password: 'SucInit#9xKq26!'
      });
      assert.equal(newAdminLogin.status, 200);
      let successorToken = newAdminLogin.data.sessionToken;
      const rotSuc = await apiJson(baseUrl, 'POST', '/api/settings/password', successorToken, {
        currentPassword: 'SucInit#9xKq26!',
        newPassword: 'SucRot#9xKq2026!'
      });
      assert.equal(rotSuc.status, 200);
      successorToken = rotSuc.data.newToken;

      const statusAfter = await apiJson(baseUrl, 'GET', '/api/setup/status');
      assert.equal(statusAfter.data.adminCount, 1);

      // Transfer authority back to original admin account so rest of test uses adminToken cleanly
      const xferBack = await apiJson(baseUrl, 'POST', '/api/admin/transfer-admin', successorToken, {
        targetUserId: adminId,
        currentPassword: 'SucRot#9xKq2026!',
        demoteCurrentToRole: 'Lead Forensic Analyst',
        confirmText: 'TRANSFER_SYSTEM_ADMIN'
      });
      assert.equal(xferBack.status, 200);

      // Re-login original admin using single-use recovery code, then disable admin 2FA using advancing +30s TOTP step
      const aStep1 = await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, {
        email: 'admin@enclave.gov',
        password: adminPassword
      });
      const aStep2 = await apiJson(baseUrl, 'POST', '/api/auth/verify-2fa', undefined, {
        challengeToken: aStep1.data.challengeToken,
        code: (globalThis as any).__qaAdminRecovery2
      });
      assert.equal(aStep2.status, 200);
      adminToken = aStep2.data.sessionToken;

      const disable2fa = await apiJson(baseUrl, 'POST', '/api/settings/2fa/disable', adminToken, {
        currentPassword: adminPassword,
        totpCode: serverSecMod.computeTotpCode(adminTotpSecret, Date.now() + 30_000)
      });
      assert.equal(disable2fa.status, 200);
    });

    await testCase('4.4 SMTP test endpoint returns honest 503 failure when SMTP is unconfigured', async () => {
      if (!process.env.SMTP_HOST) {
        const res = await apiJson(baseUrl, 'POST', '/api/admin/test-smtp', adminToken, { recipient: 'admin@enclave.gov' });
        assert.equal(res.status, 503);
      }
    });

    // ------------------------------------------------------------------
    // SECTION 5: CASE ACL, MULTIPART UPLOAD, MAGIC BYTES & ADMIN 403
    // ------------------------------------------------------------------
    console.log('\n--- SECTION 5: CASE ACL, MULTIPART UPLOAD & SEPARATION OF DUTIES ---');

    let caseId = '';
    let evidenceId = '';
    let cleanCaseId = '';
    let cleanEvidenceId = '';

    const sampleWav = buildSynthesizedWav(2.5, 16000, 155);
    const expectedWavHash = crypto.createHash('sha256').update(sampleWav).digest('hex');

    await testCase('5.1 Lead Analyst creates case & uploads real multipart WAV with magic-byte validation', async () => {
      const cRes = await apiJson(baseUrl, 'POST', '/api/cases', leadToken, {
        title: 'Suspect Call Recording #1',
        description: 'Prosecution audio exhibit for acoustic forensics.',
        priority: 'High',
        agency: 'National Audio Lab',
        analyst: 'Dr. Lead Analyst',
        assignedUserIds: [legalId]
      });
      assert.equal(cRes.status, 201);
      caseId = cRes.data.id;

      // Invalid .exe bytes renamed to .wav must fail 400
      const fakeExe = Buffer.from([0x4d, 0x5a, 0x90, 0x00, 0x03, 0x00, 0x00, 0x00, 0x04, 0x00]);
      const badUpload = await apiMultipart(
        baseUrl,
        '/api/evidence/upload',
        leadToken,
        { caseId },
        { fieldName: 'audio', filename: 'malware.wav', contentType: 'audio/wav', bytes: fakeExe }
      );
      assert.equal(badUpload.status, 400);

      // Valid WAV upload succeeds
      const goodUpload = await apiMultipart(
        baseUrl,
        '/api/evidence/upload',
        leadToken,
        { caseId },
        { fieldName: 'audio', filename: 'exhibit_call.wav', contentType: 'audio/wav', bytes: sampleWav }
      );
      assert.equal(goodUpload.status, 201);
      assert.equal(goodUpload.data.sha256Hash, expectedWavHash);
      evidenceId = goodUpload.data.id;
    });

    await testCase('5.2 Case ACL blocks unassigned examiner; assigning grants access; Admin blocked from raw evidence (403)', async () => {
      const deniedCase = await apiJson(baseUrl, 'GET', `/api/cases/${caseId}`, examiner2Token);
      assert.equal(deniedCase.status, 403);

      const deniedAudio = await apiJson(baseUrl, 'GET', `/api/evidence/${evidenceId}/audio`, examiner2Token);
      assert.equal(deniedAudio.status, 403);

      const adminAudio = await apiJson(baseUrl, 'GET', `/api/evidence/${evidenceId}/audio`, adminToken);
      assert.equal(adminAudio.status, 403);

      const adminExport = await apiJson(baseUrl, 'POST', `/api/cases/${caseId}/report-export`, adminToken, {
        format: 'PDF',
        reportType: 'preliminary'
      });
      assert.equal(adminExport.status, 403);

      // Assign examiner1 to case
      const assignRes = await apiJson(baseUrl, 'PATCH', `/api/cases/${caseId}`, leadToken, {
        assignedUserIds: [examiner1Id, legalId]
      });
      assert.equal(assignRes.status, 200);

      const allowedEx1 = await apiJson(baseUrl, 'GET', `/api/cases/${caseId}`, examiner1Token);
      assert.equal(allowedEx1.status, 200);
      const allowedAudio = await apiJson(baseUrl, 'GET', `/api/evidence/${evidenceId}/audio`, examiner1Token);
      assert.equal(allowedAudio.status, 200);
    });

    // ------------------------------------------------------------------
    // SECTION 6: HONEST AI/SPEAKER MODULES & TAMPER DETECTION
    // ------------------------------------------------------------------
    console.log('\n--- SECTION 6: HONEST AI/SPEAKER OUTPUTS & LIVE TAMPER DETECTION ---');

    await testCase('6.1 Deepfake & Speaker Verification report MODEL_UNAVAILABLE without fabricated scores', async () => {
      const analysis = await apiJson(baseUrl, 'POST', '/api/analyze-audio', examiner1Token, {
        caseId,
        evidenceId
      });
      assert.equal(analysis.status, 200);
      assert.equal(analysis.data.verdict, 'INCONCLUSIVE');
      assert.equal(analysis.data.overallConfidence, null);
      assert.ok(analysis.data.acousticMeasurements.f0MeanHz > 130);
      const cnn = analysis.data.models.find((m: any) => m.name.includes('CNN'));
      assert.equal(cnn.status, 'MODEL_UNAVAILABLE');

      // Reference voice upload + honest speaker comparison
      const refWav = buildSynthesizedWav(2.2, 16000, 158);
      const refUp = await apiMultipart(
        baseUrl,
        `/api/cases/${caseId}/references`,
        examiner1Token,
        { subjectName: 'Subject Alpha', conditionTag: 'Normal', lawfulConsentDeclared: 'true' },
        { fieldName: 'audio', filename: 'reference.wav', contentType: 'audio/wav', bytes: refWav }
      );
      assert.equal(refUp.status, 201);

      const spkCmp = await apiJson(baseUrl, 'POST', '/api/speaker-verification/compare', examiner1Token, {
        caseId,
        evidenceId,
        referenceId: refUp.data.id
      });
      assert.equal(spkCmp.status, 200);
      assert.equal(spkCmp.data.verdict, 'Model unavailable');
      assert.equal(spkCmp.data.similarityScore, null);
    });

    await testCase('6.2 Full E2E Signoff (Password Re-Auth -> Ed25519 -> Legal Certified -> Final Export -> Public Verify)', async () => {
      // Wrong password rejected
      const badPass = await apiJson(baseUrl, 'POST', `/api/cases/${caseId}/expert-reviews`, examiner1Token, {
        currentPassword: 'WrongPassword',
        technicalAssessment: 'Detailed DSP spectral inspection confirming physical metrics.',
        checklist: { swgdeStandards: true, chainOfCustodyVerified: true, reproducibleOutputs: true, confidenceIntervalsValid: true }
      });
      assert.equal(badPass.status, 401);

      // Missing checklist item rejected
      const badChecklist = await apiJson(baseUrl, 'POST', `/api/cases/${caseId}/expert-reviews`, examiner1Token, {
        currentPassword: 'Ex1Rot#9xKq2026!',
        technicalAssessment: 'Detailed DSP spectral inspection confirming physical metrics.',
        checklist: { swgdeStandards: true, chainOfCustodyVerified: false, reproducibleOutputs: true, confidenceIntervalsValid: true }
      });
      assert.equal(badChecklist.status, 400);

      // Valid review sealed with Ed25519
      const revRes = await apiJson(baseUrl, 'POST', `/api/cases/${caseId}/expert-reviews`, examiner1Token, {
        currentPassword: 'Ex1Rot#9xKq2026!',
        status: 'Approved',
        technicalAssessment: 'Independent acoustic inspection reviewed measured F0, jitter, HNR, and scientific limitations under FRE 702.',
        checklist: {
          swgdeStandards: true,
          chainOfCustodyVerified: true,
          reproducibleOutputs: true,
          confidenceIntervalsValid: true,
          acousticSpectralInspected: true
        }
      });
      assert.equal(revRes.status, 201);
      assert.ok(revRes.data.digitalSignature.startsWith('Ed25519:'));

      // Legal Certification blocked before review? Already signed above; verify legal review certification succeeds
      const legalItems = (await apiJson(baseUrl, 'GET', `/api/cases/${caseId}/legal-review`, legalToken)).data.items.map((i: any) => ({
        ...i,
        status: 'COMPLETE'
      }));
      const legCert = await apiJson(baseUrl, 'POST', `/api/cases/${caseId}/legal-review`, legalToken, {
        status: 'CERTIFIED',
        jurisdiction: 'Federal District Court',
        items: legalItems,
        notes: 'Admissible under FRE 902(13)/(14).'
      });
      assert.equal(legCert.status, 200);
      assert.equal(legCert.data.status, 'CERTIFIED');

      // CoC verify confirms valid hash chain
      const cocCheck = await apiJson(baseUrl, 'GET', `/api/cases/${caseId}/chain-of-custody/verify`, leadToken);
      assert.equal(cocCheck.status, 200);
      assert.equal(cocCheck.data.valid, true);
      assert.ok(cocCheck.data.checkedCount >= 3);

      // Export Final Report -> returns verifyToken & Ed25519 seal
      const expRes = await apiJson(baseUrl, 'POST', `/api/cases/${caseId}/report-export`, leadToken, {
        format: 'PDF',
        reportType: 'final'
      });
      assert.equal(expRes.status, 200);
      assert.equal(expRes.data.reportType, 'FINAL');
      const token = expRes.data.verifyToken;
      assert.ok(token.startsWith('VRF-'));

      // Public verification succeeds without auth
      const pubRes = await apiJson(baseUrl, 'GET', `/api/public/verify-report/${encodeURIComponent(token)}`);
      assert.equal(pubRes.status, 200);
      assert.equal(pubRes.data.verified, true);
      assert.equal(pubRes.data.evidenceSha256, expectedWavHash);

      // Invalid token fails 404
      const invalidPub = await apiJson(baseUrl, 'GET', '/api/public/verify-report/VRF-INVALID-TOKEN');
      assert.equal(invalidPub.status, 404);
      assert.equal(invalidPub.data.verified, false);
    });

    await testCase('6.3 Live evidence byte tampering triggers 409/TAMPERED across streaming, analysis, export & public verify', async () => {
      // Mutate stored evidence file on disk inside tmpUploadDir
      const storedEv = serverDb.getEvidenceById(evidenceId)!;
      assert.ok(storedEv.storageFilename);
      const diskPath = path.join(tmpUploadDir, storedEv.storageFilename);
      const bytes = fs.readFileSync(diskPath);
      bytes[bytes.length - 1] = bytes[bytes.length - 1] ^ 0xff;
      fs.writeFileSync(diskPath, bytes);

      // Stream blocked 409
      const streamTamper = await apiJson(baseUrl, 'GET', `/api/evidence/${evidenceId}/audio`, leadToken);
      assert.equal(streamTamper.status, 409);

      // Analysis blocked 409
      const analyzeTamper = await apiJson(baseUrl, 'POST', '/api/analyze-audio', leadToken, { caseId, evidenceId });
      assert.equal(analyzeTamper.status, 409);

      // Report export blocked 409
      const exportTamper = await apiJson(baseUrl, 'POST', `/api/cases/${caseId}/report-export`, leadToken, {
        format: 'PDF',
        reportType: 'preliminary'
      });
      assert.equal(exportTamper.status, 409);

      // Verify stored hash detects mismatch & logs MISMATCH_ALERT
      const verifyTamper = await apiJson(baseUrl, 'POST', '/api/evidence/verify-hash', leadToken, {
        evidenceId,
        verifyStoredBitstream: true
      });
      assert.equal(verifyTamper.status, 200);
      assert.equal(verifyTamper.data.verified, false);

      // Public verification on previously issued token must now reject with TAMPERED (400)
      const pubReport = (await apiJson(baseUrl, 'GET', `/api/cases/${caseId}/public-report`, leadToken)).data.record;
      const tamperedPub = await apiJson(baseUrl, 'GET', `/api/public/verify-report/${encodeURIComponent(pubReport.token)}`);
      assert.equal(tamperedPub.status, 400);
      assert.equal(tamperedPub.data.status, 'TAMPERED');
    });

    await testCase('6.4 Chain-of-custody tampering detection catches modified event records', async () => {
      // Create a clean secondary case to test CoC ledger mutation detection
      const c2 = await apiJson(baseUrl, 'POST', '/api/cases', leadToken, {
        title: 'Clean CoC Audit Case',
        description: 'Chain of custody integrity test.',
        priority: 'Low',
        agency: 'National Audio Lab',
        analyst: 'Dr. Lead Analyst'
      });
      cleanCaseId = c2.data.id;
      const up2 = await apiMultipart(
        baseUrl,
        '/api/evidence/upload',
        leadToken,
        { caseId: cleanCaseId },
        { fieldName: 'audio', filename: 'clean.wav', contentType: 'audio/wav', bytes: sampleWav }
      );
      assert.equal(up2.status, 201);
      cleanEvidenceId = up2.data.id;
      assert.ok(cleanEvidenceId);

      const intactCheck = await apiJson(baseUrl, 'GET', `/api/cases/${cleanCaseId}/chain-of-custody/verify`, leadToken);
      assert.equal(intactCheck.data.valid, true);

      // Corrupt event title directly inside temp JSON store (simulates DB tampering)
      const rawDb = JSON.parse(fs.readFileSync(tmpDbPath, 'utf-8'));
      const targetEvt = rawDb.chainOfCustody.find((e: any) => e.caseId === cleanCaseId);
      assert.ok(targetEvt);
      targetEvt.title = 'ALTERED_BY_ATTACKER';
      fs.writeFileSync(tmpDbPath, JSON.stringify(rawDb, null, 2));
      serverDb.reinitializePathsForTest(tmpDbPath, tmpUploadDir);

      const brokenCheck = await apiJson(baseUrl, 'GET', `/api/cases/${cleanCaseId}/chain-of-custody/verify`, leadToken);
      assert.equal(brokenCheck.data.valid, false);
    });

    // ------------------------------------------------------------------
    // SECTION 8: PHASE P0 SECURITY & INTEGRITY REGRESSION TESTS (A1–A12)
    // ------------------------------------------------------------------
    console.log('\n--- SECTION 8: PHASE P0 REGRESSION TESTS (A1–A12) ---');

    let leadTotpSecret = '';
    let leadRecoveryCodes: string[] = [];

    await testCase('P0-A1: 2FA challenge JWT rejected on session routes; session JWT rejected on verify-2fa', async () => {
      const setupLead = await apiJson(baseUrl, 'POST', '/api/settings/2fa/setup', leadToken);
      assert.equal(setupLead.status, 200);
      leadTotpSecret = setupLead.data.secret;
      const verLead = await apiJson(baseUrl, 'POST', '/api/settings/2fa/verify', leadToken, {
        code: serverSecMod.computeTotpCode(leadTotpSecret, Date.now() - 30_000)
      });
      assert.equal(verLead.status, 200);
      leadRecoveryCodes = verLead.data.recoveryCodes;

      const step1 = await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, {
        email: 'lead@lab.gov',
        password: 'Ld#9xKqP2026!'
      });
      assert.equal(step1.data.status, 'TWO_FACTOR_REQUIRED');
      const challengeJwt = step1.data.challengeToken;

      const meWithChallenge = await apiJson(baseUrl, 'GET', '/api/auth/me', challengeJwt);
      assert.equal(meWithChallenge.status, 401);
      const usersWithChallenge = await apiJson(baseUrl, 'GET', '/api/users', challengeJwt);
      assert.equal(usersWithChallenge.status, 401);

      const verifyWithSession = await apiJson(baseUrl, 'POST', '/api/auth/verify-2fa', undefined, {
        challengeToken: leadToken,
        code: '123456'
      });
      assert.equal(verifyWithSession.status, 401);
    });

    await testCase('P0-A6: Same TOTP code in same 30s time-step rejected on replay', async () => {
      const step0Code = serverSecMod.computeTotpCode(leadTotpSecret, Date.now());
      const firstUse = await apiJson(baseUrl, 'POST', '/api/auth/reauth', leadToken, {
        password: 'Ld#9xKqP2026!',
        totpCode: step0Code
      });
      assert.equal(firstUse.status, 200);

      const replayReauth = await apiJson(baseUrl, 'POST', '/api/auth/reauth', leadToken, {
        password: 'Ld#9xKqP2026!',
        totpCode: step0Code
      });
      assert.equal(replayReauth.status, 401);
    });

    await testCase('P0-A2 & P0-A3: Server ignores client fallback metrics/verdict and rejects non-WAV PCM (422)', async () => {
      // Direct PATCH verdict override blocked (400)
      const overrideVerdict = await apiJson(baseUrl, 'PATCH', `/api/cases/${cleanCaseId}`, leadToken, {
        verdict: 'DEEPFAKE'
      });
      assert.equal(overrideVerdict.status, 400);

      // Analyze ignores forged clientMeasurements and updates only server DSP
      const forgedAnalyze = await apiJson(baseUrl, 'POST', '/api/analyze-audio', leadToken, {
        caseId: cleanCaseId,
        evidenceId: cleanEvidenceId,
        clientMeasurements: { f0MeanHz: 999, speechDurationSec: 999 },
        fileHash: '0'.repeat(64)
      });
      assert.equal(forgedAnalyze.status, 200);
      assert.ok(forgedAnalyze.data.acousticMeasurements.f0MeanHz < 200);
      assert.equal(forgedAnalyze.data.overallConfidence, null);

      // Spoofing evidenceIsSynthetic: false on speaker-compare cannot override persisted record
      const refWav = buildSynthesizedWav(2.0, 16000, 155);
      const refRes = await apiMultipart(
        baseUrl,
        `/api/cases/${cleanCaseId}/references`,
        leadToken,
        { subjectName: 'Subject Beta', conditionTag: 'Normal', lawfulConsentDeclared: 'true' },
        { fieldName: 'audio', filename: 'ref2.wav', contentType: 'audio/wav', bytes: refWav }
      );
      assert.equal(refRes.status, 201);

      const spkRes = await apiJson(baseUrl, 'POST', '/api/speaker-verification/compare', leadToken, {
        caseId: cleanCaseId,
        evidenceId: cleanEvidenceId,
        referenceId: refRes.data.id,
        evidenceIsSynthetic: false,
        clientDur: 99
      });
      assert.equal(spkRes.status, 200);
      assert.equal(spkRes.data.similarityScore, null);
      assert.equal(spkRes.data.verdict, 'Model unavailable');

      // Upload valid MP3 magic bytes (cannot be decoded by server WAV parser -> 422 on analyze/speaker/voice)
      const fakeMp3 = Buffer.from([0x49, 0x44, 0x33, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0xff, 0xfb, 0x90, 0x64]);
      const mp3Up = await apiMultipart(
        baseUrl,
        '/api/evidence/upload',
        leadToken,
        { caseId: cleanCaseId },
        { fieldName: 'audio', filename: 'compressed.mp3', contentType: 'audio/mpeg', bytes: fakeMp3 }
      );
      assert.equal(mp3Up.status, 201);

      const mp3Analyze = await apiJson(baseUrl, 'POST', '/api/analyze-audio', leadToken, {
        caseId: cleanCaseId,
        evidenceId: mp3Up.data.id,
        clientMeasurements: { f0MeanHz: 150, speechDurationSec: 3 }
      });
      assert.equal(mp3Analyze.status, 422);

      const mp3Voice = await apiJson(baseUrl, 'POST', '/api/voice-analysis/condition', leadToken, {
        caseId: cleanCaseId,
        evidenceId: mp3Up.data.id,
        referenceId: refRes.data.id,
        clientMeasurements: { f0MeanHz: 150, speechDurationSec: 3 }
      });
      assert.equal(mp3Voice.status, 422);
    });

    await testCase('P0-A4 & P0-A9: AES-256-GCM at-rest encryption + non-destructive archive + retention-enforced purge', async () => {
      // Encrypted file on disk starts with ALFAENC1, not RIFF
      const storedClean = serverDb.getEvidenceById(cleanEvidenceId)!;
      assert.ok(storedClean.storageFilename);
      const diskBytes = fs.readFileSync(path.join(tmpUploadDir, storedClean.storageFilename));
      assert.equal(diskBytes.subarray(0, 8).toString('ascii'), 'ALFAENC1');

      // Decrypted HTTP audio stream starts with RIFF
      const streamRes = await fetch(`${baseUrl}/api/evidence/${cleanEvidenceId}/audio`, {
        headers: { Authorization: `Bearer ${leadToken}` }
      });
      assert.equal(streamRes.status, 200);
      const streamedBuf = Buffer.from(await streamRes.arrayBuffer());
      assert.equal(streamedBuf.subarray(0, 4).toString('ascii'), 'RIFF');

      // Archive case via DELETE (non-destructive)
      const delRes = await apiJson(baseUrl, 'DELETE', `/api/cases/${cleanCaseId}`, leadToken);
      assert.equal(delRes.status, 200);
      assert.equal(delRes.data.archived, true);
      assert.equal(delRes.data.case.status, 'Archived');

      const defaultList = await apiJson(baseUrl, 'GET', '/api/cases', leadToken);
      assert.equal(defaultList.data.some((c: any) => c.id === cleanCaseId), false);
      const archivedList = await apiJson(baseUrl, 'GET', '/api/cases?includeArchived=true', leadToken);
      assert.equal(archivedList.data.some((c: any) => c.id === cleanCaseId && c.status === 'Archived'), true);

      // Purge blocked before retention window elapsed (403)
      const blockedPurge = await apiJson(baseUrl, 'POST', `/api/admin/cases/${cleanCaseId}/purge`, adminToken, {
        currentPassword: adminPassword,
        confirmText: 'PURGE_ARCHIVED_CASE'
      });
      assert.equal(blockedPurge.status, 403);

      // Backdate case updatedDate past retentionDaysEvidence (1800d) and verify purge removes files & leaves tombstone
      const rawDb = JSON.parse(fs.readFileSync(tmpDbPath, 'utf-8'));
      const cIdx = rawDb.cases.findIndex((c: any) => c.id === cleanCaseId);
      rawDb.cases[cIdx].updatedDate = '2020-01-01 00:00:00 UTC';
      fs.writeFileSync(tmpDbPath, JSON.stringify(rawDb, null, 2));
      serverDb.reinitializePathsForTest(tmpDbPath, tmpUploadDir);

      const okPurge = await apiJson(baseUrl, 'POST', `/api/admin/cases/${cleanCaseId}/purge`, adminToken, {
        currentPassword: adminPassword,
        confirmText: 'PURGE_ARCHIVED_CASE'
      });
      assert.equal(okPurge.status, 200);
      assert.equal(fs.existsSync(path.join(tmpUploadDir, storedClean.storageFilename)), false);
      const afterPurgeCase = await apiJson(baseUrl, 'GET', `/api/cases/${cleanCaseId}`, leadToken);
      assert.equal(afterPurgeCase.status, 404);
    });

    await testCase('P0-A5 & P0-A7 & P0-A8: 2FA/OTP brute-force lockouts, uniform login errors, strong password policy', async () => {
      // Uniform 401 regardless of unknown vs wrong password on active/pending/rejected
      const unk = await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, { email: 'nobody@lab.gov', password: 'WrongPass!2026' });
      const actWrong = await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, { email: 'lead@lab.gov', password: 'WrongPass!2026' });
      const rejWrong = await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, { email: 'reject@lab.gov', password: 'WrongPass!2026' });
      assert.equal(unk.status, 401);
      assert.equal(actWrong.status, 401);
      assert.equal(rejWrong.status, 401);
      assert.equal(unk.data.error, actWrong.data.error);
      assert.equal(actWrong.data.error, rejWrong.data.error);

      // Pending status rejects missing/wrong password
      const badPend = await apiJson(baseUrl, 'POST', '/api/auth/pending-status', undefined, { email: 'lead@lab.gov', password: 'Wrong' });
      assert.equal(badPend.status, 401);

      // Weak or email-matching passwords rejected (400)
      const weakReg = await apiJson(baseUrl, 'POST', '/api/auth/register', undefined, {
        name: 'Weak User',
        email: 'weakuser@lab.gov',
        password: 'weakuser1234!',
        role: 'Lead Forensic Analyst'
      });
      assert.equal(weakReg.status, 400);

      // 5 wrong 2FA attempts revoke challenge token (on lead's 2FA challenge)
      const s1 = await apiJson(baseUrl, 'POST', '/api/auth/login', undefined, { email: 'lead@lab.gov', password: 'Ld#9xKqP2026!' });
      for (let i = 0; i < 5; i++) {
        await apiJson(baseUrl, 'POST', '/api/auth/verify-2fa', undefined, { challengeToken: s1.data.challengeToken, code: '000000' });
      }
      const revokedChallenge = await apiJson(baseUrl, 'POST', '/api/auth/verify-2fa', undefined, {
        challengeToken: s1.data.challengeToken,
        code: leadRecoveryCodes[0]
      });
      assert.equal(revokedChallenge.status, 401);

      // 5 wrong registration OTP attempts delete pending registration
      const pendingOtpEmail = 'otpcheck@lab.gov';
      const otpSalt = crypto.randomBytes(16).toString('hex');
      serverDb.savePendingRegistration({
        email: pendingOtpEmail,
        name: 'OTP Check',
        passwordHash: 'x',
        salt: otpSalt,
        role: 'Lead Forensic Analyst',
        agency: 'Lab',
        otpHash: crypto.createHash('sha256').update('654321' + otpSalt).digest('hex'),
        expiresAt: Date.now() + 600_000,
        failedAttempts: 0,
        createdAt: Date.now()
      });
      for (let i = 0; i < 5; i++) {
        await apiJson(baseUrl, 'POST', '/api/auth/verify-registration', undefined, { email: pendingOtpEmail, otp: '111111' });
      }
      assert.equal(serverDb.getPendingRegistration(pendingOtpEmail), undefined);
    });

    await testCase('P0-A10 & P0-A11 & P0-A12: Security headers, JSON 404/413, scoped audit/notifications, Gemini off by default', async () => {
      // Security headers + JSON 404
      const missingRes = await fetch(`${baseUrl}/api/nonexistent-endpoint`);
      assert.equal(missingRes.status, 404);
      assert.ok(missingRes.headers.get('content-security-policy'));
      assert.equal(missingRes.headers.get('x-content-type-options'), 'nosniff');
      assert.ok(missingRes.headers.get('permissions-policy'));
      const missingJson = await missingRes.json();
      assert.ok(missingJson.error);

      // Non-upload >1mb JSON rejected with 413
      const hugePayload = { title: 'A'.repeat(1_200_000) };
      const bigRes = await apiJson(baseUrl, 'POST', '/api/cases', leadToken, hugePayload);
      assert.equal(bigRes.status, 413);

      // Cross-user notification read blocked (403)
      const notif = serverDb.addNotification({
        id: `NTF-TEST-${Date.now()}`,
        title: 'Examiner1 Only',
        description: 'Private notification',
        severity: 'info',
        timestamp: '2026-01-01 00:00:00 UTC',
        read: false,
        targetUserId: examiner1Id
      });
      const crossRead = await apiJson(baseUrl, 'PATCH', `/api/notifications/${notif.id}/read`, examiner2Token);
      assert.equal(crossRead.status, 403);

      // Audit logs scoped by ACL (examiner2 without case access gets empty/non-case1 logs; admin sees config + all)
      const adminCfg = await apiJson(baseUrl, 'GET', '/api/admin/config', adminToken);
      assert.equal(adminCfg.data.enableGeminiAdvisory, false);
      const ex2Audits = await apiJson(baseUrl, 'GET', '/api/audit-logs', examiner2Token);
      assert.equal(ex2Audits.status, 403);
      const leadAudits = await apiJson(baseUrl, 'GET', '/api/audit-logs', leadToken);
      assert.equal(leadAudits.status, 200);
      assert.equal(leadAudits.data.some((l: any) => l.resource?.includes('Unverified') || l.user === 'admin@enclave.gov'), false);
    });

    // ------------------------------------------------------------------
    // SECTION 9: PHASE P1 AUDIO DECODING, DSP PROFILE & EXHIBIT LINEAGE
    // ------------------------------------------------------------------
    console.log('\n--- SECTION 9: PHASE P1 AUDIO DSP, LINEAGE & ISOLATION TESTS ---');

    await testCase('P1-WAV-Decoder: handles odd chunk alignment, 24-bit, 32-bit int/float, stereo, and rejects MP3 without fake PCM', () => {
      // 1. Odd-size LIST chunk (5 bytes + 1 pad byte -> 6 bytes stride) before fmt & data
      const sr = 16000;
      const numSamples = 1600;
      const oddPayload = Buffer.from('ABCDE', 'ascii'); // 5 bytes -> 1 pad byte
      const fmtSize = 16;
      const dataSize = numSamples * 2;
      const listChunkTotal = 8 + oddPayload.length + 1;
      const oddWav = Buffer.alloc(12 + listChunkTotal + 8 + fmtSize + 8 + dataSize);
      let off = 0;
      oddWav.write('RIFF', off); off += 4;
      oddWav.writeUInt32LE(oddWav.length - 8, off); off += 4;
      oddWav.write('WAVE', off); off += 4;
      oddWav.write('JUNK', off); off += 4;
      oddWav.writeUInt32LE(oddPayload.length, off); off += 4;
      oddPayload.copy(oddWav, off); off += oddPayload.length + 1; // odd padding
      oddWav.write('fmt ', off); off += 4;
      oddWav.writeUInt32LE(fmtSize, off); off += 4;
      oddWav.writeUInt16LE(1, off); off += 2;
      oddWav.writeUInt16LE(1, off); off += 2;
      oddWav.writeUInt32LE(sr, off); off += 4;
      oddWav.writeUInt32LE(sr * 2, off); off += 4;
      oddWav.writeUInt16LE(2, off); off += 2;
      oddWav.writeUInt16LE(16, off); off += 2;
      oddWav.write('data', off); off += 4;
      oddWav.writeUInt32LE(dataSize, off); off += 4;
      for (let i = 0; i < numSamples; i++) {
        oddWav.writeInt16LE(Math.round(Math.sin((2 * Math.PI * 160 * i) / sr) * 16000), off + i * 2);
      }
      const decodedOdd = audioDsp.decodeAudioBuffer(oddWav);
      assert.equal(decodedOdd.isWavDecoded, true);
      assert.equal(decodedOdd.samples.length, numSamples);

      // 2. 24-bit PCM stereo WAV
      const n24 = 800;
      const d24 = n24 * 2 * 3;
      const wav24 = Buffer.alloc(44 + d24);
      wav24.write('RIFF', 0); wav24.writeUInt32LE(36 + d24, 4); wav24.write('WAVE', 8);
      wav24.write('fmt ', 12); wav24.writeUInt32LE(16, 16); wav24.writeUInt16LE(1, 20);
      wav24.writeUInt16LE(2, 22); wav24.writeUInt32LE(sr, 24); wav24.writeUInt32LE(sr * 6, 28);
      wav24.writeUInt16LE(6, 32); wav24.writeUInt16LE(24, 34);
      wav24.write('data', 36); wav24.writeUInt32LE(d24, 40);
      for (let i = 0; i < n24 * 2; i++) {
        const s24 = Math.round(Math.sin((2 * Math.PI * 150 * Math.floor(i / 2)) / sr) * 4000000);
        wav24[44 + i * 3] = s24 & 0xff;
        wav24[44 + i * 3 + 1] = (s24 >> 8) & 0xff;
        wav24[44 + i * 3 + 2] = (s24 >> 16) & 0xff;
      }
      const dec24 = audioDsp.decodeAudioBuffer(wav24);
      assert.equal(dec24.isWavDecoded, true);
      assert.equal(dec24.channels, 2);
      assert.equal(dec24.bitsPerSample, 24);
      assert.equal(dec24.samples.length, n24);

      // 3. 32-bit IEEE float PCM WAV (format 3)
      const n32 = 800;
      const d32 = n32 * 4;
      const wavF32 = Buffer.alloc(44 + d32);
      wavF32.write('RIFF', 0); wavF32.writeUInt32LE(36 + d32, 4); wavF32.write('WAVE', 8);
      wavF32.write('fmt ', 12); wavF32.writeUInt32LE(16, 16); wavF32.writeUInt16LE(3, 20);
      wavF32.writeUInt16LE(1, 22); wavF32.writeUInt32LE(sr, 24); wavF32.writeUInt32LE(sr * 4, 28);
      wavF32.writeUInt16LE(4, 32); wavF32.writeUInt16LE(32, 34);
      wavF32.write('data', 36); wavF32.writeUInt32LE(d32, 40);
      for (let i = 0; i < n32; i++) {
        wavF32.writeFloatLE(0.4 * Math.sin((2 * Math.PI * 165 * i) / sr), 44 + i * 4);
      }
      const decF32 = audioDsp.decodeAudioBuffer(wavF32);
      assert.equal(decF32.isWavDecoded, true);
      assert.equal(decF32.audioFormatCode, 3);
      assert.equal(decF32.bitsPerSample, 32);
      assert.equal(decF32.samples.length, n32);

      // 4. 32-bit int PCM WAV (format 1)
      const wavI32 = Buffer.alloc(44 + d32);
      wavI32.write('RIFF', 0); wavI32.writeUInt32LE(36 + d32, 4); wavI32.write('WAVE', 8);
      wavI32.write('fmt ', 12); wavI32.writeUInt32LE(16, 16); wavI32.writeUInt16LE(1, 20);
      wavI32.writeUInt16LE(1, 22); wavI32.writeUInt32LE(sr, 24); wavI32.writeUInt32LE(sr * 4, 28);
      wavI32.writeUInt16LE(4, 32); wavI32.writeUInt16LE(32, 34);
      wavI32.write('data', 36); wavI32.writeUInt32LE(d32, 40);
      for (let i = 0; i < n32; i++) {
        wavI32.writeInt32LE(Math.round(0.4 * Math.sin((2 * Math.PI * 165 * i) / sr) * 2147483647), 44 + i * 4);
      }
      const decI32 = audioDsp.decodeAudioBuffer(wavI32);
      assert.equal(decI32.isWavDecoded, true);
      assert.equal(decI32.audioFormatCode, 1);
      assert.equal(decI32.bitsPerSample, 32);

      // 5. MP3 / non-WAV returns empty samples + isWavDecoded: false
      const mp3Buf = Buffer.from([0x49, 0x44, 0x33, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10]);
      const decMp3 = audioDsp.decodeAudioBuffer(mp3Buf);
      assert.equal(decMp3.isWavDecoded, false);
      assert.equal(decMp3.samples.length, 0);
    });

    await testCase('P1-DSP-Profile: computeNonBiometricDspProfile returns Mel, MFCC, LFCC, VAD & non-biometric measurement tag', () => {
      const wav = buildSynthesizedWav(2.0, 16000, 155);
      const dec = audioDsp.decodeAudioBuffer(wav);
      const meas = audioDsp.computeAcousticMeasurements(dec.samples, dec.sampleRate);
      assert.equal(meas.measurementType, 'non-biometric measurement');

      const prof = audioDsp.computeNonBiometricDspProfile(dec.samples, dec.sampleRate);
      assert.equal(prof.measurementType, 'non-biometric measurement');
      assert.equal(prof.melBandsDb.length, 24);
      assert.equal(prof.mfccMean.length, 13);
      assert.equal(prof.lfccMean.length, 13);
      assert.ok(prof.vadActiveRatio > 0 && prof.vadActiveRatio <= 1);
      assert.ok(prof.vadSegmentCount >= 1);
      assert.ok(prof.windowTelemetry.length > 0 && prof.windowTelemetry.length <= 60);
    });

    await testCase('P1-Upload-Truth & P1-Derive-Copy & P1-Analyses-Isolation & P1-VerifyHash-Tamper & P1-Report', async () => {
      // Create fresh case for isolated P1 workflow verification
      const p1Case = await apiJson(baseUrl, 'POST', '/api/cases', leadToken, {
        title: 'P1 Lineage & Isolation Docket',
        description: 'Testing server-truth metadata, derived copy, exhibit isolation, and tamper alerts',
        priority: 'High',
        agency: 'National Audio Lab',
        analyst: 'Dr. Lead Analyst',
        assignedUserIds: [examiner1Id, legalId]
      });
      assert.equal(p1Case.status, 201);
      const p1CaseId = p1Case.data.id;

      // Spoof client duration/sampleRate/channels/bitDepth/fileSize -> server ignores all of them
      const wav2s = buildSynthesizedWav(2.0, 16000, 155);
      const upA = await apiMultipart(
        baseUrl,
        '/api/evidence/upload',
        leadToken,
        {
          caseId: p1CaseId,
          duration: '99:99',
          sampleRate: '999 kHz',
          bitDepth: '64-bit',
          channels: '8-Channel',
          fileSize: '999 MB'
        },
        { fieldName: 'audio', filename: 'exhibit_a.wav', contentType: 'audio/wav', bytes: wav2s }
      );
      assert.equal(upA.status, 201);
      assert.equal(upA.data.duration, '2.0s');
      assert.equal(upA.data.sampleRate, '16000 Hz');
      assert.equal(upA.data.bitDepth, '16-bit PCM');
      assert.equal(upA.data.channels, 'Mono');
      assert.notEqual(upA.data.fileSize, '999 MB');
      const evAId = upA.data.id;
      const origHash = upA.data.sha256Hash;

      // Second WAV exhibit B
      const wavB = buildSynthesizedWav(1.5, 16000, 140);
      const upB = await apiMultipart(
        baseUrl,
        '/api/evidence/upload',
        leadToken,
        { caseId: p1CaseId },
        { fieldName: 'audio', filename: 'exhibit_b.wav', contentType: 'audio/wav', bytes: wavB }
      );
      assert.equal(upB.status, 201);
      const evBId = upB.data.id;

      // Derive normalized working copy from Exhibit A
      const deriveRes = await apiJson(baseUrl, 'POST', `/api/evidence/${evAId}/derive-copy`, leadToken, { highPassHz: 80 });
      assert.equal(deriveRes.status, 201);
      assert.equal(deriveRes.data.isDerivedCopy, true);
      assert.equal(deriveRes.data.parentEvidenceId, evAId);
      assert.ok(deriveRes.data.processingOperation);
      assert.notEqual(deriveRes.data.sha256Hash, origHash);

      // Original parent exhibit A remains intact and verifies
      const verifyOrig = await apiJson(baseUrl, 'POST', '/api/evidence/verify-hash', leadToken, {
        evidenceId: evAId,
        verifyStoredBitstream: true
      });
      assert.equal(verifyOrig.status, 200);
      assert.equal(verifyOrig.data.verified, true);
      assert.equal(verifyOrig.data.originalHash, origHash);

      // MP3 derive-copy returns 422
      const fakeMp3 = Buffer.from([0x49, 0x44, 0x33, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10]);
      const upMp3 = await apiMultipart(
        baseUrl,
        '/api/evidence/upload',
        leadToken,
        { caseId: p1CaseId },
        { fieldName: 'audio', filename: 'exhibit_mp3.mp3', contentType: 'audio/mpeg', bytes: fakeMp3 }
      );
      assert.equal(upMp3.status, 201);
      const badDerive = await apiJson(baseUrl, 'POST', `/api/evidence/${upMp3.data.id}/derive-copy`, leadToken, {});
      assert.equal(badDerive.status, 422);

      // Run analysis ONLY on evAId and verify ?evidenceId= isolation
      const anA = await apiJson(baseUrl, 'POST', '/api/analyze-audio', leadToken, {
        caseId: p1CaseId,
        evidenceId: evAId
      });
      assert.equal(anA.status, 200);
      assert.equal(anA.data.nonBiometricProfile?.measurementType, 'non-biometric measurement');
      assert.ok(Array.isArray(anA.data.models) && anA.data.models.every((m: any) => typeof m.key === 'string'));

      const filteredB = await apiJson(baseUrl, 'GET', `/api/cases/${p1CaseId}/analyses?evidenceId=${evBId}`, leadToken);
      assert.equal(filteredB.status, 200);
      assert.equal(filteredB.data.length, 0);

      const filteredA = await apiJson(baseUrl, 'GET', `/api/cases/${p1CaseId}/analyses?evidenceId=${evAId}`, leadToken);
      assert.equal(filteredA.status, 200);
      assert.equal(filteredA.data.length, 1);
      assert.equal(filteredA.data[0].evidenceId, evAId);

      // Invalid non-64-hex hash rejected with 400
      const invalidHash = await apiJson(baseUrl, 'POST', '/api/evidence/verify-hash', leadToken, {
        evidenceId: evAId,
        candidateHash: 'not-a-64-char-hex-hash'
      });
      assert.equal(invalidHash.status, 400);

      // Report export includes evidenceLineage & probabilistic decision-support caveats
      const repExport = await apiJson(baseUrl, 'POST', `/api/cases/${p1CaseId}/report-export`, leadToken, {
        format: 'PDF',
        reportType: 'preliminary'
      });
      assert.equal(repExport.status, 200);
      assert.ok(Array.isArray(repExport.data.manifest?.evidenceLineage));
      assert.ok(repExport.data.manifest.evidenceLineage.some((l: any) => l.id === deriveRes.data.id && l.parentEvidenceId === evAId));
      assert.ok(String(repExport.data.manifest?.scientificLimitations || '').toLowerCase().includes('probabilistic'));

      // Stored bitstream tamper on derived copy triggers verified:false and NOTIF-TAMPER to Admin
      const storedDerived = serverDb.getEvidenceById(deriveRes.data.id)!;
      const encFile = path.join(tmpUploadDir, storedDerived.storageFilename!);
      const corruptBytes = fs.readFileSync(encFile);
      corruptBytes[corruptBytes.length - 1] ^= 0xff; // flip ciphertext tag/byte
      fs.writeFileSync(encFile, corruptBytes);

      const tamperRes = await apiJson(baseUrl, 'POST', '/api/evidence/verify-hash', leadToken, {
        evidenceId: deriveRes.data.id,
        verifyStoredBitstream: true
      });
      assert.equal(tamperRes.status, 200);
      assert.equal(tamperRes.data.verified, false);

      const adminNotifs = await apiJson(baseUrl, 'GET', '/api/notifications', adminToken);
      assert.equal(adminNotifs.status, 200);
      assert.ok(adminNotifs.data.some((n: any) => String(n.id).startsWith('NOTIF-TAMPER')));
    });

    // ------------------------------------------------------------------
    // SECTION 10: PHASE P2 & P3 REGRESSION TESTS (2FA Policy & NFR-31 Async Queue)
    // ------------------------------------------------------------------
    console.log('\n--- SECTION 10: PHASE P2 & P3 REGRESSION TESTS ---');

    await testCase('P2-AuthMe-2FA-Policy: /api/auth/me exposes twoFactorEnrollmentRequired accurately', async () => {
      // Default config has enforceTwoFactor=false
      const meEx1Off = await apiJson(baseUrl, 'GET', '/api/auth/me', examiner1Token);
      assert.equal(meEx1Off.status, 200);
      assert.equal(meEx1Off.data.twoFactorEnrollmentRequired, false);

      // Admin enables institutional 2FA policy -> unenrolled examiner1 requires enrollment, enrolled lead does not
      const cfgOn = await apiJson(baseUrl, 'PATCH', '/api/admin/config', adminToken, { enforceTwoFactor: true });
      assert.equal(cfgOn.status, 200);
      assert.equal(cfgOn.data.enforceTwoFactor, true);

      const meEx1On = await apiJson(baseUrl, 'GET', '/api/auth/me', examiner1Token);
      assert.equal(meEx1On.status, 200);
      assert.equal(meEx1On.data.twoFactorEnrollmentRequired, true);

      const meLeadOn = await apiJson(baseUrl, 'GET', '/api/auth/me', leadToken);
      assert.equal(meLeadOn.status, 200);
      assert.equal(meLeadOn.data.twoFactorEnrollmentRequired, false);

      // Restore enforceTwoFactor=false cleanly
      const cfgOff = await apiJson(baseUrl, 'PATCH', '/api/admin/config', adminToken, { enforceTwoFactor: false });
      assert.equal(cfgOff.status, 200);
    });

    await testCase('P3-NFR31-Async-Job-Queue: 202 queued job, ACL enforcement, polling completion & 422 MP3 failure', async () => {
      const nfrCase = await apiJson(baseUrl, 'POST', '/api/cases', leadToken, {
        title: 'NFR-31 Async Worker Case',
        description: 'Async job queue regression test',
        priority: 'Medium',
        agency: 'National Audio Lab',
        analyst: 'Dr. Lead Analyst',
        assignedUserIds: [examiner1Id]
      });
      assert.equal(nfrCase.status, 201);
      const nfrCaseId = nfrCase.data.id;

      const wavAsync = buildSynthesizedWav(1.5, 16000, 150);
      const upWav = await apiMultipart(
        baseUrl,
        '/api/evidence/upload',
        leadToken,
        { caseId: nfrCaseId },
        { fieldName: 'audio', filename: 'async_wav.wav', contentType: 'audio/wav', bytes: wavAsync }
      );
      assert.equal(upWav.status, 201);

      // Queue async WAV analysis -> 202 Accepted
      const qRes = await apiJson(baseUrl, 'POST', '/api/analyze-audio?async=true', leadToken, {
        caseId: nfrCaseId,
        evidenceId: upWav.data.id
      });
      assert.equal(qRes.status, 202);
      assert.ok(qRes.data.jobId && qRes.data.jobId.startsWith('JOB-'));
      assert.equal(qRes.data.status, 'QUEUED');

      // Separation of duties & Case ACL on job status endpoint
      const adminJobCheck = await apiJson(baseUrl, 'GET', `/api/analysis-jobs/${qRes.data.jobId}`, adminToken);
      assert.equal(adminJobCheck.status, 403);
      const ex2JobCheck = await apiJson(baseUrl, 'GET', `/api/analysis-jobs/${qRes.data.jobId}`, examiner2Token);
      assert.equal(ex2JobCheck.status, 403);
      const missingJobCheck = await apiJson(baseUrl, 'GET', '/api/analysis-jobs/JOB-NONEXISTENT', leadToken);
      assert.equal(missingJobCheck.status, 404);

      // Poll as assigned examiner until COMPLETED
      let jobData: any = null;
      for (let i = 0; i < 30; i++) {
        const poll = await apiJson(baseUrl, 'GET', `/api/analysis-jobs/${qRes.data.jobId}`, examiner1Token);
        assert.equal(poll.status, 200);
        if (poll.data.status === 'COMPLETED' || poll.data.status === 'FAILED') {
          jobData = poll.data;
          break;
        }
        await new Promise((r) => setTimeout(r, 25));
      }
      assert.ok(jobData, 'Async job did not settle within timeout');
      assert.equal(jobData.status, 'COMPLETED');
      assert.equal(jobData.result.overallConfidence, null);
      assert.equal(jobData.result.nonBiometricProfile?.measurementType, 'non-biometric measurement');

      // Queue async non-WAV MP3 -> settles to FAILED with statusCode 422
      const fakeMp3 = Buffer.from([0x49, 0x44, 0x33, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10]);
      const upMp3 = await apiMultipart(
        baseUrl,
        '/api/evidence/upload',
        leadToken,
        { caseId: nfrCaseId },
        { fieldName: 'audio', filename: 'async_bad.mp3', contentType: 'audio/mpeg', bytes: fakeMp3 }
      );
      assert.equal(upMp3.status, 201);

      const qBad = await apiJson(baseUrl, 'POST', '/api/analyze-audio?async=true', leadToken, {
        caseId: nfrCaseId,
        evidenceId: upMp3.data.id
      });
      assert.equal(qBad.status, 202);

      let badJobData: any = null;
      for (let i = 0; i < 30; i++) {
        const poll = await apiJson(baseUrl, 'GET', `/api/analysis-jobs/${qBad.data.jobId}`, leadToken);
        if (poll.data.status === 'COMPLETED' || poll.data.status === 'FAILED') {
          badJobData = poll.data;
          break;
        }
        await new Promise((r) => setTimeout(r, 25));
      }
      assert.ok(badJobData);
      assert.equal(badJobData.status, 'FAILED');
      assert.equal(badJobData.statusCode, 422);
    });
  } finally {
    await new Promise<void>((resolve) => httpServer.close(() => resolve()));
    fs.rmSync(tmpRoot, { recursive: true, force: true });
  }

  // Verify real database and backup remained untouched
  await testCase('7.1 Real project database and backup remained 100% unmodified during test execution', () => {
    const realStoreHashAfter = fileSha256IfExists(realStorePath);
    const realBackupHashAfter = fileSha256IfExists(realBackupPath);
    assert.equal(realStoreHashAfter, realStoreHashBefore, 'Real database SHA-256 changed during tests!');
    assert.equal(realBackupHashAfter, realBackupHashBefore, 'Backup database SHA-256 changed during tests!');
    if (fs.existsSync(realStorePath)) {
      const content = fs.readFileSync(realStorePath, 'utf-8');
      assert.ok(!content.includes('DS-TEST-'), 'Found leftover test case in real DB');
      assert.ok(!content.includes('qa-tester@'), 'Found leftover test email in real DB');
    }
  });

  const passed = results.filter((r) => r.passed).length;
  const failed = results.filter((r) => !r.passed).length;
  console.log('\n===================================================================');
  console.log(`ISOLATED QA SUMMARY: ${passed}/${results.length} PASSED, ${failed} FAILED`);
  console.log('===================================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

main().catch((err) => {
  console.error('Fatal test harness error:', err);
  process.exit(1);
});
