import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import nodemailer from 'nodemailer';

function resolveKeyDir(): string {
  if (process.env.ALFADETECT_KEY_DIR) {
    return path.resolve(process.env.ALFADETECT_KEY_DIR);
  }
  if (process.env.ALFADETECT_DB_PATH) {
    return path.join(path.dirname(path.resolve(process.env.ALFADETECT_DB_PATH)), 'keys');
  }
  return path.join(process.cwd(), 'data', 'keys');
}

function ensureKeyDir(): string {
  const dir = resolveKeyDir();
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  }
  return dir;
}

function getOrCreateSecretHex(envName: string, filename: string, byteLength: number): string {
  const envVal = process.env[envName]?.trim();
  if (envVal && envVal.length >= 16) {
    return crypto.createHash('sha256').update(envVal).digest('hex').slice(0, byteLength * 2);
  }
  const keyPath = path.join(ensureKeyDir(), filename);
  if (fs.existsSync(keyPath)) {
    return fs.readFileSync(keyPath, 'utf-8').trim();
  }
  const generated = crypto.randomBytes(byteLength).toString('hex');
  fs.writeFileSync(keyPath, generated, { encoding: 'utf-8', mode: 0o600 });
  return generated;
}

function getMasterKey(): Buffer {
  const hex = getOrCreateSecretHex('ALFADETECT_MASTER_KEY', 'enclave_master.key', 32);
  return Buffer.from(hex.slice(0, 64), 'hex');
}

function getJwtSecret(): string {
  const envVal = process.env.JWT_SECRET?.trim();
  if (envVal && envVal.length >= 24) return envVal;
  return getOrCreateSecretHex('JWT_SECRET', 'jwt_hmac.key', 48);
}

// ---------- AES-256-GCM Encryption at Rest (NFR-22) ----------

export function encryptSensitive(plaintext: string): string {
  const key = getMasterKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `aes256gcm$${iv.toString('hex')}$${tag.toString('hex')}$${encrypted.toString('hex')}`;
}

export function decryptSensitive(ciphertext: string): string {
  if (!ciphertext.startsWith('aes256gcm$')) {
    return ciphertext;
  }
  const parts = ciphertext.split('$');
  if (parts.length !== 4) {
    throw new Error('Malformed encrypted payload');
  }
  const [, ivHex, tagHex, dataHex] = parts;
  const key = getMasterKey();
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(dataHex, 'hex')),
    decipher.final()
  ]);
  return decrypted.toString('utf8');
}

const AUDIO_ENC_MAGIC = Buffer.from('ALFAENC1', 'ascii');

export function isEncryptedAudioBuffer(buf: Buffer): boolean {
  return buf.length >= AUDIO_ENC_MAGIC.length + 28 && buf.subarray(0, AUDIO_ENC_MAGIC.length).equals(AUDIO_ENC_MAGIC);
}

export function encryptAudioBuffer(plaintextBuffer: Buffer): Buffer {
  const key = getMasterKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintextBuffer), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([AUDIO_ENC_MAGIC, iv, tag, encrypted]);
}

export function decryptAudioBuffer(storedBuffer: Buffer): { buffer: Buffer | null; encrypted: boolean; tampered: boolean } {
  if (!storedBuffer || storedBuffer.length === 0) {
    return { buffer: null, encrypted: false, tampered: false };
  }
  if (!storedBuffer.subarray(0, AUDIO_ENC_MAGIC.length).equals(AUDIO_ENC_MAGIC)) {
    return { buffer: storedBuffer, encrypted: false, tampered: false };
  }
  if (storedBuffer.length < AUDIO_ENC_MAGIC.length + 28) {
    return { buffer: null, encrypted: true, tampered: true };
  }
  try {
    const ivStart = AUDIO_ENC_MAGIC.length;
    const tagStart = ivStart + 12;
    const dataStart = tagStart + 16;
    const iv = storedBuffer.subarray(ivStart, tagStart);
    const tag = storedBuffer.subarray(tagStart, dataStart);
    const ciphertext = storedBuffer.subarray(dataStart);
    const key = getMasterKey();
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(tag);
    const decrypted = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
    return { buffer: decrypted, encrypted: true, tampered: false };
  } catch {
    return { buffer: null, encrypted: true, tampered: true };
  }
}


// ---------- Password Hashing & Validation ----------

export function hashPassword(password: string, salt: string): string {
  const derived = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${derived.toString('hex')}`;
}

export function verifyPassword(password: string, salt: string, storedHash: string): boolean {
  if (!storedHash.startsWith('scrypt$')) return false;
  const expectedHex = storedHash.slice('scrypt$'.length);
  const derivedHex = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex');
  const expectedBuf = Buffer.from(expectedHex, 'hex');
  const derivedBuf = Buffer.from(derivedHex, 'hex');
  if (expectedBuf.length !== derivedBuf.length) return false;
  return crypto.timingSafeEqual(expectedBuf, derivedBuf);
}

export function validatePasswordStrength(password: string, email?: string): { valid: boolean; error?: string } {
  if (typeof password !== 'string' || password.length < 12) {
    return { valid: false, error: 'Password must be at least 12 characters long.' };
  }
  if (!/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/[0-9]/.test(password) || !/[^A-Za-z0-9]/.test(password)) {
    return { valid: false, error: 'Password must include uppercase, lowercase, a digit, and a special character.' };
  }
  if (email) {
    const localPart = String(email).split('@')[0]?.trim().toLowerCase();
    if (localPart && localPart.length >= 3 && password.toLowerCase().includes(localPart)) {
      return { valid: false, error: 'Password must not contain your email username.' };
    }
  }
  return { valid: true };
}

// ---------- JWT Session Management (FR-02) ----------

export interface JwtSessionClaims {
  sub: string;
  email: string;
  role: string;
  name: string;
  tv: number;
  jti: string;
  typ: 'session' | '2fa_challenge';
  iat?: number;
  exp?: number;
}

export function issueJwtToken(params: {
  userId: string;
  email: string;
  role: string;
  name: string;
  tokenVersion: number;
  typ?: 'session' | '2fa_challenge';
  expiresInSeconds?: number;
}): { token: string; jti: string; expiresAt: number } {
  const jti = crypto.randomUUID();
  const ttl = params.expiresInSeconds || 8 * 60 * 60; // 8 hours
  const expiresAt = Date.now() + ttl * 1000;
  const typ: 'session' | '2fa_challenge' = params.typ || (params.role === '2FA_CHALLENGE' ? '2fa_challenge' : 'session');
  const token = jwt.sign(
    {
      sub: params.userId,
      email: params.email,
      role: params.role,
      name: params.name,
      tv: params.tokenVersion,
      jti,
      typ
    },
    getJwtSecret(),
    { algorithm: 'HS256', expiresIn: ttl, issuer: 'ALFADetect' }
  );
  return { token, jti, expiresAt };
}

export function verifyJwtToken(token: string): JwtSessionClaims | null {
  try {
    const decoded = jwt.verify(token, getJwtSecret(), {
      algorithms: ['HS256'],
      issuer: 'ALFADetect'
    }) as JwtSessionClaims;
    if (!decoded || !decoded.sub || !decoded.email || !decoded.jti) return null;
    return decoded;
  } catch {
    return null;
  }
}

// ---------- Ed25519 Enclave Digital Signatures ----------

let cachedKeys: { privateKey: string; publicKey: string; keyId: string } | null = null;
let cachedKeyDir: string | null = null;

export function getEnclaveSigningKeys(): { privateKey: string; publicKey: string; keyId: string } {
  const dir = ensureKeyDir();
  if (cachedKeys && cachedKeyDir === dir) {
    return cachedKeys;
  }
  const privPath = path.join(dir, 'enclave_ed25519_priv.pem');
  const pubPath = path.join(dir, 'enclave_ed25519_pub.pem');

  if (fs.existsSync(privPath) && fs.existsSync(pubPath)) {
    const privateKey = fs.readFileSync(privPath, 'utf-8');
    const publicKey = fs.readFileSync(pubPath, 'utf-8');
    const keyId = crypto.createHash('sha256').update(publicKey).digest('hex').slice(0, 16).toUpperCase();
    cachedKeys = { privateKey, publicKey, keyId };
    cachedKeyDir = dir;
    return cachedKeys;
  }

  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519', {
    publicKeyEncoding: { type: 'spki', format: 'pem' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' }
  });

  fs.writeFileSync(privPath, privateKey, { encoding: 'utf-8', mode: 0o600 });
  fs.writeFileSync(pubPath, publicKey, { encoding: 'utf-8', mode: 0o644 });

  const keyId = crypto.createHash('sha256').update(publicKey).digest('hex').slice(0, 16).toUpperCase();
  cachedKeys = { privateKey, publicKey, keyId };
  cachedKeyDir = dir;
  return cachedKeys;
}

export function canonicalJson(value: unknown): string {
  if (value === null || typeof value !== 'object') {
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) {
    return '[' + value.map(canonicalJson).join(',') + ']';
  }
  const obj = value as Record<string, unknown>;
  const keys = Object.keys(obj)
    .filter((k) => obj[k] !== undefined)
    .sort();
  return '{' + keys.map((k) => `${JSON.stringify(k)}:${canonicalJson(obj[k])}`).join(',') + '}';
}

export function signCanonicalPayload(payload: unknown): {
  algorithm: 'Ed25519';
  keyId: string;
  payloadHash: string;
  signature: string;
  signatureDisplay: string;
} {
  const { privateKey, keyId } = getEnclaveSigningKeys();
  const canonical = canonicalJson(payload);
  const payloadHash = crypto.createHash('sha256').update(canonical).digest('hex');
  const sigBuf = crypto.sign(null, Buffer.from(canonical, 'utf8'), privateKey);
  const signature = sigBuf.toString('hex');
  return {
    algorithm: 'Ed25519',
    keyId,
    payloadHash,
    signature,
    signatureDisplay: `Ed25519:${keyId}:${signature}`
  };
}

export function verifyCanonicalPayload(payload: unknown, signatureOrDisplay: string): boolean {
  try {
    const { publicKey } = getEnclaveSigningKeys();
    const rawHex = signatureOrDisplay.startsWith('Ed25519:')
      ? signatureOrDisplay.split(':').slice(2).join(':')
      : signatureOrDisplay;
    if (!rawHex || !/^[0-9a-fA-F]+$/.test(rawHex)) return false;
    const canonical = canonicalJson(payload);
    return crypto.verify(null, Buffer.from(canonical, 'utf8'), publicKey, Buffer.from(rawHex, 'hex'));
  } catch {
    return false;
  }
}

// ---------- Cryptographic Hash-Chained Chain of Custody ----------

export function computeCustodyBlockHash(
  prevBlockHash: string,
  fields: {
    id: string;
    caseId: string;
    evidenceId?: string;
    eventNumber: number;
    title: string;
    actorRole: string;
    timestamp: string;
    userName: string;
    hashAtEvent?: string;
  }
): string {
  const material = canonicalJson({ prevBlockHash, ...fields });
  return crypto.createHash('sha256').update(material).digest('hex');
}

export function verifyCustodyChain(
  events: Array<{
    id: string;
    caseId: string;
    evidenceId?: string;
    eventNumber: number;
    title: string;
    actorRole: string;
    timestamp: string;
    userName: string;
    hashAtEvent?: string;
    prevBlockHash?: string;
    blockHash: string;
    digitalSignature: string;
  }>
): {
  valid: boolean;
  checkedCount: number;
  brokenAtEventNumber?: number;
  reason?: string;
} {
  const ordered = [...events].sort((a, b) => a.eventNumber - b.eventNumber);
  let expectedPrev = '0'.repeat(64);

  for (const evt of ordered) {
    const prevHash = evt.prevBlockHash || expectedPrev;
    if (evt.prevBlockHash && evt.prevBlockHash !== expectedPrev) {
      return {
        valid: false,
        checkedCount: ordered.length,
        brokenAtEventNumber: evt.eventNumber,
        reason: `Previous block hash mismatch at event #${evt.eventNumber}`
      };
    }

    const expectedHash = computeCustodyBlockHash(prevHash, {
      id: evt.id,
      caseId: evt.caseId,
      evidenceId: evt.evidenceId,
      eventNumber: evt.eventNumber,
      title: evt.title,
      actorRole: evt.actorRole,
      timestamp: evt.timestamp,
      userName: evt.userName,
      hashAtEvent: evt.hashAtEvent
    });

    if (evt.blockHash !== expectedHash) {
      return {
        valid: false,
        checkedCount: ordered.length,
        brokenAtEventNumber: evt.eventNumber,
        reason: `Block digest mismatch at event #${evt.eventNumber}`
      };
    }

    if (evt.digitalSignature.startsWith('Ed25519:')) {
      const sigOk = verifyCanonicalPayload(
        {
          id: evt.id,
          caseId: evt.caseId,
          evidenceId: evt.evidenceId,
          eventNumber: evt.eventNumber,
          title: evt.title,
          timestamp: evt.timestamp,
          blockHash: evt.blockHash
        },
        evt.digitalSignature
      );
      if (!sigOk) {
        return {
          valid: false,
          checkedCount: ordered.length,
          brokenAtEventNumber: evt.eventNumber,
          reason: `Ed25519 signature verification failed at event #${evt.eventNumber}`
        };
      }
    } else {
      return {
        valid: false,
        checkedCount: ordered.length,
        brokenAtEventNumber: evt.eventNumber,
        reason: `Legacy or unverified signature format at event #${evt.eventNumber}`
      };
    }

    expectedPrev = evt.blockHash;
  }

  return { valid: true, checkedCount: ordered.length };
}

// ---------- RFC 6238 TOTP Two-Factor Authentication ----------

const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

export function base32Encode(buf: Buffer): string {
  let bits = 0;
  let value = 0;
  let output = '';
  for (const byte of buf) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      output += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) {
    output += BASE32_ALPHABET[(value << (5 - bits)) & 31];
  }
  return output;
}

export function base32Decode(str: string): Buffer {
  const cleaned = str.toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = 0;
  let value = 0;
  const out: number[] = [];
  for (const ch of cleaned) {
    const idx = BASE32_ALPHABET.indexOf(ch);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

export function generateTotpSecret(): string {
  return base32Encode(crypto.randomBytes(20));
}

export function buildTotpUri(params: { secret: string; email: string; issuer?: string }): string {
  const issuer = params.issuer || 'ALFADetect';
  const label = encodeURIComponent(`${issuer}:${params.email}`);
  return `otpauth://totp/${label}?secret=${params.secret}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;
}

export function computeTotpCode(secretBase32: string, timestampMs: number = Date.now()): string {
  const key = base32Decode(secretBase32);
  const counter = Math.floor(timestampMs / 1000 / 30);
  const counterBuf = Buffer.alloc(8);
  counterBuf.writeUInt32BE(Math.floor(counter / 0x100000000), 0);
  counterBuf.writeUInt32BE(counter >>> 0, 4);

  const hmac = crypto.createHmac('sha1', key).update(counterBuf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const binary =
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff);

  return String(binary % 1_000_000).padStart(6, '0');
}

export function verifyTotpCodeWithStep(
  secretBase32: string,
  candidateCode: string,
  windowSteps: number = 1
): { valid: boolean; timeStep?: number } {
  const clean = (candidateCode || '').replace(/\s+/g, '');
  if (!/^\d{6}$/.test(clean)) return { valid: false };
  const now = Date.now();
  const currentStep = Math.floor(now / 1000 / 30);
  const candBuf = Buffer.from(clean, 'utf8');
  for (let w = -windowSteps; w <= windowSteps; w++) {
    const expected = computeTotpCode(secretBase32, now + w * 30_000);
    const expBuf = Buffer.from(expected, 'utf8');
    if (expBuf.length === candBuf.length && crypto.timingSafeEqual(expBuf, candBuf)) {
      return { valid: true, timeStep: currentStep + w };
    }
  }
  return { valid: false };
}

export function verifyTotpCode(secretBase32: string, candidateCode: string, windowSteps: number = 1): boolean {
  return verifyTotpCodeWithStep(secretBase32, candidateCode, windowSteps).valid;
}

export function generateRecoveryCodes(count: number = 8): { plaintextCodes: string[]; hashes: string[] } {
  const plaintextCodes: string[] = [];
  const hashes: string[] = [];
  for (let i = 0; i < count; i++) {
    const partA = crypto.randomBytes(2).toString('hex').toUpperCase();
    const partB = crypto.randomBytes(2).toString('hex').toUpperCase();
    const code = `ALFA-${partA}-${partB}`;
    plaintextCodes.push(code);
    hashes.push(hashRecoveryCode(code));
  }
  return { plaintextCodes, hashes };
}

export function hashRecoveryCode(code: string): string {
  return crypto.createHash('sha256').update(code.trim().toUpperCase()).digest('hex');
}

// ---------- Magic-Byte Audio Validation (FR-03, FR-21) ----------

export interface AudioFormatValidation {
  valid: boolean;
  detectedFormat?: 'WAV' | 'MP3' | 'FLAC' | 'M4A' | 'OGG';
  mimeType?: string;
  error?: string;
}

const SUPPORTED_EXT_LIST = ['.wav', '.mp3', '.flac', '.m4a', '.ogg'];

export function validateAudioBufferAndFilename(buffer: Buffer, filename: string): AudioFormatValidation {
  if (!buffer || buffer.length === 0) {
    return { valid: false, error: 'Empty audio file: 0 bytes received.' };
  }
  if (buffer.length > 50 * 1024 * 1024) {
    return { valid: false, error: 'Audio file exceeds maximum size limit (50 MB).' };
  }
  const ext = path.extname(filename || '').toLowerCase();
  if (!SUPPORTED_EXT_LIST.includes(ext)) {
    return {
      valid: false,
      error: `Unsupported extension "${ext || 'unknown'}". Allowed formats: WAV, MP3, FLAC, M4A, OGG.`
    };
  }

  // Magic-byte verification
  const isWav =
    buffer.length >= 12 &&
    buffer.toString('ascii', 0, 4) === 'RIFF' &&
    buffer.toString('ascii', 8, 12) === 'WAVE';
  const isFlac = buffer.length >= 4 && buffer.toString('ascii', 0, 4) === 'fLaC';
  const isOgg = buffer.length >= 4 && buffer.toString('ascii', 0, 4) === 'OggS';
  const isId3Mp3 = buffer.length >= 3 && buffer.toString('ascii', 0, 3) === 'ID3';
  const isMpegFrame =
    buffer.length >= 2 &&
    buffer[0] === 0xff &&
    (buffer[1] & 0xe0) === 0xe0;
  const isM4a = buffer.length >= 12 && buffer.toString('ascii', 4, 8) === 'ftyp';

  let detectedFormat: AudioFormatValidation['detectedFormat'];
  let mimeType: string | undefined;

  if (isWav) {
    detectedFormat = 'WAV';
    mimeType = 'audio/wav';
  } else if (isFlac) {
    detectedFormat = 'FLAC';
    mimeType = 'audio/flac';
  } else if (isOgg) {
    detectedFormat = 'OGG';
    mimeType = 'audio/ogg';
  } else if (isId3Mp3 || isMpegFrame) {
    detectedFormat = 'MP3';
    mimeType = 'audio/mpeg';
  } else if (isM4a) {
    detectedFormat = 'M4A';
    mimeType = 'audio/mp4';
  }

  if (!detectedFormat) {
    return {
      valid: false,
      error: `File binary header failed magic-byte audio verification for ${filename}. Uploaded bytes do not match a valid WAV, MP3, FLAC, M4A, or OGG stream.`
    };
  }

  const extMatchMap: Record<string, string[]> = {
    WAV: ['.wav'],
    MP3: ['.mp3'],
    FLAC: ['.flac'],
    M4A: ['.m4a'],
    OGG: ['.ogg']
  };
  if (!extMatchMap[detectedFormat].includes(ext)) {
    return {
      valid: false,
      error: `File extension "${ext}" does not match detected container signature "${detectedFormat}".`
    };
  }

  return { valid: true, detectedFormat, mimeType };
}

// ---------- XSS HTML Escaping ----------

export function escapeHtml(input: unknown): string {
  return String(input ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ---------- Real SMTP Dispatch (Nodemailer) ----------

export interface SmtpDispatchResult {
  configured: boolean;
  sent: boolean;
  error?: string;
}

export function isSmtpConfigured(): boolean {
  const host = (process.env.SMTP_HOST || '').trim();
  const user = (process.env.SMTP_USER || '').trim();
  const pass = (process.env.SMTP_PASS || '').trim();
  return Boolean(host && user && pass);
}

export async function sendSmtpEmail(params: {
  to: string;
  subject: string;
  text: string;
  html: string;
}): Promise<SmtpDispatchResult> {
  if (!isSmtpConfigured()) {
    return {
      configured: false,
      sent: false,
      error: 'SMTP server is not configured (SMTP_HOST, SMTP_USER, SMTP_PASS required).'
    };
  }

  try {
    const port = Number(process.env.SMTP_PORT) || 587;
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST!.trim(),
      port,
      secure: port === 465,
      auth: {
        user: process.env.SMTP_USER!.trim(),
        pass: process.env.SMTP_PASS!.trim()
      },
      connectionTimeout: 8000,
      greetingTimeout: 8000
    });

    await transporter.verify();
    await transporter.sendMail({
      from: (process.env.SMTP_FROM || process.env.SMTP_USER!).trim(),
      to: params.to,
      subject: params.subject,
      text: params.text,
      html: params.html
    });

    return { configured: true, sent: true };
  } catch (err: any) {
    return {
      configured: true,
      sent: false,
      error: err?.message || 'SMTP delivery failed.'
    };
  }
}
