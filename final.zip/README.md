# ALFADetect — Explainable AI Deepfake Audio & Forensic Evidence Platform

ALFADetect is a forensic audio verification and digital evidence management platform built with **React 19 + TypeScript + Tailwind CSS v4** on an **Express + Vite** full-stack enclave server (`server.ts`).

Results produced by automated deepfake detection, speaker verification, and acoustic DSP pipelines are **probabilistic decision support only — never standalone proof of identity or fabrication** — and require accredited human forensic examiner evaluation under **SWGDE** guidelines and **Federal Rules of Evidence 702 & 902(13)/(14)**.

---

## Architecture & Security Model

- **Four Institutional Roles & Separation of Duties**
  - `Lead Forensic Analyst` — docket creation, evidence upload, collaborator ACL assignment, AI/DSP pipeline execution, report export.
  - `Forensic Examiner / Expert Witness` — DSP/AI inspection, voice condition & speaker comparison, SWGDE attestation, password + TOTP re-authenticated Ed25519 signoff.
  - `Prosecutor / Legal Reviewer` — read-only forensic inspection, Daubert/Frye court admissibility review & certification, chain-of-custody verification.
  - `System Security Administrator` — strictly **one** active administrator enforced across bootstrap (`POST /api/setup/init-admin`), approval, role update, and atomic transfer (`POST /api/admin/transfer-admin`). Enforces strict separation of duties (administrators cannot stream raw audio evidence, read forensic reports, or inspect evidence metadata).
- **Cryptographic Evidence Integrity**
  - Evidence and reference exemplars are encrypted at rest (`AES-256-GCM`, header `ALFAENC1`) in `/data/uploads`.
  - Server-authoritative SHA-256 hashing on multipart ingest, non-destructive working copies (`POST /api/evidence/:id/derive-copy` referencing `parentEvidenceId`), and tamper detection (`409 Conflict` + automated `NOTIF-TAMPER` alerts).
  - Append-only SHA-256 hash-linked and Ed25519-signed chain-of-custody ledger (`GET /api/cases/:caseId/chain-of-custody/verify`).
- **Honest AI & Biometric Adapter Architecture**
  - Built-in deterministic PCM WAV decoder (1–16ch, 8/16/24/32-bit int & IEEE float, `WAVE_FORMAT_EXTENSIBLE`) and physical DSP extractor (`YIN / autocorrelation F0`, jitter, shimmer, HNR, STFT spectral features, 24-band Mel, 13 MFCCs, 13 LFCCs, VAD), explicitly tagged **`non-biometric measurement`**.
  - Neural classifiers (CNN, BiLSTM, Wav2Vec2, ECAPA-TDNN, Grad-CAM/TreeSHAP) return `MODEL_UNAVAILABLE` with `null` confidence/similarity scores unless `ALFADETECT_AI_SERVICE_URL` / `ALFADETECT_SPEAKER_SERVICE_URL` are configured.
- **Asynchronous Analysis Queue (`NFR-31`)**
  - `POST /api/analyze-audio?async=true` (or `{ async: true }`) queues analysis work in-process and immediately returns HTTP `202 Accepted` with `{ jobId, status: 'QUEUED' }`.
  - Case-ACL protected polling via `GET /api/analysis-jobs/:jobId` returns live `QUEUED | PROCESSING | COMPLETED | FAILED` status and full server-authoritative result payload.
  - Default `POST /api/analyze-audio` preserves backward-compatible synchronous execution.

---

## Setup & Commands

```bash
# Install dependencies
npm install

# Configure environment (optional overrides; see .env.example)
cp .env.example .env

# Run full-stack development server (port 3000)
npm run dev

# Initialize sole System Security Administrator via CLI (optional; also supported in UI)
npm run init-admin

# Typecheck & run isolated QA, security, DSP, and E2E test suite
npm run lint
npm test

# Production build & start
npm run build
npm start
```

---

## Security Architecture Note: JWT Storage vs. Preview Iframe Context

ALFADetect transmits authenticated session tokens via `Authorization: Bearer <jwt>` headers persisted in browser `localStorage` (`auth_session_token`), paired with short-lived token versioning (`tokenVersion`), JTI revocation on sign-out/suspension/password-rotation, 5-minute inactivity terminal lock (`POST /api/auth/reauth`), and strict `helmet` CSP headers.

In standalone single-origin deployments, migrating session delivery to `HttpOnly; Secure; SameSite=Lax` cookies is recommended to eliminate script-level token access. In embedded cross-origin preview iframes (such as AI Studio previews where third-party `SameSite=Lax/Strict` cookies are blocked or stripped by modern browsers), explicit `Bearer` JWT headers ensure deterministic authentication without weakening CORS/CSRF protections.
