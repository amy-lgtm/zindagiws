import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import {
  encryptSensitive,
  decryptSensitive,
  encryptAudioBuffer,
  decryptAudioBuffer,
  isEncryptedAudioBuffer
} from './serverSecurity';

export const SYSTEM_ADMIN_ROLE = 'System Security Administrator';

export interface StoredCase {
  id: string;
  title: string;
  description: string;
  status: 'Active' | 'Under Review' | 'Pending Legal' | 'Completed' | 'Archived';
  verdict: 'DEEPFAKE' | 'AUTHENTIC' | 'INCONCLUSIVE';
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  analyst: string;
  agency: string;
  date: string;
  updatedDate: string;
  evidenceCount: number;
  threatScore?: number;
  createdBy: string;
  assignedUserIds?: string[];
}

export interface StoredEvidence {
  id: string;
  caseId: string;
  filename: string;
  fileSize: string;
  duration: string;
  sampleRate: string;
  bitDepth: string;
  channels: string;
  sha256Hash: string;
  uploadTimestamp: string;
  status: 'Uploaded' | 'Preprocessing' | 'Processed' | 'Verified' | 'Failed';
  audioUrl?: string;
  audioData?: string; // Legacy inline base64 fallback
  storageFilename?: string; // Stored outside public webroot in upload directory
  byteSize?: number;
  mimeType?: string;
  detectedFormat?: string;
  uploadedBy?: string;
  classification?: string;
  verifiedBy?: string;
  verificationDate?: string;
  isIntegrityVerified?: boolean;
  parentEvidenceId?: string;
  isDerivedCopy?: boolean;
  processingOperation?: string;
}

export interface StoredReferenceSample {
  id: string;
  caseId: string;
  subjectName: string;
  filename: string;
  fileSize: string;
  duration: string;
  sha256Hash: string;
  conditionTag: 'Normal' | 'Illness/Cold' | 'Whispering' | 'Disguised' | 'Other';
  lawfulConsentDeclared: boolean;
  consentNotes: string;
  uploadedBy: string;
  uploadedAt: string;
  audioData?: string;
  storageFilename?: string;
  byteSize?: number;
  mimeType?: string;
  detectedFormat?: string;
}

export interface StoredSpeakerVerification {
  id: string;
  caseId: string;
  evidenceId: string;
  referenceId: string;
  subjectName: string;
  verdict:
    | 'Analysis completed'
    | 'Consistent with the same speaker'
    | 'Not sufficiently consistent with the same speaker'
    | 'Inconclusive'
    | 'Insufficient audio quality'
    | 'Reference recording missing'
    | 'Model unavailable'
    | 'Analysis failed';
  similarityScore: number | null;
  threshold: number;
  speechDurationSeconds: number;
  evidenceIsSynthetic: boolean;
  decisionNote: string;
  modelsUsed: string[];
  referenceProvenance?: string;
  evidenceSha256?: string;
  referenceSha256?: string;
  limitations: string;
  analyzedAt: string;
  acousticComparison?: {
    f0DeltaHz: number;
    spectralDistance: number;
    jitterRatio: number;
    hnrDifferenceDb: number;
  };
}

export interface StoredVoiceDisguise {
  id: string;
  caseId: string;
  evidenceId: string;
  questionedFilename: string;
  referenceFilename?: string;
  evidenceSha256?: string;
  audioQualityStatus: 'Sufficient for analysis' | 'Marginal' | 'Insufficient for analysis';
  acousticMeasurements: any;
  referenceMeasurements?: any;
  hypotheses: Array<{
    hypothesis: string;
    likelihood: string;
    findings: string;
    supportingFeatures: string[];
  }>;
  overallSummary: string;
  scientificLimitations: string;
  expertNotes?: string;
  analyzedAt: string;
}

export interface StoredChainOfCustodyEvent {
  id: string;
  caseId: string;
  evidenceId?: string;
  eventNumber: number;
  title: string;
  actorRole: 'System' | 'Lead Analyst' | 'Automated' | 'Expert' | 'Legal';
  status: 'VERIFIED' | 'PENDING';
  timestamp: string;
  userName: string;
  ipAddress: string;
  digitalSignature: string;
  prevBlockHash?: string;
  blockHash: string;
  payloadHash?: string;
  hashAtEvent?: string;
  details?: string;
}

export interface StoredExpertReview {
  id: string;
  caseId: string;
  expertUserId?: string;
  expertName: string;
  email?: string;
  institution: string;
  certificationId: string;
  status: 'Approved' | 'Pending' | 'Disputed';
  technicalAssessment: string;
  overrideReason?: string;
  checklist: {
    swgdeStandards: boolean;
    chainOfCustodyVerified: boolean;
    reproducibleOutputs: boolean;
    confidenceIntervalsValid: boolean;
    acousticSpectralInspected?: boolean;
  };
  digitalSignature: string;
  signedAt: string;
  authMethodUsed?: 'PASSWORD_REAUTH' | 'PASSWORD_AND_TOTP';
  biometricVerified?: boolean;
  biometricScore?: number | null;
}

export interface StoredNotification {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  read: boolean;
  severity: 'critical' | 'success' | 'info' | 'warning';
  caseId?: string;
  targetRole?: string;
  targetUserId?: string;
  targetEmail?: string;
}

export interface StoredAuditLog {
  id: string;
  timestamp: string;
  user: string;
  action: 'VIEW' | 'WRITE' | 'SIGN' | 'UPLOAD' | 'VERIFY' | 'LOGIN' | 'CONFIG' | 'DELETE';
  resource: string;
  ipAddress: string;
  status: 'SUCCESS' | 'FAILED';
  details?: string;
  role?: string;
}

export interface StoredUserRecord {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  salt: string;
  role: string;
  requestedRole?: string;
  agency: string;
  department?: string;
  avatar: string;
  status: 'active' | 'pending' | 'rejected' | 'suspended' | 'inactive';
  casesCount: number;
  phone?: string;
  securityClearance?: string;
  certificationId?: string;
  rejectionReason?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  createdAt?: string;
  tokenVersion: number;
  twoFactorEnabled?: boolean;
  twoFactorMethod?: 'NONE' | 'TOTP';
  totpSecretEnc?: string;
  pendingTotpSecretEnc?: string;
  lastTotpStep?: number;
  mustChangePassword?: boolean;
  recoveryCodeHashes?: string[];
  themePreference?: 'light' | 'dark' | 'system';
  failedLoginCount?: number;
  lockedUntil?: number;
  pendingEmailChange?: {
    newEmail: string;
    codeHash: string;
    expiresAt: number;
  };
  lastLoginAt?: string;
  notificationPreferences?: Record<string, boolean>;
}

export interface StoredBiometricRecord {
  expertId: string;
  expertName: string;
  minutiaeHash: string;
  enrolledAt: string;
  ridgeCount: number;
  patternType: 'Whorl' | 'Right Loop' | 'Left Loop' | 'Arch';
  technology: string;
  biometricVectorEnc?: string;
  biometricVector?: number[];
  credentialId?: string;
}

export interface StoredLegalReview {
  caseId: string;
  legalCounsel: string;
  jurisdiction: string;
  status: 'UNDER REVIEW' | 'CERTIFIED' | 'REJECTED';
  readinessProgress: string;
  items: Array<{ id: string; label: string; status: 'COMPLETE' | 'PENDING' }>;
  notes?: string;
  certifiedAt?: string;
  certifiedBy?: string;
}

export interface StoredDeepfakeAnalysis {
  id: string;
  caseId: string;
  evidenceId: string;
  filename: string;
  sha256Hash: string;
  analyzedAt: string;
  analyzedBy: string;
  verdict: 'DEEPFAKE' | 'AUTHENTIC' | 'INCONCLUSIVE';
  overallConfidence: number | null;
  status: 'COMPLETED' | 'INCONCLUSIVE' | 'MODEL_UNAVAILABLE' | 'INSUFFICIENT_AUDIO';
  note: string;
  pipelineMetrics?: {
    spectralCentroidHz: number | null;
    jitterPercent: number | null;
    shimmerPercent?: number | null;
    hnrDb: number | null;
    f0MeanHz?: number | null;
    speechDurationSec?: number | null;
    estimatedSnrDb?: number | null;
  };
  models: Array<{
    key?: string;
    name: string;
    status: 'AVAILABLE' | 'MODEL_UNAVAILABLE' | 'INSUFFICIENT_AUDIO' | 'ERROR';
    verdict?: 'DEEPFAKE' | 'AUTHENTIC' | 'INCONCLUSIVE';
    confidence?: number | null;
    note?: string;
    version?: string;
  }>;
  acousticMeasurements?: any;
  nonBiometricProfile?: any;
}

export interface StoredPublicReport {
  token: string;
  reportId: string;
  caseId: string;
  evidenceId: string;
  evidenceFilename: string;
  evidenceSha256: string;
  verdict: 'DEEPFAKE' | 'AUTHENTIC' | 'INCONCLUSIVE';
  confidenceScore: number | null;
  leadAnalyst: string;
  expertWitness: string;
  expertCertificationId: string;
  signatureMethod: string;
  biometricVerified: boolean;
  biometricScore: number | null;
  biometricTechnology: string;
  signedAt: string;
  digitalSealHash: string;
  digitalSignature?: string;
  revoked: boolean;
  tampered: boolean;
}

export interface StoredSystemConfig {
  verificationThreshold: number;
  inconclusiveBand: number;
  minSpeechDurationSec: number;
  thresholdVersion: string;
  retentionDaysEvidence: number;
  retentionDaysLogs: number;
  enforceTwoFactor: boolean;
  enableGeminiAdvisory: boolean;
  sessionTtlMinutes: number;
  idleLockMinutes: number;
  updatedAt?: string;
  updatedBy?: string;
}

export interface StoredPendingRegistration {
  email: string;
  name: string;
  agency: string;
  department?: string;
  role: string;
  certificationId?: string;
  passwordHash: string;
  salt: string;
  otpHash: string;
  expiresAt: number;
  createdAt: number;
  failedAttempts?: number;
  resendCount?: number;
  lastResendAt?: number;
}

export interface StoredRevokedToken {
  jti: string;
  expiresAt: number;
}

export interface StoredPasswordResetToken {
  id: string;
  userId: string;
  email: string;
  tokenHash: string;
  expiresAt: number;
  createdAt: number;
}

export interface DatabaseSchema {
  cases: StoredCase[];
  evidence: StoredEvidence[];
  referenceSamples: StoredReferenceSample[];
  speakerVerifications: StoredSpeakerVerification[];
  voiceDisguiseAnalyses: StoredVoiceDisguise[];
  chainOfCustody: StoredChainOfCustodyEvent[];
  expertReviews: StoredExpertReview[];
  legalReviews: StoredLegalReview[];
  deepfakeAnalyses: StoredDeepfakeAnalysis[];
  publicReports: StoredPublicReport[];
  notifications: StoredNotification[];
  auditLogs: StoredAuditLog[];
  users: StoredUserRecord[];
  biometricTemplates: StoredBiometricRecord[];
  systemConfig: StoredSystemConfig;
  pendingRegistrations: StoredPendingRegistration[];
  revokedTokens: StoredRevokedToken[];
  passwordResetTokens: StoredPasswordResetToken[];
}

export const DEFAULT_SYSTEM_CONFIG: StoredSystemConfig = {
  verificationThreshold: 78,
  inconclusiveBand: 6,
  minSpeechDurationSec: 5,
  thresholdVersion: 'v1.0-SWGDE',
  retentionDaysEvidence: 2555,
  retentionDaysLogs: 3650,
  enforceTwoFactor: false,
  enableGeminiAdvisory: false,
  sessionTtlMinutes: 480,
  idleLockMinutes: 5
};

function resolveDbFilePath(): string {
  return process.env.ALFADETECT_DB_PATH
    ? path.resolve(process.env.ALFADETECT_DB_PATH)
    : path.join(process.cwd(), 'data', 'alfadetect_store.json');
}

function resolveUploadDir(dbFilePath: string): string {
  if (process.env.ALFADETECT_UPLOAD_DIR) {
    return path.resolve(process.env.ALFADETECT_UPLOAD_DIR);
  }
  return path.join(path.dirname(dbFilePath), 'uploads');
}

class ServerDatabase {
  private dbFilePath: string;
  private uploadDir: string;
  private auditArchivePath: string;
  private data: DatabaseSchema = this.emptySchema();

  constructor() {
    this.dbFilePath = resolveDbFilePath();
    this.uploadDir = resolveUploadDir(this.dbFilePath);
    this.auditArchivePath = path.join(path.dirname(this.dbFilePath), 'alfadetect_audit_archive.jsonl');
    this.init();
  }

  private emptySchema(): DatabaseSchema {
    return {
      cases: [],
      evidence: [],
      referenceSamples: [],
      speakerVerifications: [],
      voiceDisguiseAnalyses: [],
      chainOfCustody: [],
      expertReviews: [],
      legalReviews: [],
      deepfakeAnalyses: [],
      publicReports: [],
      notifications: [],
      auditLogs: [],
      users: [],
      biometricTemplates: [],
      systemConfig: { ...DEFAULT_SYSTEM_CONFIG },
      pendingRegistrations: [],
      revokedTokens: [],
      passwordResetTokens: []
    };
  }

  public reinitializePathsForTest(customDbPath: string, customUploadDir?: string) {
    this.dbFilePath = path.resolve(customDbPath);
    this.uploadDir = customUploadDir
      ? path.resolve(customUploadDir)
      : path.join(path.dirname(this.dbFilePath), 'uploads');
    this.auditArchivePath = path.join(path.dirname(this.dbFilePath), 'alfadetect_audit_archive.jsonl');
    this.init();
  }

  public getUploadDir(): string {
    if (!fs.existsSync(this.uploadDir)) {
      fs.mkdirSync(this.uploadDir, { recursive: true, mode: 0o700 });
    }
    return this.uploadDir;
  }

  private init() {
    try {
      const dataDir = path.dirname(this.dbFilePath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      if (!fs.existsSync(this.uploadDir)) {
        fs.mkdirSync(this.uploadDir, { recursive: true, mode: 0o700 });
      }

      if (fs.existsSync(this.dbFilePath)) {
        const fileContent = fs.readFileSync(this.dbFilePath, 'utf-8');
        const parsed = JSON.parse(fileContent);
        this.data = {
          cases: Array.isArray(parsed.cases) ? parsed.cases : [],
          evidence: Array.isArray(parsed.evidence) ? parsed.evidence : [],
          referenceSamples: Array.isArray(parsed.referenceSamples) ? parsed.referenceSamples : [],
          speakerVerifications: Array.isArray(parsed.speakerVerifications) ? parsed.speakerVerifications : [],
          voiceDisguiseAnalyses: Array.isArray(parsed.voiceDisguiseAnalyses) ? parsed.voiceDisguiseAnalyses : [],
          chainOfCustody: Array.isArray(parsed.chainOfCustody) ? parsed.chainOfCustody : [],
          expertReviews: Array.isArray(parsed.expertReviews) ? parsed.expertReviews : [],
          legalReviews: Array.isArray(parsed.legalReviews) ? parsed.legalReviews : [],
          deepfakeAnalyses: Array.isArray(parsed.deepfakeAnalyses) ? parsed.deepfakeAnalyses : [],
          publicReports: Array.isArray(parsed.publicReports) ? parsed.publicReports : [],
          notifications: Array.isArray(parsed.notifications) ? parsed.notifications : [],
          auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : [],
          users: Array.isArray(parsed.users)
            ? parsed.users.map((u: any) => ({ ...u, tokenVersion: typeof u.tokenVersion === 'number' ? u.tokenVersion : 1 }))
            : [],
          biometricTemplates: Array.isArray(parsed.biometricTemplates) ? parsed.biometricTemplates : [],
          systemConfig: { ...DEFAULT_SYSTEM_CONFIG, ...(parsed.systemConfig || {}) },
          pendingRegistrations: Array.isArray(parsed.pendingRegistrations) ? parsed.pendingRegistrations : [],
          revokedTokens: Array.isArray(parsed.revokedTokens) ? parsed.revokedTokens : [],
          passwordResetTokens: Array.isArray(parsed.passwordResetTokens) ? parsed.passwordResetTokens : []
        };
      } else {
        this.seedCleanState();
        this.save();
      }
      this.migrateUnencryptedUploads();
    } catch (err) {
      console.warn('Database initialization notice:', err);
      this.seedCleanState();
    }
  }

  private migrateUnencryptedUploads() {
    try {
      if (!fs.existsSync(this.uploadDir)) return;
      const entries = fs.readdirSync(this.uploadDir);
      for (const name of entries) {
        if (name.endsWith('.tmp')) continue;
        const fullPath = path.join(this.uploadDir, name);
        const stat = fs.statSync(fullPath);
        if (!stat.isFile() || stat.size === 0) continue;
        const raw = fs.readFileSync(fullPath);
        if (!isEncryptedAudioBuffer(raw)) {
          const encrypted = encryptAudioBuffer(raw);
          const tmpPath = `${fullPath}.${process.pid}.enc.tmp`;
          fs.writeFileSync(tmpPath, encrypted, { mode: 0o600 });
          fs.renameSync(tmpPath, fullPath);
        }
      }
    } catch (err) {
      console.warn('Upload encryption migration notice:', err);
    }
  }

  private seedCleanState() {
    const now = new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    this.data = this.emptySchema();
    this.data.auditLogs.push({
      id: 'AUD-INIT-001',
      timestamp: now,
      user: 'System Security Engine',
      action: 'CONFIG',
      resource: 'ALFADetect Immutable Forensic Ledger Initialized (Clean State)',
      ipAddress: '127.0.0.1',
      status: 'SUCCESS'
    });
  }

  // Atomic temp+rename save so concurrent writes/crashes cannot corrupt JSON store
  public save() {
    const dataDir = path.dirname(this.dbFilePath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    const tmpPath = `${this.dbFilePath}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmpPath, JSON.stringify(this.data, null, 2), 'utf-8');
    fs.renameSync(tmpPath, this.dbFilePath);
  }

  // Encrypted binary audio file persistence outside public static dir (AES-256-GCM at rest)
  public saveAudioFile(recordId: string, originalFilename: string, buffer: Buffer): {
    storageFilename: string;
    byteSize: number;
  } {
    const dir = this.getUploadDir();
    const safeExt = path.extname(originalFilename || '').toLowerCase().replace(/[^a-z0-9.]/g, '') || '.bin';
    const safeId = recordId.replace(/[^a-zA-Z0-9_-]/g, '');
    const storageFilename = `${safeId}_${crypto.randomBytes(6).toString('hex')}${safeExt}`;
    const targetPath = path.join(dir, storageFilename);
    const tmpPath = `${targetPath}.tmp`;
    const encrypted = encryptAudioBuffer(buffer);
    fs.writeFileSync(tmpPath, encrypted, { mode: 0o600 });
    fs.renameSync(tmpPath, targetPath);
    return { storageFilename, byteSize: buffer.length };
  }

  public readAudioBufferWithStatus(record: { storageFilename?: string; audioData?: string }): {
    buffer: Buffer | null;
    tampered: boolean;
  } {
    if (record.storageFilename) {
      const targetPath = path.join(this.getUploadDir(), path.basename(record.storageFilename));
      if (fs.existsSync(targetPath)) {
        const diskBytes = fs.readFileSync(targetPath);
        const decoded = decryptAudioBuffer(diskBytes);
        return { buffer: decoded.buffer, tampered: decoded.tampered };
      }
    }
    if (record.audioData) {
      return { buffer: Buffer.from(record.audioData, 'base64'), tampered: false };
    }
    return { buffer: null, tampered: false };
  }

  public readAudioBuffer(record: { storageFilename?: string; audioData?: string }): Buffer | null {
    return this.readAudioBufferWithStatus(record).buffer;
  }

  // ---------- Cases ----------
  public getCases(includeArchived: boolean = true): StoredCase[] {
    if (includeArchived) return this.data.cases;
    return this.data.cases.filter((c) => c.status !== 'Archived');
  }

  public getCaseById(id: string): StoredCase | undefined {
    return this.data.cases.find((c) => c.id === id);
  }

  public createCase(newCase: StoredCase): StoredCase {
    this.data.cases.unshift(newCase);
    this.save();
    return newCase;
  }

  public updateCase(id: string, updates: Partial<StoredCase>): StoredCase | null {
    const index = this.data.cases.findIndex((c) => c.id === id);
    if (index === -1) return null;
    this.data.cases[index] = {
      ...this.data.cases[index],
      ...updates,
      updatedDate: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC'
    };
    this.save();
    return this.data.cases[index];
  }

  public archiveCase(id: string): StoredCase | null {
    return this.updateCase(id, { status: 'Archived' });
  }

  public purgeCaseCompletely(id: string): { purged: boolean; filesRemoved: number } {
    const existing = this.getCaseById(id);
    if (!existing) return { purged: false, filesRemoved: 0 };

    let filesRemoved = 0;
    const evFiles = this.data.evidence.filter((e) => e.caseId === id).map((e) => e.storageFilename).filter(Boolean) as string[];
    const refFiles = this.data.referenceSamples.filter((r) => r.caseId === id).map((r) => r.storageFilename).filter(Boolean) as string[];
    for (const fname of [...evFiles, ...refFiles]) {
      const targetPath = path.join(this.getUploadDir(), path.basename(fname));
      if (fs.existsSync(targetPath)) {
        try {
          fs.unlinkSync(targetPath);
          filesRemoved++;
        } catch {
          // Ignore file unlink edge errors
        }
      }
    }

    this.data.cases = this.data.cases.filter((c) => c.id !== id);
    this.data.evidence = this.data.evidence.filter((e) => e.caseId !== id);
    this.data.referenceSamples = this.data.referenceSamples.filter((r) => r.caseId !== id);
    this.data.speakerVerifications = this.data.speakerVerifications.filter((v) => v.caseId !== id);
    this.data.voiceDisguiseAnalyses = this.data.voiceDisguiseAnalyses.filter((d) => d.caseId !== id);
    this.data.chainOfCustody = this.data.chainOfCustody.filter((coc) => coc.caseId !== id);
    this.data.expertReviews = this.data.expertReviews.filter((r) => r.caseId !== id);
    this.data.legalReviews = this.data.legalReviews.filter((l) => l.caseId !== id);
    this.data.deepfakeAnalyses = this.data.deepfakeAnalyses.filter((a) => a.caseId !== id);
    this.data.publicReports = this.data.publicReports.filter((p) => p.caseId !== id);
    this.data.notifications = this.data.notifications.filter((n) => n.caseId !== id);
    this.save();
    return { purged: true, filesRemoved };
  }

  public deleteCase(id: string): boolean {
    return Boolean(this.archiveCase(id));
  }

  // ---------- Evidence ----------
  public getEvidence(caseId?: string): StoredEvidence[] {
    if (caseId) {
      return this.data.evidence.filter((e) => e.caseId === caseId);
    }
    return this.data.evidence;
  }

  public getEvidenceById(id: string): StoredEvidence | undefined {
    return this.data.evidence.find((e) => e.id === id);
  }

  public createEvidence(ev: StoredEvidence): StoredEvidence {
    this.data.evidence.unshift(ev);
    const c = this.getCaseById(ev.caseId);
    if (c) {
      c.evidenceCount = (c.evidenceCount || 0) + 1;
      c.updatedDate = new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    }
    this.save();
    return ev;
  }

  public updateEvidence(id: string, updates: Partial<StoredEvidence>): StoredEvidence | null {
    const index = this.data.evidence.findIndex((e) => e.id === id);
    if (index === -1) return null;
    this.data.evidence[index] = { ...this.data.evidence[index], ...updates };
    this.save();
    return this.data.evidence[index];
  }

  // ---------- Reference Voice Samples ----------
  public getReferences(caseId: string): StoredReferenceSample[] {
    return this.data.referenceSamples.filter((r) => r.caseId === caseId);
  }

  public getReferenceById(id: string): StoredReferenceSample | undefined {
    return this.data.referenceSamples.find((r) => r.id === id);
  }

  public createReference(ref: StoredReferenceSample): StoredReferenceSample {
    this.data.referenceSamples.unshift(ref);
    this.save();
    return ref;
  }

  // ---------- Speaker Verifications ----------
  public getSpeakerVerifications(caseId?: string): StoredSpeakerVerification[] {
    if (caseId) {
      return this.data.speakerVerifications.filter((v) => v.caseId === caseId);
    }
    return this.data.speakerVerifications;
  }

  public createSpeakerVerification(v: StoredSpeakerVerification): StoredSpeakerVerification {
    this.data.speakerVerifications.unshift(v);
    this.save();
    return v;
  }

  // ---------- Voice Disguise Analyses ----------
  public getVoiceDisguises(caseId?: string): StoredVoiceDisguise[] {
    if (caseId) {
      return this.data.voiceDisguiseAnalyses.filter((d) => d.caseId === caseId);
    }
    return this.data.voiceDisguiseAnalyses;
  }

  public createVoiceDisguise(d: StoredVoiceDisguise): StoredVoiceDisguise {
    this.data.voiceDisguiseAnalyses.unshift(d);
    this.save();
    return d;
  }

  // ---------- Chain of Custody ----------
  public getChainOfCustody(caseId: string): StoredChainOfCustodyEvent[] {
    return this.data.chainOfCustody
      .filter((c) => c.caseId === caseId)
      .sort((a, b) => a.eventNumber - b.eventNumber);
  }

  public addChainOfCustodyEvent(evt: StoredChainOfCustodyEvent): StoredChainOfCustodyEvent {
    this.data.chainOfCustody.push(evt);
    this.save();
    return evt;
  }

  // ---------- Expert Reviews ----------
  public getExpertReviews(caseId: string): StoredExpertReview[] {
    return this.data.expertReviews.filter((r) => r.caseId === caseId);
  }

  public createExpertReview(rev: StoredExpertReview): StoredExpertReview {
    this.data.expertReviews.unshift(rev);
    this.save();
    return rev;
  }

  // ---------- Notifications ----------
  public getNotifications(user?: { id?: string; email?: string; role?: string }): StoredNotification[] {
    if (!this.data.notifications) this.data.notifications = [];
    if (!user) return this.data.notifications;
    const emailLower = (user.email || '').toLowerCase();
    return this.data.notifications.filter((n) => {
      if (n.targetUserId) return n.targetUserId === user.id;
      if (n.targetEmail) return n.targetEmail.toLowerCase() === emailLower;
      if (n.targetRole) return n.targetRole === user.role;
      return true;
    });
  }

  public getNotificationById(id: string): StoredNotification | undefined {
    if (!this.data.notifications) this.data.notifications = [];
    return this.data.notifications.find((n) => n.id === id);
  }

  public addNotification(notif: StoredNotification): StoredNotification {
    if (!this.data.notifications) this.data.notifications = [];
    this.data.notifications.unshift(notif);
    if (this.data.notifications.length > 500) this.data.notifications.pop();
    this.save();
    return notif;
  }

  public markNotificationAsRead(id: string): boolean {
    const n = this.data.notifications.find((item) => item.id === id);
    if (n) {
      n.read = true;
      this.save();
      return true;
    }
    return false;
  }

  public markAllNotificationsAsRead(user?: { id?: string; email?: string; role?: string }): number {
    if (!this.data.notifications) return 0;
    const visibleIds = new Set(this.getNotifications(user).map((n) => n.id));
    let count = 0;
    for (const n of this.data.notifications) {
      if (visibleIds.has(n.id) && !n.read) {
        n.read = true;
        count++;
      }
    }
    if (count > 0) this.save();
    return count;
  }

  // ---------- Immutable Audit Logs (with JSONL archival instead of loss) ----------
  public getAuditLogs(): StoredAuditLog[] {
    if (!this.data.auditLogs) this.data.auditLogs = [];
    if (fs.existsSync(this.auditArchivePath)) {
      try {
        const lines = fs
          .readFileSync(this.auditArchivePath, 'utf-8')
          .split('\n')
          .filter(Boolean)
          .map((line) => JSON.parse(line) as StoredAuditLog)
          .reverse();
        return [...this.data.auditLogs, ...lines];
      } catch {
        return this.data.auditLogs;
      }
    }
    return this.data.auditLogs;
  }

  public addAuditLog(log: StoredAuditLog): StoredAuditLog {
    if (!this.data.auditLogs) this.data.auditLogs = [];
    this.data.auditLogs.unshift(log);
    if (this.data.auditLogs.length > 1000) {
      const archived = this.data.auditLogs.pop();
      if (archived) {
        fs.appendFileSync(this.auditArchivePath, JSON.stringify(archived) + '\n', 'utf-8');
      }
    }
    this.save();
    return log;
  }

  // ---------- Deepfake Analyses ----------
  public getDeepfakeAnalyses(caseId?: string): StoredDeepfakeAnalysis[] {
    if (!this.data.deepfakeAnalyses) this.data.deepfakeAnalyses = [];
    if (caseId) {
      return this.data.deepfakeAnalyses.filter((a) => a.caseId === caseId);
    }
    return this.data.deepfakeAnalyses;
  }

  public createDeepfakeAnalysis(a: StoredDeepfakeAnalysis): StoredDeepfakeAnalysis {
    if (!this.data.deepfakeAnalyses) this.data.deepfakeAnalyses = [];
    this.data.deepfakeAnalyses.unshift(a);
    this.save();
    return a;
  }

  // ---------- Legal Reviews ----------
  public getLegalReview(caseId: string): StoredLegalReview | undefined {
    if (!this.data.legalReviews) this.data.legalReviews = [];
    return this.data.legalReviews.find((l) => l.caseId === caseId);
  }

  public saveLegalReview(review: StoredLegalReview): StoredLegalReview {
    if (!this.data.legalReviews) this.data.legalReviews = [];
    const idx = this.data.legalReviews.findIndex((l) => l.caseId === review.caseId);
    if (idx >= 0) {
      this.data.legalReviews[idx] = review;
    } else {
      this.data.legalReviews.unshift(review);
    }
    this.save();
    return review;
  }

  // ---------- Public Reports ----------
  public getPublicReports(): StoredPublicReport[] {
    if (!this.data.publicReports) this.data.publicReports = [];
    return this.data.publicReports;
  }

  public savePublicReport(report: StoredPublicReport): StoredPublicReport {
    if (!this.data.publicReports) this.data.publicReports = [];
    const idx = this.data.publicReports.findIndex((r) => r.token === report.token);
    if (idx >= 0) {
      this.data.publicReports[idx] = report;
    } else {
      this.data.publicReports.unshift(report);
    }
    this.save();
    return report;
  }

  // ---------- System Configuration ----------
  public getSystemConfig(): StoredSystemConfig {
    if (!this.data.systemConfig) {
      this.data.systemConfig = { ...DEFAULT_SYSTEM_CONFIG };
    }
    return this.data.systemConfig;
  }

  public updateSystemConfig(updates: Partial<StoredSystemConfig>): StoredSystemConfig {
    this.data.systemConfig = {
      ...this.getSystemConfig(),
      ...updates,
      updatedAt: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC'
    };
    this.save();
    return this.data.systemConfig;
  }

  // ---------- Live Aggregate Statistics ----------
  public getStats(accessibleCases?: StoredCase[]) {
    const casesList = accessibleCases || this.data.cases.filter((c) => c.status !== 'Archived');
    const accessibleIds = new Set(casesList.map((c) => c.id));
    const totalCases = casesList.length;
    const activeCases = casesList.filter((c) => c.status === 'Active' || c.status === 'Under Review').length;
    const deepfakeDetected = casesList.filter((c) => c.verdict === 'DEEPFAKE').length;
    const authenticAudio = casesList.filter((c) => c.verdict === 'AUTHENTIC').length;
    const reportsGenerated = this.data.expertReviews.filter(
      (r) => r.status === 'Approved' && accessibleIds.has(r.caseId)
    ).length;
    const evidenceVerified = this.data.evidence.filter(
      (e) => e.isIntegrityVerified && accessibleIds.has(e.caseId)
    ).length;

    return {
      totalCases,
      activeCases,
      deepfakeDetected,
      authenticAudio,
      reportsGenerated,
      evidenceVerified
    };
  }

  // ---------- Users & Single-Admin Governance ----------
  public getUsers(): StoredUserRecord[] {
    if (!this.data.users) this.data.users = [];
    return this.data.users;
  }

  public getUserByEmail(email: string): StoredUserRecord | undefined {
    if (!this.data.users) this.data.users = [];
    const normalized = email.trim().toLowerCase();
    return this.data.users.find((u) => u.email.toLowerCase() === normalized);
  }

  public getUserById(id: string): StoredUserRecord | undefined {
    if (!this.data.users) this.data.users = [];
    return this.data.users.find((u) => u.id === id);
  }

  public getActiveSystemAdmins(): StoredUserRecord[] {
    return this.getUsers().filter((u) => u.role === SYSTEM_ADMIN_ROLE && u.status === 'active');
  }

  public hasSystemAdmin(): boolean {
    return this.getUsers().some((u) => u.role === SYSTEM_ADMIN_ROLE && u.status === 'active');
  }

  public createUser(user: StoredUserRecord): StoredUserRecord {
    if (!this.data.users) this.data.users = [];
    const normalizedEmail = user.email.trim().toLowerCase();
    const existing = this.data.users.find((u) => u.email.toLowerCase() === normalizedEmail);
    const otherAdmins = this.data.users.filter(
      (u) => u.role === SYSTEM_ADMIN_ROLE && u.email.toLowerCase() !== normalizedEmail && u.status === 'active'
    );

    if (user.role === SYSTEM_ADMIN_ROLE && otherAdmins.length > 0) {
      throw new Error('SINGLE_ADMIN_VIOLATION: Only one active System Security Administrator may exist.');
    }

    const sanitizedUser: StoredUserRecord = {
      ...user,
      email: normalizedEmail,
      tokenVersion: typeof user.tokenVersion === 'number' ? user.tokenVersion : 1
    };

    if (existing) {
      const idx = this.data.users.indexOf(existing);
      this.data.users[idx] = sanitizedUser;
    } else {
      this.data.users.push(sanitizedUser);
    }
    this.save();
    return sanitizedUser;
  }

  public updateUser(idOrEmail: string, updates: Partial<StoredUserRecord>): StoredUserRecord | null {
    if (!this.data.users) this.data.users = [];
    const key = idOrEmail.trim().toLowerCase();
    const index = this.data.users.findIndex(
      (u) => u.id.toLowerCase() === key || u.email.toLowerCase() === key
    );
    if (index === -1) return null;

    const current = this.data.users[index];
    const nextRole = updates.role !== undefined ? updates.role : current.role;
    const nextStatus = updates.status !== undefined ? updates.status : current.status;

    if (nextRole === SYSTEM_ADMIN_ROLE) {
      const anotherActiveAdmin = this.data.users.find(
        (u) => u.id !== current.id && u.role === SYSTEM_ADMIN_ROLE && u.status === 'active'
      );
      if (anotherActiveAdmin) {
        throw new Error('SINGLE_ADMIN_VIOLATION: Cannot assign a second System Security Administrator.');
      }
    }

    if (
      current.role === SYSTEM_ADMIN_ROLE &&
      current.status === 'active' &&
      (nextStatus !== 'active' || nextRole !== SYSTEM_ADMIN_ROLE)
    ) {
      throw new Error(
        'SOLE_ADMIN_PROTECTION: Cannot suspend, deactivate, or demote the sole active System Security Administrator directly. Use the audited Administrator Transfer workflow.'
      );
    }

    this.data.users[index] = {
      ...current,
      ...updates,
      email: updates.email ? updates.email.trim().toLowerCase() : current.email
    };
    this.save();
    return this.data.users[index];
  }

  public transferSystemAdmin(params: {
    currentAdminId: string;
    targetUserId: string;
    demoteCurrentToRole: 'Lead Forensic Analyst' | 'Forensic Examiner / Expert Witness' | 'Prosecutor / Legal Reviewer';
  }): { previousAdmin: StoredUserRecord; newAdmin: StoredUserRecord } {
    const users = this.getUsers();
    const currentIdx = users.findIndex((u) => u.id === params.currentAdminId);
    const targetIdx = users.findIndex((u) => u.id === params.targetUserId);

    if (currentIdx === -1 || targetIdx === -1) {
      throw new Error('Administrator transfer users not found.');
    }
    const currentAdmin = users[currentIdx];
    const targetUser = users[targetIdx];

    if (currentAdmin.role !== SYSTEM_ADMIN_ROLE || currentAdmin.status !== 'active') {
      throw new Error('Source account is not the active System Security Administrator.');
    }
    if (currentAdmin.id === targetUser.id) {
      throw new Error('Cannot transfer administrator authority to yourself.');
    }
    if (targetUser.status !== 'active') {
      throw new Error('Target operator must already be an active approved user.');
    }

    // Atomic single-commit swap so two active admins never co-exist at any point
    const now = new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    users[currentIdx] = {
      ...currentAdmin,
      role: params.demoteCurrentToRole,
      tokenVersion: (currentAdmin.tokenVersion || 1) + 1,
      reviewedAt: now,
      reviewedBy: `Admin Transfer -> ${targetUser.email}`
    };
    users[targetIdx] = {
      ...targetUser,
      role: SYSTEM_ADMIN_ROLE,
      tokenVersion: (targetUser.tokenVersion || 1) + 1,
      reviewedAt: now,
      reviewedBy: `Admin Transfer <- ${currentAdmin.email}`
    };

    this.save();
    return { previousAdmin: users[currentIdx], newAdmin: users[targetIdx] };
  }

  // ---------- Sensitive Field Encryption Helpers (AES-256-GCM) ----------
  public setEncryptedTotpSecret(userId: string, secretPlain: string, isPending: boolean) {
    const enc = encryptSensitive(secretPlain);
    if (isPending) {
      return this.updateUser(userId, { pendingTotpSecretEnc: enc });
    }
    return this.updateUser(userId, { totpSecretEnc: enc, pendingTotpSecretEnc: undefined });
  }

  public getDecryptedTotpSecret(user: StoredUserRecord, pending = false): string | null {
    const raw = pending ? user.pendingTotpSecretEnc : user.totpSecretEnc;
    if (!raw) return null;
    try {
      return decryptSensitive(raw);
    } catch {
      return null;
    }
  }

  // ---------- Persistent Pending Registrations (OTP verified) ----------
  public savePendingRegistration(reg: StoredPendingRegistration) {
    if (!this.data.pendingRegistrations) this.data.pendingRegistrations = [];
    const emailLower = reg.email.trim().toLowerCase();
    this.data.pendingRegistrations = this.data.pendingRegistrations.filter(
      (r) => r.email.toLowerCase() !== emailLower
    );
    this.data.pendingRegistrations.push({ ...reg, email: emailLower });
    this.save();
  }

  public getPendingRegistration(email: string): StoredPendingRegistration | undefined {
    if (!this.data.pendingRegistrations) this.data.pendingRegistrations = [];
    const emailLower = email.trim().toLowerCase();
    return this.data.pendingRegistrations.find((r) => r.email.toLowerCase() === emailLower);
  }

  public deletePendingRegistration(email: string) {
    if (!this.data.pendingRegistrations) return;
    const emailLower = email.trim().toLowerCase();
    this.data.pendingRegistrations = this.data.pendingRegistrations.filter(
      (r) => r.email.toLowerCase() !== emailLower
    );
    this.save();
  }

  // ---------- Persisted JWT Revocation List ----------
  public revokeToken(jti: string, expiresAt: number) {
    if (!this.data.revokedTokens) this.data.revokedTokens = [];
    const now = Date.now();
    this.data.revokedTokens = this.data.revokedTokens.filter((t) => t.expiresAt > now);
    if (!this.data.revokedTokens.some((t) => t.jti === jti)) {
      this.data.revokedTokens.push({ jti, expiresAt });
    }
    this.save();
  }

  public isTokenRevoked(jti: string): boolean {
    if (!this.data.revokedTokens) return false;
    return this.data.revokedTokens.some((t) => t.jti === jti && t.expiresAt > Date.now());
  }

  // ---------- Password Reset Tokens (Hashed Single-Use, 15-Min TTL) ----------
  public createPasswordResetToken(record: StoredPasswordResetToken): StoredPasswordResetToken {
    if (!this.data.passwordResetTokens) this.data.passwordResetTokens = [];
    const now = Date.now();
    const emailLower = record.email.trim().toLowerCase();
    // Prune expired tokens AND invalidate all prior reset tokens for this user/email
    this.data.passwordResetTokens = this.data.passwordResetTokens.filter(
      (t) => t.expiresAt > now && t.userId !== record.userId && t.email.toLowerCase() !== emailLower
    );
    const saved: StoredPasswordResetToken = { ...record, email: emailLower };
    this.data.passwordResetTokens.push(saved);
    this.save();
    return saved;
  }

  public getPasswordResetTokenByHash(tokenHash: string): StoredPasswordResetToken | undefined {
    if (!this.data.passwordResetTokens) this.data.passwordResetTokens = [];
    return this.data.passwordResetTokens.find((t) => t.tokenHash === tokenHash);
  }

  public consumePasswordResetTokensForUser(userId: string, email?: string) {
    if (!this.data.passwordResetTokens) return;
    const emailLower = email ? email.trim().toLowerCase() : '';
    const now = Date.now();
    this.data.passwordResetTokens = this.data.passwordResetTokens.filter(
      (t) => t.expiresAt > now && t.userId !== userId && (!emailLower || t.email.toLowerCase() !== emailLower)
    );
    this.save();
  }

  // ---------- Biometric Templates (Encrypted at rest, no fake fallback seeds) ----------
  public getBiometricTemplate(expertId: string): StoredBiometricRecord | undefined {
    if (!this.data.biometricTemplates) this.data.biometricTemplates = [];
    return this.data.biometricTemplates.find((b) => b.expertId === expertId);
  }

  public saveBiometricTemplate(template: StoredBiometricRecord): StoredBiometricRecord {
    if (!this.data.biometricTemplates) this.data.biometricTemplates = [];
    const stored: StoredBiometricRecord = { ...template };
    if (stored.biometricVector) {
      stored.biometricVectorEnc = encryptSensitive(JSON.stringify(stored.biometricVector));
      delete stored.biometricVector;
    }
    const index = this.data.biometricTemplates.findIndex((b) => b.expertId === stored.expertId);
    if (index >= 0) {
      this.data.biometricTemplates[index] = stored;
    } else {
      this.data.biometricTemplates.push(stored);
    }
    this.save();
    return stored;
  }
}

export const serverDb = new ServerDatabase();
