import crypto from 'crypto';
import readline from 'readline';
import { serverDb, SYSTEM_ADMIN_ROLE } from '../serverDb';
import { hashPassword, validatePasswordStrength } from '../serverSecurity';

function promptQuestion(rl: readline.Interface, query: string): Promise<string> {
  return new Promise((resolve) => rl.question(query, resolve));
}

async function main() {
  if (process.argv.includes('--help') || process.argv.includes('-h')) {
    console.log(
      'ALFADetect First-Time Sole System Security Administrator Initializer\n\n' +
        'Usage:\n' +
        '  ADMIN_EMAIL=admin@agency.gov ADMIN_NAME="Chief Security Admin" ADMIN_PASSWORD="StrongPass99" npm run init-admin\n' +
        'Or run interactively without environment variables:\n' +
        '  npm run init-admin\n'
    );
    process.exit(0);
  }

  if (serverDb.hasSystemAdmin()) {
    const existing = serverDb.getActiveSystemAdmins()[0];
    console.error(
      `ABORTED: An active System Security Administrator already exists (${existing.email}). ` +
        'ALFADetect strictly permits exactly ONE System Security Administrator.'
    );
    process.exit(1);
  }

  let name = (process.env.ADMIN_NAME || '').trim();
  let email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  let password = process.env.ADMIN_PASSWORD || '';
  let agency = (process.env.ADMIN_AGENCY || 'Cyber Forensics Authority').trim();

  if (!name || !email || !password) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    try {
      if (!name) name = (await promptQuestion(rl, 'Administrator Full Name: ')).trim();
      if (!email) email = (await promptQuestion(rl, 'Administrator Official Email: ')).trim().toLowerCase();
      if (!agency) agency = (await promptQuestion(rl, 'Organization / Agency [Cyber Forensics Authority]: ')).trim() || 'Cyber Forensics Authority';
      if (!password) password = await promptQuestion(rl, 'Initial Password (min 12 chars, upper, lower, digit, symbol): ');
    } finally {
      rl.close();
    }
  }

  if (!name || !email || !email.includes('@')) {
    console.error('Error: Valid name and email address are required.');
    process.exit(1);
  }

  const pwCheck = validatePasswordStrength(password, email);
  if (!pwCheck.valid) {
    console.error(`Error: ${pwCheck.error}`);
    process.exit(1);
  }

  if (serverDb.getUserByEmail(email)) {
    console.error(`Error: Account with email ${email} already exists.`);
    process.exit(1);
  }

  const salt = crypto.randomBytes(16).toString('hex');
  const initials = name
    .split(/\s+/)
    .filter(Boolean)
    .map((n) => n[0].toUpperCase())
    .join('')
    .slice(0, 2) || 'SA';

  const adminId = `USR-ADMIN-${Date.now().toString().slice(-6)}`;
  const created = serverDb.createUser({
    id: adminId,
    name,
    email,
    passwordHash: hashPassword(password, salt),
    salt,
    role: SYSTEM_ADMIN_ROLE,
    agency,
    department: 'Information Security & Governance',
    avatar: initials,
    status: 'active',
    casesCount: 0,
    securityClearance: 'System Security Administrator',
    tokenVersion: 1,
    twoFactorEnabled: false,
    twoFactorMethod: 'NONE',
    themePreference: 'light',
    createdAt: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
    reviewedBy: 'CLI-BOOTSTRAP',
    reviewedAt: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
    notificationPreferences: {
      securityAlerts: true,
      emailAlerts: false,
      dailyDigest: false
    }
  });

  serverDb.addAuditLog({
    id: `AUD-${Date.now().toString().slice(-6)}`,
    timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
    user: created.email,
    action: 'CONFIG',
    resource: 'First-Time Sole System Security Administrator Provisioned (CLI)',
    ipAddress: '127.0.0.1',
    status: 'SUCCESS',
    role: SYSTEM_ADMIN_ROLE
  });

  console.log(`SUCCESS: Sole System Security Administrator provisioned: ${created.email} (ID: ${created.id})`);
}

main().catch((err) => {
  console.error('Admin initialization failed:', err?.message || err);
  process.exit(1);
});
