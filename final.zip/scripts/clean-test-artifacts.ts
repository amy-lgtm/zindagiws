import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const dbPath = process.env.ALFADETECT_DB_PATH
  ? path.resolve(process.env.ALFADETECT_DB_PATH)
  : path.join(process.cwd(), 'data', 'alfadetect_store.json');

const backupPath = `${dbPath}.preclean.${Date.now()}.bak`;

function isPositiveTestCase(c: any): boolean {
  return (
    (typeof c?.id === 'string' && c.id.startsWith('DS-TEST-')) ||
    c?.createdBy === 'qa-tester@forensics.gov'
  );
}

function isPositiveTestEvidence(e: any): boolean {
  return (
    (typeof e?.id === 'string' && e.id.startsWith('EV-TEST-')) ||
    e?.uploadedBy === 'qa-tester@forensics.gov' ||
    (typeof e?.caseId === 'string' && e.caseId.startsWith('DS-TEST-'))
  );
}

function isPositiveTestCustody(c: any): boolean {
  return (
    (typeof c?.id === 'string' && c.id.startsWith('COC-TEST-')) ||
    (typeof c?.caseId === 'string' && c.caseId.startsWith('DS-TEST-'))
  );
}

function isPositiveTestAudit(a: any): boolean {
  return (
    (typeof a?.id === 'string' && a.id.startsWith('AUD-TEST-')) ||
    a?.user === 'qa-tester@forensics.gov'
  );
}

if (!fs.existsSync(dbPath)) {
  console.log(JSON.stringify({ status: 'SKIPPED', reason: 'Database file does not exist', dbPath }, null, 2));
  process.exit(0);
}

const rawBefore = fs.readFileSync(dbPath, 'utf-8');
const hashBefore = crypto.createHash('sha256').update(rawBefore).digest('hex');
fs.writeFileSync(backupPath, rawBefore, 'utf-8');

const data = JSON.parse(rawBefore);

const removedCases = (data.cases || []).filter(isPositiveTestCase).map((c: any) => c.id);
const keptCases = (data.cases || []).filter((c: any) => !isPositiveTestCase(c));

const removedEvidence = (data.evidence || []).filter(isPositiveTestEvidence).map((e: any) => e.id);
const keptEvidence = (data.evidence || []).filter((e: any) => !isPositiveTestEvidence(e));

const removedCustody = (data.chainOfCustody || []).filter(isPositiveTestCustody).map((c: any) => c.id);
const keptCustody = (data.chainOfCustody || []).filter((c: any) => !isPositiveTestCustody(c));

const removedAudit = (data.auditLogs || []).filter(isPositiveTestAudit).map((a: any) => a.id);
const keptAudit = (data.auditLogs || []).filter((a: any) => !isPositiveTestAudit(a));

const cleaned = {
  ...data,
  cases: keptCases,
  evidence: keptEvidence,
  chainOfCustody: keptCustody,
  auditLogs: keptAudit
};

const tmpOut = `${dbPath}.tmp`;
fs.writeFileSync(tmpOut, JSON.stringify(cleaned, null, 2), 'utf-8');
fs.renameSync(tmpOut, dbPath);

const report = {
  status: 'CLEANED',
  dbPath,
  backupPath,
  backupSha256: hashBefore,
  removedCounts: {
    cases: removedCases.length,
    evidence: removedEvidence.length,
    chainOfCustody: removedCustody.length,
    auditLogs: removedAudit.length
  },
  preservedCounts: {
    cases: keptCases.length,
    evidence: keptEvidence.length,
    chainOfCustody: keptCustody.length,
    auditLogs: keptAudit.length,
    users: (cleaned.users || []).length,
    referenceSamples: (cleaned.referenceSamples || []).length
  },
  removedIds: {
    cases: removedCases,
    evidence: removedEvidence,
    chainOfCustody: removedCustody,
    auditLogs: removedAudit
  }
};

console.log(JSON.stringify(report, null, 2));
