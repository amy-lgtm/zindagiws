import {
  decodeAudioBuffer,
  computeAcousticMeasurements,
  computeNonBiometricDspProfile,
  evaluateVoiceConditionHypotheses
} from './src/utils/audioDsp';
import type { AcousticMeasurements, VoiceConditionHypothesis, NonBiometricDspProfile } from './src/types';

export interface AiModelRunResult {
  key: string;
  name: string;
  category:
    | 'deepfake'
    | 'speaker'
    | 'explainability'
    | 'voice-condition'
    | 'dsp';
  status: 'AVAILABLE' | 'MODEL_UNAVAILABLE' | 'INSUFFICIENT_AUDIO' | 'ERROR';
  verdict?: 'DEEPFAKE' | 'AUTHENTIC' | 'INCONCLUSIVE';
  confidence?: number | null;
  note: string;
  version?: string;
}

export interface AdapterModelDescriptor {
  key: string;
  name: string;
  type: string;
  status: 'AVAILABLE' | 'NOT_CONFIGURED';
  version: string;
  description: string;
}

export function getRegisteredModelsStatus(): Record<string, AdapterModelDescriptor> {
  const aiServiceUrl = Boolean(process.env.ALFADETECT_AI_SERVICE_URL?.trim());
  const speakerServiceUrl = Boolean(process.env.ALFADETECT_SPEAKER_SERVICE_URL?.trim());

  return {
    acousticDsp: {
      key: 'acousticDsp',
      name: 'DSP Pitch & Spectral Engine (Autocorrelation / YIN / STFT)',
      type: 'Physical Digital Signal Processing',
      status: 'AVAILABLE',
      version: 'ALFA-DSP-1.2',
      description: 'Extracts genuine F0 pitch contour, jitter, shimmer, HNR, spectral centroid, roll-off, flatness, and SNR from PCM frames.'
    },
    cnnVocoder: {
      key: 'cnnVocoder',
      name: 'CNN Mel-Spectrogram Vocoder Detector',
      type: 'Deep Learning Classifier',
      status: aiServiceUrl ? 'AVAILABLE' : 'NOT_CONFIGURED',
      version: aiServiceUrl ? 'External-Remote' : 'Unconfigured',
      description: aiServiceUrl
        ? 'Connected to external Python/PyTorch inference endpoint.'
        : 'Model unavailable until trained PyTorch CNN checkpoint / Python inference service is configured (ALFADETECT_AI_SERVICE_URL).'
    },
    bilstmTemporal: {
      key: 'bilstmTemporal',
      name: 'BiLSTM Acoustic Temporal Sequence Classifier',
      type: 'Deep Learning Sequence Model',
      status: aiServiceUrl ? 'AVAILABLE' : 'NOT_CONFIGURED',
      version: aiServiceUrl ? 'External-Remote' : 'Unconfigured',
      description: aiServiceUrl
        ? 'Connected to external Python/PyTorch inference endpoint.'
        : 'Model unavailable until trained BiLSTM weights / Python inference service is configured.'
    },
    wav2vec2: {
      key: 'wav2vec2',
      name: 'Wav2Vec2 Transformer Forensic Classifier',
      type: 'Self-Supervised Transformer',
      status: aiServiceUrl ? 'AVAILABLE' : 'NOT_CONFIGURED',
      version: aiServiceUrl ? 'External-Remote' : 'Unconfigured',
      description: aiServiceUrl
        ? 'Connected to external Python/PyTorch inference endpoint.'
        : 'Model unavailable until fine-tuned Wav2Vec2 checkpoint / Python inference service is configured.'
    },
    ecapaTdnn: {
      key: 'ecapaTdnn',
      name: 'ECAPA-TDNN Speaker Biometric Encoder',
      type: 'Neural Speaker Verification Model',
      status: speakerServiceUrl ? 'AVAILABLE' : 'NOT_CONFIGURED',
      version: speakerServiceUrl ? 'External-Remote' : 'Unconfigured',
      description: speakerServiceUrl
        ? 'Connected to external ECAPA-TDNN speaker embedding verification endpoint.'
        : 'Model unavailable until neural biometric speaker embedding weights (ALFADETECT_SPEAKER_SERVICE_URL) are integrated. Handcrafted DSP features are never substituted as biometric speaker ID.'
    },
    xaiGradCamShap: {
      key: 'xaiGradCamShap',
      name: 'Grad-CAM & TreeSHAP Neural Explainability',
      type: 'XAI Attribution Engine',
      status: aiServiceUrl ? 'AVAILABLE' : 'NOT_CONFIGURED',
      version: aiServiceUrl ? 'External-Remote' : 'Unconfigured',
      description: aiServiceUrl
        ? 'Connected to neural attribution endpoint.'
        : 'Neural Grad-CAM and TreeSHAP attributions require trained deepfake classifiers; genuine DSP spectrogram and YIN F0 telemetry remain active.'
    },
    disguiseIllnessClassifier: {
      key: 'disguiseIllnessClassifier',
      name: 'Neural Disguise & Pathology Classifier (ResNet/HuBERT)',
      type: 'Vocal Condition Classifier',
      status: aiServiceUrl ? 'AVAILABLE' : 'NOT_CONFIGURED',
      version: aiServiceUrl ? 'External-Remote' : 'Unconfigured',
      description: aiServiceUrl
        ? 'Connected to vocal condition classification endpoint.'
        : 'Acoustic multi-hypothesis DSP heuristics remain active; trained neural pathology/disguise classifier is awaiting model integration.'
    }
  };
}

export interface ServerDspExtraction {
  isWavDecoded: boolean;
  sampleRate: number;
  channels: number;
  bitsPerSample: number;
  audioFormatCode: number;
  durationSec: number;
  measurements: AcousticMeasurements | null;
  nonBiometricProfile: NonBiometricDspProfile | null;
}

export function extractServerAudioDsp(buffer: Buffer): ServerDspExtraction {
  const decoded = decodeAudioBuffer(buffer);
  if (!decoded.isWavDecoded || decoded.samples.length === 0) {
    return {
      isWavDecoded: false,
      sampleRate: decoded.sampleRate,
      channels: decoded.channels,
      bitsPerSample: decoded.bitsPerSample,
      audioFormatCode: decoded.audioFormatCode,
      durationSec: 0,
      measurements: null,
      nonBiometricProfile: null
    };
  }
  const measurements = computeAcousticMeasurements(decoded.samples, decoded.sampleRate);
  const nonBiometricProfile = computeNonBiometricDspProfile(decoded.samples, decoded.sampleRate);
  return {
    isWavDecoded: true,
    sampleRate: decoded.sampleRate,
    channels: decoded.channels,
    bitsPerSample: decoded.bitsPerSample,
    audioFormatCode: decoded.audioFormatCode,
    durationSec: decoded.durationSec,
    measurements,
    nonBiometricProfile
  };
}

async function queryRemoteModel(
  endpoint: string,
  payload: Record<string, unknown>
): Promise<{ verdict?: 'DEEPFAKE' | 'AUTHENTIC' | 'INCONCLUSIVE'; confidence?: number | null; note?: string } | null> {
  const baseUrl = process.env.ALFADETECT_AI_SERVICE_URL?.trim();
  if (!baseUrl) return null;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const res = await fetch(`${baseUrl.replace(/\/$/, '')}${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(process.env.ALFADETECT_AI_SERVICE_KEY
          ? { Authorization: `Bearer ${process.env.ALFADETECT_AI_SERVICE_KEY}` }
          : {})
      },
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    if (!res.ok) {
      throw new Error(`Remote inference error HTTP ${res.status}`);
    }
    return await res.json();
  } finally {
    clearTimeout(timeout);
  }
}

export async function runDeepfakeAdaptersIsolated(params: {
  evidenceId: string;
  sha256Hash: string;
  filename: string;
  measurements: AcousticMeasurements | null;
}): Promise<AiModelRunResult[]> {
  const aiUrl = process.env.ALFADETECT_AI_SERVICE_URL?.trim();

  const tasks: Array<() => Promise<AiModelRunResult>> = [
    async () => {
      if (!params.measurements || params.measurements.speechDurationSec <= 0) {
        return {
          key: 'acousticDsp',
          name: 'Acoustic DSP Pitch & Spectral Analysis (YIN / Autocorrelation)',
          category: 'dsp',
          status: 'INSUFFICIENT_AUDIO',
          verdict: 'INCONCLUSIVE',
          confidence: null,
          version: 'ALFA-DSP-1.2',
          note: 'Server-side PCM decoding requires uncompressed WAV PCM or client WebAudio metrics could not be verified for compressed container.'
        };
      }
      return {
        key: 'acousticDsp',
        name: 'Acoustic DSP Pitch & Spectral Analysis (YIN / Autocorrelation)',
        category: 'dsp',
        status: 'AVAILABLE',
        verdict: 'INCONCLUSIVE',
        confidence: null,
        version: 'ALFA-DSP-1.2',
        note: `Physical acoustic telemetry extracted (F0: ${params.measurements.f0MeanHz} Hz, Jitter: ${params.measurements.jitterPercent}%, HNR: ${params.measurements.hnrDb} dB, SNR: ${params.measurements.estimatedSnrDb} dB). DSP measurements inform expert review rather than issuing standalone binary deepfake classification.`
      };
    },
    async () => {
      if (!aiUrl) {
        return {
          key: 'cnnVocoder',
          name: 'CNN Mel-Spectrogram Vocoder Detector',
          category: 'deepfake',
          status: 'MODEL_UNAVAILABLE',
          verdict: 'INCONCLUSIVE',
          confidence: null,
          note: 'Model unavailable: CNN classifier weights / inference service not configured.'
        };
      }
      const remote = await queryRemoteModel('/predict/cnn', {
        evidenceId: params.evidenceId,
        sha256Hash: params.sha256Hash,
        filename: params.filename
      });
      return {
        key: 'cnnVocoder',
        name: 'CNN Mel-Spectrogram Vocoder Detector',
        category: 'deepfake',
        status: 'AVAILABLE',
        verdict: remote?.verdict || 'INCONCLUSIVE',
        confidence: remote?.confidence ?? null,
        note: remote?.note || 'Executed against external PyTorch CNN inference service.'
      };
    },
    async () => {
      if (!aiUrl) {
        return {
          key: 'bilstmTemporal',
          name: 'BiLSTM Acoustic Temporal Sequence Classifier',
          category: 'deepfake',
          status: 'MODEL_UNAVAILABLE',
          verdict: 'INCONCLUSIVE',
          confidence: null,
          note: 'Model unavailable: BiLSTM sequence weights / inference service not configured.'
        };
      }
      const remote = await queryRemoteModel('/predict/bilstm', {
        evidenceId: params.evidenceId,
        sha256Hash: params.sha256Hash,
        filename: params.filename
      });
      return {
        key: 'bilstmTemporal',
        name: 'BiLSTM Acoustic Temporal Sequence Classifier',
        category: 'deepfake',
        status: 'AVAILABLE',
        verdict: remote?.verdict || 'INCONCLUSIVE',
        confidence: remote?.confidence ?? null,
        note: remote?.note || 'Executed against external BiLSTM sequence service.'
      };
    },
    async () => {
      if (!aiUrl) {
        return {
          key: 'wav2vec2',
          name: 'Wav2Vec2 Transformer Forensic Classifier',
          category: 'deepfake',
          status: 'MODEL_UNAVAILABLE',
          verdict: 'INCONCLUSIVE',
          confidence: null,
          note: 'Model unavailable: Wav2Vec2 transformer weights / inference service not configured.'
        };
      }
      const remote = await queryRemoteModel('/predict/wav2vec2', {
        evidenceId: params.evidenceId,
        sha256Hash: params.sha256Hash,
        filename: params.filename
      });
      return {
        key: 'wav2vec2',
        name: 'Wav2Vec2 Transformer Forensic Classifier',
        category: 'deepfake',
        status: 'AVAILABLE',
        verdict: remote?.verdict || 'INCONCLUSIVE',
        confidence: remote?.confidence ?? null,
        note: remote?.note || 'Executed against external Wav2Vec2 transformer service.'
      };
    }
  ];

  // Independent model isolation (FR-57): failure in one model never fails the whole pipeline
  const settled = await Promise.allSettled(tasks.map((fn) => fn()));
  return settled.map((res, idx) => {
    if (res.status === 'fulfilled') return res.value;
    const fallbackNames = [
      'Acoustic DSP Pitch & Spectral Analysis (YIN / Autocorrelation)',
      'CNN Mel-Spectrogram Vocoder Detector',
      'BiLSTM Acoustic Temporal Sequence Classifier',
      'Wav2Vec2 Transformer Forensic Classifier'
    ];
    return {
      key: ['acousticDsp', 'cnnVocoder', 'bilstmTemporal', 'wav2vec2'][idx],
      name: fallbackNames[idx],
      category: idx === 0 ? 'dsp' : 'deepfake',
      status: 'ERROR',
      verdict: 'INCONCLUSIVE',
      confidence: null,
      note: `Isolated model error: ${res.reason?.message || 'Execution failed'}`
    };
  });
}

export function evaluateDisguiseWithServerDsp(params: {
  questionedBuffer: Buffer;
  referenceBuffer?: Buffer;
}): {
  usedServerBytes: boolean;
  qMeas: AcousticMeasurements | null;
  rMeas: AcousticMeasurements | null;
  hypotheses: VoiceConditionHypothesis[];
} {
  const qDsp = extractServerAudioDsp(params.questionedBuffer);
  const rDsp = params.referenceBuffer ? extractServerAudioDsp(params.referenceBuffer) : null;

  const qMeas = qDsp.measurements || null;
  const rMeas = rDsp?.measurements || undefined;

  if (!qDsp.isWavDecoded || !qMeas || qMeas.speechDurationSec <= 0) {
    return {
      usedServerBytes: qDsp.isWavDecoded,
      qMeas: null,
      rMeas: rMeas || null,
      hypotheses: []
    };
  }

  const hypotheses = evaluateVoiceConditionHypotheses(qMeas, rMeas);
  return {
    usedServerBytes: qDsp.isWavDecoded,
    qMeas,
    rMeas: rMeas || null,
    hypotheses
  };
}
