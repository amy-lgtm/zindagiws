import { AcousticMeasurements, VoiceConditionHypothesis, NonBiometricDspProfile } from '../types';

export interface DecodedAudio {
  sampleRate: number;
  channels: number;
  samples: Float32Array;
  durationSec: number;
  isWavDecoded: boolean;
  bitsPerSample: number;
  audioFormatCode: number;
}

/**
 * Decodes RIFF WAV headers strictly (formats 1 PCM, 3 IEEE Float, 0xFFFE Extensible; 8/16/24/32 PCM + 32/64 float;
 * multi-channel downmix; RIFF 2-byte word alignment) into normalized mono Float32 PCM samples.
 * Never fabricates PCM from non-WAV bitstreams.
 */
export function decodeAudioBuffer(buffer: Buffer): DecodedAudio {
  const emptyFail: DecodedAudio = {
    sampleRate: 0,
    channels: 0,
    samples: new Float32Array(0),
    durationSec: 0,
    isWavDecoded: false,
    bitsPerSample: 0,
    audioFormatCode: 0
  };

  if (
    !buffer ||
    buffer.length < 44 ||
    buffer.toString('ascii', 0, 4) !== 'RIFF' ||
    buffer.toString('ascii', 8, 12) !== 'WAVE'
  ) {
    return emptyFail;
  }

  try {
    let offset = 12;
    let fmtFound = false;
    let dataFound = false;
    let audioFormatCode = 0;
    let channels = 0;
    let sampleRate = 0;
    let bitsPerSample = 0;
    let dataOffset = 0;
    let dataLength = 0;

    while (offset <= buffer.length - 8) {
      const subchunkId = buffer.toString('ascii', offset, offset + 4);
      const subchunkSize = buffer.readUInt32LE(offset + 4);
      const chunkStart = offset + 8;

      if (subchunkId === 'fmt ' && chunkStart + 16 <= buffer.length) {
        fmtFound = true;
        const rawFormat = buffer.readUInt16LE(chunkStart);
        channels = buffer.readUInt16LE(chunkStart + 2);
        sampleRate = buffer.readUInt32LE(chunkStart + 4);
        bitsPerSample = buffer.readUInt16LE(chunkStart + 14);
        if (rawFormat === 0xfffe && subchunkSize >= 40 && chunkStart + 26 <= buffer.length) {
          audioFormatCode = buffer.readUInt16LE(chunkStart + 24);
        } else {
          audioFormatCode = rawFormat;
        }
      } else if (subchunkId === 'data') {
        dataFound = true;
        dataOffset = chunkStart;
        dataLength = Math.max(0, Math.min(subchunkSize, buffer.length - dataOffset));
      }

      if (fmtFound && dataFound) break;

      const step = 8 + subchunkSize + (subchunkSize & 1);
      if (step <= 8) break;
      offset += step;
    }

    if (
      !fmtFound ||
      !dataFound ||
      channels < 1 ||
      channels > 16 ||
      sampleRate < 1000 ||
      sampleRate > 384000
    ) {
      return emptyFail;
    }

    const isIntPcm = audioFormatCode === 1 && (bitsPerSample === 8 || bitsPerSample === 16 || bitsPerSample === 24 || bitsPerSample === 32);
    const isFloatPcm = audioFormatCode === 3 && (bitsPerSample === 32 || bitsPerSample === 64);
    if (!isIntPcm && !isFloatPcm) {
      return emptyFail;
    }

    const bytesPerSample = bitsPerSample / 8;
    const frameSize = bytesPerSample * channels;
    const numFrames = Math.floor(dataLength / frameSize);
    if (numFrames <= 0) {
      return emptyFail;
    }

    const samples = new Float32Array(numFrames);
    for (let i = 0; i < numFrames; i++) {
      let acc = 0;
      const frameOffset = dataOffset + i * frameSize;
      for (let ch = 0; ch < channels; ch++) {
        const idx = frameOffset + ch * bytesPerSample;
        if (idx + bytesPerSample > buffer.length) break;
        if (audioFormatCode === 1) {
          if (bitsPerSample === 8) {
            acc += (buffer.readUInt8(idx) - 128) / 128.0;
          } else if (bitsPerSample === 16) {
            acc += buffer.readInt16LE(idx) / 32768.0;
          } else if (bitsPerSample === 24) {
            acc += buffer.readIntLE(idx, 3) / 8388608.0;
          } else if (bitsPerSample === 32) {
            acc += buffer.readInt32LE(idx) / 2147483648.0;
          }
        } else if (audioFormatCode === 3) {
          if (bitsPerSample === 32) {
            acc += Math.max(-1.0, Math.min(1.0, buffer.readFloatLE(idx)));
          } else if (bitsPerSample === 64) {
            acc += Math.max(-1.0, Math.min(1.0, buffer.readDoubleLE(idx)));
          }
        }
      }
      samples[i] = Math.max(-1.0, Math.min(1.0, acc / channels));
    }

    const durationSec = numFrames / sampleRate;
    return {
      sampleRate,
      channels,
      samples,
      durationSec,
      isWavDecoded: true,
      bitsPerSample,
      audioFormatCode
    };
  } catch {
    return emptyFail;
  }
}

/**
 * Pure DataView/Uint8Array 16-bit mono RIFF WAV encoder (browser & Node safe).
 */
export function encodeFloat32ToWavBuffer(samples: Float32Array, sampleRate: number): Uint8Array {
  const safeRate = Math.max(8000, Math.min(384000, Math.round(sampleRate || 16000)));
  const dataBytes = samples.length * 2;
  const out = new Uint8Array(44 + dataBytes);
  const view = new DataView(out.buffer);

  const writeAscii = (pos: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      out[pos + i] = str.charCodeAt(i);
    }
  };

  writeAscii(0, 'RIFF');
  view.setUint32(4, 36 + dataBytes, true);
  writeAscii(8, 'WAVE');
  writeAscii(12, 'fmt ');
  view.setUint32(16, 16, true); // PCM fmt chunk size
  view.setUint16(20, 1, true); // PCM format
  view.setUint16(22, 1, true); // mono
  view.setUint32(24, safeRate, true);
  view.setUint32(28, safeRate * 2, true); // byte rate
  view.setUint16(32, 2, true); // block align
  view.setUint16(34, 16, true); // bits per sample
  writeAscii(36, 'data');
  view.setUint32(40, dataBytes, true);

  for (let i = 0; i < samples.length; i++) {
    const clamped = Math.max(-1.0, Math.min(1.0, samples[i]));
    const pcm = clamped < 0 ? Math.round(clamped * 32768) : Math.round(clamped * 32767);
    view.setInt16(44 + i * 2, pcm, true);
  }

  return out;
}

/**
 * Derives a non-destructive peak-normalized (-1 dBFS) and DC-removed (+ optional Butterworth high-pass)
 * 16-bit PCM working copy without modifying the original buffer.
 */
export function deriveNormalizedWav(
  buffer: Buffer,
  options?: { highPassHz?: number }
): {
  wavBuffer: Buffer;
  sampleRate: number;
  durationSec: number;
  peakDbBefore: number;
  highPassHz: number;
} | null {
  const decoded = decodeAudioBuffer(buffer);
  if (!decoded.isWavDecoded || decoded.samples.length === 0 || decoded.sampleRate <= 0) {
    return null;
  }

  const sr = decoded.sampleRate;
  const n = decoded.samples.length;
  const work = new Float32Array(n);

  // 1. DC Offset removal
  let mean = 0;
  for (let i = 0; i < n; i++) mean += decoded.samples[i];
  mean /= n;
  for (let i = 0; i < n; i++) work[i] = decoded.samples[i] - mean;

  // 2. Optional 2nd-order Butterworth high-pass filter (default 80 Hz)
  const highPassHz = options?.highPassHz !== undefined ? Math.max(0, options.highPassHz) : 80;
  if (highPassHz > 0 && highPassHz < sr / 2) {
    const w0 = (2 * Math.PI * highPassHz) / sr;
    const cosW0 = Math.cos(w0);
    const alpha = Math.sin(w0) / Math.SQRT2;
    const a0 = 1 + alpha;
    const b0 = (1 + cosW0) / 2 / a0;
    const b1 = -(1 + cosW0) / a0;
    const b2 = (1 + cosW0) / 2 / a0;
    const a1 = (-2 * cosW0) / a0;
    const a2 = (1 - alpha) / a0;

    let x1 = 0;
    let x2 = 0;
    let y1 = 0;
    let y2 = 0;
    for (let i = 0; i < n; i++) {
      const x0 = work[i];
      const y0 = b0 * x0 + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
      x2 = x1;
      x1 = x0;
      y2 = y1;
      y1 = y0;
      work[i] = y0;
    }
  }

  // 3. Peak normalization to -1.0 dBFS (0.89125)
  let peak = 0;
  for (let i = 0; i < n; i++) {
    const abs = Math.abs(work[i]);
    if (abs > peak) peak = abs;
  }
  const peakDbBefore = peak > 0 ? +(20 * Math.log10(peak)).toFixed(2) : -96;
  const targetPeak = Math.pow(10, -1 / 20);
  if (peak > 1e-6) {
    const gain = targetPeak / peak;
    for (let i = 0; i < n; i++) {
      work[i] = Math.max(-1.0, Math.min(1.0, work[i] * gain));
    }
  }

  const encoded = encodeFloat32ToWavBuffer(work, sr);
  return {
    wavBuffer: Buffer.from(encoded.buffer, encoded.byteOffset, encoded.byteLength),
    sampleRate: sr,
    durationSec: decoded.durationSec,
    peakDbBefore,
    highPassHz
  };
}

/**
 * Computes genuine acoustic and voice quality measurements from PCM samples.
 */
export function computeAcousticMeasurements(samples: Float32Array, sampleRate: number): AcousticMeasurements {
  if (samples.length === 0) {
    return {
      measurementType: 'non-biometric measurement',
      f0MeanHz: 0,
      f0MinHz: 0,
      f0MaxHz: 0,
      f0StdDevHz: 0,
      pitchRangeSemitones: 0,
      jitterPercent: 0,
      shimmerPercent: 0,
      hnrDb: 0,
      spectralCentroidHz: 0,
      spectralRollOffHz: 0,
      spectralFlatness: 0,
      voicedFractionPercent: 0,
      pauseCount: 0,
      speechDurationSec: 0,
      rmsEnergy: 0,
      estimatedSnrDb: 0,
      clippingPercent: 0
    };
  }

  const frameSize = 1024;
  const hopSize = 512;
  const numFrames = Math.floor((samples.length - frameSize) / hopSize);

  let sumSquares = 0;
  let clippingCount = 0;
  for (let i = 0; i < samples.length; i++) {
    const s = samples[i];
    sumSquares += s * s;
    if (Math.abs(s) >= 0.985) clippingCount++;
  }
  const rmsEnergy = +Math.sqrt(sumSquares / samples.length).toFixed(4);
  const clippingPercent = +( (clippingCount / samples.length) * 100 ).toFixed(2);

  if (numFrames <= 0) {
    return {
      measurementType: 'non-biometric measurement',
      f0MeanHz: 0,
      f0MinHz: 0,
      f0MaxHz: 0,
      f0StdDevHz: 0,
      pitchRangeSemitones: 0,
      jitterPercent: 0,
      shimmerPercent: 0,
      hnrDb: 0,
      spectralCentroidHz: 0,
      spectralRollOffHz: 0,
      spectralFlatness: 0,
      voicedFractionPercent: 0,
      pauseCount: 0,
      speechDurationSec: +(samples.length / sampleRate).toFixed(2),
      rmsEnergy,
      estimatedSnrDb: 0,
      clippingPercent
    };
  }

  const minPitch = 65; // deep adult male voice (65 Hz)
  const maxPitch = 450; // adult female / child voice (450 Hz)
  const minLag = Math.floor(sampleRate / maxPitch);
  const maxLag = Math.floor(sampleRate / minPitch);

  const pitches: number[] = [];
  const peakAmplitudes: number[] = [];
  const hnrValues: number[] = [];
  let voicedCount = 0;
  let noiseEnergySum = 0;
  let noiseFrames = 0;
  let voicedEnergySum = 0;
  let pauseCount = 0;
  let wasInPause = false;

  for (let f = 0; f < numFrames; f++) {
    const start = f * hopSize;
    let frameSumSquares = 0;
    let maxVal = 0;

    for (let i = 0; i < frameSize; i++) {
      const v = samples[start + i];
      frameSumSquares += v * v;
      if (Math.abs(v) > maxVal) maxVal = Math.abs(v);
    }

    const frameRms = Math.sqrt(frameSumSquares / frameSize);

    // Energy threshold for silence / pause
    if (frameRms < 0.015) {
      noiseEnergySum += frameRms;
      noiseFrames++;
      if (!wasInPause) {
        pauseCount++;
        wasInPause = true;
      }
      continue;
    }

    wasInPause = false;

    // Autocorrelation for pitch detection
    let bestLag = 0;
    let maxCorr = -1;

    for (let lag = minLag; lag <= maxLag; lag++) {
      let corr = 0;
      let energyLag = 0;
      for (let i = 0; i < frameSize - lag; i++) {
        const x1 = samples[start + i];
        const x2 = samples[start + i + lag];
        corr += x1 * x2;
        energyLag += x2 * x2;
      }
      const norm = Math.sqrt(frameSumSquares * (energyLag || 1));
      const normCorr = norm > 0 ? corr / norm : 0;
      if (normCorr > maxCorr) {
        maxCorr = normCorr;
        bestLag = lag;
      }
    }

    // Voicing threshold
    if (maxCorr >= 0.40 && bestLag > 0) {
      const pitchHz = sampleRate / bestLag;
      if (pitchHz >= minPitch && pitchHz <= maxPitch) {
        pitches.push(pitchHz);
        peakAmplitudes.push(maxVal);
        voicedCount++;
        voicedEnergySum += frameRms;

        // Harmonics-to-Noise Ratio (dB) = 10 * log10(R / (1 - R))
        const clampedR = Math.min(0.99, Math.max(0.01, maxCorr));
        const frameHnr = 10 * Math.log10(clampedR / (1 - clampedR));
        hnrValues.push(frameHnr);
      }
    }
  }

  const voicedFractionPercent = +( (voicedCount / numFrames) * 100 ).toFixed(1);
  const speechDurationSec = +( (samples.length / sampleRate) * (voicedFractionPercent / 100) ).toFixed(2);

  // F0 statistics
  let f0MeanHz = 0;
  let f0MinHz = 0;
  let f0MaxHz = 0;
  let f0StdDevHz = 0;
  let pitchRangeSemitones = 0;
  let jitterPercent = 0;
  let shimmerPercent = 0;

  if (pitches.length > 0) {
    f0MinHz = +Math.min(...pitches).toFixed(1);
    f0MaxHz = +Math.max(...pitches).toFixed(1);
    const sumF0 = pitches.reduce((a, b) => a + b, 0);
    f0MeanHz = +(sumF0 / pitches.length).toFixed(1);

    const variance = pitches.reduce((acc, p) => acc + Math.pow(p - f0MeanHz, 2), 0) / pitches.length;
    f0StdDevHz = +Math.sqrt(variance).toFixed(1);

    if (f0MinHz > 0) {
      pitchRangeSemitones = +( 12 * Math.log2(f0MaxHz / f0MinHz) ).toFixed(1);
    }

    // Jitter: cycle-to-cycle pitch perturbation
    let pitchDiffSum = 0;
    for (let i = 1; i < pitches.length; i++) {
      pitchDiffSum += Math.abs(pitches[i] - pitches[i - 1]);
    }
    const meanPitchDiff = pitches.length > 1 ? pitchDiffSum / (pitches.length - 1) : 0;
    jitterPercent = +( (meanPitchDiff / (f0MeanHz || 1)) * 100 ).toFixed(2);

    // Shimmer: cycle-to-cycle peak amplitude perturbation
    let ampDiffSum = 0;
    for (let i = 1; i < peakAmplitudes.length; i++) {
      ampDiffSum += Math.abs(peakAmplitudes[i] - peakAmplitudes[i - 1]);
    }
    const meanAmp = peakAmplitudes.reduce((a, b) => a + b, 0) / peakAmplitudes.length;
    const meanAmpDiff = peakAmplitudes.length > 1 ? ampDiffSum / (peakAmplitudes.length - 1) : 0;
    shimmerPercent = +( (meanAmpDiff / (meanAmp || 0.001)) * 100 ).toFixed(2);
  }

  // Mean HNR
  const hnrDb = hnrValues.length > 0
    ? +( hnrValues.reduce((a, b) => a + b, 0) / hnrValues.length ).toFixed(1)
    : 0;

  // Spectral Centroid, Spectral Roll-off, and Spectral Flatness via 512-point FFT approximation
  const fftSize = 512;
  const numFftBins = fftSize / 2;
  const binWidthHz = (sampleRate / 2) / numFftBins;

  let totalSpectralEnergy = 0;
  let weightedSpectralEnergy = 0;
  const powerSpectrum: number[] = new Array(numFftBins).fill(0);

  // Compute average spectrum across sample windows
  const sampleSteps = Math.min(100, Math.floor(samples.length / fftSize));
  for (let w = 0; w < sampleSteps; w++) {
    const base = w * fftSize;
    for (let k = 0; k < numFftBins; k++) {
      // Frequency bin energy approximation using Discrete Fourier Transform kernel on step
      const freq = k * binWidthHz;
      let re = 0;
      let im = 0;
      for (let n = 0; n < 64; n++) {
        const angle = (2 * Math.PI * k * n) / 64;
        const s = samples[base + n * 8] || 0;
        re += s * Math.cos(angle);
        im -= s * Math.sin(angle);
      }
      const power = re * re + im * im;
      powerSpectrum[k] += power;
      totalSpectralEnergy += power;
      weightedSpectralEnergy += power * freq;
    }
  }

  const spectralCentroidHz = totalSpectralEnergy > 0
    ? +Math.round(weightedSpectralEnergy / totalSpectralEnergy)
    : 0;

  // Spectral Roll-off (frequency below which 85% of total power lies)
  let rollOffEnergy = 0;
  const targetRollOffEnergy = totalSpectralEnergy * 0.85;
  let spectralRollOffHz = 4000;

  for (let k = 0; k < numFftBins; k++) {
    rollOffEnergy += powerSpectrum[k];
    if (rollOffEnergy >= targetRollOffEnergy) {
      spectralRollOffHz = +Math.round(k * binWidthHz);
      break;
    }
  }

  // Spectral Flatness (ratio of geometric mean to arithmetic mean)
  let logSum = 0;
  let nonZeroBins = 0;
  for (let k = 0; k < numFftBins; k++) {
    const p = powerSpectrum[k] / (sampleSteps || 1);
    if (p > 0.000001) {
      logSum += Math.log(p);
      nonZeroBins++;
    }
  }
  const geomMean = nonZeroBins > 0 ? Math.exp(logSum / nonZeroBins) : 0;
  const arithMean = totalSpectralEnergy / (numFftBins * (sampleSteps || 1) || 1);
  const spectralFlatness = +( arithMean > 0 ? Math.min(1.0, geomMean / arithMean) : 0 ).toFixed(3);

  // Estimated SNR (dB)
  const avgVoicedRms = voicedCount > 0 ? voicedEnergySum / voicedCount : rmsEnergy;
  const avgNoiseRms = noiseFrames > 0 ? noiseEnergySum / noiseFrames : 0.005;
  const snrRatio = Math.max(1.0, avgVoicedRms / (avgNoiseRms || 0.001));
  const estimatedSnrDb = +( 20 * Math.log10(snrRatio) ).toFixed(1);

  return {
    measurementType: 'non-biometric measurement',
    f0MeanHz,
    f0MinHz,
    f0MaxHz,
    f0StdDevHz,
    pitchRangeSemitones,
    jitterPercent,
    shimmerPercent,
    hnrDb,
    spectralCentroidHz,
    spectralRollOffHz,
    spectralFlatness,
    voicedFractionPercent,
    pauseCount,
    speechDurationSec,
    rmsEnergy,
    estimatedSnrDb,
    clippingPercent
  };
}

/**
 * Extracts a normalized 32-dimensional acoustic speaker representation from audio PCM samples.
 */
export function extractSpeakerEmbeddingVector(samples: Float32Array, sampleRate: number): number[] {
  const measurements = computeAcousticMeasurements(samples, sampleRate);
  const vector: number[] = [];

  // Dimensions 0-7: Fundamental frequency and pitch dynamics
  vector.push(measurements.f0MeanHz / 300.0);
  vector.push(measurements.f0StdDevHz / 50.0);
  vector.push(measurements.pitchRangeSemitones / 24.0);
  vector.push(measurements.jitterPercent / 3.0);
  vector.push(measurements.shimmerPercent / 5.0);
  vector.push(measurements.hnrDb / 30.0);
  vector.push(measurements.voicedFractionPercent / 100.0);
  vector.push(measurements.pauseCount / 20.0);

  // Dimensions 8-15: Spectral features
  vector.push(measurements.spectralCentroidHz / 5000.0);
  vector.push(measurements.spectralRollOffHz / 10000.0);
  vector.push(measurements.spectralFlatness);
  vector.push(measurements.rmsEnergy * 5.0);
  vector.push(measurements.estimatedSnrDb / 40.0);
  vector.push(measurements.clippingPercent / 5.0);
  vector.push((measurements.f0MaxHz - measurements.f0MeanHz) / 100.0);
  vector.push((measurements.f0MeanHz - measurements.f0MinHz) / 100.0);

  // Dimensions 16-31: Filterbank energy distribution across 16 logarithmic frequency bands
  const numFilterBands = 16;
  const maxFreq = sampleRate / 2;
  const bandWidth = maxFreq / numFilterBands;

  for (let b = 0; b < numFilterBands; b++) {
    const centerFreq = (b + 0.5) * bandWidth;
    let bandEnergy = 0;
    const step = Math.max(1, Math.floor(samples.length / 512));
    for (let i = 0; i < samples.length; i += step) {
      const t = i / sampleRate;
      const val = samples[i] * Math.sin(2 * Math.PI * centerFreq * t);
      bandEnergy += val * val;
    }
    vector.push(Math.sqrt(bandEnergy / (samples.length / step || 1)));
  }

  // L2 Normalization
  let norm = 0;
  for (let i = 0; i < vector.length; i++) {
    norm += vector[i] * vector[i];
  }
  const l2 = Math.sqrt(norm) || 1;
  return vector.map((v) => +(v / l2).toFixed(4));
}

/**
 * Computes exact mathematical cosine similarity between two feature vectors.
 */
export function calculateCosineSimilarity(vecA: number[], vecB: number[]): number {
  if (!vecA || !vecB || vecA.length === 0 || vecB.length === 0) return 0;
  const len = Math.min(vecA.length, vecB.length);
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < len; i++) {
    dot += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }
  if (normA === 0 || normB === 0) return 0;
  return dot / (Math.sqrt(normA) * Math.sqrt(normB));
}

/**
 * Evaluates the 5 distinct voice condition & disguise hypotheses based on real acoustic measurements.
 */
export function evaluateVoiceConditionHypotheses(
  qMeas: AcousticMeasurements,
  rMeas?: AcousticMeasurements,
  context?: { microphone?: string; environment?: string; noiseLevel?: string }
): VoiceConditionHypothesis[] {
  const hypotheses: VoiceConditionHypothesis[] = [];

  // Hypothesis 1: Illness or temporary vocal condition (laryngeal edema, acute laryngitis, cold)
  // Acoustic markers: elevated jitter (> 1.2%), reduced HNR (< 16 dB), increased shimmer (> 3.8%)
  const hasIllnessMarkers = qMeas.jitterPercent > 1.2 && qMeas.hnrDb < 17.0;
  const illnessFeatures: string[] = [];
  if (qMeas.jitterPercent > 1.2) illnessFeatures.push(`Elevated vocal fold jitter (${qMeas.jitterPercent}% > 1.0% normal threshold)`);
  if (qMeas.hnrDb < 17.0) illnessFeatures.push(`Depressed Harmonics-to-Noise Ratio (${qMeas.hnrDb} dB < 20 dB standard vocal clarity)`);
  if (qMeas.shimmerPercent > 3.8) illnessFeatures.push(`Increased amplitude shimmer (${qMeas.shimmerPercent}%) indicating glottal waveform perturbation`);

  hypotheses.push({
    hypothesis: 'Illness or temporary vocal condition',
    likelihood: hasIllnessMarkers ? 'Supported by acoustic data' : 'Unconfirmed',
    findings: hasIllnessMarkers
      ? `Acoustic perturbations align with physiological hoarseness or upper respiratory vocal fold inflammation. Jitter is elevated to ${qMeas.jitterPercent}% and HNR is reduced to ${qMeas.hnrDb} dB.`
      : `Vocal quality metrics (Jitter: ${qMeas.jitterPercent}%, HNR: ${qMeas.hnrDb} dB) do not exhibit classical indicators of acute vocal tract pathology.`,
    supportingFeatures: illnessFeatures
  });

  // Hypothesis 2: Vocal strain / fatigue
  // Acoustic markers: high shimmer (> 4.0%), restricted dynamic range, slight pitch elevation
  const hasStrainMarkers = qMeas.shimmerPercent > 4.2 || (rMeas && qMeas.f0MeanHz > rMeas.f0MeanHz + 25);
  const strainFeatures: string[] = [];
  if (qMeas.shimmerPercent > 4.2) strainFeatures.push(`Elevated cycle-to-cycle shimmer (${qMeas.shimmerPercent}%) indicating vocal fold fatigue`);
  if (rMeas && qMeas.f0MeanHz > rMeas.f0MeanHz + 20) strainFeatures.push(`Mean pitch elevated by +${(qMeas.f0MeanHz - rMeas.f0MeanHz).toFixed(1)} Hz above reference exemplar`);

  hypotheses.push({
    hypothesis: 'Vocal strain / fatigue',
    likelihood: hasStrainMarkers ? 'Supported by acoustic data' : 'Unconfirmed',
    findings: hasStrainMarkers
      ? `Perturbations in amplitude stability (${qMeas.shimmerPercent}% shimmer) and elevated vocal tension are consistent with muscle tension or vocal fatigue.`
      : `Amplitude perturbation and pitch stability remain within typical relaxed conversational bounds.`,
    supportingFeatures: strainFeatures
  });

  // Hypothesis 3: Intentional vocal disguise
  // Acoustic markers: intentional pitch shifting (|delta F0| > 40 Hz), whispering, falsetto, or altered speech tempo with normal biological tremor
  const hasDisguiseShift = rMeas ? Math.abs(qMeas.f0MeanHz - rMeas.f0MeanHz) > 42.0 : qMeas.pitchRangeSemitones > 22.0 || qMeas.f0MeanHz > 280;
  const disguiseFeatures: string[] = [];
  if (rMeas && Math.abs(qMeas.f0MeanHz - rMeas.f0MeanHz) > 42.0) {
    disguiseFeatures.push(`Voluntary pitch transposition of ${Math.abs(qMeas.f0MeanHz - rMeas.f0MeanHz).toFixed(1)} Hz compared to subject reference voice`);
  }
  if (qMeas.voicedFractionPercent < 30.0 && qMeas.speechDurationSec > 2.0) {
    disguiseFeatures.push(`Abnormally low voiced fraction (${qMeas.voicedFractionPercent}%) characteristic of forced whispering or pinched voice`);
  }

  hypotheses.push({
    hypothesis: 'Intentional vocal disguise',
    likelihood: hasDisguiseShift ? 'Supported by acoustic data' : 'Unconfirmed',
    findings: hasDisguiseShift
      ? `Measured substantial shift in baseline register (${rMeas ? Math.abs(qMeas.f0MeanHz - rMeas.f0MeanHz).toFixed(1) + ' Hz shift vs reference' : 'unusual pitch range'}). However, audio analysis cannot establish intent without independent corroborating evidence.`
      : `Pitch center (${qMeas.f0MeanHz} Hz) and voiced speech ratio align with expected conversational vocal behavior; no voluntary register transposition detected.`,
    supportingFeatures: disguiseFeatures
  });

  // Hypothesis 4: AI-based voice conversion / cloning
  // Acoustic markers: unnatural pitch flatlining (F0 std dev < 0.9 Hz), vocoder high-frequency roll-off (spectral cutoff >14kHz with steep drop), phase discontinuities
  const hasAiMarkers = (qMeas.f0StdDevHz < 1.2 && qMeas.speechDurationSec > 2.0) || qMeas.spectralRollOffHz < 12000;
  const aiFeatures: string[] = [];
  if (qMeas.f0StdDevHz < 1.2 && qMeas.speechDurationSec > 2.0) {
    aiFeatures.push(`Unnatural prosodic flatlining: F0 standard deviation (${qMeas.f0StdDevHz} Hz) is below natural human biological micro-intonation bounds (σ >= 2.5 Hz)`);
  }
  if (qMeas.spectralRollOffHz < 12000) {
    aiFeatures.push(`High-frequency spectral cutoff detected at ${qMeas.spectralRollOffHz} Hz, characteristic of neural vocoder upsampling filter attenuation`);
  }

  hypotheses.push({
    hypothesis: 'AI-based voice conversion / cloning',
    likelihood: hasAiMarkers ? 'Supported by acoustic data' : 'Unconfirmed',
    findings: hasAiMarkers
      ? `Acoustic feature analysis revealed anomalies characteristic of generative neural vocoders (e.g. HiFi-GAN / VITS), including reduced prosodic variation (${qMeas.f0StdDevHz} Hz F0 std dev).`
      : `Natural biological micro-tremor and vocal tract resonance continuity are preserved; vocoder synthesis artifacts were not flagged.`,
    supportingFeatures: aiFeatures
  });

  // Hypothesis 5: Acoustic / equipment / noise confounding
  // Acoustic markers: poor SNR (< 12 dB), high clipping (> 1.0%), high spectral flatness
  const hasConfounding = qMeas.estimatedSnrDb < 14.0 || qMeas.clippingPercent > 1.0;
  const confoundingFeatures: string[] = [];
  if (qMeas.estimatedSnrDb < 14.0) confoundingFeatures.push(`Elevated background noise floor (estimated SNR: ${qMeas.estimatedSnrDb} dB < 18 dB forensic threshold)`);
  if (qMeas.clippingPercent > 1.0) confoundingFeatures.push(`Digital/analog microphone clipping detected on ${qMeas.clippingPercent}% of samples`);
  if (context?.environment) confoundingFeatures.push(`Reported recording condition: ${context.environment}`);
  if (context?.microphone) confoundingFeatures.push(`Reported transducer: ${context.microphone}`);

  hypotheses.push({
    hypothesis: 'Acoustic / equipment / noise confounding',
    likelihood: hasConfounding ? 'Supported by acoustic data' : 'Unconfirmed',
    findings: hasConfounding
      ? `Channel degradation detected: Estimated SNR of ${qMeas.estimatedSnrDb} dB and ${qMeas.clippingPercent}% sample clipping may distort vocal formant extraction and pitch estimation.`
      : `Recording environment exhibits adequate signal clarity (SNR: ${qMeas.estimatedSnrDb} dB, clipping: ${qMeas.clippingPercent}%); acoustic transmission effects are minimal.`,
    supportingFeatures: confoundingFeatures
  });

  return hypotheses;
}

/**
 * Computes deterministic 24-band Mel filterbank, 13 MFCCs, 13 LFCCs, energy+ZCR Voice Activity Detection,
 * and per-window acoustic telemetry, tagged explicitly as 'non-biometric measurement'.
 */
export function computeNonBiometricDspProfile(
  samples: Float32Array,
  sampleRate: number
): NonBiometricDspProfile {
  const numBands = 24;
  const numCepstra = 13;
  if (!samples || samples.length === 0 || !sampleRate || sampleRate <= 0) {
    return {
      measurementType: 'non-biometric measurement',
      melBandsDb: new Array(numBands).fill(-96),
      mfccMean: new Array(numCepstra).fill(0),
      lfccMean: new Array(numCepstra).fill(0),
      vadActiveRatio: 0,
      vadSegmentCount: 0,
      vadSegments: [],
      windowTelemetry: []
    };
  }

  const nyquist = sampleRate / 2;
  const hzToMel = (hz: number) => 2595 * Math.log10(1 + hz / 700);
  const melToHz = (mel: number) => 700 * (Math.pow(10, mel / 2595) - 1);

  const melMin = hzToMel(50);
  const melMax = hzToMel(Math.min(8000, nyquist));
  const melCenters: number[] = [];
  for (let b = 0; b < numBands; b++) {
    const mel = melMin + ((b + 0.5) / numBands) * (melMax - melMin);
    melCenters.push(melToHz(mel));
  }

  const linMax = Math.min(8000, nyquist);
  const linCenters: number[] = [];
  for (let b = 0; b < numBands; b++) {
    linCenters.push(50 + ((b + 0.5) / numBands) * Math.max(100, linMax - 50));
  }

  const goertzelMagnitude = (frameStart: number, frameLen: number, freqHz: number): number => {
    const omega = (2 * Math.PI * freqHz) / sampleRate;
    const coeff = 2 * Math.cos(omega);
    let q0 = 0;
    let q1 = 0;
    let q2 = 0;
    for (let i = 0; i < frameLen; i++) {
      const idx = frameStart + i;
      const win = 0.54 - 0.46 * Math.cos((2 * Math.PI * i) / Math.max(1, frameLen - 1));
      const x = (idx < samples.length ? samples[idx] : 0) * win;
      q0 = coeff * q1 - q2 + x;
      q2 = q1;
      q1 = q0;
    }
    const power = Math.max(1e-12, q1 * q1 + q2 * q2 - q1 * q2 * coeff);
    return Math.sqrt(power) / Math.max(1, frameLen);
  };

  const frameLen = Math.min(512, Math.max(128, Math.round(sampleRate * 0.025)));
  const maxEvalFrames = 32;
  const frameStride = Math.max(frameLen, Math.floor((samples.length - frameLen) / maxEvalFrames));
  const melDbAcc = new Array(numBands).fill(0);
  const linDbAcc = new Array(numBands).fill(0);
  let evalFrameCount = 0;

  for (let pos = 0; pos + frameLen <= samples.length && evalFrameCount < maxEvalFrames; pos += frameStride) {
    for (let b = 0; b < numBands; b++) {
      const magMel = goertzelMagnitude(pos, frameLen, melCenters[b]);
      melDbAcc[b] += 20 * Math.log10(Math.max(1e-6, magMel));
      const magLin = goertzelMagnitude(pos, frameLen, linCenters[b]);
      linDbAcc[b] += 20 * Math.log10(Math.max(1e-6, magLin));
    }
    evalFrameCount++;
  }

  const melBandsDb = melDbAcc.map((v) => +(v / Math.max(1, evalFrameCount)).toFixed(2));
  const linBandsDb = linDbAcc.map((v) => +(v / Math.max(1, evalFrameCount)).toFixed(2));

  const dctII = (bands: number[], count: number): number[] => {
    const N = bands.length;
    const out: number[] = [];
    for (let k = 0; k < count; k++) {
      let sum = 0;
      for (let n = 0; n < N; n++) {
        sum += bands[n] * Math.cos((Math.PI * k * (n + 0.5)) / N);
      }
      const scale = k === 0 ? Math.sqrt(1 / N) : Math.sqrt(2 / N);
      out.push(+(sum * scale).toFixed(3));
    }
    return out;
  };

  const mfccMean = dctII(melBandsDb, numCepstra);
  const lfccMean = dctII(linBandsDb, numCepstra);

  // Energy + Zero-Crossing Rate Voice Activity Detection & Window Telemetry
  const vadFrameSize = Math.max(160, Math.round(sampleRate * 0.025)); // 25ms
  const totalVadFrames = Math.max(1, Math.floor(samples.length / vadFrameSize));
  const frameStates: Array<{
    startSec: number;
    endSec: number;
    rmsDb: number;
    voiced: boolean;
    f0Hz: number | null;
  }> = [];

  const minLag = Math.floor(sampleRate / 420);
  const maxLag = Math.min(Math.floor(vadFrameSize / 2), Math.floor(sampleRate / 65));

  let activeCount = 0;
  for (let f = 0; f < totalVadFrames; f++) {
    const start = f * vadFrameSize;
    const end = Math.min(samples.length, start + vadFrameSize);
    const len = end - start;
    let sumSq = 0;
    let zeroCrossings = 0;
    for (let i = 0; i < len; i++) {
      const s = samples[start + i];
      sumSq += s * s;
      if (i > 0) {
        const prev = samples[start + i - 1];
        if ((prev >= 0 && s < 0) || (prev < 0 && s >= 0)) zeroCrossings++;
      }
    }
    const rms = Math.sqrt(sumSq / Math.max(1, len));
    const rmsDb = +(20 * Math.log10(Math.max(1e-5, rms))).toFixed(2);
    const zcr = zeroCrossings / Math.max(1, len);
    const isActive = rms > 0.012 && zcr >= 0.005 && zcr <= 0.35;
    if (isActive) activeCount++;

    let f0Hz: number | null = null;
    if (isActive && len > maxLag && maxLag > minLag) {
      let bestLag = 0;
      let bestCorr = 0;
      for (let lag = minLag; lag <= maxLag; lag++) {
        let corr = 0;
        let eLag = 0;
        for (let i = 0; i < len - lag; i++) {
          const x1 = samples[start + i];
          const x2 = samples[start + i + lag];
          corr += x1 * x2;
          eLag += x2 * x2;
        }
        const denom = Math.sqrt(sumSq * (eLag || 1));
        const r = denom > 0 ? corr / denom : 0;
        if (r > bestCorr) {
          bestCorr = r;
          bestLag = lag;
        }
      }
      if (bestCorr >= 0.38 && bestLag > 0) {
        f0Hz = +(sampleRate / bestLag).toFixed(1);
      }
    }

    frameStates.push({
      startSec: +(start / sampleRate).toFixed(3),
      endSec: +(end / sampleRate).toFixed(3),
      rmsDb,
      voiced: isActive,
      f0Hz
    });
  }

  const vadSegments: Array<{ startSec: number; endSec: number }> = [];
  let inSeg = false;
  let segStart = 0;
  for (let i = 0; i < frameStates.length; i++) {
    if (frameStates[i].voiced && !inSeg) {
      inSeg = true;
      segStart = frameStates[i].startSec;
    } else if (!frameStates[i].voiced && inSeg) {
      inSeg = false;
      vadSegments.push({ startSec: segStart, endSec: frameStates[i - 1].endSec });
    }
  }
  if (inSeg && frameStates.length > 0) {
    vadSegments.push({ startSec: segStart, endSec: frameStates[frameStates.length - 1].endSec });
  }

  // Downsample/aggregate windowTelemetry cleanly to <= 60 windows
  const maxWindows = 60;
  const windowTelemetry: NonBiometricDspProfile['windowTelemetry'] = [];
  if (frameStates.length <= maxWindows) {
    windowTelemetry.push(...frameStates);
  } else {
    const groupSize = Math.ceil(frameStates.length / maxWindows);
    for (let g = 0; g < frameStates.length; g += groupSize) {
      const slice = frameStates.slice(g, g + groupSize);
      const avgRms = +(slice.reduce((a, x) => a + x.rmsDb, 0) / slice.length).toFixed(2);
      const voicedFrames = slice.filter((x) => x.voiced);
      const f0Frames = slice.filter((x) => x.f0Hz !== null);
      const avgF0 = f0Frames.length > 0 ? +(f0Frames.reduce((a, x) => a + (x.f0Hz || 0), 0) / f0Frames.length).toFixed(1) : null;
      windowTelemetry.push({
        startSec: slice[0].startSec,
        endSec: slice[slice.length - 1].endSec,
        rmsDb: avgRms,
        f0Hz: avgF0,
        voiced: voicedFrames.length >= Math.ceil(slice.length / 2)
      });
    }
  }

  return {
    measurementType: 'non-biometric measurement',
    melBandsDb,
    mfccMean,
    lfccMean,
    vadActiveRatio: +(activeCount / Math.max(1, totalVadFrames)).toFixed(3),
    vadSegmentCount: vadSegments.length,
    vadSegments: vadSegments.slice(0, 64),
    windowTelemetry
  };
}
