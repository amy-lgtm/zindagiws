// Centralized Secure API Client for ALFADetect Forensic Platform

export function getAuthToken(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('auth_session_token');
}

export function setAuthToken(token: string): void {
  if (typeof window !== 'undefined' && token) {
    localStorage.setItem('auth_session_token', token);
  }
}

export function clearAuthSession(): void {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('auth_session_token');
    localStorage.removeItem('deepfake_detector_user');
  }
}

export class ApiError extends Error {
  status: number;
  data: any;
  constructor(message: string, status: number, data?: any) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

export async function authFetch(url: string, options: RequestInit = {}): Promise<Response> {
  const token = getAuthToken();
  const hadStoredSession = Boolean(
    token || (typeof window !== 'undefined' && localStorage.getItem('deepfake_detector_user'))
  );
  const headers = new Headers(options.headers || {});

  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  // Only default JSON Content-Type for plain string payloads (never overwrite FormData multipart boundary)
  if (options.body && typeof options.body === 'string' && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const response = await fetch(url, {
    credentials: 'same-origin',
    ...options,
    headers
  });

  // If 401 Unauthorized returned on an authenticated flow, clear storage and notify App
  if (
    response.status === 401 &&
    !url.includes('/api/auth/login') &&
    !url.includes('/api/auth/reauth') &&
    !url.includes('/api/auth/verify-2fa') &&
    !url.includes('/api/auth/reset-password')
  ) {
    clearAuthSession();
    if (typeof window !== 'undefined' && (hadStoredSession || !url.includes('/api/auth/me'))) {
      window.dispatchEvent(
        new CustomEvent('alfadetect:session-expired', {
          detail: { message: 'Session expired, please sign in again.' }
        })
      );
    }
  }

  // If 403 returned because account was suspended/rejected/pending while token existed, clean stale session
  if (response.status === 403 && !url.includes('/api/auth/')) {
    try {
      const cloned = response.clone();
      const body = await cloned.json().catch(() => null);
      if (body?.accountStatus && body.accountStatus !== 'active') {
        clearAuthSession();
        if (typeof window !== 'undefined' && hadStoredSession) {
          window.dispatchEvent(
            new CustomEvent('alfadetect:session-expired', {
              detail: {
                message: body?.error || 'Session expired or account access disabled, please sign in again.'
              }
            })
          );
        }
      }
    } catch {
      // Ignore clone errors
    }
  }

  return response;
}

export async function apiRequest<T = any>(url: string, options: RequestInit = {}): Promise<T> {
  const response = await authFetch(url, options);
  let data: any = null;
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('application/json')) {
    try {
      data = await response.json();
    } catch {
      data = null;
    }
  } else {
    data = await response.text();
  }

  if (!response.ok) {
    const errorMsg = data?.error || data?.message || `Request failed with status ${response.status}`;
    throw new ApiError(errorMsg, response.status, data);
  }

  return data as T;
}

export async function uploadMultipart<T = any>(url: string, formData: FormData): Promise<T> {
  const response = await authFetch(url, {
    method: 'POST',
    body: formData
  });
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    const errorMsg = data?.error || data?.message || `Upload failed with status ${response.status}`;
    throw new ApiError(errorMsg, response.status, data);
  }
  return data as T;
}

export const api = {
  get: <T = any>(url: string) => apiRequest<T>(url, { method: 'GET' }),
  post: <T = any>(url: string, body?: any) =>
    apiRequest<T>(url, {
      method: 'POST',
      body: body ? JSON.stringify(body) : undefined
    }),
  patch: <T = any>(url: string, body?: any) =>
    apiRequest<T>(url, {
      method: 'PATCH',
      body: body ? JSON.stringify(body) : undefined
    }),
  delete: <T = any>(url: string) => apiRequest<T>(url, { method: 'DELETE' }),
  uploadMultipart,

  // First-Run Single-Admin Setup
  getSetupStatus: async () => apiRequest<{
    initialized: boolean;
    needsAdminSetup: boolean;
    requiresInitToken: boolean;
    adminCount: number;
    totalUsers: number;
    smtpConfigured: boolean;
  }>('/api/setup/status', { method: 'GET' }),

  initAdmin: async (payload: {
    name: string;
    email: string;
    password: string;
    agency?: string;
    department?: string;
    initToken?: string;
  }) => apiRequest('/api/setup/init-admin', { method: 'POST', body: JSON.stringify(payload) }),

  // Registration Status & Auth
  checkPendingStatus: async (email: string, password: string) =>
    apiRequest('/api/auth/pending-status', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    }),

  verify2faLogin: async (challengeToken: string, code: string, loginMode?: 'user' | 'admin') =>
    apiRequest('/api/auth/verify-2fa', {
      method: 'POST',
      body: JSON.stringify({ challengeToken, code, ...(loginMode ? { loginMode } : {}) })
    }),

  forgotPassword: async (email: string) =>
    apiRequest<{ status: string; smtpConfigured: boolean; message: string }>('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email })
    }),

  resetPassword: async (payload: { token: string; newPassword: string; totpCode?: string }) =>
    apiRequest<{ success: boolean; message: string }>('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),

  // Admin Governance
  getUsers: async (params?: { search?: string; role?: string; status?: string }) => {
    const qs = new URLSearchParams();
    if (params?.search) qs.set('search', params.search);
    if (params?.role && params.role !== 'ALL') qs.set('role', params.role);
    if (params?.status && params.status !== 'ALL') qs.set('status', params.status);
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return apiRequest(`/api/users${suffix}`, { method: 'GET' });
  },
  getPendingUsers: async () => apiRequest('/api/admin/pending-users', { method: 'GET' }),
  getAdminRoles: async () => apiRequest('/api/admin/roles', { method: 'GET' }),
  createAdminUser: async (payload: {
    name: string;
    email: string;
    password: string;
    role: string;
    agency?: string;
    department?: string;
    certificationId?: string;
  }) =>
    apiRequest('/api/admin/users', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
  approveUser: async (id: string, assignedRole?: string) =>
    apiRequest(`/api/admin/users/${encodeURIComponent(id)}/approve`, {
      method: 'POST',
      body: JSON.stringify({ assignedRole })
    }),
  rejectUser: async (id: string, reason: string) =>
    apiRequest(`/api/admin/users/${encodeURIComponent(id)}/reject`, {
      method: 'POST',
      body: JSON.stringify({ reason })
    }),
  updateUserRole: async (id: string, role: string) =>
    apiRequest(`/api/users/${encodeURIComponent(id)}/role`, {
      method: 'PATCH',
      body: JSON.stringify({ role })
    }),
  updateUserStatus: async (id: string, status: string) =>
    apiRequest(`/api/users/${encodeURIComponent(id)}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status })
    }),
  transferAdmin: async (payload: {
    targetUserId: string;
    currentPassword: string;
    totpCode?: string;
    demoteCurrentToRole: string;
    confirmText: string;
  }) =>
    apiRequest('/api/admin/transfer-admin', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
  testSmtp: async (recipient?: string) =>
    apiRequest('/api/admin/test-smtp', {
      method: 'POST',
      body: JSON.stringify({ recipient })
    }),
  adminResetUserPassword: async (id: string, newPassword?: string) =>
    apiRequest<{
      success: boolean;
      temporaryPassword: string;
      mustChangePassword: boolean;
      smtpConfigured?: boolean;
      emailDispatched?: boolean;
      user: any;
    }>(`/api/admin/users/${encodeURIComponent(id)}/reset-password`, {
      method: 'POST',
      body: JSON.stringify(newPassword ? { newPassword } : {})
    }),
  adminResetUser2fa: async (id: string, payload: { currentPassword: string; totpCode?: string }) =>
    apiRequest<{ success: boolean; user: any }>(`/api/admin/users/${encodeURIComponent(id)}/reset-2fa`, {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
  getAdminActivity: async (params?: { search?: string; action?: string; user?: string; limit?: number; offset?: number }) => {
    const qs = new URLSearchParams();
    if (params?.search) qs.set('search', params.search);
    if (params?.action && params.action !== 'ALL') qs.set('action', params.action);
    if (params?.user && params.user !== 'ALL') qs.set('user', params.user);
    if (params?.limit) qs.set('limit', String(params.limit));
    if (params?.offset) qs.set('offset', String(params.offset));
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return apiRequest(`/api/admin/activity${suffix}`, { method: 'GET' });
  },
  getSystemConfig: async () => apiRequest('/api/admin/config', { method: 'GET' }),
  updateSystemConfig: async (payload: Record<string, any>) =>
    apiRequest('/api/admin/config', {
      method: 'PATCH',
      body: JSON.stringify(payload)
    }),

  // Settings endpoints (persisting refreshed JWT when issued)
  updateProfile: async (payload: Record<string, any>) =>
    apiRequest('/api/settings/profile', {
      method: 'PATCH',
      body: JSON.stringify(payload)
    }),
  requestEmailChange: async (payload: { newEmail: string; currentPassword: string }) =>
    apiRequest('/api/settings/email-change/request', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
  confirmEmailChange: async (code: string) => {
    const res = await apiRequest('/api/settings/email-change/confirm', {
      method: 'POST',
      body: JSON.stringify({ code })
    });
    if (res?.newToken) setAuthToken(res.newToken);
    if (res?.user && typeof window !== 'undefined') {
      localStorage.setItem('deepfake_detector_user', JSON.stringify(res.user));
    }
    return res;
  },
  changePassword: async (payload: { currentPassword: string; newPassword: string }) => {
    const res = await apiRequest('/api/settings/password', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    if (res?.newToken) setAuthToken(res.newToken);
    return res;
  },
  get2faStatus: async () => apiRequest('/api/settings/2fa/status', { method: 'GET' }),
  setup2fa: async () => apiRequest('/api/settings/2fa/setup', { method: 'POST' }),
  verify2faSetup: async (code: string) =>
    apiRequest('/api/settings/2fa/verify', { method: 'POST', body: JSON.stringify({ code }) }),
  disable2fa: async (payload: { currentPassword: string; totpCode: string }) =>
    apiRequest('/api/settings/2fa/disable', { method: 'POST', body: JSON.stringify(payload) }),

  // Notifications
  markAllNotificationsRead: async () =>
    apiRequest('/api/notifications/read-all', { method: 'POST' }),

  // Collaborators & Cases
  getCollaborators: async () => apiRequest('/api/collaborators', { method: 'GET' }),
  getCases: async (includeArchived = false) =>
    apiRequest(`/api/cases${includeArchived ? '?includeArchived=true' : ''}`, { method: 'GET' }),
  createCase: async (payload: {
    title: string;
    description: string;
    priority: string;
    agency: string;
    analyst: string;
    createdBy?: string;
    assignedUserIds?: string[];
  }) =>
    apiRequest('/api/cases', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
  updateCase: async (id: string, payload: Record<string, any>) =>
    apiRequest(`/api/cases/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload)
    }),
  archiveCase: async (id: string) =>
    apiRequest(`/api/cases/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  getRetentionCases: async () =>
    apiRequest('/api/admin/retention-cases', { method: 'GET' }),
  purgeCase: async (
    id: string,
    payload: { currentPassword: string; totpCode?: string; confirmText: string }
  ) =>
    apiRequest(`/api/admin/cases/${encodeURIComponent(id)}/purge`, {
      method: 'POST',
      body: JSON.stringify(payload)
    }),

  // Evidence endpoints
  uploadEvidence: async (payload: Record<string, any>) =>
    apiRequest('/api/evidence/upload', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
  uploadEvidenceMultipart: async (formData: FormData) =>
    uploadMultipart('/api/evidence/upload', formData),
  verifyEvidenceHashMultipart: async (formData: FormData) =>
    uploadMultipart('/api/evidence/verify-hash', formData),
  getEvidence: async (caseId?: string) => {
    const url = caseId ? `/api/evidence?caseId=${encodeURIComponent(caseId)}` : '/api/evidence';
    return apiRequest(url, { method: 'GET' });
  },
  deriveEvidenceCopy: async (evidenceId: string, payload?: { highPassHz?: number }) =>
    apiRequest(`/api/evidence/${encodeURIComponent(evidenceId)}/derive-copy`, {
      method: 'POST',
      body: payload ? JSON.stringify(payload) : undefined
    }),

  // Chain of Custody verification
  verifyChainOfCustody: async (caseId: string) =>
    apiRequest(`/api/cases/${encodeURIComponent(caseId)}/chain-of-custody/verify`, { method: 'GET' }),

  // AI & Analysis endpoints
  analyzeAudio: async (payload: Record<string, any>) =>
    apiRequest('/api/analyze-audio', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
  analyzeAudioAsync: async (payload: { caseId: string; evidenceId: string }) =>
    apiRequest('/api/analyze-audio?async=true', {
      method: 'POST',
      body: JSON.stringify({ ...payload, async: true })
    }),
  getAnalysisJob: async (jobId: string) =>
    apiRequest(`/api/analysis-jobs/${encodeURIComponent(jobId)}`, { method: 'GET' }),
  getCaseAnalyses: async (caseId: string, evidenceId?: string) => {
    const qs = evidenceId ? `?evidenceId=${encodeURIComponent(evidenceId)}` : '';
    return apiRequest(`/api/cases/${encodeURIComponent(caseId)}/analyses${qs}`, { method: 'GET' });
  },
  getModelsStatus: async () =>
    apiRequest('/api/ai/models-status', { method: 'GET' }),

  // Legal Review & Expert Review & Report Export
  getLegalReview: async (caseId: string) =>
    apiRequest(`/api/cases/${encodeURIComponent(caseId)}/legal-review`, { method: 'GET' }),
  saveLegalReview: async (caseId: string, payload: Record<string, any>) =>
    apiRequest(`/api/cases/${encodeURIComponent(caseId)}/legal-review`, {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
  exportCaseReport: async (caseId: string, payload: Record<string, any>) =>
    apiRequest(`/api/cases/${encodeURIComponent(caseId)}/report-export`, {
      method: 'POST',
      body: JSON.stringify(payload)
    }),

  // Speaker verification endpoints
  compareSpeakerVoices: async (payload: Record<string, any>) =>
    apiRequest('/api/speaker-verification/compare', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),

  // Voice condition analysis
  analyzeVoiceCondition: async (payload: Record<string, any>) =>
    apiRequest('/api/voice-analysis/condition', {
      method: 'POST',
      body: JSON.stringify(payload)
    })
};
