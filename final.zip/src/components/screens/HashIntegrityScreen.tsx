import React, { useState, useEffect } from 'react';
import {
  Hash,
  CheckCircle2,
  ShieldCheck,
  AlertOctagon,
  Upload,
  RefreshCw,
  Lock,
  Copy,
  Check,
  User as UserIcon,
  Clock,
  FileCheck,
  ShieldAlert,
  Info,
  AlertCircle
} from 'lucide-react';
import { ScreenId, AudioEvidence, User } from '../../types';
import { calculateFileSHA256 } from '../../utils/crypto';
import { BackButton } from '../common/BackButton';
import { authFetch, api } from '../../utils/api';

interface HashIntegrityScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  activeEvidence: AudioEvidence;
  setActiveEvidence?: (ev: AudioEvidence) => void;
  currentUser: User;
}

function deriveInitialVerificationState(ev: AudioEvidence): 'MATCH' | 'NO_MATCH' | 'UNVERIFIED' {
  const hasEv = !!ev?.id && ev.id !== 'EV-INIT' && !!ev.sha256Hash;
  if (!hasEv) return 'UNVERIFIED';
  if (ev.status === 'Failed' || ev.isIntegrityVerified === false) return 'NO_MATCH';
  if (ev.status === 'Verified') return 'MATCH';
  return 'UNVERIFIED';
}

export const HashIntegrityScreen: React.FC<HashIntegrityScreenProps> = ({
  setCurrentScreen,
  activeEvidence,
  setActiveEvidence,
  currentUser
}) => {
  const hasActiveEvidence = !!activeEvidence?.id && activeEvidence.id !== 'EV-INIT' && !!activeEvidence.sha256Hash;
  const [caseEvidenceList, setCaseEvidenceList] = useState<AudioEvidence[]>([]);
  const [selectedFileName, setSelectedFileName] = useState(activeEvidence.filename);
  const [originalHash, setOriginalHash] = useState(activeEvidence.sha256Hash || '');
  const [currentHash, setCurrentHash] = useState<string>(activeEvidence.sha256Hash || '');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<'MATCH' | 'NO_MATCH' | 'UNVERIFIED'>(
    deriveInitialVerificationState(activeEvidence)
  );
  const [verificationTimestamp, setVerificationTimestamp] = useState<string>(
    activeEvidence.verificationDate || activeEvidence.uploadTimestamp || ''
  );
  const [verifierName, setVerifierName] = useState<string>(
    activeEvidence.verifiedBy || `${currentUser.name} (${currentUser.role})`
  );
  const [errorNotice, setErrorNotice] = useState<string | null>(null);
  const [copiedOriginal, setCopiedOriginal] = useState(false);
  const [copiedCurrent, setCopiedCurrent] = useState(false);

  useEffect(() => {
    setSelectedFileName(activeEvidence.filename);
    setOriginalHash(activeEvidence.sha256Hash || '');
    setCurrentHash(activeEvidence.sha256Hash || '');
    setVerificationResult(deriveInitialVerificationState(activeEvidence));
    setVerificationTimestamp(activeEvidence.verificationDate || activeEvidence.uploadTimestamp || '');
    setVerifierName(activeEvidence.verifiedBy || `${currentUser.name} (${currentUser.role})`);
    setErrorNotice(null);
  }, [activeEvidence, currentUser.name, currentUser.role]);

  useEffect(() => {
    if (!activeEvidence?.caseId) return;
    let cancelled = false;
    authFetch(`/api/cases/${encodeURIComponent(activeEvidence.caseId)}/evidence`)
      .then((res) => (res.ok ? res.json() : []))
      .then((list) => {
        if (!cancelled && Array.isArray(list)) {
          setCaseEvidenceList(list);
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [activeEvidence?.caseId, activeEvidence?.id]);

  // Real candidate file upload verification against backend SHA-256 baseline (multipart FormData)
  const handleFileChange = async (file: File) => {
    setSelectedFileName(file.name);
    setIsVerifying(true);
    setErrorNotice(null);

    try {
      const localHash = await calculateFileSHA256(file);
      setCurrentHash(localHash);

      const formData = new FormData();
      if (hasActiveEvidence) {
        formData.append('evidenceId', activeEvidence.id);
      }
      if (originalHash) {
        formData.append('expectedHash', originalHash);
      }
      formData.append('candidateHash', localHash);
      formData.append('audio', file, file.name);

      const data = await api.verifyEvidenceHashMultipart(formData);

      setOriginalHash(data.originalHash || originalHash);
      setCurrentHash(data.computedHash || localHash);
      setVerificationResult(data.verified ? 'MATCH' : 'NO_MATCH');
      setVerificationTimestamp(new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC');
      setVerifierName(`${currentUser.name} (${currentUser.role})`);
    } catch (err: any) {
      setErrorNotice(err?.message || 'Failed to calculate or verify SHA-256 checksum against the forensic enclave.');
      setVerificationResult('UNVERIFIED');
    } finally {
      setIsVerifying(false);
    }
  };

  // Re-verify stored server bitstream via POST /api/evidence/verify-hash
  const handleRecomputeHash = async () => {
    if (!hasActiveEvidence) {
      setErrorNotice('Select or ingest an audio evidence exhibit first to verify its server-sealed SHA-256 hash.');
      return;
    }

    setIsVerifying(true);
    setErrorNotice(null);

    try {
      const res = await authFetch('/api/evidence/verify-hash', {
        method: 'POST',
        body: JSON.stringify({
          evidenceId: activeEvidence.id,
          verifyStoredBitstream: true
        })
      });
      const data = await res.json().catch(() => null);

      if (!res.ok) {
        setErrorNotice(data?.error || `Server bitstream verification failed (${res.status}).`);
        return;
      }

      setOriginalHash(data.originalHash);
      setCurrentHash(data.computedHash);
      setVerificationResult(data.verified ? 'MATCH' : 'NO_MATCH');
      setVerificationTimestamp(new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC');
      setVerifierName(`${currentUser.name} (${currentUser.role})`);
    } catch {
      setErrorNotice('Unable to reach forensic backend server for SHA-256 verification.');
    } finally {
      setIsVerifying(false);
    }
  };

  const copyToClipboard = (text: string, isOriginal: boolean) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    if (isOriginal) {
      setCopiedOriginal(true);
      setTimeout(() => setCopiedOriginal(false), 2000);
    } else {
      setCopiedCurrent(true);
      setTimeout(() => setCopiedCurrent(false), 2000);
    }
  };

  return (
    <div id="hash-integrity-screen" className="p-4 sm:p-6 space-y-6 bg-[#F4F8F6] min-h-full text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-900/10 pb-5">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('evidence')} label="Back to Evidence" variant="pill" />
          </div>
          <div className="flex items-center space-x-2.5 flex-wrap gap-y-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center space-x-2 font-sans">
              <Hash className="w-6 h-6 text-emerald-700" />
              <span>Cryptographic Hash Integrity Verification</span>
            </h1>
            <span className="text-xs font-mono font-bold text-emerald-900 bg-emerald-100 border border-emerald-300 px-3 py-1 rounded-full shadow-xs">
              FRE 902(13)/(14) SELF-AUTHENTICATING
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real server-backed SHA-256 bitstream verification establishing byte-for-byte immutability
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => setCurrentScreen('chain-of-custody')}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-900/20 transition-all flex items-center space-x-1.5 cursor-pointer"
          >
            <span>View Chain of Custody →</span>
          </button>
        </div>
      </div>

      {errorNotice && (
        <div className="p-3.5 bg-[#FEF2F2] border border-[#B91C1C]/30 text-[#B91C1C] text-xs rounded-2xl flex items-center space-x-2 font-medium">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorNotice}</span>
        </div>
      )}

      {/* Feature Explanation Banner */}
      <div className="bg-white border border-emerald-900/10 rounded-2xl p-5 shadow-sm space-y-2">
        <div className="flex items-center space-x-2 text-emerald-900 font-bold text-sm">
          <Info className="w-4 h-4 text-emerald-700 shrink-0" />
          <span>What is Cryptographic Hash Integrity in Digital Forensics?</span>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed">
          When digital audio evidence is first ingested into the forensic repository, a unique <strong>256-bit SHA-256 cryptographic digest</strong> is mathematically computed from its raw binary content. Upload any suspected duplicate copy below or trigger an enclave stored-bitstream re-hash to verify bit-level fidelity.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 text-xs">
          <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl flex items-start space-x-2 text-emerald-950">
            <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <strong className="block font-bold">Match (Identical Checksums)</strong>
              <span className="text-slate-600">The evidence file has not been altered, truncated, or modified in any way since initial collection.</span>
            </div>
          </div>
          <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl flex items-start space-x-2 text-rose-950">
            <ShieldAlert className="w-4 h-4 text-rose-700 shrink-0 mt-0.5" />
            <div>
              <strong className="block font-bold">No Match (Checksum Mismatch)</strong>
              <span className="text-slate-600">Downstream AI pipelines are blocked until tampering or corruption is investigated and resolved.</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 max-w-5xl mx-auto">
        {/* Left Column: Evidence File & Live Checksum Computation */}
        <div className="lg:col-span-6 bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-5 shadow-sm">
          <h2 className="text-sm font-bold uppercase tracking-wider text-emerald-950 border-b border-slate-100 pb-3 flex items-center justify-between">
            <span>1. Current Evidence Audio File</span>
            <FileCheck className="w-4 h-4 text-emerald-700" />
          </h2>

          <div className="space-y-3">
            {caseEvidenceList.length > 1 && setActiveEvidence && (
              <div>
                <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                  Switch Docket Exhibit
                </label>
                <select
                  value={activeEvidence.id}
                  onChange={(e) => {
                    const nextEv = caseEvidenceList.find((ev) => ev.id === e.target.value);
                    if (nextEv) setActiveEvidence(nextEv);
                  }}
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 cursor-pointer"
                >
                  {caseEvidenceList.map((ev) => (
                    <option key={ev.id} value={ev.id}>
                      {ev.id} — {ev.filename} ({ev.status})
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-bold uppercase text-[10px]">Evidence ID</span>
                <span className="font-mono font-bold text-emerald-900">
                  {hasActiveEvidence ? activeEvidence.id : 'NONE SELECTED'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-bold uppercase text-[10px]">File Name</span>
                <span className="font-bold text-slate-900">{selectedFileName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-bold uppercase text-[10px]">File Size</span>
                <span className="font-mono text-slate-700">{activeEvidence.fileSize || 'N/A'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-bold uppercase text-[10px]">Ingestion Timestamp</span>
                <span className="font-mono text-slate-700">{activeEvidence.uploadTimestamp || 'N/A'}</span>
              </div>
            </div>

            {/* Dropzone for candidate file check */}
            <div className="border-2 border-dashed border-emerald-300 hover:border-emerald-600 bg-emerald-50/40 rounded-xl p-5 text-center space-y-2 relative transition-all cursor-pointer">
              <Upload className="w-6 h-6 text-emerald-700 mx-auto" />
              <div>
                <p className="text-xs font-bold text-slate-900">Upload candidate file to verify against sealed SHA-256</p>
                <p className="text-[10px] text-slate-500">Audited server-side via POST /api/evidence/verify-hash</p>
              </div>
              <input
                type="file"
                disabled={!hasActiveEvidence || isVerifying}
                onChange={(e) => e.target.files?.[0] && handleFileChange(e.target.files[0])}
                className="absolute inset-0 opacity-0 cursor-pointer disabled:cursor-not-allowed"
              />
            </div>

            <button
              onClick={handleRecomputeHash}
              disabled={!hasActiveEvidence || isVerifying}
              className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-900/20 flex items-center justify-center space-x-2 transition-all cursor-pointer"
            >
              {isVerifying ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Verifying Stored Bitstream...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Re-Verify Stored Enclave Bitstream (SHA-256)</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Comparative Hash Audit */}
        <div className="lg:col-span-6 bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-5 shadow-sm">
          <h2 className="text-sm font-bold uppercase tracking-wider text-emerald-950 border-b border-slate-100 pb-3 flex items-center justify-between">
            <span>2. Hash Comparison & Audit Result</span>
            <Lock className="w-4 h-4 text-emerald-700" />
          </h2>

          <div className="space-y-4 text-xs">
            {/* Original Stored Hash */}
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-slate-500 font-bold uppercase">
                  Original Ingestion SHA-256 Hash
                </span>
                {originalHash && (
                  <button
                    onClick={() => copyToClipboard(originalHash, true)}
                    className="text-[10px] text-emerald-700 hover:text-emerald-900 font-bold flex items-center space-x-1 cursor-pointer"
                  >
                    {copiedOriginal ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedOriginal ? 'Copied' : 'Copy'}</span>
                  </button>
                )}
              </div>
              <div className="p-2.5 bg-[#032319] border border-emerald-950/20 rounded-xl font-mono text-[11px] text-emerald-300 break-all leading-tight shadow-inner">
                {originalHash || 'Unavailable — select or ingest an evidence audio exhibit first.'}
              </div>
            </div>

            {/* Current Computed Hash */}
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-slate-500 font-bold uppercase">
                  Verified / Candidate SHA-256 Hash
                </span>
                {currentHash && (
                  <button
                    onClick={() => copyToClipboard(currentHash, false)}
                    className="text-[10px] text-emerald-700 hover:text-emerald-900 font-bold flex items-center space-x-1 cursor-pointer"
                  >
                    {copiedCurrent ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedCurrent ? 'Copied' : 'Copy'}</span>
                  </button>
                )}
              </div>
              <div
                className={`p-2.5 rounded-xl font-mono text-[11px] break-all leading-tight shadow-inner border ${
                  verificationResult === 'NO_MATCH'
                    ? 'bg-rose-950 border-rose-700 text-rose-200'
                    : 'bg-[#032319] border-emerald-950/20 text-emerald-300'
                }`}
              >
                {currentHash || 'Awaiting verification execution.'}
              </div>
            </div>

            {/* Status Card: Match vs No Match vs Awaiting Verification vs No Exhibit */}
            {verificationResult === 'MATCH' ? (
              <div className="p-4 bg-emerald-50 border-2 border-emerald-400 rounded-xl space-y-2 text-emerald-950">
                <div className="flex items-center space-x-2 font-bold text-sm">
                  <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" />
                  <span>MATCH: EVIDENCE HAS NOT BEEN ALTERED</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Cryptographic verification confirms 100% bit-level fidelity with the initial ingestion repository.
                </p>
              </div>
            ) : verificationResult === 'NO_MATCH' ? (
              <div className="p-4 bg-rose-50 border-2 border-rose-400 rounded-xl space-y-2 text-rose-950">
                <div className="flex items-center space-x-2 font-bold text-sm text-rose-900">
                  <AlertOctagon className="w-5 h-5 text-rose-700 shrink-0" />
                  <span>NO MATCH: EVIDENCE TAMPERED OR CORRUPTED</span>
                </div>
                <p className="text-xs text-rose-800 leading-relaxed">
                  Alert: Candidate bitstream hash deviates from the baseline ingestion digest. Evidence status flagged as Failed and logged to Chain of Custody.
                </p>
              </div>
            ) : hasActiveEvidence ? (
              <div className="p-4 bg-[#FEF3C7]/40 border border-[#C88A2C]/40 rounded-xl space-y-2 text-slate-800">
                <div className="flex items-center space-x-2 font-bold text-sm text-[#B2751E]">
                  <Info className="w-5 h-5 shrink-0" />
                  <span>AWAITING EXPLICIT CRYPTOGRAPHIC VERIFICATION</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Exhibit <strong>{activeEvidence.id}</strong> has an ingestion SHA-256 seal ({activeEvidence.status}), but explicit re-verification has not yet been executed in this workflow. Click <strong>Re-Verify Stored Enclave Bitstream</strong> or upload a candidate copy on the left.
                </p>
              </div>
            ) : (
              <div className="p-4 bg-[#FEF3C7]/40 border border-[#C88A2C]/30 rounded-xl space-y-2 text-slate-800">
                <div className="flex items-center space-x-2 font-bold text-sm text-[#B2751E]">
                  <Info className="w-5 h-5 shrink-0" />
                  <span>NO ACTIVE EXHIBIT SELECTED</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Ingest or select an evidence item in the Evidence Locker to verify cryptographic hashes against the server baseline.
                </p>
              </div>
            )}

            {/* Audit Log Metadata Footer */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5 text-[11px]">
              <div className="flex justify-between items-center">
                <span className="text-slate-500 flex items-center space-x-1">
                  <Clock className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Verification Date & Time:</span>
                </span>
                <span className="font-mono font-bold text-slate-800">{verificationTimestamp || '—'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 flex items-center space-x-1">
                  <UserIcon className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Verified By:</span>
                </span>
                <span className="font-bold text-slate-800">{verifierName}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
