import React, { useState, useEffect, useCallback } from 'react';
import {
  FileSpreadsheet,
  Download,
  Search,
  CheckCircle2,
  Check,
  RefreshCw,
  AlertCircle,
  AlertOctagon
} from 'lucide-react';
import { ScreenId, User, AuditLogEntry } from '../../types';
import { BackButton } from '../common/BackButton';
import { authFetch } from '../../utils/api';

interface AuditLogScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  currentUser: User;
}

export function sanitizeCsvCell(val: unknown): string {
  const str = String(val ?? '');
  const trimmedStart = str.replace(/^\s+/, '');
  const neutralized =
    /^[=+\-@\t\r]/.test(str) || /^[=+\-@]/.test(trimmedStart) ? `'${str}` : str;
  return `"${neutralized.replace(/"/g, '""')}"`;
}

export const AuditLogScreen: React.FC<AuditLogScreenProps> = ({ setCurrentScreen }) => {
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('ALL');
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);

  const loadAuditLogs = useCallback(async () => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await authFetch('/api/audit-logs');
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        setErrorMsg(data?.error || `Failed to load audit trail (${res.status}).`);
        return;
      }
      const list = await res.json();
      setLogs(Array.isArray(list) ? list : []);
    } catch {
      setErrorMsg('Unable to synchronize audit trail from forensic enclave.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAuditLogs();
  }, [loadAuditLogs]);

  const filteredLogs = logs.filter((l) => {
    const q = searchTerm.toLowerCase();
    const matchesSearch =
      !q ||
      (l.user || '').toLowerCase().includes(q) ||
      (l.role || '').toLowerCase().includes(q) ||
      (l.resource || '').toLowerCase().includes(q) ||
      (l.details || '').toLowerCase().includes(q) ||
      (l.ipAddress || '').includes(q);
    const matchesAction = actionFilter === 'ALL' ? true : l.action === actionFilter;
    return matchesSearch && matchesAction;
  });

  const getActionBadge = (action: string) => {
    switch (action) {
      case 'VIEW': return 'bg-sky-50 text-sky-800 border-sky-200';
      case 'WRITE': return 'bg-emerald-50 text-emerald-800 border-emerald-200';
      case 'SIGN': return 'bg-purple-50 text-purple-800 border-purple-200';
      case 'UPLOAD': return 'bg-teal-50 text-teal-800 border-teal-200';
      case 'VERIFY': return 'bg-indigo-50 text-indigo-800 border-indigo-200';
      case 'LOGIN': return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'CONFIG': return 'bg-emerald-100 text-emerald-900 border-emerald-300';
      case 'DELETE': return 'bg-rose-50 text-rose-800 border-rose-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  // Real CSV Export with Formula-Injection Sanitization
  const handleExportCSV = () => {
    setIsExporting(true);

    const headers = [
      'Log ID',
      'Timestamp (UTC)',
      'Operator Email',
      'Role',
      'Action Performed',
      'Resource Target',
      'Details',
      'IP Address',
      'Status'
    ];

    const rows = filteredLogs.map((log) => [
      sanitizeCsvCell(log.id),
      sanitizeCsvCell(log.timestamp),
      sanitizeCsvCell(log.user),
      sanitizeCsvCell(log.role || 'Authorized Operator'),
      sanitizeCsvCell(log.action),
      sanitizeCsvCell(log.resource),
      sanitizeCsvCell(log.details || ''),
      sanitizeCsvCell(log.ipAddress),
      sanitizeCsvCell(log.status)
    ]);

    const csvContent = [headers.map(sanitizeCsvCell).join(','), ...rows.map((r) => r.join(','))].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `ALFADETECT_Audit_Log_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setIsExporting(false);
    setExportSuccess(true);
    setTimeout(() => setExportSuccess(false), 3000);
  };

  return (
    <div id="audit-log-screen" className="p-4 sm:p-6 space-y-6 bg-[#F4F8F6] min-h-full text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-900/10 pb-5">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('dashboard')} label="Back to Dashboard" variant="pill" />
          </div>
          <div className="flex items-center space-x-2.5 flex-wrap gap-y-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center space-x-2 font-sans">
              <FileSpreadsheet className="w-6 h-6 text-emerald-700" />
              <span>Immutable Security Audit Log</span>
            </h1>
            <span className="text-xs font-mono font-bold text-emerald-900 bg-emerald-100 border border-emerald-300 px-3 py-1 rounded-full shadow-xs">
              ISO/IEC 27037 APPEND-ONLY
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Live tamper-evident activity trail synchronized from backend enclave ({logs.length} persisted events)
          </p>
        </div>

        <div className="flex items-center space-x-2 self-start sm:self-auto">
          <button
            onClick={loadAuditLogs}
            disabled={isLoading}
            className="px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl flex items-center space-x-1.5 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          <button
            onClick={handleExportCSV}
            disabled={isExporting || filteredLogs.length === 0}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center space-x-2 shadow-md shadow-emerald-900/20 transition-all cursor-pointer"
          >
            {exportSuccess ? (
              <>
                <Check className="w-4 h-4 text-emerald-200" />
                <span>CSV Exported Safely!</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Export Audit Log (CSV)</span>
              </>
            )}
          </button>
        </div>
      </div>

      {errorMsg && (
        <div className="p-3.5 bg-[#FEF2F2] border border-[#B91C1C]/30 text-[#B91C1C] text-xs rounded-2xl flex items-center space-x-2 font-medium">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Filter Toolbar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-white border border-emerald-900/10 p-3 rounded-2xl shadow-sm">
        <div className="flex items-center space-x-1 overflow-x-auto w-full md:w-auto">
          {['ALL', 'VIEW', 'WRITE', 'SIGN', 'UPLOAD', 'VERIFY', 'LOGIN', 'CONFIG', 'DELETE'].map((act) => (
            <button
              key={act}
              onClick={() => setActionFilter(act)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                actionFilter === act
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {act}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search operator, role, IP, or resource..."
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-emerald-600 shadow-xs"
          />
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-emerald-50/80 text-emerald-950 uppercase text-[10px] tracking-wider border-b border-emerald-900/10 font-bold">
              <tr>
                <th className="py-3 px-4">Log ID</th>
                <th className="py-3 px-4">Timestamp (UTC)</th>
                <th className="py-3 px-4">Operator & Role</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">Resource & Details</th>
                <th className="py-3 px-4">Source IP</th>
                <th className="py-3 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-slate-500">
                    {isLoading ? 'Synchronizing persisted audit records...' : 'No audit log entries match the current filter.'}
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-emerald-50/40 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-emerald-900 whitespace-nowrap">{log.id}</td>
                    <td className="py-3.5 px-4 font-mono text-slate-600 text-[11px] whitespace-nowrap">{log.timestamp}</td>
                    <td className="py-3.5 px-4">
                      <span className="font-bold text-slate-900 block">{log.user}</span>
                      <span className="text-[10px] text-slate-500">{log.role || 'System / Authorized Operator'}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-md border ${getActionBadge(
                          log.action
                        )}`}
                      >
                        {log.action}
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-semibold text-slate-800 block">{log.resource}</span>
                      {log.details && <span className="text-[10px] font-mono text-slate-500">{log.details}</span>}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-700 text-[11px]">{log.ipAddress}</td>
                    <td className="py-3.5 px-4 text-right">
                      <span
                        className={`text-[10px] font-bold px-2.5 py-1 rounded-full border inline-flex items-center space-x-1 ${
                          log.status === 'SUCCESS'
                            ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                            : 'bg-rose-100 text-rose-900 border-rose-300'
                        }`}
                      >
                        {log.status === 'SUCCESS' ? (
                          <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                        ) : (
                          <AlertOctagon className="w-3 h-3 text-rose-700" />
                        )}
                        <span>{log.status}</span>
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
