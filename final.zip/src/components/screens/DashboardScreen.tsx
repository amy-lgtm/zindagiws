import React, { useState, useEffect } from 'react';
import {
  FolderKanban,
  Activity,
  AlertTriangle,
  CheckCircle2,
  FileText,
  ShieldCheck,
  Plus,
  Upload,
  Clock,
  Shield,
  Lock,
  Eye,
  Layers,
  Sparkles,
  Inbox,
  Users,
  Cpu,
  FileCheck2,
  Scale,
  RefreshCw,
  ArrowRight,
  Hash,
  AlertCircle
} from 'lucide-react';
import { ScreenId, Case, User, UserRole } from '../../types';
import {
  canCreateCases,
  canUploadEvidence,
  canRunAiAnalysis,
  canManageUsers,
  isReadOnlyForensics,
  ROLE_CONFIGS
} from '../../utils/rbac';
import { authFetch } from '../../utils/api';

interface DashboardScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  setSelectedCaseId: (id: string) => void;
  cases: Case[];
  currentUser: User;
  onOpenNewCaseModal: () => void;
}

interface DashboardStats {
  totalCases: number;
  activeCases: number;
  deepfakeDetected: number;
  authenticAudio: number;
  reportsGenerated: number;
  evidenceVerified: number;
}

interface ModelStatusItem {
  name: string;
  status: 'AVAILABLE' | 'NOT_CONFIGURED';
  type: string;
  description: string;
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({
  setCurrentScreen,
  setSelectedCaseId,
  cases,
  currentUser,
  onOpenNewCaseModal
}) => {
  const roleConfig = ROLE_CONFIGS[currentUser.role] || ROLE_CONFIGS['Lead Forensic Analyst'];
  const userCanCreate = canCreateCases(currentUser.role);
  const userCanUpload = canUploadEvidence(currentUser.role);
  const userCanAnalyze = canRunAiAnalysis(currentUser.role);
  const userCanManageUsers = canManageUsers(currentUser.role);
  const isReadOnly = isReadOnlyForensics(currentUser.role);

  const [stats, setStats] = useState<DashboardStats>({
    totalCases: cases.length,
    activeCases: cases.filter((c) => c.status === 'Active' || c.status === 'Under Review').length,
    deepfakeDetected: cases.filter((c) => c.verdict === 'DEEPFAKE').length,
    authenticAudio: cases.filter((c) => c.verdict === 'AUTHENTIC').length,
    reportsGenerated: 0,
    evidenceVerified: 0
  });

  const [recentAudit, setRecentAudit] = useState<
    Array<{ id: string; timestamp: string; user: string; action: string; resource: string; status: string }>
  >([]);
  const [modelsStatus, setModelsStatus] = useState<Record<string, ModelStatusItem> | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);

  useEffect(() => {
    async function loadDashboardData() {
      setIsLoading(true);
      setConnectionError(null);

      try {
        // 1. Fetch real stats
        const statsRes = await authFetch('/api/dashboard/stats');
        if (statsRes.ok) {
          const statsData = await statsRes.json();
          setStats(statsData);
        }

        // 2. Fetch real model statuses
        const modelsRes = await authFetch('/api/ai/models-status');
        if (modelsRes.ok) {
          const modelsData = await modelsRes.json();
          setModelsStatus(modelsData);
        }

        // 3. Fetch real audit logs if user has role clearance
        if (currentUser.role === 'System Security Administrator' || currentUser.role === 'Lead Forensic Analyst') {
          const auditRes = await authFetch('/api/audit-logs');
          if (auditRes.ok) {
            const auditData = await auditRes.json();
            if (Array.isArray(auditData)) {
              setRecentAudit(auditData.slice(0, 5));
            }
          }
        }
      } catch {
        setConnectionError('Forensic backend service unreachable. Showing current in-memory workspace state.');
      } finally {
        setIsLoading(false);
      }
    }

    loadDashboardData();
  }, [cases, currentUser.role]);

  return (
    <div id="dashboard-screen" className="p-6 space-y-6 bg-[#F8FAF9] min-h-full text-[#112217]">
      {/* Top Welcome / Header Area */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E1EBE4] pb-5">
        <div>
          <div className="flex items-center space-x-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-[#112217] font-serif-title">
              Forensic Enclave Dashboard
            </h1>
            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full border bg-[#FEF3C7] text-[#B2751E] border-[#C88A2C]/30 font-mono">
              {roleConfig.shortLabel}
            </span>
          </div>
          <p className="text-xs text-[#54665C] mt-1">
            Operator: <strong className="text-[#112217]">{currentUser.name}</strong> · Agency: <strong className="text-[#112217]">{currentUser.agency || 'National Forensics Institute'}</strong>
          </p>
        </div>

        {/* Action Shortcuts */}
        <div className="flex items-center space-x-2.5 flex-wrap">
          {userCanCreate && (
            <button
              onClick={onOpenNewCaseModal}
              className="px-3.5 py-2 bg-[#0A3D24] hover:bg-[#062817] text-white text-xs font-bold rounded-xl flex items-center space-x-1.5 shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>New Docket</span>
            </button>
          )}

          {userCanUpload && (
            <button
              onClick={() => setCurrentScreen('evidence')}
              className="px-3.5 py-2 bg-white hover:bg-[#F0FDF4] border border-[#E1EBE4] text-[#0A3D24] text-xs font-bold rounded-xl flex items-center space-x-1.5 shadow-xs transition-colors cursor-pointer"
            >
              <Upload className="w-4 h-4 text-[#0A3D24]" />
              <span>Ingest Evidence</span>
            </button>
          )}

          <button
            onClick={() => setCurrentScreen('hash-integrity')}
            className="px-3.5 py-2 bg-white hover:bg-slate-50 border border-[#E1EBE4] text-[#54665C] text-xs font-bold rounded-xl flex items-center space-x-1.5 transition-colors cursor-pointer"
          >
            <Hash className="w-4 h-4 text-[#54665C]" />
            <span>Verify Hash</span>
          </button>
        </div>
      </div>

      {connectionError && (
        <div className="p-3.5 bg-[#FEF3C7] border border-[#C88A2C]/30 text-[#B2751E] rounded-2xl text-xs flex items-center space-x-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{connectionError}</span>
        </div>
      )}

      {/* Real Metric Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-[#E1EBE4] rounded-2xl p-4 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-[#54665C]">
            <span className="text-[11px] font-bold uppercase tracking-wider">Total Case Dockets</span>
            <FolderKanban className="w-4 h-4 text-[#0A3D24]" />
          </div>
          <p className="text-2xl font-bold text-[#112217] font-serif-title">{stats.totalCases}</p>
          <p className="text-[11px] text-[#54665C]">{stats.activeCases} actively under examination</p>
        </div>

        <div className="bg-white border border-[#E1EBE4] rounded-2xl p-4 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-[#54665C]">
            <span className="text-[11px] font-bold uppercase tracking-wider">Verified Deepfakes</span>
            <AlertTriangle className="w-4 h-4 text-[#B91C1C]" />
          </div>
          <p className="text-2xl font-bold text-[#B91C1C] font-serif-title">{stats.deepfakeDetected}</p>
          <p className="text-[11px] text-[#54665C]">Flagged with acoustic vocoder anomalies</p>
        </div>

        <div className="bg-white border border-[#E1EBE4] rounded-2xl p-4 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-[#54665C]">
            <span className="text-[11px] font-bold uppercase tracking-wider">Authentic Exemplars</span>
            <CheckCircle2 className="w-4 h-4 text-[#15803D]" />
          </div>
          <p className="text-2xl font-bold text-[#15803D] font-serif-title">{stats.authenticAudio}</p>
          <p className="text-[11px] text-[#54665C]">Consistent with natural human phonation</p>
        </div>

        <div className="bg-white border border-[#E1EBE4] rounded-2xl p-4 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-[#54665C]">
            <span className="text-[11px] font-bold uppercase tracking-wider">Custody Integrity</span>
            <ShieldCheck className="w-4 h-4 text-[#0A3D24]" />
          </div>
          <p className="text-2xl font-bold text-[#0A3D24] font-serif-title">SHA-256</p>
          <p className="text-[11px] text-[#54665C]">Bitstream hash seal active</p>
        </div>
      </div>

      {/* Role-Specific Operational Workspace Banner */}
      <div className="bg-white border border-[#E1EBE4] rounded-3xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-3">
          <div className="flex items-center space-x-2">
            <Shield className="w-4 h-4 text-[#0A3D24]" />
            <h2 className="text-sm font-bold text-[#112217] uppercase tracking-wider font-serif-title">
              {currentUser.role} Workspace
            </h2>
          </div>
          <span className="text-[11px] font-mono text-[#54665C]">
            {isReadOnly ? 'Read-Only Legal Clearance' : 'Active Forensic Clearance'}
          </span>
        </div>

        {/* Dynamic content tailored to user's assigned role */}
        {currentUser.role === 'Lead Forensic Analyst' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div
              onClick={() => setCurrentScreen('cases')}
              className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2 hover:border-[#0A3D24] cursor-pointer transition-colors"
            >
              <div className="flex items-center space-x-2 text-[#0A3D24] font-bold">
                <FolderKanban className="w-4 h-4" />
                <span>Case Docket Management</span>
              </div>
              <p className="text-[#54665C]">Create, assign, and organize multi-exhibit criminal investigation dockets.</p>
              <span className="text-[11px] font-bold text-[#0A3D24] block pt-1">Open Dockets →</span>
            </div>

            <div
              onClick={() => setCurrentScreen('evidence')}
              className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2 hover:border-[#0A3D24] cursor-pointer transition-colors"
            >
              <div className="flex items-center space-x-2 text-[#0A3D24] font-bold">
                <Upload className="w-4 h-4" />
                <span>Evidence Locker & Ingestion</span>
              </div>
              <p className="text-[#54665C]">Upload disputed audio voice notes with automatic SHA-256 bitstream sealing.</p>
              <span className="text-[11px] font-bold text-[#0A3D24] block pt-1">Upload Evidence →</span>
            </div>

            <div
              onClick={() => setCurrentScreen('report-generation')}
              className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2 hover:border-[#0A3D24] cursor-pointer transition-colors"
            >
              <div className="flex items-center space-x-2 text-[#0A3D24] font-bold">
                <FileCheck2 className="w-4 h-4" />
                <span>Court-Ready Forensic Reports</span>
              </div>
              <p className="text-[#54665C]">Compile and cryptographically sign self-authenticating reports for trial submission.</p>
              <span className="text-[11px] font-bold text-[#0A3D24] block pt-1">Generate Report →</span>
            </div>
          </div>
        )}

        {currentUser.role === 'Forensic Examiner / Expert Witness' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div
              onClick={() => setCurrentScreen('pipeline')}
              className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2 hover:border-[#0A3D24] cursor-pointer transition-colors"
            >
              <div className="flex items-center space-x-2 text-[#0A3D24] font-bold">
                <Cpu className="w-4 h-4" />
                <span>Acoustic Signal Processing</span>
              </div>
              <p className="text-[#54665C]">Inspect F0 pitch contours, micro-jitter, and harmonic-to-noise ratios.</p>
              <span className="text-[11px] font-bold text-[#0A3D24] block pt-1">Execute Pipeline →</span>
            </div>

            <div
              onClick={() => setCurrentScreen('speaker-verification')}
              className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2 hover:border-[#0A3D24] cursor-pointer transition-colors"
            >
              <div className="flex items-center space-x-2 text-[#0A3D24] font-bold">
                <Users className="w-4 h-4" />
                <span>Speaker Verification Workspace</span>
              </div>
              <p className="text-[#54665C]">Compare questioned audio with enrolled reference exemplars with synthetic caveats.</p>
              <span className="text-[11px] font-bold text-[#0A3D24] block pt-1">Compare Speakers →</span>
            </div>

            <div
              onClick={() => setCurrentScreen('expert-validation')}
              className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2 hover:border-[#0A3D24] cursor-pointer transition-colors"
            >
              <div className="flex items-center space-x-2 text-[#0A3D24] font-bold">
                <FileCheck2 className="w-4 h-4" />
                <span>Expert Witness Affidavits</span>
              </div>
              <p className="text-[#54665C]">Submit sworn technical assessments and SWGDE checklist attestations.</p>
              <span className="text-[11px] font-bold text-[#0A3D24] block pt-1">Review Affidavits →</span>
            </div>
          </div>
        )}

        {currentUser.role === 'Prosecutor / Legal Reviewer' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div
              onClick={() => setCurrentScreen('cases')}
              className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2 hover:border-[#0A3D24] cursor-pointer transition-colors"
            >
              <div className="flex items-center space-x-2 text-[#0A3D24] font-bold">
                <FolderKanban className="w-4 h-4" />
                <span>Legal Docket Inspection</span>
              </div>
              <p className="text-[#54665C]">Inspect authenticated evidence files and forensic examination conclusions.</p>
              <span className="text-[11px] font-bold text-[#0A3D24] block pt-1">Inspect Dockets →</span>
            </div>

            <div
              onClick={() => setCurrentScreen('chain-of-custody')}
              className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2 hover:border-[#0A3D24] cursor-pointer transition-colors"
            >
              <div className="flex items-center space-x-2 text-[#0A3D24] font-bold">
                <ShieldCheck className="w-4 h-4" />
                <span>Chain of Custody Audit</span>
              </div>
              <p className="text-[#54665C]">Verify immutable custodial history and examiner digital signatures.</p>
              <span className="text-[11px] font-bold text-[#0A3D24] block pt-1">Audit Custody →</span>
            </div>

            <div
              onClick={() => setCurrentScreen('legal-review')}
              className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2 hover:border-[#0A3D24] cursor-pointer transition-colors"
            >
              <div className="flex items-center space-x-2 text-[#0A3D24] font-bold">
                <Scale className="w-4 h-4" />
                <span>Daubert / Frye Admissibility</span>
              </div>
              <p className="text-[#54665C]">Certify compliance with procedural evidence standards prior to trial presentation.</p>
              <span className="text-[11px] font-bold text-[#0A3D24] block pt-1">Review Checklist →</span>
            </div>
          </div>
        )}

        {currentUser.role === 'System Security Administrator' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div
              onClick={() => setCurrentScreen('admin-panel')}
              className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2 hover:border-[#0A3D24] cursor-pointer transition-colors"
            >
              <div className="flex items-center space-x-2 text-[#0A3D24] font-bold">
                <Users className="w-4 h-4" />
                <span>Operator Account Provisioning</span>
              </div>
              <p className="text-[#54665C]">Manage examiner accounts, review registration applications, and enforce role clearance.</p>
              <span className="text-[11px] font-bold text-[#0A3D24] block pt-1">Manage Operators →</span>
            </div>

            <div
              onClick={() => setCurrentScreen('audit-log')}
              className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2 hover:border-[#0A3D24] cursor-pointer transition-colors"
            >
              <div className="flex items-center space-x-2 text-[#0A3D24] font-bold">
                <Clock className="w-4 h-4" />
                <span>Platform Security Audit Log</span>
              </div>
              <p className="text-[#54665C]">Inspect timestamped enclave records for all logins, uploads, and signatures.</p>
              <span className="text-[11px] font-bold text-[#0A3D24] block pt-1">View Audit Trail →</span>
            </div>

            <div
              onClick={() => setCurrentScreen('pending-approval')}
              className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2 hover:border-[#0A3D24] cursor-pointer transition-colors"
            >
              <div className="flex items-center space-x-2 text-[#0A3D24] font-bold">
                <ShieldCheck className="w-4 h-4" />
                <span>Clearance Approval Status</span>
              </div>
              <p className="text-[#54665C]">Inspect status resolution states for pending and suspended operator accounts.</p>
              <span className="text-[11px] font-bold text-[#0A3D24] block pt-1">Check Status UI →</span>
            </div>
          </div>
        )}
      </div>

      {/* Two Column Layout: Model Integration Status & Real Case Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Honest AI & DSP Engine Status */}
        <div className="lg:col-span-5 bg-white border border-[#E1EBE4] rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-3">
            <div className="flex items-center space-x-2">
              <Cpu className="w-4 h-4 text-[#0A3D24]" />
              <h2 className="text-sm font-bold text-[#112217] font-serif-title">
                Model Integration Enclave Status
              </h2>
            </div>
            <span className="text-[10px] font-mono text-[#54665C]">Runtime Inspection</span>
          </div>

          <p className="text-xs text-[#54665C] leading-relaxed">
            Forensic analysis models are verified server-side. Unconfigured neural weights are honestly reported below to prevent deceptive automated verdicts.
          </p>

          <div className="space-y-2.5 text-xs">
            {modelsStatus ? (
              (Object.entries(modelsStatus) as [string, ModelStatusItem][]).map(([key, item]) => {
                const isOnline = item.status === 'AVAILABLE';
                return (
                  <div key={key} className="p-3 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#112217]">{item.name}</span>
                      <span
                        className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded border ${
                          isOnline
                            ? 'bg-[#F0FDF4] text-[#15803D] border-[#15803D]/30'
                            : 'bg-amber-50 text-amber-800 border-amber-300'
                        }`}
                      >
                        {isOnline ? 'ONLINE' : 'AWAITING WEIGHTS'}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#54665C] leading-snug">{item.description}</p>
                  </div>
                );
              })
            ) : (
              <div className="p-4 text-center text-xs text-[#54665C] bg-[#F8FAF9] rounded-xl border border-[#E1EBE4]">
                <span>Loading model runtime status...</span>
              </div>
            )}
          </div>
        </div>

        {/* Right: Active Cases Overview & Empty States */}
        <div className="lg:col-span-7 bg-white border border-[#E1EBE4] rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-3">
            <div className="flex items-center space-x-2">
              <FolderKanban className="w-4 h-4 text-[#0A3D24]" />
              <h2 className="text-sm font-bold text-[#112217] font-serif-title">
                Active Case Dockets ({cases.length})
              </h2>
            </div>
            <button
              onClick={() => setCurrentScreen('cases')}
              className="text-xs font-semibold text-[#0A3D24] hover:text-[#062817] cursor-pointer"
            >
              View All Cases →
            </button>
          </div>

          {cases.length === 0 ? (
            <div className="p-8 text-center bg-[#F8FAF9] rounded-2xl border border-[#E1EBE4] space-y-3">
              <Inbox className="w-8 h-8 text-[#54665C] mx-auto opacity-60" />
              <div className="space-y-1">
                <p className="font-bold text-sm text-[#112217]">No Case Dockets Initialized</p>
                <p className="text-xs text-[#54665C] max-w-sm mx-auto">
                  Your forensic workspace is clean. Create a new case docket to begin evidence ingestion, SHA-256 verification, and acoustic analysis.
                </p>
              </div>
              {userCanCreate && (
                <button
                  onClick={onOpenNewCaseModal}
                  className="px-4 py-2 bg-[#0A3D24] text-white font-bold text-xs rounded-xl shadow-xs hover:bg-[#062817] transition-colors cursor-pointer"
                >
                  Create First Docket
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-2.5">
              {cases.slice(0, 4).map((c) => (
                <div
                  key={c.id}
                  onClick={() => {
                    setSelectedCaseId(c.id);
                    setCurrentScreen('cases');
                  }}
                  className="p-3.5 bg-[#F8FAF9] border border-[#E1EBE4] hover:border-[#0A3D24] rounded-xl flex items-center justify-between transition-all cursor-pointer text-xs"
                >
                  <div className="space-y-0.5 truncate pr-3">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono font-bold text-[#0A3D24]">{c.id}</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-white border border-[#E1EBE4] text-[#54665C]">
                        {c.status}
                      </span>
                    </div>
                    <p className="font-bold text-[#112217] truncate">{c.title}</p>
                    <p className="text-[11px] text-[#54665C] truncate">
                      Analyst: {c.analyst} · Evidence: {c.evidenceCount} item(s)
                    </p>
                  </div>

                  <div className="text-right shrink-0">
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                        c.verdict === 'DEEPFAKE'
                          ? 'bg-[#FEF2F2] text-[#B91C1C] border-[#B91C1C]/30'
                          : c.verdict === 'AUTHENTIC'
                          ? 'bg-[#F0FDF4] text-[#15803D] border-[#15803D]/30'
                          : 'bg-slate-100 text-slate-700 border-slate-300'
                      }`}
                    >
                      {c.verdict}
                    </span>
                    <span className="text-[10px] text-[#54665C] block mt-1">{c.date}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Real Audit Activity Feed (If user is authorized to inspect audit logs) */}
      {(currentUser.role === 'System Security Administrator' || currentUser.role === 'Lead Forensic Analyst') && (
        <div className="bg-white border border-[#E1EBE4] rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-3">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-[#0A3D24]" />
              <h2 className="text-sm font-bold text-[#112217] font-serif-title">
                Recent Security Audit Events
              </h2>
            </div>
            <button
              onClick={() => setCurrentScreen('audit-log')}
              className="text-xs font-semibold text-[#0A3D24] hover:text-[#062817] cursor-pointer"
            >
              Full Audit Trail →
            </button>
          </div>

          {recentAudit.length === 0 ? (
            <p className="text-xs text-[#54665C] italic p-4 text-center bg-[#F8FAF9] rounded-xl border border-[#E1EBE4]">
              No security audit events recorded for current session.
            </p>
          ) : (
            <div className="divide-y divide-[#E1EBE4] text-xs">
              {recentAudit.map((log) => (
                <div key={log.id} className="py-2.5 flex items-center justify-between">
                  <div className="space-y-0.5 truncate pr-2">
                    <p className="font-semibold text-[#112217] truncate">{log.resource}</p>
                    <p className="text-[11px] text-[#54665C]">
                      Actor: <span className="font-mono">{log.user}</span> · Action: <span className="font-mono font-bold text-[#0A3D24]">{log.action}</span>
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-[10px] font-mono text-[#54665C]">{log.timestamp}</span>
                    <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-[#F0FDF4] text-[#15803D] border border-[#15803D]/20 block mt-0.5">
                      {log.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
