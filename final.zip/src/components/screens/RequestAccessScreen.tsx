import React, { useState, useEffect, useRef } from 'react';
import {
  Shield,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Award,
  UserCheck,
  Mail,
  RefreshCw,
  Lock,
  HardDrive,
  Info
} from 'lucide-react';
import { ScreenId, UserRole, ExpertReview, User } from '../../types';
import { playSuccessSound, playNotificationChime } from '../../utils/audioPlayer';
import { BackButton } from '../common/BackButton';
import { PasswordInput } from '../common/PasswordInput';

export interface RegistrationPanelProps {
  onSwitchToSignIn: (prefillEmail?: string, notice?: string) => void;
  onOpenPendingStatus: (email?: string) => void;
  onRegistrationSubmitted?: (email: string) => void;
  initialEmail?: string;
}

export const RegistrationPanel: React.FC<RegistrationPanelProps> = ({
  onSwitchToSignIn,
  onOpenPendingStatus,
  onRegistrationSubmitted,
  initialEmail = ''
}) => {
  const [regStep, setRegStep] = useState<'FORM' | 'VERIFY_OTP' | 'SUCCESS'>('FORM');

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState(initialEmail);
  const [agency, setAgency] = useState('');
  const [department, setDepartment] = useState('');
  const [role, setRole] = useState<UserRole>('Forensic Examiner / Expert Witness');
  const [certificationId, setCertificationId] = useState('');
  const [specialty, setSpecialty] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [_createdUser, setCreatedUser] = useState<User | null>(null);

  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [duplicateEmailConflict, setDuplicateEmailConflict] = useState(false);

  const [webAuthnSupported, setWebAuthnSupported] = useState<boolean>(false);
  const [hardwareKeyStatus, setHardwareKeyStatus] = useState<string>('Detecting hardware authenticator support...');

  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [otpTimer, setOtpTimer] = useState<number>(300);
  const [isOtpExpired, setIsOtpExpired] = useState<boolean>(false);
  const [resendCooldown, setResendCooldown] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [otpError, setOtpError] = useState<string | null>(null);

  const otpInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (initialEmail && !email) {
      setEmail(initialEmail);
    }
  }, [initialEmail]);

  useEffect(() => {
    if (typeof window !== 'undefined' && window.PublicKeyCredential) {
      PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()
        .then((available) => {
          setWebAuthnSupported(available);
          if (available) {
            setHardwareKeyStatus('Platform biometric / FIDO2 hardware authenticator available.');
          } else {
            setHardwareKeyStatus('Hardware platform authenticator unavailable. Standard cryptographic credentials will be used.');
          }
        })
        .catch(() => {
          setWebAuthnSupported(false);
          setHardwareKeyStatus('Hardware platform authenticator unavailable on this device.');
        });
    } else {
      setWebAuthnSupported(false);
      setHardwareKeyStatus('WebAuthn API not supported by this browser environment.');
    }
  }, []);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (regStep === 'VERIFY_OTP' && otpTimer > 0 && !isOtpExpired) {
      interval = setInterval(() => {
        setOtpTimer((prev) => {
          if (prev <= 1) {
            setIsOtpExpired(true);
            setOtpError('Verification code expired (5-minute security timeout). Please request a new code.');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [regStep, otpTimer, isOtpExpired]);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (resendCooldown > 0) {
      interval = setInterval(() => {
        setResendCooldown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [resendCooldown]);

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleInitiateRegistration = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setDuplicateEmailConflict(false);
    const errors: Record<string, string> = {};

    if (!firstName.trim()) errors.firstName = 'First name is required.';
    if (!lastName.trim()) errors.lastName = 'Last name is required.';

    const trimmedEmail = email.trim();
    if (!trimmedEmail) {
      errors.email = 'Official agency email is required.';
    } else if (!trimmedEmail.includes('@') || !trimmedEmail.includes('.')) {
      errors.email = 'Please enter a valid official institutional email address (e.g., examiner@agency.gov).';
    }

    if (!agency.trim()) errors.agency = 'Agency or forensic laboratory name is required.';

    const localPart = trimmedEmail.toLowerCase().split('@')[0];
    if (!password) {
      errors.password = 'Password is required.';
    } else if (
      password.length < 12 ||
      !/[A-Z]/.test(password) ||
      !/[a-z]/.test(password) ||
      !/\d/.test(password) ||
      !/[^A-Za-z0-9]/.test(password)
    ) {
      errors.password =
        'Password must be at least 12 characters with uppercase, lowercase, number, and special symbol.';
    } else if (localPart && localPart.length >= 3 && password.toLowerCase().includes(localPart)) {
      errors.password = 'Password must not contain your email username.';
    }

    if (password !== confirmPassword) {
      errors.confirmPassword = 'Passwords do not match.';
    }

    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      setFormError('Please resolve the highlighted field errors below.');
      return;
    }

    setFieldErrors({});
    const fullName = `${firstName} ${lastName}`.trim();
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: trimmedEmail,
          password,
          name: fullName,
          agency,
          department: department.trim() || undefined,
          role,
          certificationId: certificationId.trim() || undefined,
          specialty
        })
      });

      const data = await response.json().catch(() => null);
      setIsSubmitting(false);

      if (!response.ok) {
        if (response.status === 409) {
          setDuplicateEmailConflict(true);
          setFormError(
            data?.error || 'An account with this email address already exists. Please sign in instead.'
          );
        } else {
          setFormError(data?.error || 'Failed to submit registration request to the server.');
        }
        return;
      }

      if (data?.status === 'PENDING_ADMIN_APPROVAL') {
        if (data.user) {
          setCreatedUser(data.user);
        }
        if (onRegistrationSubmitted) {
          onRegistrationSubmitted(trimmedEmail);
        }
        playSuccessSound();
        setRegStep('SUCCESS');
        return;
      }

      if (data?.status === 'REGISTRATION_OTP_SENT') {
        setRegStep('VERIFY_OTP');
        setOtpDigits(['', '', '', '', '', '']);
        setOtpTimer(300);
        setIsOtpExpired(false);
        setResendCooldown(60);
        setOtpError(null);
        playNotificationChime();
        setTimeout(() => {
          otpInputRefs.current[0]?.focus();
        }, 200);
        return;
      }

      setFormError('Unexpected server response during registration processing.');
    } catch {
      setIsSubmitting(false);
      setFormError(
        'Authentication service unavailable: Could not establish a connection to the forensic backend server.'
      );
    }
  };

  const handleResendOtp = async () => {
    if (resendCooldown > 0) return;
    setIsSubmitting(true);
    setOtpError(null);

    try {
      const response = await fetch('/api/auth/resend-otp', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim() })
      });

      const data = await response.json().catch(() => null);
      setIsSubmitting(false);

      if (response.ok) {
        setOtpTimer(300);
        setIsOtpExpired(false);
        setResendCooldown(60);
        playNotificationChime();
      } else {
        setOtpError(data?.error || 'Failed to resend verification code.');
      }
    } catch {
      setIsSubmitting(false);
      setOtpError('Network error while resending verification code.');
    }
  };

  const handleOtpDigitChange = (index: number, value: string) => {
    if (isOtpExpired) return;
    const val = value.replace(/[^0-9]/g, '');
    const newDigits = [...otpDigits];
    newDigits[index] = val ? val.slice(-1) : '';
    setOtpDigits(newDigits);

    if (val && index < 5) {
      otpInputRefs.current[index + 1]?.focus();
    }

    if (index === 5 && val) {
      const fullCode = newDigits.join('');
      if (fullCode.length === 6) {
        executeVerifyRegistration(fullCode);
      }
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      otpInputRefs.current[index - 1]?.focus();
    }
  };

  const executeVerifyRegistration = async (codeToVerify?: string) => {
    const finalCode = codeToVerify || otpDigits.join('');

    if (isOtpExpired) {
      setOtpError('The 5-minute security window has expired. Please click "Resend Code".');
      return;
    }

    if (finalCode.length < 6) {
      setOtpError('Please enter all 6 digits of the verification code sent to your email.');
      return;
    }

    setOtpError(null);
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/auth/verify-registration', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim(),
          otp: finalCode
        })
      });

      const data = await response.json().catch(() => null);
      setIsSubmitting(false);

      if (!response.ok) {
        setOtpError(data?.error || 'Incorrect email verification code. Please check your inbox.');
        return;
      }

      playSuccessSound();
      if (data?.user) {
        setCreatedUser(data.user);
      }
      if (onRegistrationSubmitted) {
        onRegistrationSubmitted(email.trim());
      }
      setRegStep('SUCCESS');
    } catch {
      setIsSubmitting(false);
      setOtpError('Network error during registration verification. Please try again.');
    }
  };

  if (regStep === 'VERIFY_OTP') {
    return (
      <div className="space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-[#F0FDF4] border border-[#15803D]/30 flex items-center justify-center text-[#15803D] mx-auto">
            <Mail className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-[#112217] font-serif-title">
            Verify Official Email Address
          </h3>
          <p className="text-xs text-[#54665C] max-w-sm mx-auto">
            A 6-digit confirmation code was sent to <strong className="text-[#112217]">{email}</strong> to verify institutional provenance.
          </p>
        </div>

        {otpError && (
          <div className="p-3 bg-[#FEF2F2] border border-[#B91C1C]/30 text-[#B91C1C] text-xs rounded-xl flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 text-[#B91C1C] shrink-0" />
            <span>{otpError}</span>
          </div>
        )}

        <div className="flex justify-between gap-2 max-w-sm mx-auto">
          {otpDigits.map((digit, idx) => (
            <input
              key={idx}
              ref={(el) => {
                otpInputRefs.current[idx] = el;
              }}
              type="text"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={1}
              value={digit}
              onChange={(e) => handleOtpDigitChange(idx, e.target.value)}
              onKeyDown={(e) => handleOtpKeyDown(idx, e)}
              className="w-12 h-14 bg-[#F8FAF9] border-2 border-[#E1EBE4] focus:border-[#0A3D24] rounded-xl text-center text-xl font-mono font-bold text-[#112217] focus:outline-none shadow-2xs"
            />
          ))}
        </div>

        <div className="flex items-center justify-between text-xs text-[#54665C] font-mono">
          <span>Code expires in: <strong className="text-[#112217]">{formatTimer(otpTimer)}</strong></span>
          <button
            type="button"
            onClick={handleResendOtp}
            disabled={resendCooldown > 0 || isSubmitting}
            className="text-[#0A3D24] hover:text-[#062817] disabled:opacity-40 font-bold cursor-pointer"
          >
            {resendCooldown > 0 ? `Resend Code (${resendCooldown}s)` : 'Resend Code'}
          </button>
        </div>

        <div className="flex items-center space-x-3 pt-2">
          <button
            type="button"
            onClick={() => setRegStep('FORM')}
            className="w-1/2 py-2.5 bg-white border border-[#E1EBE4] hover:bg-slate-50 text-[#112217] font-bold text-xs rounded-xl cursor-pointer"
          >
            Edit Details
          </button>
          <button
            type="button"
            onClick={() => executeVerifyRegistration()}
            disabled={isSubmitting}
            className="w-1/2 py-2.5 bg-[#0A3D24] hover:bg-[#062817] disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center space-x-2 cursor-pointer"
          >
            {isSubmitting ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Verifying...</span>
              </>
            ) : (
              <span>Confirm Registration</span>
            )}
          </button>
        </div>
      </div>
    );
  }

  if (regStep === 'SUCCESS') {
    return (
      <div className="space-y-6 text-center py-4">
        <div className="w-16 h-16 rounded-full bg-[#F0FDF4] border border-[#15803D]/30 flex items-center justify-center text-[#0A3D24] mx-auto shadow-sm">
          <CheckCircle2 className="w-8 h-8 text-[#15803D]" />
        </div>

        <div className="space-y-2">
          <h3 className="text-2xl font-bold text-[#112217] font-serif-title">
            Account created. Waiting for administrator approval.
          </h3>
          <p className="text-xs text-[#54665C] max-w-md mx-auto leading-relaxed">
            Your credentials for <strong className="text-[#112217]">{email}</strong> have been saved as a pending application. You cannot sign in until the System Security Administrator reviews and approves your account.
          </p>
        </div>

        <div className="bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl p-4 max-w-md mx-auto text-left text-xs space-y-2.5">
          <div className="flex justify-between items-center py-1 border-b border-slate-100">
            <span className="text-[#54665C]">Application Status:</span>
            <span className="font-bold text-[#B2751E] bg-[#FEF3C7] px-2 py-0.5 rounded border border-[#C88A2C]/30 font-mono text-[10px]">
              PENDING ADMIN APPROVAL
            </span>
          </div>
          <div className="flex justify-between items-center py-1 border-b border-slate-100">
            <span className="text-[#54665C]">Requested Role:</span>
            <span className="font-bold text-[#0A3D24]">{role}</span>
          </div>
          <div className="flex justify-between items-center py-1 border-b border-slate-100">
            <span className="text-[#54665C]">Affiliated Agency:</span>
            <span className="font-medium text-[#112217]">{agency}</span>
          </div>
          <div className="p-2.5 bg-white border border-[#E1EBE4] rounded-xl text-[11px] text-[#54665C]">
            Once your clearance is approved and role assigned by the System Security Administrator, return to Sign In.
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 justify-center max-w-md mx-auto pt-2">
          <button
            type="button"
            onClick={() => onOpenPendingStatus(email.trim())}
            className="flex-1 py-3 bg-white border border-[#0A3D24] text-[#0A3D24] hover:bg-[#F0FDF4] font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            View Approval Status
          </button>
          <button
            type="button"
            onClick={() => onSwitchToSignIn(email.trim())}
            className="flex-1 py-3 bg-[#0A3D24] hover:bg-[#062817] text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center space-x-1.5"
          >
            <span>Go to Sign In</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-2xl font-bold text-[#112217] font-serif-title">
          Create Accredited Operator Account
        </h3>
        <p className="text-xs text-[#54665C] mt-1">
          Submit institutional credentials to apply for authorized forensic workspace access.
        </p>
      </div>

      <div className="p-3 bg-[#FEF3C7] border border-[#C88A2C]/30 text-[#B2751E] rounded-xl text-xs flex items-start space-x-2.5">
        <Info className="w-4 h-4 shrink-0 mt-0.5" />
        <span className="leading-relaxed">
          <strong>Approval Required:</strong> New accounts always start as <strong>Pending</strong>. Access requires administrator review and role verification. Self-registration for Administrator is prohibited.
        </span>
      </div>

      {formError && (
        <div className="p-3 bg-[#FEF2F2] border border-[#B91C1C]/30 text-[#B91C1C] text-xs rounded-xl space-y-2">
          <div className="flex items-start space-x-2">
            <AlertCircle className="w-4 h-4 text-[#B91C1C] shrink-0 mt-0.5" />
            <span>{formError}</span>
          </div>
          {duplicateEmailConflict && (
            <div className="flex flex-wrap items-center gap-2 pl-6">
              <button
                type="button"
                onClick={() => onSwitchToSignIn(email.trim(), 'This email is already registered. Sign in below.')}
                className="px-3 py-1.5 bg-[#0A3D24] text-white font-bold text-[11px] rounded-lg hover:bg-[#062817] cursor-pointer"
              >
                Switch to Sign In with {email.trim()} →
              </button>
              <button
                type="button"
                onClick={() => onOpenPendingStatus(email.trim())}
                className="px-3 py-1.5 bg-white border border-[#CBD5E1] text-[#112217] font-semibold text-[11px] rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Check Approval Status
              </button>
            </div>
          )}
        </div>
      )}

      <form onSubmit={handleInitiateRegistration} className="space-y-3.5 text-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label htmlFor="reg-first-name" className="block text-[10px] font-bold uppercase text-[#54665C] mb-1">
              First Name *
            </label>
            <input
              id="reg-first-name"
              type="text"
              autoComplete="given-name"
              required
              value={firstName}
              onChange={(e) => {
                setFirstName(e.target.value);
                if (fieldErrors.firstName) setFieldErrors((prev) => ({ ...prev, firstName: '' }));
              }}
              placeholder="Sarah"
              className={`w-full bg-[#F8FAF9] border rounded-xl p-2.5 text-[#112217] focus:outline-none focus:bg-white ${
                fieldErrors.firstName ? 'border-[#B91C1C]' : 'border-[#E1EBE4] focus:border-[#0A3D24]'
              }`}
            />
            {fieldErrors.firstName && (
              <p className="text-[10px] text-[#B91C1C] mt-1">{fieldErrors.firstName}</p>
            )}
          </div>
          <div>
            <label htmlFor="reg-last-name" className="block text-[10px] font-bold uppercase text-[#54665C] mb-1">
              Last Name *
            </label>
            <input
              id="reg-last-name"
              type="text"
              autoComplete="family-name"
              required
              value={lastName}
              onChange={(e) => {
                setLastName(e.target.value);
                if (fieldErrors.lastName) setFieldErrors((prev) => ({ ...prev, lastName: '' }));
              }}
              placeholder="Anderson"
              className={`w-full bg-[#F8FAF9] border rounded-xl p-2.5 text-[#112217] focus:outline-none focus:bg-white ${
                fieldErrors.lastName ? 'border-[#B91C1C]' : 'border-[#E1EBE4] focus:border-[#0A3D24]'
              }`}
            />
            {fieldErrors.lastName && (
              <p className="text-[10px] text-[#B91C1C] mt-1">{fieldErrors.lastName}</p>
            )}
          </div>
        </div>

        <div>
          <label htmlFor="reg-email" className="block text-[10px] font-bold uppercase text-[#54665C] mb-1">
            Official Institutional / Agency Email *
          </label>
          <input
            id="reg-email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              if (fieldErrors.email) setFieldErrors((prev) => ({ ...prev, email: '' }));
              if (duplicateEmailConflict) setDuplicateEmailConflict(false);
            }}
            placeholder="s.anderson@fbi.gov"
            className={`w-full bg-[#F8FAF9] border rounded-xl p-2.5 text-[#112217] font-mono focus:outline-none focus:bg-white ${
              fieldErrors.email ? 'border-[#B91C1C]' : 'border-[#E1EBE4] focus:border-[#0A3D24]'
            }`}
          />
          {fieldErrors.email && (
            <p className="text-[10px] text-[#B91C1C] mt-1">{fieldErrors.email}</p>
          )}
        </div>

        <div className="space-y-3">
          <div>
            <label htmlFor="reg-password" className="block text-[10px] font-bold uppercase text-[#54665C] mb-1">
              Password *
            </label>
            <PasswordInput
              id="reg-password"
              autoComplete="new-password"
              required
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                if (fieldErrors.password) setFieldErrors((prev) => ({ ...prev, password: '' }));
              }}
              placeholder="Minimum 12 chars with uppercase, number & symbol"
              error={fieldErrors.password}
              showStrengthChecklist
              emailForStrengthCheck={email}
              inputClassName={`w-full bg-[#F8FAF9] border rounded-xl py-2.5 text-[#112217] text-xs focus:outline-none focus:bg-white ${
                fieldErrors.password ? 'border-[#B91C1C]' : 'border-[#E1EBE4] focus:border-[#0A3D24]'
              }`}
            />
          </div>

          <div>
            <label htmlFor="reg-confirm-password" className="block text-[10px] font-bold uppercase text-[#54665C] mb-1">
              Confirm Password *
            </label>
            <PasswordInput
              id="reg-confirm-password"
              autoComplete="new-password"
              required
              value={confirmPassword}
              onChange={(e) => {
                setConfirmPassword(e.target.value);
                if (fieldErrors.confirmPassword) setFieldErrors((prev) => ({ ...prev, confirmPassword: '' }));
              }}
              placeholder="Re-enter password"
              error={fieldErrors.confirmPassword}
              inputClassName={`w-full bg-[#F8FAF9] border rounded-xl py-2.5 text-[#112217] text-xs focus:outline-none focus:bg-white ${
                fieldErrors.confirmPassword ? 'border-[#B91C1C]' : 'border-[#E1EBE4] focus:border-[#0A3D24]'
              }`}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label htmlFor="reg-agency" className="block text-[10px] font-bold uppercase text-[#54665C] mb-1">
              Agency / Forensic Laboratory *
            </label>
            <input
              id="reg-agency"
              type="text"
              autoComplete="organization"
              required
              value={agency}
              onChange={(e) => {
                setAgency(e.target.value);
                if (fieldErrors.agency) setFieldErrors((prev) => ({ ...prev, agency: '' }));
              }}
              placeholder="FBI Digital Forensics Division"
              className={`w-full bg-[#F8FAF9] border rounded-xl p-2.5 text-[#112217] focus:outline-none focus:bg-white ${
                fieldErrors.agency ? 'border-[#B91C1C]' : 'border-[#E1EBE4] focus:border-[#0A3D24]'
              }`}
            />
            {fieldErrors.agency && (
              <p className="text-[10px] text-[#B91C1C] mt-1">{fieldErrors.agency}</p>
            )}
          </div>

          <div>
            <label htmlFor="reg-role" className="block text-[10px] font-bold uppercase text-[#54665C] mb-1">
              Requested Role *
            </label>
            <select
              id="reg-role"
              value={role}
              onChange={(e) => setRole(e.target.value as UserRole)}
              className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 text-[#112217] focus:outline-none focus:border-[#0A3D24] shadow-2xs font-medium cursor-pointer"
            >
              <option value="Forensic Examiner / Expert Witness">Forensic Examiner / Expert Witness</option>
              <option value="Lead Forensic Analyst">Investigator / Lead Forensic Analyst</option>
              <option value="Prosecutor / Legal Reviewer">Legal Professional / Prosecutor</option>
            </select>
            <p className="text-[10px] text-[#54665C] mt-1">
              Administrator authority cannot be self-registered.
            </p>
          </div>
        </div>

        <div>
          <label htmlFor="reg-dept" className="block text-[10px] font-bold uppercase text-[#54665C] mb-1">
            Department / Unit (Optional)
          </label>
          <input
            id="reg-dept"
            type="text"
            value={department}
            onChange={(e) => setDepartment(e.target.value)}
            placeholder="e.g. Digital Multimedia Evidence Section"
            className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 text-[#112217] focus:outline-none focus:border-[#0A3D24]"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label htmlFor="reg-cert" className="block text-[10px] font-bold uppercase text-[#54665C] mb-1">
              Certification ID (Optional)
            </label>
            <input
              id="reg-cert"
              type="text"
              value={certificationId}
              onChange={(e) => setCertificationId(e.target.value)}
              placeholder="e.g. CFCE-9924"
              className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 text-[#112217] font-mono focus:outline-none focus:border-[#0A3D24] shadow-2xs"
            />
          </div>
          <div>
            <label htmlFor="reg-spec" className="block text-[10px] font-bold uppercase text-[#54665C] mb-1">
              Specialization (Optional)
            </label>
            <input
              id="reg-spec"
              type="text"
              value={specialty}
              onChange={(e) => setSpecialty(e.target.value)}
              placeholder="e.g. Neural Vocoder Forensics"
              className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 text-[#112217] focus:outline-none focus:border-[#0A3D24] shadow-2xs"
            />
          </div>
        </div>

        <div className="p-3 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <HardDrive className="w-4 h-4 text-[#0A3D24]" />
            <div>
              <p className="font-bold text-[#112217] text-[11px]">Hardware Authenticator Status</p>
              <p className="text-[10px] text-[#54665C]">{hardwareKeyStatus}</p>
            </div>
          </div>
          <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-white border border-[#E1EBE4] text-[#54665C]">
            {webAuthnSupported ? 'FIDO2 Available' : 'Standard PWD + TOTP'}
          </span>
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full py-3 bg-[#0A3D24] hover:bg-[#062817] disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center space-x-2 transition-all cursor-pointer"
        >
          {isSubmitting ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Submitting Registration Application...</span>
            </>
          ) : (
            <>
              <span>Create Account (Pending Approval)</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </form>
    </div>
  );
};

interface RequestAccessScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  onRegisterExpert?: (newExpert: ExpertReview) => void;
  setSelectedExpertId?: (id: string) => void;
  onRegistrationSubmitted?: (email: string) => void;
  onDuplicateEmailSignIn?: (email: string, notice?: string) => void;
}

export const RequestAccessScreen: React.FC<RequestAccessScreenProps> = ({
  setCurrentScreen,
  onRegistrationSubmitted,
  onDuplicateEmailSignIn
}) => {
  return (
    <div id="request-access-screen" className="min-h-full bg-[#F8FAF9] text-[#112217] flex items-center justify-center p-4 sm:p-6 md:p-8">
      <div className="w-full max-w-5xl bg-white border border-[#E1EBE4] rounded-3xl overflow-hidden shadow-xl grid grid-cols-1 lg:grid-cols-12">
        <div className="lg:col-span-5 bg-[#062817] p-8 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-[#0A3D24] text-white">
          <div className="space-y-6">
            <div className="flex items-center space-x-3">
              <div className="w-11 h-11 rounded-2xl bg-[#0A3D24] flex items-center justify-center text-white shadow-lg border border-[#C88A2C]/30">
                <Shield className="w-6 h-6 text-[#C88A2C]" />
              </div>
              <div>
                <span className="text-base font-extrabold tracking-tight block font-serif-title">ALFADetect</span>
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#C88A2C] font-bold">
                  CLEARANCE PROVISIONING
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <h2 className="text-xl font-bold tracking-tight text-white font-serif-title">
                Forensic Clearance Protocol
              </h2>
              <p className="text-xs text-emerald-200/80 leading-relaxed">
                Registration requests are reviewed under zero-trust authorization policies to prevent unauthorized access to judicial audio evidence.
              </p>
            </div>

            <div className="space-y-3 pt-3 border-t border-emerald-900/50 text-xs">
              <div className="p-3 bg-[#0A3D24]/60 border border-[#135A37] rounded-xl space-y-1">
                <div className="flex items-center space-x-2 text-[#C88A2C] font-bold text-[11px]">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Lead Forensic Analyst</span>
                </div>
                <p className="text-[11px] text-emerald-200/70">
                  Case management, evidence intake, and final forensic report signing.
                </p>
              </div>

              <div className="p-3 bg-[#0A3D24]/60 border border-[#135A37] rounded-xl space-y-1">
                <div className="flex items-center space-x-2 text-[#C88A2C] font-bold text-[11px]">
                  <Award className="w-3.5 h-3.5" />
                  <span>Forensic Examiner / Expert Witness</span>
                </div>
                <p className="text-[11px] text-emerald-200/70">
                  Acoustic signal analysis, speaker voice verification, and expert affidavits.
                </p>
              </div>

              <div className="p-3 bg-[#0A3D24]/60 border border-[#135A37] rounded-xl space-y-1">
                <div className="flex items-center space-x-2 text-[#C88A2C] font-bold text-[11px]">
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>Prosecutor / Legal Reviewer</span>
                </div>
                <p className="text-[11px] text-emerald-200/70">
                  Read-only evidence inspection, chain-of-custody audit, and Daubert checklist certification.
                </p>
              </div>

              <div className="p-3 bg-[#0A3D24]/60 border border-[#135A37] rounded-xl space-y-1">
                <div className="flex items-center space-x-2 text-[#C88A2C] font-bold text-[11px]">
                  <Lock className="w-3.5 h-3.5" />
                  <span>System Security Administrator (Sole Authority)</span>
                </div>
                <p className="text-[11px] text-emerald-200/70">
                  Single-administrator governance for user approvals, policy config, and security audit monitoring.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-emerald-900/50 text-[10px] text-emerald-400/70 font-mono flex items-center justify-between">
            <span>ZERO-TRUST GOVERNANCE</span>
            <span>ENCLAVE RBAC</span>
          </div>
        </div>

        <div className="lg:col-span-7 p-8 space-y-5">
          <div className="flex items-center justify-between">
            <BackButton onClick={() => setCurrentScreen('signin')} label="Back to Sign In" variant="pill" />
            <button
              type="button"
              onClick={() => setCurrentScreen('pending-approval')}
              className="text-[11px] font-semibold text-[#0A3D24] hover:text-[#062817] cursor-pointer"
            >
              Check Approval Status
            </button>
          </div>

          {/* Unified Auth Tabs */}
          <div className="grid grid-cols-2 bg-[#F1F5F9] p-1 rounded-xl border border-[#E1EBE4]">
            <button
              type="button"
              onClick={() => setCurrentScreen('signin')}
              className="py-2 rounded-lg text-xs font-bold text-[#54665C] hover:text-[#112217] cursor-pointer transition-colors"
            >
              Sign In
            </button>
            <button
              type="button"
              className="py-2 rounded-lg text-xs font-bold bg-white text-[#0A3D24] shadow-xs cursor-default"
            >
              Create Account
            </button>
          </div>

          <RegistrationPanel
            onSwitchToSignIn={(prefillEmail, notice) => {
              if (onDuplicateEmailSignIn && prefillEmail) {
                onDuplicateEmailSignIn(prefillEmail, notice);
              }
              setCurrentScreen('signin');
            }}
            onOpenPendingStatus={(pendingEmail) => {
              if (pendingEmail && onRegistrationSubmitted) onRegistrationSubmitted(pendingEmail);
              setCurrentScreen('pending-approval');
            }}
            onRegistrationSubmitted={onRegistrationSubmitted}
          />
        </div>
      </div>
    </div>
  );
};
