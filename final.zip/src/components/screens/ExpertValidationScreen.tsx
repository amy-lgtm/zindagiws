import React, { useState, useEffect, useRef } from 'react';
import {
  UserCheck,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  Volume2,
  Pause,
  Play,
  KeyRound,
  Lock,
  ExternalLink
} from 'lucide-react';
import { ScreenId, User, ExpertReview, AudioEvidence, VerdictType } from '../../types';
import { authFetch } from '../../utils/api';
import { speakAudioEvidence, stopAudioEvidence, playSuccessSound } from '../../utils/audioPlayer';
import { BackButton } from '../common/BackButton';
import { PasswordInput } from '../common/PasswordInput';

interface ExpertValidationScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  selectedCaseId: string;
  currentUser: User;
  expertReviews?: ExpertReview[];
  setExpertReviews?: React.Dispatch<React.SetStateAction<ExpertReview[]>>;
  onRegisterExpert?: (newExpert: ExpertReview) => void;
  initialSelectedExpertId?: string;
}

export const ExpertValidationScreen: React.FC<ExpertValidationScreenProps> = ({
  setCurrentScreen,
  selectedCaseId,
  currentUser,
  expertReviews = [],
  setExpertReviews,
  initialSelectedExpertId
}) => {
  const activeCaseId = selectedCaseId || '';

  const [caseEvidence, setCaseEvidence] = useState<AudioEvidence[]>([]);
  const [caseVerdict, setCaseVerdict] = useState<VerdictType>('INCONCLUSIVE');
  const [activeReviewId, setActiveReviewId] = useState<string>(initialSelectedExpertId || '');

  const [assessmentText, setAssessmentText] = useState('');
  const [overrideVerdict, setOverrideVerdict] = useState<'' | VerdictType>('');
  const [overrideReason, setOverrideReason] = useState('');
  const [checklist, setChecklist] = useState({
    swgdeStandards: false,
    chainOfCustodyVerified: false,
    reproducibleOutputs: false,
    confidenceIntervalsValid: false,
    acousticSpectralInspected: false
  });

  // Real Credential Re-Authentication Inputs (No simulated biometrics)
  const [currentPassword, setCurrentPassword] = useState('');
  const [totpCode, setTotpCode] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [latestSignedReview, setLatestSignedReview] = useState<ExpertReview | null>(null);

  // Evidence Audio Playback State
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [playbackProgress, setPlaybackProgress] = useState(0);
  const playbackTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const canSignAsExpert =
    currentUser.role === 'Forensic Examiner / Expert Witness' ||
    currentUser.role === 'Lead Forensic Analyst';

  const caseReviews = activeCaseId
    ? expertReviews.filter((r) => r.caseId === activeCaseId)
    : expertReviews;

  const selectedReview =
    caseReviews.find((r) => r.id === activeReviewId) || caseReviews[0] || null;

  useEffect(() => {
    if (!activeCaseId) return;
    let cancelled = false;

    async function loadCaseData() {
      try {
        const [revRes, evRes, caseRes] = await Promise.all([
          authFetch(`/api/cases/${encodeURIComponent(activeCaseId)}/expert-reviews`),
          authFetch(`/api/cases/${encodeURIComponent(activeCaseId)}/evidence`),
          authFetch(`/api/cases/${encodeURIComponent(activeCaseId)}`)
        ]);
        if (cancelled) return;

        if (revRes.ok) {
          const fetchedReviews: ExpertReview[] = await revRes.json();
          if (Array.isArray(fetchedReviews) && setExpertReviews) {
            setExpertReviews((prev) => {
              const others = prev.filter((p) => p.caseId !== activeCaseId);
              return [...fetchedReviews, ...others];
            });
            if (fetchedReviews.length > 0) {
              setActiveReviewId((prev) => prev || fetchedReviews[0].id);
            }
          }
        }
        if (evRes.ok) {
          const evList: AudioEvidence[] = await evRes.json();
          if (Array.isArray(evList)) setCaseEvidence(evList);
        }
        if (caseRes.ok) {
          const c = await caseRes.json();
          if (c?.verdict) setCaseVerdict(c.verdict);
        }
      } catch (err) {
        console.warn('ExpertValidation case sync error:', err);
      }
    }

    loadCaseData();
    return () => {
      cancelled = true;
    };
  }, [activeCaseId, setExpertReviews]);

  useEffect(() => {
    return () => {
      if (playbackTimerRef.current) clearInterval(playbackTimerRef.current);
      stopAudioEvidence();
    };
  }, []);

  const primaryEvidence = caseEvidence[0];

  const handleToggleAudioPlayback = () => {
    if (isPlayingAudio) {
      stopAudioEvidence();
      setIsPlayingAudio(false);
      if (playbackTimerRef.current) clearInterval(playbackTimerRef.current);
    } else {
      setIsPlayingAudio(true);
      setPlaybackProgress(0);

      speakAudioEvidence(
        primaryEvidence
          ? `Questioned evidence exhibit ${primaryEvidence.filename} for case ${activeCaseId}.`
          : `Forensic docket ${activeCaseId} expert review verification.`,
        {
          audioUrl: primaryEvidence?.audioUrl,
          onEnd: () => {
            setIsPlayingAudio(false);
            setPlaybackProgress(100);
            if (playbackTimerRef.current) clearInterval(playbackTimerRef.current);
          }
        }
      );

      const startTime = Date.now();
      playbackTimerRef.current = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const pct = Math.min(100, (elapsed / 25000) * 100);
        setPlaybackProgress(pct);
        if (pct >= 100 && playbackTimerRef.current) {
          clearInterval(playbackTimerRef.current);
        }
      }, 250);
    }
  };

  const handleExecuteCertification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCaseId) {
      setActionError('Please open or select an active case docket before certifying.');
      return;
    }

    if (!canSignAsExpert) {
      setActionError(
        `Role Restriction: Your current role (${currentUser.role}) cannot sign an Expert Witness Certification.`
      );
      return;
    }

    const mandatoryOk =
      checklist.swgdeStandards &&
      checklist.chainOfCustodyVerified &&
      checklist.reproducibleOutputs &&
      checklist.confidenceIntervalsValid;
    if (!mandatoryOk) {
      setActionError(
        'Forensic Protocol Requirement: All mandatory SWGDE / FRE 702 checklist items must be explicitly checked before legal certification.'
      );
      return;
    }

    if (assessmentText.trim().length < 10) {
      setActionError('Technical Assessment commentary (minimum 10 characters) is required before signing.');
      return;
    }

    if (overrideVerdict && overrideVerdict !== caseVerdict && !overrideReason.trim()) {
      setActionError('Justification Note is mandatory whenever modifying the case verdict.');
      return;
    }

    if (!currentPassword) {
      setActionError('Current account password is required to authorize the Ed25519 digital signature.');
      return;
    }

    if (currentUser.twoFactorEnabled && !/^\d{6}$/.test(totpCode.trim())) {
      setActionError('Two-Factor Authentication is enabled on your account. Enter your 6-digit TOTP authenticator code.');
      return;
    }

    setActionError(null);
    setIsSubmitting(true);

    try {
      const response = await authFetch(`/api/cases/${encodeURIComponent(activeCaseId)}/expert-reviews`, {
        method: 'POST',
        body: JSON.stringify({
          currentPassword,
          totpCode: currentUser.twoFactorEnabled ? totpCode.trim() : undefined,
          status: 'Approved',
          technicalAssessment: assessmentText.trim(),
          overrideVerdict: overrideVerdict || undefined,
          overrideReason: overrideReason.trim() || undefined,
          checklist
        })
      });

      const data = await response.json().catch(() => null);

      if (!response.ok || !data?.id) {
        setActionError(data?.error || `Expert review signing rejected (${response.status}).`);
        return;
      }

      const created: ExpertReview = data;
      setLatestSignedReview(created);
      setActiveReviewId(created.id);

      if (setExpertReviews) {
        setExpertReviews((prev) => [created, ...prev]);
      }

      if (overrideVerdict) {
        setCaseVerdict(overrideVerdict);
      }

      // Immediately clear sensitive credential inputs from React state
      setCurrentPassword('');
      setTotpCode('');
      playSuccessSound();
    } catch {
      setActionError('Network error connecting to the certification server.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const displaySealed = latestSignedReview || (selectedReview?.status === 'Approved' ? selectedReview : null);

  return (
    <div id="expert-validation-screen" className="p-4 sm:p-6 space-y-6 bg-[#F4F8F6] min-h-full text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-900/10 pb-5">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('detection-results')} label="Back to Detection Results" variant="pill" />
          </div>
          <div className="flex items-center space-x-2.5 flex-wrap gap-y-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 font-sans flex items-center space-x-2">
              <UserCheck className="w-6 h-6 text-emerald-700" />
              <span>Expert Witness Review & Cryptographic Certification</span>
            </h1>
            <span className="text-xs font-mono font-bold text-emerald-900 bg-emerald-100 border border-emerald-300 px-3 py-1 rounded-full shadow-xs">
              DOCKET: {activeCaseId || 'UNSELECTED'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Independent FRE 702 technical validation sealed with server Ed25519 enclave keys after credential re-authentication
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={() => setCurrentScreen('legal-review')}
            className="px-3.5 py-2.5 bg-white hover:bg-slate-50 text-emerald-900 border border-emerald-300 text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer"
          >
            <span>Legal Review →</span>
          </button>
          <button
            type="button"
            onClick={() => setCurrentScreen('report-generation')}
            className="px-4 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-900/20 transition-all cursor-pointer"
          >
            <span>Report Generation →</span>
          </button>
        </div>
      </div>

      {/* Action Error Banner */}
      {actionError && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-2xl flex items-center justify-between text-xs text-red-800 shadow-xs max-w-6xl mx-auto">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            <span className="font-medium">{actionError}</span>
          </div>
          <button
            type="button"
            onClick={() => setActionError(null)}
            className="text-red-700 hover:text-red-900 font-bold ml-3 px-2 py-0.5 rounded-md hover:bg-red-100 transition-colors cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 max-w-6xl mx-auto">
        {/* Left Column: Persisted Reviews & Enclave Re-Auth Info */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-5 space-y-4 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div>
                <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center space-x-1.5">
                  <span>Recorded Case Expert Reviews</span>
                  <span className="px-1.5 py-0.2 bg-emerald-100 text-emerald-900 rounded-full font-mono text-[10px]">
                    {caseReviews.length}
                  </span>
                </h2>
                <p className="text-[10px] text-slate-500">Persisted expert affidavits linked to this docket</p>
              </div>
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
            </div>

            {caseReviews.length === 0 ? (
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 space-y-1">
                <p className="font-bold text-slate-800">No Expert Reviews Recorded Yet</p>
                <p className="text-[11px]">
                  Complete the SWGDE checklist, document your technical assessment, and re-authenticate on the right to issue the Ed25519 witness seal.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
                {caseReviews.map((rev) => (
                  <div
                    key={rev.id}
                    onClick={() => setActiveReviewId(rev.id)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                      selectedReview?.id === rev.id
                        ? 'bg-emerald-50 border-emerald-500 text-slate-900 shadow-xs'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-emerald-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-slate-900">{rev.expertName}</span>
                      <span
                        className={`text-[9px] font-bold px-2 py-0.5 rounded-full border ${
                          rev.status === 'Approved'
                            ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                            : 'bg-amber-100 text-amber-900 border-amber-300'
                        }`}
                      >
                        {rev.status === 'Approved' ? 'CERTIFIED' : rev.status.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1">{rev.institution}</p>
                    <div className="flex justify-between items-center text-[10px] font-mono text-emerald-800 font-bold mt-1.5 pt-1.5 border-t border-slate-200/60">
                      <span>Cert: {rev.certificationId}</span>
                      <span className="text-[9px] text-slate-500">{rev.signedAt}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Honest Signing Operator Card */}
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-5 space-y-4 shadow-sm">
            <div className="border-b border-slate-100 pb-2 flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase text-slate-900 flex items-center space-x-2">
                  <KeyRound className="w-4 h-4 text-emerald-700" />
                  <span>Signing Enclave Security Policy</span>
                </h3>
                <p className="text-[10px] text-slate-500 mt-0.5">
                  Operator: <strong>{currentUser.name}</strong> ({currentUser.role})
                </p>
              </div>
              <span className="text-[9px] font-mono text-emerald-900 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded font-bold">
                Ed25519 Enclave
              </span>
            </div>

            <div className="space-y-2 text-xs text-slate-600">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                <p className="font-bold text-slate-800 text-[11px]">No Simulated Hardware Biometrics</p>
                <p className="text-[11px] leading-relaxed">
                  ALFADetect requires direct server-verified credential re-authentication (scrypt password{currentUser.twoFactorEnabled ? ' + RFC 6238 TOTP 2FA' : ''}) and seals every affidavit using an enclave Ed25519 private key after verifying live evidence SHA-256 digests.
                </p>
              </div>

              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-[11px]">
                <span className="font-bold text-emerald-900">Account 2FA Enforcement:</span>
                <span
                  className={`font-mono font-bold px-2 py-0.5 rounded ${
                    currentUser.twoFactorEnabled
                      ? 'bg-emerald-200 text-emerald-950'
                      : 'bg-amber-100 text-amber-900'
                  }`}
                >
                  {currentUser.twoFactorEnabled ? 'TOTP ACTIVE' : 'PASSWORD RE-AUTH'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Review & Certification Form */}
        <form
          onSubmit={handleExecuteCertification}
          className="lg:col-span-7 bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-6 shadow-sm"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-3 gap-2">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Independent Review & Certification Affidavit</h2>
              <span className="text-xs font-mono font-bold text-emerald-800">
                {currentUser.name} — {currentUser.certificationId || `CRED-${currentUser.id}`} | Case Verdict: {caseVerdict}
              </span>
            </div>

            <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300 self-start sm:self-auto">
              FRE 702 / 902(13)
            </span>
          </div>

          {/* Evidence Audio Playback */}
          <div className="p-4 bg-[#032319] border border-emerald-950/20 rounded-2xl space-y-3 shadow-inner">
            <div className="flex items-center justify-between text-xs text-emerald-300">
              <div className="flex items-center space-x-2">
                <Volume2 className="w-4 h-4 text-emerald-400" />
                <span className="font-bold uppercase tracking-wider text-white">
                  Case Evidence Playback Inspection
                </span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400">
                {primaryEvidence ? primaryEvidence.filename : 'No Audio Uploaded'}
              </span>
            </div>

            <div className="h-2 bg-emerald-950 rounded-full overflow-hidden border border-emerald-900/60">
              <div
                style={{ width: `${playbackProgress}%` }}
                className="h-full bg-emerald-500 rounded-full transition-all duration-200"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <button
                type="button"
                onClick={handleToggleAudioPlayback}
                disabled={!primaryEvidence}
                className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 disabled:opacity-50 text-white font-bold text-xs rounded-xl flex items-center space-x-2 transition-colors shadow-xs cursor-pointer"
              >
                {isPlayingAudio ? (
                  <>
                    <Pause className="w-4 h-4" />
                    <span>Pause Evidence Audio</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4" />
                    <span>Listen to Questioned Evidence</span>
                  </>
                )}
              </button>

              <span className="text-[10px] font-mono text-emerald-300/80">
                {primaryEvidence ? `${primaryEvidence.id} • ${primaryEvidence.duration}` : 'Upload evidence first'}
              </span>
            </div>
          </div>

          {/* Technical Assessment Commentary */}
          <div className="space-y-2">
            <label className="block text-[11px] font-bold uppercase text-slate-500">
              EXPERT WITNESS TECHNICAL ASSESSMENT & FINDINGS VALIDATION
            </label>
            <textarea
              rows={4}
              value={assessmentText}
              onChange={(e) => setAssessmentText(e.target.value)}
              placeholder="Document acoustic findings, vocal tract observations, vocoder indicators, and scientific justification for judicial review (min 10 chars)..."
              className="w-full bg-[#F8FAF9] border border-slate-200 rounded-xl p-3 text-xs text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white font-sans leading-relaxed shadow-xs"
            />
          </div>

          {/* Verdict Override Controls */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 text-xs">
            <label className="block text-[11px] font-bold uppercase text-slate-600">
              FORENSIC VERDICT DETERMINATION / OVERRIDE (OPTIONAL)
            </label>
            <select
              value={overrideVerdict}
              onChange={(e) => setOverrideVerdict(e.target.value as '' | VerdictType)}
              className="w-full bg-white border border-slate-200 rounded-xl p-2.5 text-xs font-bold text-slate-900"
            >
              <option value="">Retain Current Case Verdict ({caseVerdict})</option>
              <option value="DEEPFAKE">Certify Determination: DEEPFAKE</option>
              <option value="AUTHENTIC">Certify Determination: AUTHENTIC</option>
              <option value="INCONCLUSIVE">Certify Determination: INCONCLUSIVE</option>
            </select>

            {overrideVerdict && (
              <div className="space-y-1">
                <label className="block text-[10px] font-bold uppercase text-rose-700">
                  Mandatory Justification Note (Audit Required)
                </label>
                <textarea
                  rows={2}
                  value={overrideReason}
                  onChange={(e) => setOverrideReason(e.target.value)}
                  placeholder="Provide empirical forensic justification for assigning or overriding the docket verdict..."
                  className="w-full bg-white border border-rose-200 rounded-xl p-2.5 text-xs text-slate-900"
                />
              </div>
            )}
          </div>

          {/* Methodological Review Checklist */}
          <div className="space-y-2">
            <label className="block text-[11px] font-bold uppercase text-slate-500">
              METHODOLOGICAL REVIEW CHECKLIST (EXPLICIT CONFIRMATION REQUIRED)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs text-slate-800">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={checklist.swgdeStandards}
                  onChange={(e) => setChecklist({ ...checklist, swgdeStandards: e.target.checked })}
                  className="rounded-sm text-emerald-600 focus:ring-emerald-500"
                />
                <span>Conforms to SWGDE Standards</span>
              </label>

              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={checklist.chainOfCustodyVerified}
                  onChange={(e) => setChecklist({ ...checklist, chainOfCustodyVerified: e.target.checked })}
                  className="rounded-sm text-emerald-600 focus:ring-emerald-500"
                />
                <span>Chain of Custody Verified</span>
              </label>

              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={checklist.reproducibleOutputs}
                  onChange={(e) => setChecklist({ ...checklist, reproducibleOutputs: e.target.checked })}
                  className="rounded-sm text-emerald-600 focus:ring-emerald-500"
                />
                <span>DSP Measurements Reproducible</span>
              </label>

              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={checklist.confidenceIntervalsValid}
                  onChange={(e) => setChecklist({ ...checklist, confidenceIntervalsValid: e.target.checked })}
                  className="rounded-sm text-emerald-600 focus:ring-emerald-500"
                />
                <span>Methodological Limitations Reviewed</span>
              </label>

              <label className="flex items-center space-x-2 cursor-pointer sm:col-span-2">
                <input
                  type="checkbox"
                  checked={checklist.acousticSpectralInspected}
                  onChange={(e) => setChecklist({ ...checklist, acousticSpectralInspected: e.target.checked })}
                  className="rounded-sm text-emerald-600 focus:ring-emerald-500"
                />
                <span>Acoustic & spectral anomaly regions inspected & validated</span>
              </label>
            </div>
          </div>

          {/* Credential Re-Authentication Enclave */}
          <div className="p-4 bg-emerald-50/70 border border-emerald-300 rounded-2xl space-y-3 text-xs">
            <div className="flex items-center space-x-2 font-bold text-emerald-950">
              <Lock className="w-4 h-4 text-emerald-700" />
              <span>CREDENTIAL RE-AUTHENTICATION TO SIGN (ED25519 ENCLAVE)</span>
            </div>

            <div className={`grid grid-cols-1 ${currentUser.twoFactorEnabled ? 'sm:grid-cols-2' : ''} gap-3`}>
              <div>
                <label htmlFor="expert-reauth-password" className="block text-[10px] font-bold uppercase text-slate-600 mb-1">
                  Account Password *
                </label>
                <PasswordInput
                  id="expert-reauth-password"
                  autoComplete="current-password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Re-enter your account password"
                  inputClassName="w-full bg-white border border-emerald-900/20 rounded-xl py-2 text-xs text-slate-900 focus:outline-hidden focus:border-emerald-700"
                />
              </div>

              {currentUser.twoFactorEnabled && (
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-600 mb-1">
                    6-Digit TOTP Code *
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={6}
                    value={totpCode}
                    onChange={(e) => setTotpCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    placeholder="000000"
                    className="w-full bg-white border border-emerald-900/20 rounded-xl px-3 py-2 text-xs font-mono tracking-widest text-slate-900 focus:outline-hidden focus:border-emerald-700"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Persisted Certified Seal Confirmation */}
          {displaySealed && (
            <div className="p-4 bg-emerald-50 border-2 border-emerald-400 rounded-2xl space-y-3 text-emerald-950 text-xs">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center space-x-2 font-bold text-sm text-emerald-900">
                  <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" />
                  <span>EXPERT WITNESS REVIEW CERTIFIED & SEALED</span>
                </div>
                <button
                  type="button"
                  onClick={() => setCurrentScreen('legal-review')}
                  className="px-2.5 py-1 bg-emerald-800 text-white rounded-lg text-[10px] font-bold flex items-center space-x-1 cursor-pointer"
                >
                  <ExternalLink className="w-3 h-3" />
                  <span>Proceed to Legal Review</span>
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono">
                <div>
                  <span className="text-slate-500 block">Expert Witness:</span>
                  <span className="font-bold text-slate-800">
                    {displaySealed.expertName} ({displaySealed.certificationId})
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Signed Timestamp:</span>
                  <span className="font-bold text-slate-800">{displaySealed.signedAt}</span>
                </div>
              </div>
              <div className="p-2.5 bg-[#032319] rounded-xl font-mono text-[10px] text-emerald-300 break-all leading-tight">
                {displaySealed.digitalSignature}
              </div>
            </div>
          )}

          <div className="flex justify-end pt-2">
            <button
              id="certify-sign-button"
              type="submit"
              disabled={isSubmitting || !canSignAsExpert}
              className="px-6 py-3.5 bg-emerald-800 hover:bg-emerald-900 disabled:bg-slate-200 disabled:text-slate-400 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-900/20 transition-all flex items-center space-x-2 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>
                {isSubmitting
                  ? 'Signing & Sealing Affidavit...'
                  : canSignAsExpert
                  ? `Certify & Seal Affidavit (${currentUser.name})`
                  : `Signing Restricted (${currentUser.role})`}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
