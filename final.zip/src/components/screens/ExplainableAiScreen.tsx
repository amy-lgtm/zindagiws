import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Layers,
  AlertTriangle,
  Activity,
  Eye,
  EyeOff,
  Info,
  RefreshCw,
  Upload,
  Cpu
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';
import {
  ScreenId,
  User,
  AudioEvidence,
  F0AnalysisResult,
  AcousticMeasurements,
  NonBiometricDspProfile
} from '../../types';
import { extractF0FromPCM } from '../../utils/pitchExtractor';
import { computeAcousticMeasurements, computeNonBiometricDspProfile } from '../../utils/audioDsp';
import { authFetch } from '../../utils/api';
import { BackButton } from '../common/BackButton';

interface ExplainableAiScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  selectedCaseId: string;
  activeEvidence?: AudioEvidence;
  setActiveEvidence?: (ev: AudioEvidence) => void;
  currentUser: User;
  audioEvidenceUrl?: string;
}

interface SpectrogramData {
  cols: number;
  rows: number;
  durationSec: number;
  nyquistKhz: number;
  matrix: number[][]; // matrix[col][row] normalized 0..1
}

function buildSpectrogramFromPcm(samples: Float32Array, sampleRate: number, cols = 120, rows = 36): SpectrogramData {
  const durationSec = samples.length / sampleRate;
  const nyquistKhz = +(sampleRate / 2000).toFixed(1);
  const windowSize = Math.min(512, Math.max(64, Math.floor(samples.length / cols)));
  const matrix: number[][] = [];
  let maxEnergy = 0.0001;

  for (let c = 0; c < cols; c++) {
    const start = Math.floor((c / cols) * Math.max(0, samples.length - windowSize));
    const colBins: number[] = [];

    // Estimate energy in sub-bands via Goertzel/DFT magnitude bins
    for (let r = 0; r < rows; r++) {
      const freqRatio = (r + 0.5) / rows; // 0 low .. 1 Nyquist
      const freqHz = freqRatio * (sampleRate / 2);
      const omega = (2 * Math.PI * freqHz) / sampleRate;
      let re = 0;
      let im = 0;
      const step = Math.max(1, Math.floor(windowSize / 64));
      for (let n = 0; n < windowSize; n += step) {
        const s = samples[start + n] || 0;
        const win = 0.54 - 0.46 * Math.cos((2 * Math.PI * n) / (windowSize - 1));
        const val = s * win;
        re += val * Math.cos(omega * n);
        im -= val * Math.sin(omega * n);
      }
      const mag = Math.log1p(Math.sqrt(re * re + im * im));
      if (mag > maxEnergy) maxEnergy = mag;
      colBins.push(mag);
    }
    matrix.push(colBins);
  }

  // Normalize 0..1
  for (let c = 0; c < cols; c++) {
    for (let r = 0; r < rows; r++) {
      matrix[c][r] = matrix[c][r] / maxEnergy;
    }
  }

  return { cols, rows, durationSec, nyquistKhz, matrix };
}

export const ExplainableAiScreen: React.FC<ExplainableAiScreenProps> = ({
  setCurrentScreen,
  selectedCaseId,
  activeEvidence,
  setActiveEvidence,
  audioEvidenceUrl
}) => {
  const [selectedModel, setSelectedModel] = useState<'CNN' | 'Wav2Vec2' | 'BiLSTM' | 'Ensemble'>('CNN');
  const [showRegionsOverlay, setShowRegionsOverlay] = useState(true);
  const [activeHighlightId, setActiveHighlightId] = useState<string | null>(null);

  const [caseEvidenceList, setCaseEvidenceList] = useState<AudioEvidence[]>([]);
  const [selectedUrl, setSelectedUrl] = useState<string | undefined>(audioEvidenceUrl);
  const [f0Result, setF0Result] = useState<F0AnalysisResult | null>(null);
  const [measurements, setMeasurements] = useState<AcousticMeasurements | null>(null);
  const [nonBiometricProfile, setNonBiometricProfile] = useState<NonBiometricDspProfile | null>(null);
  const [spectrogramData, setSpectrogramData] = useState<SpectrogramData | null>(null);
  const [isAnalyzingF0, setIsAnalyzingF0] = useState<boolean>(false);
  const [customAudioName, setCustomAudioName] = useState<string | null>(null);
  const [decodeError, setDecodeError] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setSelectedUrl(audioEvidenceUrl);
  }, [audioEvidenceUrl]);

  useEffect(() => {
    if (!selectedCaseId) return;
    let cancelled = false;
    authFetch(`/api/cases/${encodeURIComponent(selectedCaseId)}/evidence`)
      .then((res) => (res.ok ? res.json() : []))
      .then((list) => {
        if (!cancelled && Array.isArray(list)) {
          setCaseEvidenceList(list);
          if (!audioEvidenceUrl && list[0]?.audioUrl) {
            setSelectedUrl(list[0].audioUrl);
          }
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [selectedCaseId]);

  const processArrayBuffer = async (arrayBuffer: ArrayBuffer) => {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) {
      throw new Error('Web Audio API unavailable in browser.');
    }
    const ctx = new AudioCtx();
    try {
      const audioBuffer = await ctx.decodeAudioData(arrayBuffer);
      const channelData = audioBuffer.getChannelData(0);
      const sr = audioBuffer.sampleRate;
      const f0 = extractF0FromPCM(channelData, sr);
      const meas = computeAcousticMeasurements(channelData, sr);
      const profile = computeNonBiometricDspProfile(channelData, sr);
      const spec = buildSpectrogramFromPcm(channelData, sr);
      return { f0, meas, profile, spec };
    } finally {
      ctx.close().catch(() => {});
    }
  };

  useEffect(() => {
    let isMounted = true;

    async function loadAudioAnalysis() {
      if (!selectedUrl) {
        setF0Result(null);
        setMeasurements(null);
        setNonBiometricProfile(null);
        setSpectrogramData(null);
        setDecodeError('No audio stream selected. Select an uploaded audio exhibit or upload an audio file below.');
        return;
      }

      setIsAnalyzingF0(true);
      setDecodeError(null);
      try {
        const resp = selectedUrl.startsWith('/api/')
          ? await authFetch(selectedUrl)
          : await fetch(selectedUrl);
        if (!resp.ok) {
          throw new Error(`Audio stream returned status ${resp.status}`);
        }
        const ab = await resp.arrayBuffer();
        const { f0, meas, profile, spec } = await processArrayBuffer(ab);
        if (isMounted) {
          setF0Result(f0);
          setMeasurements(meas);
          setNonBiometricProfile(profile);
          setSpectrogramData(spec);
        }
      } catch (err: any) {
        if (isMounted) {
          setF0Result(null);
          setMeasurements(null);
          setNonBiometricProfile(null);
          setSpectrogramData(null);
          setDecodeError(
            err?.message || 'Unable to decode audio exhibit in browser Web Audio engine. Upload a valid WAV/MP3/FLAC file to inspect.'
          );
        }
      } finally {
        if (isMounted) setIsAnalyzingF0(false);
      }
    }

    loadAudioAnalysis();
    return () => {
      isMounted = false;
    };
  }, [selectedUrl]);

  const handleCustomAudioUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setCustomAudioName(file.name);
    setIsAnalyzingF0(true);
    setDecodeError(null);

    try {
      const ab = await file.arrayBuffer();
      const { f0, meas, profile, spec } = await processArrayBuffer(ab);
      setF0Result(f0);
      setMeasurements(meas);
      setNonBiometricProfile(profile);
      setSpectrogramData(spec);
    } catch {
      setDecodeError('Could not decode uploaded audio file. Ensure the file is a valid WAV, MP3, FLAC, or M4A recording.');
    } finally {
      setIsAnalyzingF0(false);
    }
  };

  // Real irregular regions strictly derived from F0 DSP analysis
  const detectedRegions = (f0Result?.irregularRegions || []).map((reg, idx) => ({
    id: `dsp-reg-${idx}`,
    timeRange: reg.timeRange,
    timeStartSec: reg.startSec,
    timeEndSec: reg.endSec,
    severity: reg.severity,
    label: reg.type,
    description: reg.description
  }));

  // Render Genuine Computed Spectrogram on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    ctx.fillStyle = '#031D15';
    ctx.fillRect(0, 0, width, height);

    if (!spectrogramData) {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = 1;
      for (let i = 1; i <= 4; i++) {
        const y = (height / 5) * i;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }
      ctx.fillStyle = '#94A3B8';
      ctx.font = '12px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('Load or upload a decodable audio file to plot real time-frequency energy', width / 2, height / 2);
      ctx.textAlign = 'left';
      return;
    }

    const { cols, rows, matrix, durationSec } = spectrogramData;
    const colWidth = width / cols;
    const rowHeight = height / rows;

    for (let c = 0; c < cols; c++) {
      for (let r = 0; r < rows; r++) {
        const intensity = matrix[c][rows - 1 - r]; // High freq at top, low freq at bottom
        if (intensity < 0.2) {
          ctx.fillStyle = '#032319';
        } else if (intensity < 0.42) {
          ctx.fillStyle = '#065F46';
        } else if (intensity < 0.65) {
          ctx.fillStyle = '#10B981';
        } else if (intensity < 0.84) {
          ctx.fillStyle = '#F59E0B';
        } else {
          ctx.fillStyle = '#E11D48';
        }
        ctx.fillRect(c * colWidth, r * rowHeight, colWidth + 0.5, rowHeight + 0.5);
      }
    }

    // Highlight real DSP F0 discontinuity spans if toggle enabled
    if (showRegionsOverlay && durationSec > 0 && detectedRegions.length > 0) {
      detectedRegions.forEach((reg) => {
        const xStart = Math.max(0, (reg.timeStartSec / durationSec) * width);
        const xEnd = Math.min(width, (reg.timeEndSec / durationSec) * width);
        const regionW = Math.max(xEnd - xStart, 18);

        ctx.fillStyle = activeHighlightId === reg.id ? 'rgba(225, 29, 72, 0.35)' : 'rgba(245, 158, 11, 0.22)';
        ctx.fillRect(xStart, 0, regionW, height);

        ctx.strokeStyle = activeHighlightId === reg.id ? '#FFFFFF' : '#F59E0B';
        ctx.lineWidth = activeHighlightId === reg.id ? 2 : 1.5;
        ctx.setLineDash([4, 4]);
        ctx.strokeRect(xStart, 2, regionW, height - 4);
        ctx.setLineDash([]);

        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 9px monospace';
        ctx.fillText(`DSP ANOMALY`, xStart + 3, 14);
      });
    }

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
    ctx.lineWidth = 1;
    for (let i = 1; i <= 4; i++) {
      const y = (height / 5) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
  }, [spectrogramData, showRegionsOverlay, activeHighlightId, detectedRegions]);

  const chartData =
    f0Result?.points && f0Result.points.length > 0
      ? f0Result.points.map((pt) => ({
          time: pt.timeLabel,
          observedF0: pt.isVoiced ? pt.f0Hz : null,
          isAnomaly: pt.isAnomaly
        }))
      : [];

  const nyquistMax = spectrogramData ? spectrogramData.nyquistKhz : 22.0;

  return (
    <div id="explainable-ai-screen" className="p-4 sm:p-6 space-y-6 bg-[#F4F8F6] min-h-full text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-900/10 pb-5">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('detection-results')} label="Back to Detection Results" variant="pill" />
          </div>
          <div className="flex items-center space-x-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center space-x-2 font-sans">
              <Sparkles className="w-6 h-6 text-emerald-700" />
              <span>Explainable AI (XAI) & Acoustic DSP Inspection</span>
            </h1>
            <span className="text-xs font-mono font-bold text-emerald-900 bg-emerald-100 border border-emerald-300 px-3 py-1 rounded-full shadow-xs">
              FRE 702 TRANSPARENCY
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Genuine STFT time-frequency spectrogram, YIN/autocorrelation pitch contour extraction, and model attribution readiness for Case <strong className="text-slate-800">{selectedCaseId || 'UNASSIGNED'}</strong>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {caseEvidenceList.length > 0 && (
            <select
              value={activeEvidence?.id || caseEvidenceList.find((e) => e.audioUrl === selectedUrl)?.id || caseEvidenceList[0]?.id || ''}
              onChange={(e) => {
                const picked = caseEvidenceList.find((ev) => ev.id === e.target.value);
                if (picked) {
                  setCustomAudioName(null);
                  setSelectedUrl(picked.audioUrl);
                  if (setActiveEvidence) setActiveEvidence(picked);
                }
              }}
              className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 shadow-xs cursor-pointer"
            >
              {caseEvidenceList.map((ev) => (
                <option key={ev.id} value={ev.id}>
                  {ev.id} — {ev.filename}
                </option>
              ))}
            </select>
          )}
          <button
            onClick={() => setCurrentScreen('expert-validation')}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-900/20 transition-all flex items-center space-x-1.5 cursor-pointer"
          >
            <span>Proceed to Expert Validation →</span>
          </button>
        </div>
      </div>

      {decodeError && (
        <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl flex items-center space-x-2.5 text-xs text-amber-900">
          <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
          <span>{decodeError}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Computed Spectrogram & Pitch Extraction */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center space-x-2">
                <Layers className="w-4 h-4 text-emerald-700" />
                <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Time-Frequency Spectrogram & Anomaly Overlay
                </h2>
              </div>

              <div className="flex items-center space-x-2">
                <div className="flex bg-slate-100 p-0.5 rounded-xl border border-slate-200 text-[11px] font-bold">
                  {(['CNN', 'Wav2Vec2', 'BiLSTM', 'Ensemble'] as const).map((m) => (
                    <button
                      key={m}
                      onClick={() => setSelectedModel(m)}
                      className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                        selectedModel === m
                          ? 'bg-emerald-700 text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => setShowRegionsOverlay(!showRegionsOverlay)}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold border flex items-center space-x-1 transition-all cursor-pointer ${
                    showRegionsOverlay
                      ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                      : 'bg-slate-50 text-slate-600 border-slate-200'
                  }`}
                >
                  {showRegionsOverlay ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                  <span>{showRegionsOverlay ? 'DSP Overlay On' : 'DSP Overlay Off'}</span>
                </button>
              </div>
            </div>

            <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-xl flex items-start space-x-2 text-[11px] text-amber-900">
              <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <span>
                <strong>Model Attribution Disclosure ({selectedModel}):</strong> PyTorch {selectedModel} weights are currently <strong>NOT_CONFIGURED</strong> in this runtime. Spectrogram colors below depict objective measured STFT energy from the decoded audio PCM rather than synthetic Grad-CAM weights.
              </span>
            </div>

            <div className="relative bg-[#031D15] rounded-2xl border border-emerald-950/20 p-4 space-y-2 shadow-inner">
              <div className="flex justify-between items-center text-[10px] font-mono text-emerald-400">
                <span className="font-bold uppercase tracking-wider">
                  COMPUTED AUDIO STFT ENERGY DISTRIBUTION (0 kHz — {nyquistMax} kHz)
                </span>
                <span>{spectrogramData ? `DURATION: ${spectrogramData.durationSec.toFixed(1)}s` : 'NO PCM LOADED'}</span>
              </div>

              <div className="flex gap-2">
                <div className="flex flex-col justify-between text-[9px] font-mono text-emerald-400/90 text-right pr-1 select-none w-14 shrink-0 py-1">
                  <span>{nyquistMax.toFixed(1)} kHz</span>
                  <span>{(nyquistMax * 0.75).toFixed(1)} kHz</span>
                  <span>{(nyquistMax * 0.5).toFixed(1)} kHz</span>
                  <span>{(nyquistMax * 0.25).toFixed(1)} kHz</span>
                  <span>0.0 kHz</span>
                </div>

                <div className="flex-1 relative rounded-xl overflow-hidden border border-emerald-900/60">
                  <canvas
                    ref={canvasRef}
                    width={700}
                    height={220}
                    className="w-full h-52 block"
                  />
                </div>
              </div>

              <div className="flex justify-between text-[10px] text-emerald-400 font-mono pl-16 pr-2 pt-1 border-t border-emerald-900/50">
                <span>00:00.0</span>
                <span>{spectrogramData ? `00:${(spectrogramData.durationSec * 0.5).toFixed(1)}` : '--'}</span>
                <span>{spectrogramData ? `00:${spectrogramData.durationSec.toFixed(1)} (End)` : 'End'}</span>
              </div>
            </div>

            {/* Real DSP Irregular Regions List Below Spectrogram */}
            <div className="space-y-2 pt-2">
              <span className="text-[11px] font-bold uppercase text-slate-500 block">
                Measured Pitch & Discontinuity Regions (DSP Extracted):
              </span>
              {detectedRegions.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {detectedRegions.map((reg) => (
                    <div
                      key={reg.id}
                      onMouseEnter={() => setActiveHighlightId(reg.id)}
                      onMouseLeave={() => setActiveHighlightId(null)}
                      className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                        activeHighlightId === reg.id
                          ? 'bg-emerald-50 border-emerald-500 shadow-xs'
                          : 'bg-slate-50 border-slate-200 hover:border-emerald-300'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-slate-900">{reg.label}</span>
                        <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-rose-100 text-rose-800">
                          {reg.severity}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-600 mt-1">{reg.description}</p>
                      <div className="text-[10px] text-slate-500 font-mono mt-1">
                        Time Window: {reg.timeRange}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-[11px] text-slate-600">
                  {f0Result?.isAvailable
                    ? 'None Detected — Pitch tracking detected natural micro-variations across voiced segments.'
                    : 'No decodable voiced frames available to inspect discontinuity windows.'}
                </div>
              )}
            </div>
          </div>

          {/* Real Pitch (F0) Extraction & Line Chart Card */}
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2">
                <Activity className="w-4 h-4 text-emerald-700" />
                <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Real Fundamental Frequency (F0) Extraction & Pitch Jitter
                </h2>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleCustomAudioUpload}
                  accept="audio/*"
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-colors cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{customAudioName ? `Inspecting: ${customAudioName}` : 'Extract F0 from Audio File'}</span>
                </button>
              </div>
            </div>

            {f0Result && f0Result.isAvailable ? (
              <div className="space-y-3">
                <div className="p-3 bg-[#F0FDF4] border border-[#15803D]/20 rounded-xl flex items-center justify-between text-xs">
                  <span className="font-bold text-[#0A3D24]">Fundamental Frequency Analysis Summary</span>
                  <span className="text-[10px] font-mono bg-white px-2 py-0.5 rounded border border-[#E1EBE4] text-[#112217]">
                    Normalized Autocorrelation & YIN (Real DSP)
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                    <span className="text-[9px] uppercase font-bold text-slate-500 block">Average F0</span>
                    <span className="text-base font-bold font-mono text-emerald-900">{f0Result.avgF0} Hz</span>
                  </div>
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                    <span className="text-[9px] uppercase font-bold text-slate-500 block">Minimum F0</span>
                    <span className="text-base font-bold font-mono text-slate-800">{f0Result.minF0} Hz</span>
                  </div>
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                    <span className="text-[9px] uppercase font-bold text-slate-500 block">Maximum F0</span>
                    <span className="text-base font-bold font-mono text-slate-800">{f0Result.maxF0} Hz</span>
                  </div>
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                    <span className="text-[9px] uppercase font-bold text-slate-500 block">Median F0</span>
                    <span className="text-base font-bold font-mono text-slate-800">{f0Result.medianF0} Hz</span>
                  </div>
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl col-span-2 sm:col-span-1">
                    <span className="text-[9px] uppercase font-bold text-slate-500 block">Irregular Regions</span>
                    <span className="text-xs font-bold font-mono text-rose-700 truncate block">
                      {f0Result.irregularRegions.length > 0
                        ? f0Result.irregularRegions.map((r) => r.timeRange).join(', ')
                        : 'None Detected'}
                    </span>
                  </div>
                </div>
              </div>
            ) : f0Result && !f0Result.isAvailable ? (
              <div className="p-4 bg-amber-50 border border-amber-300 text-amber-900 rounded-2xl flex items-center space-x-3 text-xs">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                <div>
                  <p className="font-bold">F0 analysis unavailable for this audio.</p>
                  <p className="text-[11px] text-amber-800 mt-0.5">
                    Reason: {f0Result.unavailableReason || 'insufficient voiced segments/no reliable pitch detected.'}
                  </p>
                </div>
              </div>
            ) : null}

            {isAnalyzingF0 ? (
              <div className="h-60 w-full flex items-center justify-center bg-slate-50 rounded-2xl border border-dashed border-slate-300">
                <div className="flex items-center space-x-2 text-emerald-800 text-xs font-bold">
                  <RefreshCw className="w-4 h-4 animate-spin text-emerald-700" />
                  <span>Executing Normalized Autocorrelation & YIN Pitch DSP...</span>
                </div>
              </div>
            ) : chartData.length > 0 && f0Result?.isAvailable !== false ? (
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 px-1">
                  <span>Y-AXIS: FUNDAMENTAL FREQUENCY (Hz)</span>
                  <span>X-AXIS: TIME</span>
                </div>
                <div className="h-60 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                      <XAxis dataKey="time" stroke="#64748B" tick={{ fontSize: 10 }} />
                      <YAxis stroke="#64748B" unit=" Hz" domain={['dataMin - 20', 'dataMax + 20']} tick={{ fontSize: 10 }} />
                      <Tooltip contentStyle={{ backgroundColor: '#ffffff', borderColor: '#CBD5E1', borderRadius: '12px', fontSize: '11px' }} />
                      <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                      <Line
                        type="monotone"
                        dataKey="observedF0"
                        name="Observed Extracted F0 Evidence (Hz)"
                        stroke="#E11D48"
                        strokeWidth={2.5}
                        dot={{ r: 2, fill: '#E11D48' }}
                        connectNulls={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            ) : (
              <div className="p-6 text-center text-xs text-slate-500 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                Upload or select an audio exhibit with decodable voiced speech to plot its extracted F0 contour.
              </div>
            )}

            {f0Result && f0Result.irregularRegions.length > 0 && (
              <div className="p-3.5 bg-rose-50 border border-rose-300 rounded-2xl space-y-1.5 text-xs text-rose-900">
                <div className="flex items-center space-x-2 font-bold">
                  <AlertTriangle className="w-4 h-4 text-rose-700 shrink-0" />
                  <span>Acoustic Evidence Anomaly: Pitch Discontinuity / Flatline Discovered</span>
                </div>
                <p className="text-[11px] text-rose-800 leading-relaxed">
                  Autocorrelation analysis detected {f0Result.irregularRegions.length} anomalous region(s) requiring accredited human expert inspection under SWGDE standards.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Honest Attribution Readiness & Measured DSP Indicators */}
        <div className="lg:col-span-4 bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-5 shadow-sm">
          <div className="border-b border-slate-100 pb-3">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center space-x-1.5">
              <Cpu className="w-4 h-4 text-emerald-700" />
              <span>Feature Attribution & Acoustic Indicators</span>
            </h2>
            <p className="text-[11px] text-slate-500 mt-1">
              Honest reporting of TreeSHAP availability alongside measured physical DSP telemetry.
            </p>
          </div>

          <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl space-y-1.5 text-xs text-amber-900">
            <div className="flex items-center justify-between">
              <span className="font-bold">TreeSHAP / Grad-CAM Attribution</span>
              <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-amber-100 border border-amber-300">
                MODEL_UNAVAILABLE
              </span>
            </div>
            <p className="text-[11px] leading-relaxed">
              Neural TreeSHAP marginal scores require trained PyTorch / GBDT weights not configured in this enclave. Static placeholder SHAP values are disabled to prevent fabrication.
            </p>
          </div>

          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <h3 className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Measured Physical DSP Telemetry
              </h3>
              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                non-biometric measurement
              </span>
            </div>
            {measurements ? (
              <div className="space-y-2 text-xs">
                {[
                  { label: 'Mean Pitch (F0)', value: `${measurements.f0MeanHz} Hz`, note: `StdDev: ${measurements.f0StdDevHz} Hz (Range: ${measurements.pitchRangeSemitones} st)` },
                  { label: 'Cycle-to-Cycle Jitter', value: `${measurements.jitterPercent}%`, note: 'Normal conversational vocal range: 0.4% – 2.0%' },
                  { label: 'Amplitude Shimmer', value: `${measurements.shimmerPercent}%`, note: 'Cycle-to-cycle amplitude perturbation' },
                  { label: 'Harmonics-to-Noise (HNR)', value: `${measurements.hnrDb} dB`, note: 'Harmonic laryngeal periodicity clarity' },
                  { label: 'Spectral Centroid', value: `${measurements.spectralCentroidHz.toLocaleString()} Hz`, note: `Roll-off (85% power): ${measurements.spectralRollOffHz.toLocaleString()} Hz` },
                  { label: 'Estimated Signal SNR', value: `${measurements.estimatedSnrDb} dB`, note: `Clipping: ${measurements.clippingPercent}% | Voiced: ${measurements.voicedFractionPercent}%` }
                ].map((m, i) => (
                  <div key={i} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-0.5">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-slate-900">{m.label}</span>
                      <span className="font-mono font-bold text-emerald-800">{m.value}</span>
                    </div>
                    <p className="text-[10px] text-slate-500">{m.note}</p>
                  </div>
                ))}

                {nonBiometricProfile && (
                  <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-1.5">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-emerald-950 text-[11px]">
                        Mel / MFCC / LFCC & VAD Profile
                      </span>
                      <span className="text-[9px] font-mono text-emerald-800">
                        {nonBiometricProfile.measurementType}
                      </span>
                    </div>
                    <p className="text-[10px] font-mono text-slate-700">
                      VAD Active: {Math.round(nonBiometricProfile.vadActiveRatio * 100)}% (
                      {nonBiometricProfile.vadSegmentCount} voiced segments)
                    </p>
                    <p className="text-[10px] font-mono text-slate-600 truncate">
                      MFCC[0..3]: {nonBiometricProfile.mfccMean.slice(0, 4).join(', ')}
                    </p>
                    <p className="text-[10px] font-mono text-slate-600 truncate">
                      LFCC[0..3]: {nonBiometricProfile.lfccMean.slice(0, 4).join(', ')}
                    </p>
                  </div>
                )}

                <p className="text-[10px] text-slate-500 leading-relaxed pt-1">
                  Probabilistic decision support only: physical acoustic descriptors and spectrograms never establish identity or authenticity by themselves.
                </p>
              </div>
            ) : (
              <div className="p-5 bg-slate-50 border border-dashed border-slate-200 rounded-xl text-center text-[11px] text-slate-500">
                No decodable audio signal loaded yet. Load an uploaded audio exhibit or select an audio file to inspect acoustic parameters.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
