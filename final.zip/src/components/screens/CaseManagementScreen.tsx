import React, { useState, useEffect } from 'react';
import {
  Search,
  Plus,
  Filter,
  Eye,
  FileText,
  AlertTriangle,
  CheckCircle2,
  X,
  Lock,
  Shield,
  FolderKanban,
  Music,
  ArrowRight,
  Upload,
  Hash,
  Cpu,
  Clock,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { ScreenId, Case, CaseStatus, PriorityType, User, AudioEvidence } from '../../types';
import { canCreateCases, canAssignCaseCollaborators, canUploadEvidence, isReadOnlyForensics, ROLE_CONFIGS } from '../../utils/rbac';
import { BackButton } from '../common/BackButton';
import { authFetch, api } from '../../utils/api';

interface CaseManagementScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  setSelectedCaseId: (id: string) => void;
  cases: Case[];
  setCases: React.Dispatch<React.SetStateAction<Case[]>>;
  isNewCaseModalOpen: boolean;
  setIsNewCaseModalOpen: (open: boolean) => void;
  currentUser: User;
}

export const CaseManagementScreen: React.FC<CaseManagementScreenProps> = ({
  setCurrentScreen,
  setSelectedCaseId,
  cases,
  setCases,
  isNewCaseModalOpen,
  setIsNewCaseModalOpen,
  currentUser
}) => {
  const [activeTab, setActiveTab] = useState<'All' | CaseStatus>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [isSubmittingCase, setIsSubmittingCase] = useState(false);
  const [caseModalError, setCaseModalError] = useState<string | null>(null);

  // Selected Case Detail View Drawer/Modal
  const [inspectedCase, setInspectedCase] = useState<Case | null>(null);
  const [caseEvidence, setCaseEvidence] = useState<AudioEvidence[]>([]);
  const [loadingEvidence, setLoadingEvidence] = useState(false);
  const [updatingCase, setUpdatingCase] = useState(false);
  const [confirmArchiveCase, setConfirmArchiveCase] = useState(false);
  const [caseActionFeedback, setCaseActionFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Role permissions
  const userCanCreate = canCreateCases(currentUser.role);
  const userCanAssign = canAssignCaseCollaborators(currentUser.role);
  const userCanUpload = canUploadEvidence(currentUser.role);
  const isReadOnly = isReadOnlyForensics(currentUser.role);
  const roleConfig = ROLE_CONFIGS[currentUser.role];

  interface CollaboratorOption {
    id: string;
    name: string;
    email: string;
    role: string;
    agency: string;
    certificationId?: string;
  }
  const [collaborators, setCollaborators] = useState<CollaboratorOption[]>([]);
  const [selectedCollaboratorIds, setSelectedCollaboratorIds] = useState<string[]>([currentUser.id]);

  // Form state for New Case Modal
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newPriority, setNewPriority] = useState<PriorityType>('High');
  const [newAgency, setNewAgency] = useState(currentUser.agency || 'Federal Forensic Audio Division');
  const [newAnalyst, setNewAnalyst] = useState(currentUser.name);

  useEffect(() => {
    if (!userCanAssign) return;
    let cancelled = false;
    api
      .getCollaborators()
      .then((list) => {
        if (!cancelled && Array.isArray(list)) {
          setCollaborators(list);
        }
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [userCanAssign]);

  // Load evidence for inspected case
  useEffect(() => {
    if (inspectedCase) {
      async function loadCaseEvidence() {
        setLoadingEvidence(true);
        try {
          const res = await authFetch(`/api/evidence?caseId=${encodeURIComponent(inspectedCase.id)}`);
          if (res.ok) {
            const data = await res.json();
            if (Array.isArray(data)) {
              setCaseEvidence(data);
            }
          }
        } catch {
          // Keep empty array
        } finally {
          setLoadingEvidence(false);
        }
      }
      loadCaseEvidence();
    }
  }, [inspectedCase]);

  // Filter cases
  const filteredCases = cases.filter((c) => {
    const matchesTab = activeTab === 'All' ? true : c.status === activeTab;
    const matchesSearch =
      c.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.analyst.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.agency.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesTab && matchesSearch;
  });

  const handleCreateCase = async (e: React.FormEvent) => {
    e.preventDefault();
    setCaseModalError(null);

    if (!newTitle.trim()) {
      setCaseModalError('Case Docket Title is required.');
      return;
    }

    setIsSubmittingCase(true);
    try {
      const res = await authFetch('/api/cases', {
        method: 'POST',
        body: JSON.stringify({
          title: newTitle.trim(),
          description: newDesc.trim(),
          priority: newPriority,
          agency: newAgency,
          analyst: newAnalyst,
          createdBy: currentUser.email,
          assignedUserIds: Array.from(new Set([currentUser.id, ...selectedCollaboratorIds]))
        })
      });

      const data = await res.json().catch(() => null);
      setIsSubmittingCase(false);

      if (res.ok && data) {
        setCases([data, ...cases]);
        setSelectedCaseId(data.id);
        setIsNewCaseModalOpen(false);
        setNewTitle('');
        setNewDesc('');
        setSelectedCollaboratorIds([currentUser.id]);
        setCurrentScreen('evidence');
      } else {
        setCaseModalError(data?.error || 'Failed to create case docket on server.');
      }
    } catch {
      setIsSubmittingCase(false);
      setCaseModalError('Network error: Unable to contact forensic case docket service.');
    }
  };

  const handleTabChange = async (tab: 'All' | CaseStatus) => {
    setActiveTab(tab);
    setCaseActionFeedback(null);
    try {
      const refreshed = await api.getCases(tab === 'Archived');
      if (Array.isArray(refreshed)) {
        setCases(refreshed);
      }
    } catch {
      // Keep current list on transient failure
    }
  };

  const handleUpdateInspectedCase = async (updates: {
    status?: CaseStatus;
    assignedUserIds?: string[];
  }) => {
    if (!inspectedCase) return;
    setUpdatingCase(true);
    setCaseActionFeedback(null);
    try {
      const res = await authFetch(`/api/cases/${encodeURIComponent(inspectedCase.id)}`, {
        method: 'PATCH',
        body: JSON.stringify(updates)
      });
      const updated = await res.json().catch(() => null);
      if (res.ok && updated) {
        setInspectedCase(updated);
        setCases((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
      } else {
        setCaseActionFeedback({ type: 'error', text: updated?.error || 'Failed to update case docket.' });
      }
    } finally {
      setUpdatingCase(false);
    }
  };

  const handleArchiveInspectedCase = async () => {
    if (!inspectedCase) return;
    setUpdatingCase(true);
    setCaseActionFeedback(null);
    try {
      await api.archiveCase(inspectedCase.id);
      const archivedId = inspectedCase.id;
      setConfirmArchiveCase(false);
      setInspectedCase(null);
      const refreshed = await api.getCases(activeTab === 'Archived');
      if (Array.isArray(refreshed)) {
        setCases(refreshed);
      }
      setCaseActionFeedback({
        type: 'success',
        text: `Case ${archivedId} was archived non-destructively (evidence & audit logs preserved).`
      });
    } catch (err: any) {
      setCaseActionFeedback({ type: 'error', text: err?.message || 'Failed to archive case docket.' });
    } finally {
      setUpdatingCase(false);
    }
  };

  const toggleCreateCollaborator = (userId: string) => {
    if (userId === currentUser.id) return;
    setSelectedCollaboratorIds((prev) =>
      prev.includes(userId) ? prev.filter((id) => id !== userId) : [...prev, userId]
    );
  };

  const toggleInspectedCollaborator = (userId: string) => {
    if (!inspectedCase || userId === currentUser.id) return;
    const current = Array.isArray(inspectedCase.assignedUserIds)
      ? inspectedCase.assignedUserIds
      : [currentUser.id];
    const next = current.includes(userId)
      ? current.filter((id) => id !== userId)
      : [...current, userId];
    handleUpdateInspectedCase({ assignedUserIds: Array.from(new Set([currentUser.id, ...next])) });
  };

  return (
    <div id="cases-screen" className="p-6 space-y-6 bg-[#F8FAF9] min-h-full text-[#112217]">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E1EBE4] pb-5">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('dashboard')} label="Back to Dashboard" variant="pill" />
          </div>
          <div className="flex items-center space-x-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-[#112217] font-serif-title">
              Forensic Case Management
            </h1>
            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full border bg-[#FEF3C7] text-[#B2751E] border-[#C88A2C]/30 font-mono">
              {roleConfig?.shortLabel}
            </span>
          </div>
          <p className="text-xs text-[#54665C] mt-1">
            Docket registry, chain of custody tracking, and forensic examiner assignments.
          </p>
        </div>

        {userCanCreate ? (
          <button
            id="new-case-modal-trigger-btn"
            onClick={() => {
              setCaseModalError(null);
              setIsNewCaseModalOpen(true);
            }}
            className="px-4 py-2.5 bg-[#0A3D24] hover:bg-[#062817] text-white font-bold text-xs rounded-xl shadow-xs flex items-center space-x-2 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create Case Docket</span>
          </button>
        ) : (
          <div className="px-3.5 py-2 bg-white border border-[#E1EBE4] rounded-xl text-xs text-[#54665C] flex items-center space-x-2 shadow-xs">
            <Lock className="w-3.5 h-3.5 text-[#54665C]" />
            <span>Docket Creation: Lead Analyst Only</span>
          </div>
        )}
      </div>

      {caseActionFeedback && (
        <div
          className={`p-3 rounded-2xl border text-xs flex items-center justify-between ${
            caseActionFeedback.type === 'success'
              ? 'bg-[#F0FDF4] border-[#15803D]/30 text-[#15803D]'
              : 'bg-[#FEF2F2] border-[#B91C1C]/30 text-[#B91C1C]'
          }`}
        >
          <span>{caseActionFeedback.text}</span>
          <button onClick={() => setCaseActionFeedback(null)} className="p-1 cursor-pointer">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-stretch md:items-center">
        {/* Status Tabs */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-2 md:pb-0">
          {(['All', 'Active', 'Under Review', 'Pending Legal', 'Completed', 'Archived'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => handleTabChange(tab)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === tab
                  ? 'bg-[#0A3D24] text-white shadow-xs'
                  : 'bg-white border border-[#E1EBE4] text-[#54665C] hover:bg-[#F0FDF4] hover:text-[#0A3D24]'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Search Bar */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-[#54665C] absolute left-3 top-2.5 pointer-events-none" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search docket ID, title, analyst..."
            className="w-full bg-white border border-[#E1EBE4] rounded-xl pl-9 pr-3 py-2 text-xs text-[#112217] placeholder-slate-400 focus:outline-none focus:border-[#0A3D24] shadow-xs"
          />
        </div>
      </div>

      {/* Case Table Container */}
      <div className="bg-white border border-[#E1EBE4] rounded-3xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#112217]">
            <thead className="bg-[#F8FAF9] border-b border-[#E1EBE4] text-[#0A3D24] uppercase text-[10px] font-bold tracking-wider">
              <tr>
                <th className="py-3.5 px-4 font-mono">Docket ID</th>
                <th className="py-3.5 px-4">Case Title</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Verdict</th>
                <th className="py-3.5 px-4">Priority</th>
                <th className="py-3.5 px-4">Lead Examiner / Agency</th>
                <th className="py-3.5 px-4">Evidence</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E1EBE4]">
              {filteredCases.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-[#54665C]">
                    <FolderKanban className="w-8 h-8 text-[#54665C] mx-auto mb-2 opacity-50" />
                    <p className="font-bold text-xs text-[#112217]">No Forensic Dockets Found</p>
                    <p className="text-[11px] text-[#54665C] mt-0.5">
                      {searchTerm ? 'No cases match your search query.' : 'Initialize your first case docket to begin.'}
                    </p>
                  </td>
                </tr>
              ) : (
                filteredCases.map((c) => (
                  <tr
                    key={c.id}
                    className="hover:bg-[#F0FDF4]/60 transition-colors group cursor-pointer"
                    onClick={() => {
                      setSelectedCaseId(c.id);
                      setInspectedCase(c);
                    }}
                  >
                    <td className="py-3.5 px-4 font-mono font-bold text-[#0A3D24] whitespace-nowrap">
                      {c.id}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-[#112217] max-w-xs truncate">
                      {c.title}
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#F8FAF9] text-[#54665C] border border-[#E1EBE4]">
                        {c.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border ${
                          c.verdict === 'DEEPFAKE'
                            ? 'bg-[#FEF2F2] text-[#B91C1C] border-[#B91C1C]/30'
                            : c.verdict === 'AUTHENTIC'
                            ? 'bg-[#F0FDF4] text-[#15803D] border-[#15803D]/30'
                            : 'bg-slate-100 text-slate-700 border-slate-300'
                        }`}
                      >
                        {c.verdict}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          c.priority === 'Critical'
                            ? 'bg-[#FEF2F2] text-[#B91C1C]'
                            : c.priority === 'High'
                            ? 'bg-[#FEF3C7] text-[#B2751E]'
                            : 'bg-[#F8FAF9] text-[#54665C]'
                        }`}
                      >
                        {c.priority}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap text-[#54665C]">
                      <span className="font-semibold text-[#112217]">{c.analyst}</span>
                      <span className="text-[10px] text-[#54665C] block">{c.agency}</span>
                    </td>
                    <td className="py-3.5 px-4 font-mono font-bold text-[#112217] whitespace-nowrap">
                      {c.evidenceCount} item(s)
                    </td>
                    <td className="py-3.5 px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end space-x-1.5">
                        <button
                          onClick={() => {
                            setSelectedCaseId(c.id);
                            setInspectedCase(c);
                          }}
                          className="p-1.5 text-[#0A3D24] hover:bg-[#F0FDF4] rounded-lg transition-colors cursor-pointer"
                          title="Inspect Case Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            setSelectedCaseId(c.id);
                            setCurrentScreen('evidence');
                          }}
                          className="p-1.5 text-[#54665C] hover:text-[#0A3D24] hover:bg-[#F0FDF4] rounded-lg transition-colors cursor-pointer"
                          title="Evidence Locker"
                        >
                          <Music className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            setSelectedCaseId(c.id);
                            setCurrentScreen('report-generation');
                          }}
                          className="p-1.5 text-[#54665C] hover:text-[#0A3D24] hover:bg-[#F0FDF4] rounded-lg transition-colors cursor-pointer"
                          title="Generate Forensic Report"
                        >
                          <FileText className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Case Details Inspector Modal */}
      {inspectedCase && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#E1EBE4] rounded-3xl max-w-2xl w-full p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between border-b border-[#E1EBE4] pb-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-[#F0FDF4] border border-[#15803D]/20 text-[#0A3D24] flex items-center justify-center">
                  <FolderKanban className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-mono font-bold text-xs text-[#0A3D24]">{inspectedCase.id}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded border bg-slate-100 text-slate-700">
                      {inspectedCase.status}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-[#112217] mt-0.5 font-serif-title">
                    {inspectedCase.title}
                  </h3>
                </div>
              </div>
              <button
                onClick={() => setInspectedCase(null)}
                className="text-[#54665C] hover:text-[#112217] p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Case Metadata */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#F8FAF9] p-4 rounded-2xl border border-[#E1EBE4] text-xs">
              <div>
                <span className="text-[10px] text-[#54665C] block">Priority:</span>
                <span className="font-bold text-[#112217]">{inspectedCase.priority}</span>
              </div>
              <div>
                <span className="text-[10px] text-[#54665C] block mb-0.5">Verdict (Read-Only):</span>
                <span className="font-mono font-bold text-[#0A3D24] block">{inspectedCase.verdict}</span>
                <span className="text-[10px] text-[#54665C] block">Derived via Analysis / Expert Review</span>
              </div>
              <div>
                <span className="text-[10px] text-[#54665C] block mb-0.5">Docket Status:</span>
                {userCanCreate && inspectedCase.status !== 'Archived' ? (
                  <select
                    disabled={updatingCase}
                    value={inspectedCase.status}
                    onChange={(e) => handleUpdateInspectedCase({ status: e.target.value as CaseStatus })}
                    className="bg-white border border-[#E1EBE4] rounded-lg px-2 py-1 font-semibold text-[#112217] text-[11px]"
                  >
                    <option value="Active">Active</option>
                    <option value="Under Review">Under Review</option>
                    <option value="Pending Legal">Pending Legal</option>
                    <option value="Completed">Completed</option>
                  </select>
                ) : (
                  <span className="font-semibold text-[#112217]">{inspectedCase.status}</span>
                )}
              </div>
              <div>
                <span className="text-[10px] text-[#54665C] block">Docket Date:</span>
                <span className="font-mono text-[#112217]">{inspectedCase.date}</span>
              </div>
            </div>

            {/* Synopsis */}
            {inspectedCase.description && (
              <div className="space-y-1 text-xs">
                <span className="font-bold text-[#112217]">Docket Synopsis / Allegation:</span>
                <p className="text-[#54665C] bg-[#F8FAF9] p-3 rounded-xl border border-[#E1EBE4] leading-relaxed">
                  {inspectedCase.description}
                </p>
              </div>
            )}

            {/* Case-Level Collaborator ACL Assignment (Lead Analyst Only) */}
            {userCanAssign && collaborators.length > 0 && (
              <div className="space-y-1.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#112217]">Authorized Case Collaborators (Case-Level ACL):</span>
                  <span className="text-[10px] font-mono text-[#54665C]">
                    {(inspectedCase.assignedUserIds || [currentUser.id]).length} assigned
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-32 overflow-y-auto bg-[#F8FAF9] p-2.5 rounded-xl border border-[#E1EBE4]">
                  {collaborators.map((collab) => {
                    const checked =
                      collab.id === currentUser.id ||
                      (inspectedCase.assignedUserIds || []).includes(collab.id);
                    return (
                      <label
                        key={collab.id}
                        className="flex items-center space-x-2 p-1.5 rounded-lg hover:bg-white cursor-pointer text-[11px]"
                      >
                        <input
                          type="checkbox"
                          disabled={updatingCase || collab.id === currentUser.id}
                          checked={checked}
                          onChange={() => toggleInspectedCollaborator(collab.id)}
                          className="rounded text-[#0A3D24]"
                        />
                        <div className="truncate">
                          <span className="font-semibold text-[#112217]">{collab.name}</span>
                          <span className="text-[10px] text-[#54665C] block truncate">{collab.role}</span>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Associated Evidence Items */}
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-[#112217] flex items-center space-x-1.5">
                  <Music className="w-4 h-4 text-[#0A3D24]" />
                  <span>Associated Evidence Files ({caseEvidence.length})</span>
                </span>
                {userCanUpload && (
                  <button
                    onClick={() => {
                      setSelectedCaseId(inspectedCase.id);
                      setInspectedCase(null);
                      setCurrentScreen('evidence');
                    }}
                    className="text-[11px] font-bold text-[#0A3D24] hover:text-[#062817] flex items-center space-x-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Upload to this Docket</span>
                  </button>
                )}
              </div>

              {loadingEvidence ? (
                <div className="p-4 text-center text-[#54665C] italic">Loading evidence items...</div>
              ) : caseEvidence.length === 0 ? (
                <div className="p-4 bg-[#F8FAF9] rounded-xl border border-[#E1EBE4] text-center text-[#54665C]">
                  No audio evidence files attached to this case yet.
                </div>
              ) : (
                <div className="space-y-1.5 max-h-48 overflow-y-auto">
                  {caseEvidence.map((ev) => (
                    <div
                      key={ev.id}
                      className="p-3 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl flex items-center justify-between text-xs"
                    >
                      <div className="space-y-0.5 truncate pr-2">
                        <p className="font-bold text-[#112217] truncate">{ev.filename}</p>
                        <p className="text-[10px] font-mono text-[#54665C]">
                          SHA-256: {ev.sha256Hash ? `${ev.sha256Hash.slice(0, 16)}...` : 'Pending'}
                        </p>
                      </div>
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-white border border-[#E1EBE4] text-[#54665C] shrink-0">
                        {ev.fileSize}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Actions */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-4 border-t border-[#E1EBE4]">
              <div>
                {userCanCreate && inspectedCase.status !== 'Archived' && (
                  confirmArchiveCase ? (
                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        disabled={updatingCase}
                        onClick={handleArchiveInspectedCase}
                        className="px-3 py-1.5 bg-[#B91C1C] hover:bg-red-800 text-white font-bold text-[11px] rounded-xl cursor-pointer disabled:opacity-50"
                      >
                        {updatingCase ? 'Archiving...' : 'Confirm Archive'}
                      </button>
                      <button
                        type="button"
                        disabled={updatingCase}
                        onClick={() => setConfirmArchiveCase(false)}
                        className="px-3 py-1.5 bg-white border border-[#E1EBE4] text-[#54665C] font-bold text-[11px] rounded-xl cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmArchiveCase(true)}
                      className="px-3.5 py-2 bg-white border border-[#B91C1C]/30 hover:bg-[#FEF2F2] text-[#B91C1C] font-bold text-xs rounded-xl cursor-pointer"
                    >
                      Archive Case
                    </button>
                  )
                )}
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    setSelectedCaseId(inspectedCase.id);
                    setConfirmArchiveCase(false);
                    setInspectedCase(null);
                    setCurrentScreen('detection-results');
                  }}
                  className="px-4 py-2 bg-white border border-[#E1EBE4] hover:bg-slate-50 text-[#112217] font-bold text-xs rounded-xl cursor-pointer"
                >
                  View Detection Results
                </button>
                <button
                  onClick={() => {
                    setSelectedCaseId(inspectedCase.id);
                    setConfirmArchiveCase(false);
                    setInspectedCase(null);
                    setCurrentScreen('evidence');
                  }}
                  className="px-4 py-2 bg-[#0A3D24] hover:bg-[#062817] text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer flex items-center space-x-1.5"
                >
                  <span>Evidence Locker</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* New Case Modal (Lead Analyst Privilege) */}
      {isNewCaseModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#E1EBE4] rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-4">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-[#F0FDF4] border border-[#15803D]/20 rounded-xl text-[#0A3D24]">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#112217] font-serif-title">
                    Initiate Forensic Case Docket
                  </h3>
                  <p className="text-[11px] text-[#54665C]">Chain of Custody Registered Intake</p>
                </div>
              </div>
              <button
                onClick={() => setIsNewCaseModalOpen(false)}
                className="text-[#54665C] hover:text-[#112217] p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {caseModalError && (
              <div className="p-3 bg-[#FEF2F2] border border-[#B91C1C]/30 text-[#B91C1C] text-xs rounded-xl flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{caseModalError}</span>
              </div>
            )}

            <form onSubmit={handleCreateCase} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-[11px] font-bold uppercase text-[#54665C] block">
                  Case Docket Title *
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Wire Intercept Voice Clone Examination"
                  className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl px-3.5 py-2.5 text-[#112217] focus:outline-none focus:border-[#0A3D24] focus:bg-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold uppercase text-[#54665C] block">
                  Incident Synopsis / Allegation
                </label>
                <textarea
                  rows={3}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Describe context of the intercepted audio recording..."
                  className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl px-3.5 py-2.5 text-[#112217] focus:outline-none focus:border-[#0A3D24] focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold uppercase text-[#54665C] block">
                    Priority Level
                  </label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as PriorityType)}
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl px-3 py-2 text-[#112217] focus:outline-none focus:border-[#0A3D24]"
                  >
                    <option value="Critical">Critical</option>
                    <option value="High">High Priority</option>
                    <option value="Medium">Medium Priority</option>
                    <option value="Low">Low Priority</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold uppercase text-[#54665C] block">
                    Lead Examiner
                  </label>
                  <input
                    type="text"
                    value={newAnalyst}
                    onChange={(e) => setNewAnalyst(e.target.value)}
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl px-3 py-2 text-[#112217] focus:outline-none focus:border-[#0A3D24]"
                  />
                </div>
              </div>

              {userCanAssign && collaborators.length > 0 && (
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold uppercase text-[#54665C] block">
                    Assign Examiners / Legal Reviewers (Case ACL)
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-28 overflow-y-auto bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5">
                    {collaborators.map((collab) => {
                      const isSelf = collab.id === currentUser.id;
                      const checked = isSelf || selectedCollaboratorIds.includes(collab.id);
                      return (
                        <label
                          key={collab.id}
                          className="flex items-center space-x-2 text-[11px] p-1 rounded hover:bg-white cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            disabled={isSelf}
                            checked={checked}
                            onChange={() => toggleCreateCollaborator(collab.id)}
                            className="rounded text-[#0A3D24]"
                          />
                          <div className="truncate">
                            <span className="font-semibold text-[#112217]">{collab.name}</span>
                            <span className="text-[10px] text-[#54665C] block truncate">{collab.role}</span>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="flex space-x-3 pt-3 border-t border-[#E1EBE4]">
                <button
                  type="button"
                  onClick={() => setIsNewCaseModalOpen(false)}
                  disabled={isSubmittingCase}
                  className="flex-1 py-2.5 bg-white border border-[#E1EBE4] hover:bg-slate-50 text-[#112217] font-bold text-xs rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingCase}
                  className="flex-1 py-2.5 bg-[#0A3D24] hover:bg-[#062817] disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center space-x-1.5 cursor-pointer"
                >
                  {isSubmittingCase ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Creating Docket...</span>
                    </>
                  ) : (
                    <span>Save & Open Evidence Locker</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
