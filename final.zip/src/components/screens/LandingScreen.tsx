import React, { useState } from 'react';
import {
  Shield,
  ShieldCheck,
  Lock,
  ArrowRight,
  FileCheck2,
  FileText,
  Activity,
  Layers,
  Search,
  ExternalLink,
  Cpu,
  Sparkles,
  Users,
  ChevronRight,
  CheckCircle2,
  Scale,
  Music,
  Hash,
  Info
} from 'lucide-react';
import { ScreenId } from '../../types';

interface LandingScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
}

export const LandingScreen: React.FC<LandingScreenProps> = ({ setCurrentScreen }) => {
  const [activeTab, setActiveTab] = useState<'evidence' | 'pipeline' | 'speaker' | 'reports'>('evidence');

  return (
    <div id="landing-screen" className="min-h-full bg-[#F8FAF9] text-[#112217] pb-20 selection:bg-[#0A3D24] selection:text-white">
      {/* Public Navigation Header */}
      <nav className="bg-white border-b border-[#E1EBE4] sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setCurrentScreen('landing')}>
            <div className="w-9 h-9 rounded-xl bg-[#0A3D24] p-0.5 flex items-center justify-center shadow-sm">
              <Shield className="w-5 h-5 text-[#C88A2C]" />
            </div>
            <div>
              <span className="font-extrabold text-[#112217] tracking-tight text-base font-serif-title">ALFADetect</span>
              <span className="text-[10px] font-mono font-bold uppercase text-[#0A3D24] block leading-none">
                FORENSIC AUDIO ENCLAVE
              </span>
            </div>
          </div>

          <div className="hidden md:flex items-center space-x-6 text-xs font-semibold text-[#54665C]">
            <a href="#overview" className="hover:text-[#0A3D24] transition-colors">Overview</a>
            <a href="#capabilities" className="hover:text-[#0A3D24] transition-colors">Capabilities</a>
            <button onClick={() => setCurrentScreen('workflow')} className="hover:text-[#0A3D24] transition-colors cursor-pointer">
              Workflow
            </button>
            <a href="#about" className="hover:text-[#0A3D24] transition-colors">About</a>
            <button onClick={() => setCurrentScreen('public-verify')} className="hover:text-[#C88A2C] transition-colors cursor-pointer flex items-center space-x-1">
              <ExternalLink className="w-3 h-3" />
              <span>Verify Token</span>
            </button>
          </div>

          <div className="flex items-center space-x-2.5">
            <button
              onClick={() => setCurrentScreen('signin')}
              className="px-4 py-2 text-xs font-bold text-[#0A3D24] hover:text-[#062817] hover:bg-[#F0FDF4] rounded-xl transition-colors cursor-pointer"
            >
              Sign In
            </button>
            <button
              onClick={() => setCurrentScreen('request-access')}
              className="px-4 py-2 bg-[#0A3D24] hover:bg-[#062817] text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer flex items-center space-x-1.5"
            >
              <span>Get Started</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="overview" className="relative overflow-hidden pt-12 pb-16 px-4 sm:px-6 lg:px-8 border-b border-[#E1EBE4] bg-white">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Hero Content */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center space-x-2 px-3 py-1 bg-[#F0FDF4] border border-[#15803D]/20 text-[#0A3D24] text-xs font-bold rounded-full">
              <ShieldCheck className="w-3.5 h-3.5 text-[#15803D]" />
              <span>Digital Forensics & Legal Evidence Verification</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#112217] tracking-tight leading-[1.15] font-serif-title">
              Explainable AI-Based Detection of <br />
              <span className="text-[#0A3D24]">Deepfake Audio</span> for Digital Forensics
            </h1>

            <p className="text-sm sm:text-base text-[#54665C] leading-relaxed max-w-2xl">
              ALFADetect is an institutional software platform designed for forensic investigators, acoustic experts, and legal professionals to inspect, verify, and document disputed audio evidence with cryptographic integrity and full evidentiary traceability.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => setCurrentScreen('signin')}
                className="px-6 py-3.5 bg-[#0A3D24] hover:bg-[#062817] text-white font-bold text-xs rounded-xl shadow-md flex items-center space-x-2 transition-all cursor-pointer"
              >
                <Lock className="w-4 h-4 text-[#C88A2C]" />
                <span>Get Started</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setCurrentScreen('workflow')}
                className="px-5 py-3.5 bg-white border border-[#E1EBE4] hover:border-[#0A3D24] hover:bg-[#F0FDF4] text-[#112217] font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center space-x-2"
              >
                <Layers className="w-4 h-4 text-[#0A3D24]" />
                <span>Explore Platform</span>
              </button>

              <button
                onClick={() => setCurrentScreen('request-access')}
                className="px-4 py-3.5 text-[#54665C] hover:text-[#0A3D24] text-xs font-bold rounded-xl transition-all cursor-pointer"
              >
                Request Clearance
              </button>
            </div>

            {/* Core Trust Framework Pillars (Honest, factual standards) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-[#E1EBE4]">
              <div>
                <p className="text-xl sm:text-2xl font-bold text-[#0A3D24] font-serif-title">SHA-256</p>
                <p className="text-[11px] text-[#54665C] mt-0.5">Bitstream Ingest Hash</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-bold text-[#112217] font-serif-title">Audit Trail</p>
                <p className="text-[11px] text-[#54665C] mt-0.5">Chain of Custody</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-bold text-[#0A3D24] font-serif-title">Multi-Model</p>
                <p className="text-[11px] text-[#54665C] mt-0.5">Planned AI Ensemble</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-bold text-[#C88A2C] font-serif-title">FRE / SWGDE</p>
                <p className="text-[11px] text-[#54665C] mt-0.5">Procedural Guidelines</p>
              </div>
            </div>
          </div>

          {/* Right Hero: Tasteful Forensic Audio Visualization */}
          <div className="lg:col-span-5">
            <div className="bg-[#F8FAF9] border border-[#E1EBE4] rounded-3xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-3">
                <div className="flex items-center space-x-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#15803D]" />
                  <span className="text-xs font-bold text-[#112217]">Forensic Audio Inspection Enclave</span>
                </div>
                <span className="text-[10px] font-mono text-[#54665C]">Bitstream Analysis</span>
              </div>

              {/* Static Forensic Spectro-Temporal Diagram */}
              <div className="bg-[#062817] rounded-2xl p-4 text-white space-y-3">
                <div className="flex justify-between items-center text-[11px] font-mono text-emerald-300">
                  <span>SPECTRAL DENSITY MAP</span>
                  <span className="text-[#C88A2C]">0 Hz - 22,050 Hz</span>
                </div>

                {/* Static Frequency Bands Grid */}
                <div className="grid grid-cols-12 gap-1 h-28 p-2 bg-black/40 rounded-xl border border-emerald-900/60">
                  {Array.from({ length: 48 }).map((_, i) => {
                    const row = Math.floor(i / 12);
                    const isMidHigh = row === 1 || row === 2;
                    const isAnomalyZone = isMidHigh && i % 12 > 4 && i % 12 < 9;
                    return (
                      <div
                        key={i}
                        className={`rounded-xs transition-opacity ${
                          isAnomalyZone
                            ? 'bg-[#C88A2C]/80'
                            : row === 0
                            ? 'bg-[#15803D]'
                            : row === 1
                            ? 'bg-[#135A37]'
                            : row === 2
                            ? 'bg-[#0A3D24]'
                            : 'bg-emerald-950'
                        }`}
                      />
                    );
                  })}
                </div>

                <div className="flex justify-between text-[10px] font-mono text-emerald-300/70">
                  <span>0.00s Ingest Intake</span>
                  <span>Harmonic Formants</span>
                  <span>4.12s Time Horizon</span>
                </div>
              </div>

              {/* Evidence Overview Box */}
              <div className="p-3.5 bg-white border border-[#E1EBE4] rounded-2xl space-y-2 text-xs">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-[#54665C]">Integrity Verification:</span>
                  <span className="font-mono font-bold text-[#15803D] flex items-center space-x-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Cryptographic SHA-256 Match</span>
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-[#54665C]">Analysis Pipeline:</span>
                  <span className="font-mono font-semibold text-[#0A3D24]">
                    Multi-Model Enclave Ready
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-[#54665C]">Speaker Matching:</span>
                  <span className="font-mono text-[#54665C]">
                    Planned Integration
                  </span>
                </div>
              </div>

              <button
                onClick={() => setCurrentScreen('signin')}
                className="w-full py-2.5 bg-[#0A3D24] hover:bg-[#062817] text-white text-xs font-bold rounded-xl transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                <span>Enter Workspace</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Supporting Sections */}
      <section id="capabilities" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
        <div className="text-center max-w-3xl mx-auto space-y-2">
          <span className="text-[11px] font-mono font-bold text-[#0A3D24] uppercase tracking-wider bg-[#F0FDF4] px-3 py-1 rounded-full border border-[#15803D]/20">
            Forensic Capabilities
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#112217] font-serif-title">
            Engineered for Legal & Investigative Rigor
          </h2>
          <p className="text-xs sm:text-sm text-[#54665C] leading-relaxed">
            A comprehensive suite of forensic audio workflows designed to support judicial review, law enforcement investigation, and scientific examination.
          </p>
        </div>

        {/* 5 Core Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {/* Pillar 1: Evidence Integrity & Chain of Custody */}
          <div className="bg-white border border-[#E1EBE4] rounded-2xl p-6 shadow-xs hover:border-[#0A3D24] transition-all space-y-3.5">
            <div className="w-11 h-11 rounded-xl bg-[#F0FDF4] border border-[#15803D]/20 flex items-center justify-center text-[#0A3D24]">
              <Hash className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#112217] font-serif-title">
              Evidence Integrity & Chain of Custody
            </h3>
            <p className="text-xs text-[#54665C] leading-relaxed">
              Every ingested audio recording is fingerprinted with real bitstream SHA-256 digests upon upload. An append-only audit trail logs every access, inspection, and verification event to ensure court traceability.
            </p>
            <div className="pt-2 text-[11px] font-mono font-bold text-[#0A3D24] flex items-center space-x-1">
              <span>Immutable Ingestion Logs</span>
            </div>
          </div>

          {/* Pillar 2: Deepfake Audio Analysis Workflow */}
          <div className="bg-white border border-[#E1EBE4] rounded-2xl p-6 shadow-xs hover:border-[#0A3D24] transition-all space-y-3.5">
            <div className="w-11 h-11 rounded-xl bg-[#F0FDF4] border border-[#15803D]/20 flex items-center justify-center text-[#0A3D24]">
              <Cpu className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#112217] font-serif-title">
              Deepfake Audio Analysis Pipeline
            </h3>
            <p className="text-xs text-[#54665C] leading-relaxed">
              Architected to integrate state-of-the-art neural architectures (CNN Mel-Spectrogram, BiLSTM Temporal, and Wav2Vec2 Contextual Transformers) to examine acoustic phase discontinuities and synthetic vocoder artifacts.
            </p>
            <div className="pt-2 text-[11px] font-mono font-bold text-[#0A3D24] flex items-center space-x-1">
              <span>Ensemble Model Integration Ready</span>
            </div>
          </div>

          {/* Pillar 3: Reference Voice & Speaker Verification (Honest planned status) */}
          <div className="bg-white border border-[#E1EBE4] rounded-2xl p-6 shadow-xs hover:border-[#0A3D24] transition-all space-y-3.5">
            <div className="w-11 h-11 rounded-xl bg-[#FEF3C7] border border-[#C88A2C]/30 flex items-center justify-center text-[#B2751E]">
              <Users className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#112217] font-serif-title">
              Speaker Verification & Voice Matching
            </h3>
            <p className="text-xs text-[#54665C] leading-relaxed">
              Provides enrollment of verified reference exemplars with declared legal consent. Designed to compare questioned audio against known exemplars with mandatory forensic caveats when synthetic conversion is present.
            </p>
            <div className="pt-2 text-[11px] font-mono font-bold text-[#B2751E] flex items-center space-x-1">
              <span>Planned Integration Workflow</span>
            </div>
          </div>

          {/* Pillar 4: Explainable Analysis & Forensic Reporting */}
          <div className="bg-white border border-[#E1EBE4] rounded-2xl p-6 shadow-xs hover:border-[#0A3D24] transition-all space-y-3.5">
            <div className="w-11 h-11 rounded-xl bg-[#F0FDF4] border border-[#15803D]/20 flex items-center justify-center text-[#0A3D24]">
              <Sparkles className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#112217] font-serif-title">
              Explainable AI (XAI) & Reporting
            </h3>
            <p className="text-xs text-[#54665C] leading-relaxed">
              Avoids opaque black-box scores by preparing visual heatmaps and SHAP feature attribution containers, paired with standardized court-admissible PDF report generation for judicial presentation.
            </p>
            <div className="pt-2 text-[11px] font-mono font-bold text-[#0A3D24] flex items-center space-x-1">
              <span>Court-Admissible PDF Export</span>
            </div>
          </div>

          {/* Pillar 5: Security-Conscious Access & Case Management */}
          <div className="bg-white border border-[#E1EBE4] rounded-2xl p-6 shadow-xs hover:border-[#0A3D24] transition-all space-y-3.5">
            <div className="w-11 h-11 rounded-xl bg-[#F0FDF4] border border-[#15803D]/20 flex items-center justify-center text-[#0A3D24]">
              <Lock className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#112217] font-serif-title">
              Role-Based Access & Governance
            </h3>
            <p className="text-xs text-[#54665C] leading-relaxed">
              Strictly partitions duties between Investigators, Forensic Examiners, Legal Reviewers, and System Administrators. Registration requests require administrator verification before access to evidence is granted.
            </p>
            <div className="pt-2 text-[11px] font-mono font-bold text-[#0A3D24] flex items-center space-x-1">
              <span>Zero-Trust RBAC Enforced</span>
            </div>
          </div>

          {/* Pillar 6: Public Token Verification */}
          <div className="bg-white border border-[#E1EBE4] rounded-2xl p-6 shadow-xs hover:border-[#0A3D24] transition-all space-y-3.5">
            <div className="w-11 h-11 rounded-xl bg-[#F0FDF4] border border-[#15803D]/20 flex items-center justify-center text-[#0A3D24]">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#112217] font-serif-title">
              Public Report Token Verification
            </h3>
            <p className="text-xs text-[#54665C] leading-relaxed">
              External judicial parties can verify the authenticity of issued forensic reports and evidence hashes through unique verification tokens without exposing confidential case details.
            </p>
            <div className="pt-2 text-[11px] font-mono font-bold text-[#0A3D24] flex items-center space-x-1">
              <span>Cross-Party Validation</span>
            </div>
          </div>
        </div>
      </section>

      {/* Intended User Personas Section */}
      <section id="about" className="py-14 bg-white border-y border-[#E1EBE4] px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="text-2xl font-bold text-[#112217] font-serif-title">
              Tailored for Specialized Forensic Roles
            </h2>
            <p className="text-xs text-[#54665C]">
              Distinct workspaces designed for every phase of judicial evidence processing.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            <div className="p-5 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2.5">
              <span className="text-[10px] font-mono font-bold text-[#0A3D24] uppercase px-2 py-0.5 bg-[#F0FDF4] rounded border border-[#15803D]/20">
                Investigators
              </span>
              <h4 className="font-bold text-sm text-[#112217]">Lead Forensic Analysts</h4>
              <p className="text-xs text-[#54665C] leading-relaxed">
                Open case dockets, ingest audio evidence, review multi-model outcomes, and manage chain of custody.
              </p>
            </div>

            <div className="p-5 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2.5">
              <span className="text-[10px] font-mono font-bold text-[#0A3D24] uppercase px-2 py-0.5 bg-[#F0FDF4] rounded border border-[#15803D]/20">
                Acoustic Specialists
              </span>
              <h4 className="font-bold text-sm text-[#112217]">Forensic Examiners</h4>
              <p className="text-xs text-[#54665C] leading-relaxed">
                Conduct deep signal analysis, verify pitch micro-tremors, execute voice comparisons, and submit expert affidavits.
              </p>
            </div>

            <div className="p-5 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2.5">
              <span className="text-[10px] font-mono font-bold text-[#0A3D24] uppercase px-2 py-0.5 bg-[#F0FDF4] rounded border border-[#15803D]/20">
                Legal Counsel
              </span>
              <h4 className="font-bold text-sm text-[#112217]">Prosecutors & Reviewers</h4>
              <p className="text-xs text-[#54665C] leading-relaxed">
                Review verified findings, examine chain-of-custody provenance, and certify Daubert admissibility checklists.
              </p>
            </div>

            <div className="p-5 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2.5">
              <span className="text-[10px] font-mono font-bold text-[#0A3D24] uppercase px-2 py-0.5 bg-[#F0FDF4] rounded border border-[#15803D]/20">
                Security Officers
              </span>
              <h4 className="font-bold text-sm text-[#112217]">System Administrators</h4>
              <p className="text-xs text-[#54665C] leading-relaxed">
                Review pending registration applications, manage user credentials, and audit all platform operations.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Footer Banner */}
      <section className="pt-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="bg-[#062817] rounded-3xl p-8 sm:p-12 text-white border border-[#0A3D24] flex flex-col md:flex-row items-center justify-between gap-8 shadow-xl">
          <div className="space-y-3 max-w-xl">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-[#15803D] animate-pulse" />
              <span className="text-xs uppercase font-mono tracking-widest text-[#C88A2C] font-bold">
                OPERATIONAL SECURITY ENCLAVE
              </span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-bold tracking-tight font-serif-title">
              Enter the Forensic Analysis Platform
            </h3>
            <p className="text-xs sm:text-sm text-emerald-200/80 leading-relaxed">
              Sign in with your institutional credentials or submit an application for accredited operator clearance.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto shrink-0">
            <button
              onClick={() => setCurrentScreen('signin')}
              className="w-full sm:w-auto px-6 py-3.5 bg-[#0A3D24] hover:bg-[#135A37] text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center space-x-2 cursor-pointer border border-[#C88A2C]/30"
            >
              <Lock className="w-4 h-4 text-[#C88A2C]" />
              <span>Sign In to Terminal</span>
            </button>
            <button
              onClick={() => setCurrentScreen('request-access')}
              className="w-full sm:w-auto px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl border border-white/20 transition-all flex items-center justify-center space-x-2 cursor-pointer"
            >
              <span>Request Access</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
