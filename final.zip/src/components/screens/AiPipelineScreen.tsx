import React, { useState, useEffect } from 'react';
import {
  Cpu,
  CheckCircle2,
  Play,
  ArrowRight,
  Sparkles,
  RefreshCw,
  Layers,
  AlertCircle
} from 'lucide-react';
import { ScreenId, AudioEvidence, User } from '../../types';
import { canRunAiAnalysis, ROLE_CONFIGS } from '../../utils/rbac';
import { BackButton } from '../common/BackButton';
import { authFetch } from '../../utils/api';

export type PipelineStateType =
  | 'NOT_CONNECTED'
  | 'READY'
  | 'QUEUED'
  | 'PROCESSING'
  | 'COMPLETED'
  | 'FAILED'
  | 'MODEL_UNAVAILABLE';

interface AiPipelineScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  activeEvidence: AudioEvidence;
  setActiveEvidence?: (ev: AudioEvidence) => void;
  currentUser: User;
}

export const AiPipelineScreen: React.FC<AiPipelineScreenProps> = ({
  setCurrentScreen,
  activeEvidence,
  setActiveEvidence,
  currentUser
}) => {
  const [pipelineState, setPipelineState] = useState<PipelineStateType>('READY');
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [modelsStatus, setModelsStatus] = useState<Record<string, any> | null>(null);
  const [analysisResult, setAnalysisResult] = useState<any | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [caseEvidenceList, setCaseEvidenceList] = useState<AudioEvidence[]>([]);

  const canRun = canRunAiAnalysis(currentUser.role);
  const roleConfig = ROLE_CONFIGS[currentUser.role];

  const pipelineStages = [
    { id: 1, name: 'Bitstream Integrity Verification', desc: 'SHA-256 cryptographic checksum matching against evidence locker digest' },
    { id: 2, name: 'DSP Signal Normalization', desc: 'Resampling, amplitude peak scaling, and DC offset correction' },
    { id: 3, name: 'Acoustic Feature Extraction', desc: 'Spectral Centroid, Roll-Off, Flatness, and HNR harmonic-to-noise computation' },
    { id: 4, name: 'F0 Fundamental Pitch Tracking', desc: 'Normalized autocorrelation and YIN micro-tremor perturbation analysis' },
    { id: 5, name: 'CNN Spectral Vocoder Detection', desc: 'Evaluates high-frequency spectral roll-off and synthetic vocoder boundary resets (when weights configured)' },
    { id: 6, name: 'BiLSTM Temporal Sequence Analysis', desc: 'Evaluates unnatural prosodic flatlining and glottal flow discontinuities (when weights configured)' },
    { id: 7, name: 'Transformer Contextual Embeddings', desc: 'Self-supervised speech representations for deepfake voice conversion (when weights configured)' },
    { id: 8, name: 'Multi-Model Ensemble Fusion', desc: 'Honest arbitration across active DSP and available neural heads' },
    { id: 9, name: 'Explainable AI Feature Attribution', desc: 'Real DSP pitch/spectral inspection and Grad-CAM/SHAP readiness verification' },
    { id: 10, name: 'Forensic Package Finalization', desc: 'Packaging court-admissible findings and expert examiner review notes' }
  ];

  useEffect(() => {
    async function fetchModelStatus() {
      try {
        const res = await authFetch('/api/ai/models-status');
        if (res.ok) {
          const data = await res.json();
          setModelsStatus(data);
        } else {
          setPipelineState('NOT_CONNECTED');
        }
      } catch {
        setPipelineState('NOT_CONNECTED');
      }
    }
    fetchModelStatus();
  }, []);

  useEffect(() => {
    setAnalysisResult(null);
    setErrorMessage(null);
    setCurrentStepIndex(0);
    setPipelineState('READY');
    if (!activeEvidence?.caseId) return;
    let cancelled = false;
    authFetch(`/api/cases/${encodeURIComponent(activeEvidence.caseId)}/evidence`)
      .then((res) => (res.ok ? res.json() : []))
      .then((list) => {
        if (!cancelled && Array.isArray(list)) {
          setCaseEvidenceList(list);
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [activeEvidence?.id, activeEvidence?.caseId]);

  const runAnalysisPipeline = async () => {
    if (!activeEvidence || activeEvidence.id === 'EV-INIT') {
      setErrorMessage('No active evidence file selected. Please select an evidence file from the Evidence Locker first.');
      return;
    }

    setErrorMessage(null);
    setPipelineState('PROCESSING');
    setCurrentStepIndex(1);
    setAnalysisResult(null);

    let currentStage = 1;
    const progressInterval = setInterval(() => {
      currentStage++;
      if (currentStage <= 8) {
        setCurrentStepIndex(currentStage);
      }
    }, 300);

    try {
      const res = await authFetch('/api/analyze-audio', {
        method: 'POST',
        body: JSON.stringify({
          caseId: activeEvidence.caseId,
          evidenceId: activeEvidence.id
        })
      });

      clearInterval(progressInterval);
      setCurrentStepIndex(10);

      const data = await res.json().catch(() => null);

      if (res.ok && data) {
        setAnalysisResult(data);
        setPipelineState('COMPLETED');
      } else {
        setPipelineState('FAILED');
        if (res.status === 422) {
          setErrorMessage(
            data?.error ||
              'Server-side PCM decoding requires an uncompressed WAV bitstream (RIFF). Convert or re-record this exhibit as uncompressed WAV in the Evidence Locker before analysis.'
          );
        } else {
          setErrorMessage(data?.error || `Analysis request failed with status ${res.status}.`);
        }
      }
    } catch {
      clearInterval(progressInterval);
      setPipelineState('FAILED');
      setErrorMessage('Network connection error: Unable to reach the forensic audio analysis engine on port 3000.');
    }
  };

  const measurementsList: Array<{ name: string; value: string; status?: string }> = Array.isArray(
    analysisResult?.acousticMeasurementsList
  )
    ? analysisResult.acousticMeasurementsList
    : Array.isArray(analysisResult?.acousticMeasurements)
    ? analysisResult.acousticMeasurements
    : [];

  return (
    <div id="ai-pipeline-screen" className="p-6 space-y-6 bg-[#F8FAF9] min-h-full text-[#112217]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E1EBE4] pb-5">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('evidence')} label="Back to Evidence" variant="pill" />
          </div>
          <div className="flex items-center space-x-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-[#112217] font-serif-title flex items-center space-x-2">
              <Cpu className="w-6 h-6 text-[#0A3D24]" />
              <span>AI Analysis Pipeline</span>
            </h1>
            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full border bg-[#FEF3C7] text-[#B2751E] border-[#C88A2C]/30 font-mono">
              {roleConfig?.shortLabel}
            </span>
          </div>
          <p className="text-xs text-[#54665C] mt-1">
            Sequential 10-stage forensic pipeline for evidence: <strong className="text-[#112217]">{activeEvidence.filename}</strong>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {caseEvidenceList.length > 1 && setActiveEvidence && (
            <select
              value={activeEvidence.id}
              onChange={(e) => {
                const nextEv = caseEvidenceList.find((ev) => ev.id === e.target.value);
                if (nextEv) setActiveEvidence(nextEv);
              }}
              className="px-3 py-2 bg-white border border-[#E1EBE4] rounded-xl text-xs font-bold text-[#112217] shadow-xs cursor-pointer"
            >
              {caseEvidenceList.map((ev) => (
                <option key={ev.id} value={ev.id}>
                  {ev.id} — {ev.filename}
                </option>
              ))}
            </select>
          )}
          <button
            onClick={runAnalysisPipeline}
            disabled={pipelineState === 'PROCESSING' || !canRun}
            className="px-5 py-2.5 bg-[#0A3D24] hover:bg-[#062817] disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs flex items-center space-x-2 transition-all cursor-pointer"
          >
            {pipelineState === 'PROCESSING' ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Executing Pipeline Stages...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 text-[#C88A2C]" />
                <span>Execute AI Pipeline</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* State Status Banner */}
      <div className="bg-white border border-[#E1EBE4] rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-xs">
        <div className="flex items-center space-x-2.5">
          <div
            className={`w-3 h-3 rounded-full ${
              pipelineState === 'COMPLETED'
                ? 'bg-[#15803D]'
                : pipelineState === 'PROCESSING'
                ? 'bg-[#C88A2C] animate-pulse'
                : pipelineState === 'FAILED'
                ? 'bg-[#B91C1C]'
                : 'bg-emerald-600'
            }`}
          />
          <span className="font-bold text-[#112217]">
            Pipeline State:{' '}
            <span className="font-mono text-[#0A3D24]">{pipelineState}</span>
          </span>
          <span className="text-[#54665C]">·</span>
          <span className="text-[#54665C]">
            Evidence SHA-256:{' '}
            <span className="font-mono text-[#112217]">
              {activeEvidence.sha256Hash ? `${activeEvidence.sha256Hash.slice(0, 16)}...` : 'Not computed'}
            </span>
          </span>
        </div>

        <span className="text-[11px] font-mono text-[#54665C]">
          Case Docket: {activeEvidence.caseId || 'UNASSIGNED'}
        </span>
      </div>

      {errorMessage && (
        <div className="p-3.5 bg-[#FEF2F2] border border-[#B91C1C]/30 text-[#B91C1C] text-xs rounded-2xl flex items-start space-x-2.5 font-medium">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* 10-Stage Pipeline Visual Workflow */}
      <div className="bg-white border border-[#E1EBE4] rounded-3xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-3">
          <div className="flex items-center space-x-2">
            <Layers className="w-4 h-4 text-[#0A3D24]" />
            <h2 className="text-sm font-bold text-[#112217] font-serif-title">
              Ensemble Pipeline Stages (10 Steps)
            </h2>
          </div>
          <span className="text-[11px] font-mono text-[#54665C]">
            {currentStepIndex > 0 ? `Stage ${currentStepIndex} of 10 active` : 'Ready to execute'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {pipelineStages.map((stage) => {
            const isCompleted = currentStepIndex > stage.id || pipelineState === 'COMPLETED';
            const isCurrent = currentStepIndex === stage.id && pipelineState === 'PROCESSING';

            return (
              <div
                key={stage.id}
                className={`p-3.5 rounded-2xl border transition-all text-xs space-y-1 ${
                  isCurrent
                    ? 'bg-[#F0FDF4] border-[#0A3D24] shadow-xs'
                    : isCompleted
                    ? 'bg-[#F8FAF9] border-[#15803D]/30'
                    : 'bg-[#F8FAF9] border-[#E1EBE4] opacity-75'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="font-mono font-bold text-[#0A3D24] text-[11px]">
                      {stage.id.toString().padStart(2, '0')}
                    </span>
                    <span className="font-bold text-[#112217]">{stage.name}</span>
                  </div>
                  {isCompleted ? (
                    <span className="text-[10px] font-mono font-bold text-[#15803D] flex items-center space-x-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>EVALUATED</span>
                    </span>
                  ) : isCurrent ? (
                    <span className="text-[10px] font-mono font-bold text-[#C88A2C] flex items-center space-x-1">
                      <RefreshCw className="w-3 h-3 animate-spin" />
                      <span>EVALUATING</span>
                    </span>
                  ) : (
                    <span className="text-[10px] font-mono text-[#54665C]">QUEUED</span>
                  )}
                </div>
                <p className="text-[11px] text-[#54665C] leading-snug">{stage.desc}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Results and Honest Model Information */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white border border-[#E1EBE4] rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-3">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-[#0A3D24]" />
              <h3 className="text-sm font-bold text-[#112217] font-serif-title">
                Analysis Verdict & Measurements
              </h3>
            </div>
            <span className="text-[10px] font-mono text-[#54665C]">
              Status: {analysisResult ? analysisResult.status || analysisResult.overallVerdict : 'Awaiting Execution'}
            </span>
          </div>

          {!analysisResult ? (
            <div className="p-8 text-center bg-[#F8FAF9] rounded-2xl border border-[#E1EBE4] space-y-2">
              <Cpu className="w-8 h-8 text-[#54665C] mx-auto opacity-50" />
              <p className="font-bold text-xs text-[#112217]">No Analysis Performed Yet</p>
              <p className="text-[11px] text-[#54665C] max-w-sm mx-auto">
                Execute the pipeline above to run digital signal processing and multimodal forensic verification.
              </p>
            </div>
          ) : (
            <div className="space-y-4 text-xs">
              {/* Verdict Banner */}
              <div
                className={`p-4 rounded-2xl border flex items-center justify-between gap-4 ${
                  analysisResult.overallVerdict === 'DEEPFAKE'
                    ? 'bg-[#FEF2F2] border-[#B91C1C]/30 text-[#B91C1C]'
                    : analysisResult.overallVerdict === 'AUTHENTIC'
                    ? 'bg-[#F0FDF4] border-[#15803D]/30 text-[#15803D]'
                    : 'bg-[#FEF3C7] border-[#C88A2C]/30 text-[#B2751E]'
                }`}
              >
                <div>
                  <span className="text-[10px] font-mono uppercase font-bold block">
                    Forensic Classification Outcome
                  </span>
                  <span className="text-lg font-bold font-serif-title">
                    {analysisResult.overallVerdict}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono uppercase font-bold block">Confidence</span>
                  <span className="text-xs font-mono font-bold">
                    {analysisResult.overallConfidence != null && analysisResult.overallConfidence > 0
                      ? `${analysisResult.overallConfidence}%`
                      : 'INCONCLUSIVE (Pending Neural Weights & Expert Review)'}
                  </span>
                </div>
              </div>

              {/* Real Acoustic Measurements returned by DSP */}
              {measurementsList.length > 0 ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-[#112217] uppercase text-[10px] tracking-wider">
                      Extracted Acoustic Signal Measurements:
                    </h4>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#F0FDF4] text-[#0A3D24] border border-[#15803D]/20">
                      non-biometric measurement
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {measurementsList.map((m, idx) => (
                      <div key={idx} className="p-2.5 bg-[#F8FAF9] rounded-xl border border-[#E1EBE4]">
                        <span className="text-[10px] text-[#54665C] block">{m.name}</span>
                        <span className="font-mono font-bold text-[#112217]">{m.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-[#F8FAF9] rounded-xl border border-[#E1EBE4] text-[11px] text-[#54665C]">
                  No PCM acoustic measurements extracted (binary audio decoding unavailable for this file).
                </div>
              )}

              {/* Non-Biometric Spectral & VAD Profile */}
              {analysisResult.nonBiometricProfile && (
                <div className="p-3 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl space-y-1.5 text-[11px]">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#112217] uppercase text-[10px]">
                      Cepstral & Voice Activity Profile
                    </span>
                    <span className="font-mono text-[9px] text-[#54665C]">
                      {analysisResult.nonBiometricProfile.measurementType}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 font-mono text-[10px]">
                    <div>
                      <span className="text-[#54665C] block">VAD Active Ratio</span>
                      <strong className="text-[#0A3D24]">
                        {Math.round((analysisResult.nonBiometricProfile.vadActiveRatio || 0) * 100)}% (
                        {analysisResult.nonBiometricProfile.vadSegmentCount} segs)
                      </strong>
                    </div>
                    <div>
                      <span className="text-[#54665C] block">MFCC / LFCC</span>
                      <strong className="text-[#112217]">
                        {analysisResult.nonBiometricProfile.mfccMean?.length || 0} /{' '}
                        {analysisResult.nonBiometricProfile.lfccMean?.length || 0} dims
                      </strong>
                    </div>
                    <div>
                      <span className="text-[#54665C] block">Mel Filterbank</span>
                      <strong className="text-[#112217]">
                        {analysisResult.nonBiometricProfile.melBandsDb?.length || 0} bands
                      </strong>
                    </div>
                  </div>
                </div>
              )}

              {/* Legal Summary Rationale */}
              {analysisResult.legalSummary && (
                <div className="p-3.5 bg-[#F8FAF9] rounded-2xl border border-[#E1EBE4] space-y-1">
                  <span className="font-bold text-[#0A3D24] text-[11px] block">
                    Forensic Examiner Technical Rationale:
                  </span>
                  <p className="text-[#54665C] text-xs leading-relaxed italic">
                    &ldquo;{analysisResult.legalSummary}&rdquo;
                  </p>
                </div>
              )}

              {/* Scientific Caveat / Limitations Container */}
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 leading-snug space-y-1">
                <p>
                  <strong>Probabilistic Decision Support Only:</strong> Automated acoustic metrics and model scores are investigative indicators only, never proof of identity or sole grounds for determination.
                </p>
                <p>
                  <strong>Forensic Limitation:</strong> {analysisResult.limitations}
                </p>
              </div>

              {/* Action Button */}
              <div className="pt-2">
                <button
                  onClick={() => setCurrentScreen('detection-results')}
                  className="w-full py-2.5 bg-[#0A3D24] hover:bg-[#062817] text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <span>Inspect Full Detection Results & XAI</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right: Model Integration Status & Version Info */}
        <div className="lg:col-span-5 bg-white border border-[#E1EBE4] rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-3">
            <div className="flex items-center space-x-2">
              <Cpu className="w-4 h-4 text-[#0A3D24]" />
              <h3 className="text-sm font-bold text-[#112217] font-serif-title">
                Neural Model Backend Status
              </h3>
            </div>
            <span className="text-[10px] font-mono text-[#54665C]">Enclave Config</span>
          </div>

          <p className="text-xs text-[#54665C] leading-relaxed">
            The ALFADetect multi-model architecture combines digital signal processing with deep learning classifiers. Backends currently unconfigured in the runtime environment are truthfully marked below.
          </p>

          <div className="space-y-2.5 text-xs">
            {modelsStatus ? (
              Object.entries(modelsStatus).map(([key, item]: [string, any]) => {
                const isAvailable = item.status === 'AVAILABLE';
                return (
                  <div key={key} className="p-3 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#112217]">{item.name}</span>
                      <span
                        className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded border ${
                          isAvailable
                            ? 'bg-[#F0FDF4] text-[#15803D] border-[#15803D]/30'
                            : 'bg-amber-50 text-amber-800 border-amber-300'
                        }`}
                      >
                        {isAvailable ? 'AVAILABLE' : 'NOT_CONFIGURED'}
                      </span>
                    </div>
                    <p className="text-[10px] text-[#54665C]">{item.description}</p>
                  </div>
                );
              })
            ) : (
              <div className="p-4 text-center text-xs text-[#54665C]">
                Loading model configuration...
              </div>
            )}
          </div>

          <div className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-2 text-xs">
            <div className="flex items-center space-x-2 text-[#0A3D24] font-bold">
              <Sparkles className="w-4 h-4" />
              <span>Explainability Container (Grad-CAM & SHAP)</span>
            </div>
            <p className="text-[#54665C] text-[11px] leading-relaxed">
              Full neural Grad-CAM & TreeSHAP weights are currently awaiting local PyTorch checkpoint integration. Objective DSP spectral and F0 acoustic plots remain active on the XAI screen.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
