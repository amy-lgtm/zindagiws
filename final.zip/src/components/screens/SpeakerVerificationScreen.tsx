import React, { useState, useEffect } from 'react';
import {
  Users,
  AlertTriangle,
  Plus,
  Scale,
  Play,
  Pause,
  Sparkles,
  RefreshCw,
  FolderKanban,
  X
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';
import {
  ScreenId,
  User,
  AudioEvidence,
  Case,
  F0AnalysisResult,
  ReferenceVoiceSample,
  AcousticMeasurements
} from '../../types';
import { BackButton } from '../common/BackButton';
import { authFetch, api } from '../../utils/api';
import { extractF0FromPCM } from '../../utils/pitchExtractor';
import { computeAcousticMeasurements } from '../../utils/audioDsp';
import { speakAudioEvidence, stopAudioEvidence } from '../../utils/audioPlayer';

interface SpeakerVerificationRecord {
  id: string;
  caseId: string;
  evidenceId: string;
  referenceId: string;
  subjectName: string;
  verdict:
    | 'Analysis completed'
    | 'Consistent with the same speaker'
    | 'Not sufficiently consistent with the same speaker'
    | 'Inconclusive'
    | 'Insufficient audio quality'
    | 'Reference recording missing'
    | 'Model unavailable'
    | 'Analysis failed';
  similarityScore: number | null;
  threshold: number;
  speechDurationSeconds: number;
  evidenceIsSynthetic: boolean;
  decisionNote: string;
  modelsUsed: string[];
  referenceProvenance?: string;
  limitations: string;
  analyzedAt: string;
  acousticComparison?: {
    f0DeltaHz: number;
    spectralDistance: number;
    jitterRatio: number;
    hnrDifferenceDb: number;
  };
}

interface SpeakerVerificationScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  selectedCaseId: string;
  activeEvidence: AudioEvidence;
  currentUser: User;
  cases?: Case[];
}

function formatSecDuration(sec: number): string {
  if (!isFinite(sec) || sec <= 0) return 'Unknown';
  const m = Math.floor(sec / 60);
  const s = Math.round(sec % 60);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

async function decodeUrlToDsp(audioUrl?: string): Promise<{
  f0: F0AnalysisResult;
  meas: AcousticMeasurements;
} | null> {
  if (!audioUrl) return null;
  try {
    const resp = audioUrl.startsWith('/api/') ? await authFetch(audioUrl) : await fetch(audioUrl);
    if (!resp.ok) return null;
    const ab = await resp.arrayBuffer();
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return null;
    const ctx = new AudioCtx();
    try {
      const audioBuffer = await ctx.decodeAudioData(ab);
      const samples = audioBuffer.getChannelData(0);
      const sr = audioBuffer.sampleRate;
      const f0 = extractF0FromPCM(samples, sr);
      const meas = computeAcousticMeasurements(samples, sr);
      return { f0, meas };
    } finally {
      ctx.close().catch(() => {});
    }
  } catch {
    return null;
  }
}

export const SpeakerVerificationScreen: React.FC<SpeakerVerificationScreenProps> = ({
  setCurrentScreen,
  selectedCaseId,
  activeEvidence,
  currentUser,
  cases = []
}) => {
  const [activeCaseId, setActiveCaseId] = useState<string>(selectedCaseId || cases[0]?.id || '');
  const [caseEvidenceList, setCaseEvidenceList] = useState<AudioEvidence[]>([]);
  const [selectedEvidenceId, setSelectedEvidenceId] = useState<string>(activeEvidence?.id || '');
  const [references, setReferences] = useState<ReferenceVoiceSample[]>([]);
  const [selectedReferenceId, setSelectedReferenceId] = useState<string>('');

  const [isPlayingQuestioned, setIsPlayingQuestioned] = useState(false);
  const [isPlayingReference, setIsPlayingReference] = useState(false);

  const [isComparing, setIsComparing] = useState(false);
  const [questionedF0, setQuestionedF0] = useState<F0AnalysisResult | null>(null);
  const [referenceF0, setReferenceF0] = useState<F0AnalysisResult | null>(null);
  const [questionedMeas, setQuestionedMeas] = useState<AcousticMeasurements | null>(null);
  const [referenceMeas, setReferenceMeas] = useState<AcousticMeasurements | null>(null);
  const [comparisonResult, setComparisonResult] = useState<SpeakerVerificationRecord | null>(null);
  const [pastVerifications, setPastVerifications] = useState<SpeakerVerificationRecord[]>([]);

  const [isEnrollModalOpen, setIsEnrollModalOpen] = useState(false);
  const [enrollSubjectName, setEnrollSubjectName] = useState('');
  const [enrollConditionTag, setEnrollConditionTag] = useState<'Normal' | 'Illness/Cold' | 'Whispering' | 'Disguised' | 'Other'>('Normal');
  const [enrollConsentDeclared, setEnrollConsentDeclared] = useState(false);
  const [enrollConsentNotes, setEnrollConsentNotes] = useState('Lawful exemplar obtained under Title III consensual interception protocol / FRE 902(11).');
  const [enrollFile, setEnrollFile] = useState<File | null>(null);
  const [isEnrolling, setIsEnrolling] = useState(false);
  const [enrollError, setEnrollError] = useState('');
  const [actionError, setActionError] = useState<string | null>(null);

  useEffect(() => {
    if (selectedCaseId) {
      setActiveCaseId(selectedCaseId);
    }
  }, [selectedCaseId]);

  useEffect(() => {
    if (!activeCaseId) return;

    // Clear stale case state when switching dockets
    setSelectedReferenceId('');
    setComparisonResult(null);
    setQuestionedF0(null);
    setReferenceF0(null);
    setQuestionedMeas(null);
    setReferenceMeas(null);

    async function loadCaseData() {
      try {
        const [refRes, verifRes, evRes] = await Promise.all([
          authFetch(`/api/cases/${encodeURIComponent(activeCaseId)}/references`),
          authFetch(`/api/cases/${encodeURIComponent(activeCaseId)}/speaker-verifications`),
          authFetch(`/api/cases/${encodeURIComponent(activeCaseId)}/evidence`)
        ]);

        if (refRes.ok) {
          const refs = await refRes.json();
          if (Array.isArray(refs)) {
            setReferences(refs);
            if (refs.length > 0) {
              setSelectedReferenceId(refs[0].id);
            }
          }
        }

        if (verifRes.ok) {
          const list = await verifRes.json();
          if (Array.isArray(list)) {
            setPastVerifications(list);
          }
        }

        if (evRes.ok) {
          const evList = await evRes.json();
          if (Array.isArray(evList)) {
            setCaseEvidenceList(evList);
            if (evList.length > 0) {
              setSelectedEvidenceId(evList[0].id);
            } else {
              setSelectedEvidenceId('');
            }
          }
        }
      } catch (err) {
        console.warn('Speaker verification load note:', err);
      }
    }

    loadCaseData();
  }, [activeCaseId]);

  const selectedEvidence =
    caseEvidenceList.find((e) => e.id === selectedEvidenceId) ||
    (activeEvidence?.id && activeEvidence.id !== 'EV-INIT' && activeEvidence.caseId === activeCaseId
      ? activeEvidence
      : null);

  const selectedReference = references.find((r) => r.id === selectedReferenceId) || null;

  const handleEnrollSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCaseId) {
      setEnrollError('Select an active forensic case docket before enrolling a reference voice sample.');
      return;
    }
    if (!enrollSubjectName.trim()) {
      setEnrollError('Subject Name is required.');
      return;
    }
    if (!enrollConsentDeclared) {
      setEnrollError('Consent declaration is required under FRE 902(11) to enroll a reference voice exemplar.');
      return;
    }
    if (!enrollFile) {
      setEnrollError('An audio exemplar recording file (WAV/MP3/FLAC) is required.');
      return;
    }

    setIsEnrolling(true);
    setEnrollError('');

    try {
      let measuredDuration = 'Unknown';
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          const ctx = new AudioCtx();
          try {
            const ab = await enrollFile.arrayBuffer();
            const audioBuf = await ctx.decodeAudioData(ab);
            measuredDuration = formatSecDuration(audioBuf.duration);
          } finally {
            ctx.close().catch(() => {});
          }
        }
      } catch {
        // Leave Unknown if browser cannot decode compressed audio header
      }

      const formData = new FormData();
      formData.append('subjectName', enrollSubjectName.trim());
      formData.append('fileSize', `${(enrollFile.size / (1024 * 1024)).toFixed(2)} MB`);
      formData.append('duration', measuredDuration);
      formData.append('conditionTag', enrollConditionTag);
      formData.append('lawfulConsentDeclared', 'true');
      formData.append('consentNotes', enrollConsentNotes);
      formData.append('uploadedBy', currentUser.name);
      formData.append('audio', enrollFile, enrollFile.name);

      const newRef = await api.uploadMultipart(`/api/cases/${encodeURIComponent(activeCaseId)}/references`, formData);
      setReferences((prev) => [newRef, ...prev]);
      setSelectedReferenceId(newRef.id);
      setIsEnrollModalOpen(false);
      setEnrollSubjectName('');
      setEnrollFile(null);
      setEnrollConsentDeclared(false);
    } catch (err: any) {
      setEnrollError(err?.message || 'Failed to enroll reference sample.');
    } finally {
      setIsEnrolling(false);
    }
  };

  const handleRunComparison = async () => {
    setActionError(null);
    if (!selectedEvidence) {
      setActionError('Questioned audio evidence file must be selected from the Evidence Locker.');
      return;
    }
    if (!selectedReference) {
      setActionError('Reference voice recording must be selected with verified lawful consent.');
      return;
    }

    setIsComparing(true);
    setComparisonResult(null);

    try {
      const [qDsp, rDsp] = await Promise.all([
        decodeUrlToDsp(selectedEvidence.audioUrl),
        decodeUrlToDsp(selectedReference.audioUrl)
      ]);

      setQuestionedF0(qDsp?.f0 || null);
      setReferenceF0(rDsp?.f0 || null);
      setQuestionedMeas(qDsp?.meas || null);
      setReferenceMeas(rDsp?.meas || null);

      const res = await authFetch('/api/speaker-verification/compare', {
        method: 'POST',
        body: JSON.stringify({
          caseId: activeCaseId,
          evidenceId: selectedEvidence.id,
          referenceId: selectedReference.id
        })
      });

      if (res.ok) {
        const data: SpeakerVerificationRecord = await res.json();
        setComparisonResult(data);
        setPastVerifications((prev) => [data, ...prev]);
      } else {
        const err = await res.json().catch(() => null);
        setActionError(err?.error || 'Comparison failed on server.');
      }
    } catch {
      setActionError('Network error running speaker verification.');
    } finally {
      setIsComparing(false);
    }
  };

  const togglePlayQuestioned = () => {
    if (isPlayingQuestioned) {
      stopAudioEvidence();
      setIsPlayingQuestioned(false);
    } else {
      setIsPlayingQuestioned(true);
      speakAudioEvidence('Questioned audio evidence sample playback.', {
        audioUrl: selectedEvidence?.audioUrl,
        onEnd: () => setIsPlayingQuestioned(false)
      });
    }
  };

  const togglePlayReference = () => {
    if (isPlayingReference) {
      stopAudioEvidence();
      setIsPlayingReference(false);
    } else {
      setIsPlayingReference(true);
      speakAudioEvidence('Reference voice exemplar recording playback.', {
        audioUrl: selectedReference?.audioUrl,
        onEnd: () => setIsPlayingReference(false)
      });
    }
  };

  const chartData = (questionedF0?.points || []).map((pt, idx) => {
    const refPt = referenceF0?.points[idx];
    return {
      time: pt.timeLabel,
      questionedF0: pt.isVoiced ? pt.f0Hz : null,
      referenceF0: refPt && refPt.isVoiced ? refPt.f0Hz : null
    };
  });

  const qMeanF0 = questionedMeas?.f0MeanHz ?? (questionedF0?.isAvailable ? questionedF0.avgF0 : null);
  const rMeanF0 = referenceMeas?.f0MeanHz ?? (referenceF0?.isAvailable ? referenceF0.avgF0 : null);
  const qJitter = questionedMeas?.jitterPercent ?? (questionedF0?.isAvailable ? questionedF0.jitterPercent : null);
  const rJitter = referenceMeas?.jitterPercent ?? (referenceF0?.isAvailable ? referenceF0.jitterPercent : null);
  const qVoiced = questionedMeas?.voicedFractionPercent ?? (questionedF0?.isAvailable ? questionedF0.voicedFraction : null);
  const rVoiced = referenceMeas?.voicedFractionPercent ?? (referenceF0?.isAvailable ? referenceF0.voicedFraction : null);
  const qHnr = questionedMeas?.hnrDb ?? null;
  const rHnr = referenceMeas?.hnrDb ?? null;

  return (
    <div id="speaker-verification-screen" className="p-4 sm:p-6 space-y-6 bg-[#F8FAF9] min-h-full text-[#112217]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E1EBE4] pb-5">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('evidence')} label="Back to Evidence" variant="pill" />
          </div>
          <div className="flex items-center space-x-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-[#112217] font-serif-title flex items-center space-x-2">
              <Users className="w-6 h-6 text-[#0A3D24]" />
              <span>Speaker Verification & Voice Matching</span>
            </h1>
            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full border bg-[#FEF3C7] text-[#B2751E] border-[#C88A2C]/30 font-mono">
              FRE 902 / FRE 702
            </span>
          </div>
          <p className="text-xs text-[#54665C] mt-1">
            Biometric voice comparison between questioned forensic audio and enrolled reference exemplar.
          </p>
        </div>

        {/* Case Selector */}
        <div className="flex items-center space-x-2">
          <FolderKanban className="w-4 h-4 text-[#0A3D24]" />
          <select
            value={activeCaseId}
            onChange={(e) => setActiveCaseId(e.target.value)}
            className="px-3 py-1.5 bg-white border border-[#E1EBE4] rounded-xl text-xs font-bold text-[#112217] shadow-xs cursor-pointer focus:outline-hidden"
          >
            {cases.length === 0 ? (
              <option value="">No Cases Enrolled</option>
            ) : (
              cases.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.id} — {c.title.slice(0, 32)}
                </option>
              ))
            )}
          </select>
        </div>
      </div>

      {/* Action Error Banner */}
      {actionError && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-2xl flex items-center justify-between text-xs text-red-800 shadow-xs">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            <span className="font-medium">{actionError}</span>
          </div>
          <button
            onClick={() => setActionError(null)}
            className="text-red-700 hover:text-red-900 font-bold ml-3 px-2 py-0.5 rounded-md hover:bg-red-100 transition-colors"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Forensic Distinction Notice */}
      <div className="p-4 bg-white border-l-4 border-l-[#0A3D24] border border-[#E1EBE4] rounded-2xl flex items-start space-x-3 text-xs shadow-xs">
        <Scale className="w-5 h-5 text-[#0A3D24] shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="text-[#112217] font-bold">
            Forensic Distinction: Deepfake Detection vs. Speaker Verification
          </p>
          <p className="text-[#54665C] leading-relaxed">
            Deepfake detection investigates whether an audio stream was synthesized by machine learning vocoders. Speaker verification compares physical vocal parameters (non-biometric F0, micro-jitter, HNR) alongside neural speaker embeddings (ECAPA-TDNN, when configured) as probabilistic decision support — never proof of identity. Per forensic standards, high speaker similarity on synthetic speech does <strong>not</strong> prove authentic human authorship.
          </p>
        </div>
      </div>

      {/* Audio Sample Selection Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Left: Questioned Audio Evidence */}
        <div className="bg-white border border-[#E1EBE4] rounded-2xl p-5 space-y-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-3">
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#B91C1C]"></span>
              <h3 className="text-sm font-bold text-[#112217] font-serif-title">
                1. Questioned Audio Evidence
              </h3>
            </div>
            <span className="text-[10px] font-mono text-[#54665C]">Intercepted Exhibit</span>
          </div>

          {selectedEvidence ? (
            <div className="space-y-3">
              {caseEvidenceList.length > 1 && (
                <select
                  value={selectedEvidenceId}
                  onChange={(e) => setSelectedEvidenceId(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl text-xs font-bold text-[#112217]"
                >
                  {caseEvidenceList.map((e) => (
                    <option key={e.id} value={e.id}>
                      {e.id} — {e.filename}
                    </option>
                  ))}
                </select>
              )}

              <div className="p-3.5 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-[#112217]">{selectedEvidence.filename}</span>
                  <span className="font-mono text-[10px] text-[#0A3D24] bg-[#F0FDF4] px-2 py-0.5 rounded border border-[#E1EBE4]">
                    {selectedEvidence.id}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-[11px] text-[#54665C]">
                  <div>Duration: <strong className="text-[#112217]">{selectedEvidence.duration}</strong></div>
                  <div>Sample Rate: <strong className="text-[#112217]">{selectedEvidence.sampleRate}</strong></div>
                  <div>Format: <strong className="text-[#112217]">{selectedEvidence.channels}</strong></div>
                </div>
                <div className="text-[10px] font-mono text-[#54665C] truncate">
                  SHA-256: {selectedEvidence.sha256Hash || 'Cryptographic seal on record'}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <button
                  onClick={togglePlayQuestioned}
                  disabled={!selectedEvidence.audioUrl}
                  className="px-3.5 py-1.5 bg-[#0A3D24] hover:bg-[#062817] disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center space-x-2 transition-all cursor-pointer shadow-xs"
                >
                  {isPlayingQuestioned ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{isPlayingQuestioned ? 'Pause Questioned' : 'Play Questioned'}</span>
                </button>
                <button
                  onClick={() => setCurrentScreen('evidence')}
                  className="text-xs text-[#0A3D24] hover:underline font-bold"
                >
                  Change Evidence File →
                </button>
              </div>
            </div>
          ) : (
            <div className="p-6 bg-[#F8FAF9] border border-dashed border-[#E1EBE4] rounded-xl text-center space-y-2">
              <AlertTriangle className="w-6 h-6 text-[#D97706] mx-auto" />
              <p className="text-xs font-bold text-[#112217]">No Questioned Evidence Selected</p>
              <p className="text-[11px] text-[#54665C]">
                Select or upload audio evidence in Evidence Management to evaluate speaker verification.
              </p>
              <button
                onClick={() => setCurrentScreen('evidence')}
                className="mt-2 px-3.5 py-1.5 bg-[#0A3D24] text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
              >
                Go to Evidence Locker
              </button>
            </div>
          )}
        </div>

        {/* Right: Reference Voice Exemplar */}
        <div className="bg-white border border-[#E1EBE4] rounded-2xl p-5 space-y-4 shadow-xs">
          <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-3">
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#15803D]"></span>
              <h3 className="text-sm font-bold text-[#112217] font-serif-title">
                2. Reference Voice Exemplar
              </h3>
            </div>
            <button
              id="enroll-reference-btn"
              onClick={() => setIsEnrollModalOpen(true)}
              className="px-2.5 py-1 bg-[#F0FDF4] hover:bg-[#E1EBE4] border border-[#0A3D24]/20 text-[#0A3D24] text-xs font-bold rounded-lg flex items-center space-x-1 cursor-pointer transition-all"
            >
              <Plus className="w-3 h-3" />
              <span>Enroll Exemplar</span>
            </button>
          </div>

          {selectedReference ? (
            <div className="space-y-3">
              <div className="p-3.5 bg-[#F0FDF4] border border-[#15803D]/20 rounded-xl space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <div>
                    <span className="font-bold text-[#0A3D24]">{selectedReference.subjectName}</span>
                    <span className="text-[10px] text-[#54665C] ml-2">({selectedReference.filename})</span>
                  </div>
                  <span className="text-[10px] font-mono font-bold bg-[#FEF3C7] text-[#B2751E] px-2 py-0.5 rounded border border-[#C88A2C]/30">
                    {selectedReference.conditionTag}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-[11px] text-[#54665C]">
                  <div>Consent: <strong className="text-[#15803D]">FRE 902(11)</strong></div>
                  <div>Duration: <strong className="text-[#112217]">{selectedReference.duration}</strong></div>
                  <div>Enrolled: <strong className="text-[#112217]">{selectedReference.uploadedAt.slice(0, 10)}</strong></div>
                </div>
                <p className="text-[10px] text-[#54665C] italic">
                  &ldquo;{selectedReference.consentNotes}&rdquo;
                </p>
              </div>

              {references.length > 1 && (
                <div className="flex items-center space-x-2 text-xs">
                  <span className="text-[#54665C]">Switch Exemplar:</span>
                  <select
                    value={selectedReferenceId}
                    onChange={(e) => setSelectedReferenceId(e.target.value)}
                    className="px-2 py-1 bg-white border border-[#E1EBE4] rounded-lg text-xs font-medium text-[#112217]"
                  >
                    {references.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.subjectName} ({r.conditionTag})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="flex items-center justify-between">
                <button
                  onClick={togglePlayReference}
                  disabled={!selectedReference.audioUrl}
                  className="px-3.5 py-1.5 bg-[#0A3D24] hover:bg-[#062817] disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center space-x-2 transition-all cursor-pointer shadow-xs"
                >
                  {isPlayingReference ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{isPlayingReference ? 'Pause Exemplar' : 'Play Exemplar'}</span>
                </button>
                <span className="text-[10px] font-mono text-[#15803D] font-bold">
                  ✓ Lawful Exemplar Enrolled
                </span>
              </div>
            </div>
          ) : (
            <div className="p-6 bg-[#F8FAF9] border border-dashed border-[#E1EBE4] rounded-xl text-center space-y-2">
              <Users className="w-6 h-6 text-[#54665C] mx-auto" />
              <p className="text-xs font-bold text-[#112217]">No Reference Voice Exemplar</p>
              <p className="text-[11px] text-[#54665C] max-w-xs mx-auto">
                An authorized reference recording with verified lawful consent under FRE 902(11) is required before speaker verification can run.
              </p>
              <button
                onClick={() => setIsEnrollModalOpen(true)}
                className="mt-2 px-3.5 py-1.5 bg-[#0A3D24] text-white text-xs font-bold rounded-xl shadow-xs inline-flex items-center space-x-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Enroll Reference Voice Exemplar</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Action Trigger Button */}
      <div className="flex justify-center">
        <button
          id="run-speaker-verification-btn"
          onClick={handleRunComparison}
          disabled={!selectedEvidence || !selectedReference || isComparing}
          className="px-6 py-3 bg-[#0A3D24] hover:bg-[#062817] disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md flex items-center space-x-2 cursor-pointer transition-all"
        >
          {isComparing ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin text-[#C88A2C]" />
              <span>Analyzing Acoustic Pitch Contours & Spectral Distance...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-[#C88A2C]" />
              <span>Execute Comparative Speaker Voice Verification</span>
            </>
          )}
        </button>
      </div>

      {/* Comparison Analysis Results Section */}
      {comparisonResult && (
        <div className="space-y-6">
          <div
            className={`p-5 rounded-2xl border flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm ${
              comparisonResult.verdict === 'Consistent with the same speaker'
                ? 'bg-[#F0FDF4] border-[#15803D]/30 text-[#112217]'
                : comparisonResult.verdict === 'Inconclusive' || comparisonResult.verdict === 'Model unavailable'
                ? 'bg-[#FFFBEB] border-[#D97706]/30 text-[#112217]'
                : 'bg-[#FEF2F2] border-[#B91C1C]/30 text-[#112217]'
            }`}
          >
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <span className="text-[10px] font-mono uppercase tracking-widest font-bold text-[#54665C]">
                  FORENSIC VERDICT
                </span>
                <span
                  className={`text-xs font-bold px-2.5 py-0.5 rounded-full font-mono border ${
                    comparisonResult.verdict === 'Consistent with the same speaker'
                      ? 'bg-[#15803D] text-white border-[#15803D]'
                      : comparisonResult.verdict === 'Inconclusive' || comparisonResult.verdict === 'Model unavailable'
                      ? 'bg-[#D97706] text-white border-[#D97706]'
                      : 'bg-[#B91C1C] text-white border-[#B91C1C]'
                  }`}
                >
                  {comparisonResult.verdict}
                </span>
              </div>
              <h2 className="text-lg font-bold font-serif-title text-[#112217]">
                Subject Comparison: {comparisonResult.subjectName}
              </h2>
              <p className="text-xs text-[#54665C] leading-relaxed max-w-3xl">
                {comparisonResult.decisionNote}
              </p>
            </div>

            <div className="text-right shrink-0 bg-white/80 p-3 rounded-xl border border-[#E1EBE4]">
              <p className="text-[10px] font-mono text-[#54665C]">BIOMETRIC SPEAKER SCORE</p>
              <p className="text-xl font-black font-mono text-[#0A3D24]">
                {comparisonResult.similarityScore !== null && comparisonResult.similarityScore !== undefined
                  ? `${comparisonResult.similarityScore}%`
                  : 'MODEL UNAVAILABLE'}
              </p>
              <p className="text-[10px] font-mono text-[#54665C]">
                {comparisonResult.similarityScore !== null && comparisonResult.similarityScore !== undefined
                  ? `Probabilistic Score (Threshold: ${comparisonResult.threshold}%) · Speech: ${comparisonResult.speechDurationSeconds}s`
                  : `Non-biometric measurement only · Speech: ${comparisonResult.speechDurationSeconds}s`}
              </p>
            </div>
          </div>

          {/* Side-by-Side Dual Pitch Curve Visualization */}
          <div className="bg-white border border-[#E1EBE4] rounded-2xl p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-[#112217] font-serif-title">
                  Fundamental Frequency (F0) Comparative Pitch Trajectories
                </h3>
                <p className="text-xs text-[#54665C]">
                  Overlay of Questioned audio pitch contour vs. enrolled Reference exemplar (Hz)
                </p>
              </div>
              <span className="text-[10px] font-mono text-[#0A3D24] bg-[#F0FDF4] px-2 py-1 rounded border border-[#E1EBE4]">
                DSP YIN Extraction
              </span>
            </div>

            {chartData.length > 0 ? (
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E1EBE4" />
                    <XAxis dataKey="time" stroke="#54665C" tick={{ fontSize: 10 }} />
                    <YAxis stroke="#54665C" tick={{ fontSize: 10 }} domain={['dataMin - 20', 'dataMax + 20']} unit=" Hz" />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#ffffff', borderColor: '#E1EBE4', borderRadius: '12px', fontSize: '11px' }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                    <Line type="monotone" dataKey="questionedF0" name="Questioned Audio (F0)" stroke="#B91C1C" strokeWidth={2.5} dot={false} connectNulls />
                    <Line type="monotone" dataKey="referenceF0" name="Reference Exemplar (F0)" stroke="#0A3D24" strokeWidth={2.5} dot={false} connectNulls />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="p-6 text-center text-xs text-[#54665C] bg-[#F8FAF9] rounded-xl border border-dashed border-[#E1EBE4]">
                Pitch contour plot unavailable for compressed/undecodable browser stream; server WAV DSP embedding was evaluated directly where supported.
              </div>
            )}
          </div>

          {/* Comparative Acoustic Metrics Table */}
          <div className="bg-white border border-[#E1EBE4] rounded-2xl p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#112217]">
                Physical Acoustic Metrics Comparison Matrix
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#F0FDF4] text-[#0A3D24] border border-[#15803D]/20">
                non-biometric measurement
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-[#112217]">
                <thead className="bg-[#F8FAF9] text-[#54665C] uppercase text-[10px] font-bold border-b border-[#E1EBE4]">
                  <tr>
                    <th className="py-2.5 px-3">Acoustic Feature</th>
                    <th className="py-2.5 px-3 text-red-800">Questioned Audio</th>
                    <th className="py-2.5 px-3 text-[#0A3D24]">Reference Exemplar</th>
                    <th className="py-2.5 px-3">Variance / Delta</th>
                    <th className="py-2.5 px-3 text-right">Evaluation Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  <tr>
                    <td className="py-3 px-3 font-sans font-bold">Mean Fundamental Pitch (F0)</td>
                    <td className="py-3 px-3">{qMeanF0 !== null ? `${qMeanF0} Hz` : 'N/A'}</td>
                    <td className="py-3 px-3">{rMeanF0 !== null ? `${rMeanF0} Hz` : 'N/A'}</td>
                    <td className="py-3 px-3 text-[#0A3D24] font-bold">
                      {comparisonResult.acousticComparison ? `Δ ${comparisonResult.acousticComparison.f0DeltaHz} Hz` : 'N/A'}
                    </td>
                    <td className="py-3 px-3 text-right font-sans">
                      <span className="text-[10px] font-bold text-[#15803D] bg-[#F0FDF4] px-2 py-0.5 rounded border border-[#15803D]/20">
                        {comparisonResult.acousticComparison ? (comparisonResult.acousticComparison.f0DeltaHz <= 25 ? 'Compatible' : 'Divergent') : 'Server Measured'}
                      </span>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-3 font-sans font-bold">Cycle-to-Cycle Micro-Jitter</td>
                    <td className="py-3 px-3">{qJitter !== null ? `${qJitter}%` : 'N/A'}</td>
                    <td className="py-3 px-3">{rJitter !== null ? `${rJitter}%` : 'N/A'}</td>
                    <td className="py-3 px-3 text-[#54665C]">
                      {comparisonResult.acousticComparison ? `Ratio: ${comparisonResult.acousticComparison.jitterRatio}x` : 'N/A'}
                    </td>
                    <td className="py-3 px-3 text-right font-sans">
                      <span className="text-[10px] font-bold text-[#15803D] bg-[#F0FDF4] px-2 py-0.5 rounded border border-[#15803D]/20">
                        DSP Measured
                      </span>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-3 font-sans font-bold">Voiced Speech Fraction</td>
                    <td className="py-3 px-3">{qVoiced !== null ? `${qVoiced}%` : 'N/A'}</td>
                    <td className="py-3 px-3">{rVoiced !== null ? `${rVoiced}%` : 'N/A'}</td>
                    <td className="py-3 px-3 text-[#54665C]">
                      {qVoiced !== null && rVoiced !== null ? `Δ ${Math.abs(qVoiced - rVoiced).toFixed(1)}%` : 'N/A'}
                    </td>
                    <td className="py-3 px-3 text-right font-sans">
                      <span className="text-[10px] font-bold text-[#15803D] bg-[#F0FDF4] px-2 py-0.5 rounded border border-[#15803D]/20">
                        {comparisonResult.speechDurationSeconds}s Evaluated
                      </span>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-3 font-sans font-bold">Harmonics-to-Noise Ratio (HNR)</td>
                    <td className="py-3 px-3">{qHnr !== null ? `${qHnr} dB` : 'N/A'}</td>
                    <td className="py-3 px-3">{rHnr !== null ? `${rHnr} dB` : 'N/A'}</td>
                    <td className="py-3 px-3 text-[#54665C]">
                      {comparisonResult.acousticComparison ? `Δ ${comparisonResult.acousticComparison.hnrDifferenceDb} dB` : 'N/A'}
                    </td>
                    <td className="py-3 px-3 text-right font-sans">
                      <span className="text-[10px] font-bold text-[#15803D] bg-[#F0FDF4] px-2 py-0.5 rounded border border-[#15803D]/20">
                        {comparisonResult.acousticComparison ? 'Within Record' : 'Server Measured'}
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* FRE 702 / SWGDE Legal & Scientific Caveats */}
          <div className="bg-white border border-[#E1EBE4] rounded-2xl p-5 space-y-3 shadow-xs">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#112217] flex items-center space-x-1.5">
              <Scale className="w-4 h-4 text-[#0A3D24]" />
              <span>Judicial Evidentiary Admissibility Notice</span>
            </h3>
            <p className="text-xs text-[#54665C] leading-relaxed">
              {comparisonResult.limitations}
            </p>
            <div className="pt-2 flex items-center justify-between text-xs border-t border-[#E1EBE4]">
              <span className="text-[10px] text-[#54665C] font-mono">
                Analyzed at: {comparisonResult.analyzedAt} &bull; Models: {comparisonResult.modelsUsed.join(', ')}
              </span>
              <button
                onClick={() => setCurrentScreen('report-generation')}
                className="px-3.5 py-1.5 bg-[#0A3D24] text-white font-bold rounded-xl shadow-xs text-xs cursor-pointer"
              >
                Export to Forensic Report →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Past Verifications for this Case Docket */}
      {pastVerifications.length > 0 && (
        <div className="bg-white border border-[#E1EBE4] rounded-2xl p-5 space-y-3 shadow-xs">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#112217]">
            Recorded Speaker Verifications in Docket ({pastVerifications.length})
          </h3>

          <div className="divide-y divide-slate-100">
            {pastVerifications.map((v) => (
              <div key={v.id} className="py-2.5 flex items-center justify-between text-xs">
                <div>
                  <span className="font-mono font-bold text-[#0A3D24]">{v.id}</span>
                  <span className="text-[#54665C] ml-2">vs. {v.subjectName}</span>
                  <span className="text-[10px] text-[#54665C] block">{v.analyzedAt}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="font-mono font-bold text-[#54665C]">
                    {v.similarityScore !== null && v.similarityScore !== undefined ? `${v.similarityScore}%` : 'DSP Only'}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      v.verdict === 'Consistent with the same speaker'
                        ? 'bg-[#F0FDF4] text-[#15803D]'
                        : v.verdict === 'Inconclusive' || v.verdict === 'Model unavailable'
                        ? 'bg-[#FFFBEB] text-[#D97706]'
                        : 'bg-[#FEF2F2] text-[#B91C1C]'
                    }`}
                  >
                    {v.verdict}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal: Enroll Reference Voice Exemplar */}
      {isEnrollModalOpen && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#0A3D24]/20 rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-3">
              <div className="flex items-center space-x-2">
                <Users className="w-5 h-5 text-[#0A3D24]" />
                <h3 className="text-base font-bold text-[#112217] font-serif-title">
                  Enroll Reference Voice Exemplar
                </h3>
              </div>
              <button
                onClick={() => setIsEnrollModalOpen(false)}
                className="text-[#54665C] hover:text-[#112217] p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {enrollError && (
              <div className="p-3 bg-[#FEF2F2] border border-red-200 rounded-xl text-xs text-[#B91C1C]">
                {enrollError}
              </div>
            )}

            <form onSubmit={handleEnrollSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-bold uppercase text-[#54665C] mb-1">
                  Subject Full Name / Known Identity *
                </label>
                <input
                  type="text"
                  required
                  value={enrollSubjectName}
                  onChange={(e) => setEnrollSubjectName(e.target.value)}
                  placeholder="e.g. Target Subject A"
                  className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl px-3.5 py-2 text-[#112217] focus:outline-hidden focus:border-[#0A3D24]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-[#54665C] mb-1">
                  Vocal Condition Tag
                </label>
                <select
                  value={enrollConditionTag}
                  onChange={(e) => setEnrollConditionTag(e.target.value as any)}
                  className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl px-3.5 py-2 text-[#112217] focus:outline-hidden"
                >
                  <option value="Normal">Normal Phonation (Baseline)</option>
                  <option value="Illness/Cold">Illness / Upper Respiratory Congestion</option>
                  <option value="Whispering">Whispering / Acoustic Disguise</option>
                  <option value="Disguised">Suspected Intentional Pitch Shift</option>
                  <option value="Other">Other Environmental Channel</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-[#54665C] mb-1">
                  Reference Audio Exemplar Recording * (WAV / MP3 / FLAC)
                </label>
                <input
                  type="file"
                  accept="audio/*"
                  required
                  onChange={(e) => setEnrollFile(e.target.files?.[0] || null)}
                  className="w-full text-xs text-[#54665C] file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-[#0A3D24] file:text-white cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-[#54665C] mb-1">
                  Consent & Chain-of-Custody Notes
                </label>
                <textarea
                  rows={2}
                  value={enrollConsentNotes}
                  onChange={(e) => setEnrollConsentNotes(e.target.value)}
                  className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 text-[#112217] focus:outline-hidden"
                />
              </div>

              <label className="flex items-start space-x-2.5 p-3 bg-[#F0FDF4] border border-[#15803D]/20 rounded-xl cursor-pointer">
                <input
                  type="checkbox"
                  checked={enrollConsentDeclared}
                  onChange={(e) => setEnrollConsentDeclared(e.target.checked)}
                  className="mt-0.5 rounded text-[#0A3D24] focus:ring-[#0A3D24]"
                />
                <span className="text-[11px] text-[#0A3D24] leading-relaxed">
                  <strong>Lawful Consent Declared:</strong> I certify that this reference voice sample was lawfully acquired with subject consent or pursuant to Title III / FRE 902(11) judicial authorization for forensic comparison.
                </span>
              </label>

              <div className="flex space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEnrollModalOpen(false)}
                  className="flex-1 py-2.5 bg-white border border-[#E1EBE4] text-[#54665C] font-bold rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isEnrolling}
                  className="flex-1 py-2.5 bg-[#0A3D24] hover:bg-[#062817] disabled:opacity-50 text-white font-bold rounded-xl shadow-md cursor-pointer transition-all"
                >
                  {isEnrolling ? 'Hashing & Enrolling...' : 'Enroll Exemplar'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
