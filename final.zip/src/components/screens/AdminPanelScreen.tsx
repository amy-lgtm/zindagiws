import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldAlert,
  Users,
  Cpu,
  Lock,
  Plus,
  CheckCircle2,
  X,
  ShieldCheck,
  Activity,
  Filter,
  Clock,
  RefreshCw,
  AlertCircle,
  UserPlus,
  Ban,
  Mail,
  Download,
  ArrowRightLeft,
  KeyRound,
  Copy
} from 'lucide-react';
import { ScreenId, User, UserRole, AuditLogEntry, SystemConfig } from '../../types';
import { ROLE_CONFIGS } from '../../utils/rbac';
import { BackButton } from '../common/BackButton';
import { PasswordInput } from '../common/PasswordInput';
import { buildSafeCsvContent } from '../../utils/csv';
import { api, clearAuthSession } from '../../utils/api';

interface AdminPanelScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  currentUser: User;
  users?: User[];
  setUsers?: React.Dispatch<React.SetStateAction<User[]>>;
  onSignOut?: () => void | Promise<void>;
}

interface ModelStatusItem {
  name: string;
  role: string;
  architecture: string;
  status: 'AVAILABLE' | 'NOT_CONFIGURED';
  note?: string;
}

interface AdminRoleSummary {
  role: UserRole;
  activeCount: number;
  pendingCount: number;
  maxAllowed: number | null;
}

// Strictly non-administrator assignable roles (single System Security Administrator policy)
const NON_ADMIN_USER_ROLES: UserRole[] = [
  'Lead Forensic Analyst',
  'Forensic Examiner / Expert Witness',
  'Prosecutor / Legal Reviewer'
];

export const AdminPanelScreen: React.FC<AdminPanelScreenProps> = ({
  setCurrentScreen,
  currentUser,
  users: parentUsers,
  setUsers: parentSetUsers,
  onSignOut
}) => {
  const [activeTab, setActiveTab] = useState<'Pending' | 'Activity' | 'Users' | 'Roles' | 'Models' | 'Security'>('Pending');
  const [internalUsers, setInternalUsers] = useState<User[]>([]);
  const users = parentUsers && parentUsers.length > 0 ? parentUsers : internalUsers;
  const setUsers = parentSetUsers || setInternalUsers;

  const [pendingApplicants, setPendingApplicants] = useState<User[]>([]);
  const [selectedRolesByUserId, setSelectedRolesByUserId] = useState<Record<string, UserRole>>({});
  const [rejectingUserId, setRejectingUserId] = useState<string | null>(null);
  const [rejectionReasonInput, setRejectionReasonInput] = useState<string>('');

  const [roleSummaries, setRoleSummaries] = useState<AdminRoleSummary[]>([]);
  const [auditActivities, setAuditActivities] = useState<AuditLogEntry[]>([]);
  const [modelsStatus, setModelsStatus] = useState<ModelStatusItem[]>([]);
  const [systemConfig, setSystemConfig] = useState<SystemConfig | null>(null);
  const [configDirty, setConfigDirty] = useState(false);
  const [configLoadError, setConfigLoadError] = useState<string | null>(null);

  // Retention-enforced archived/completed case purge state (metadata only — no raw evidence or title read)
  interface RetentionCaseSummary {
    id: string;
    status: string;
    date: string;
    updatedDate: string;
    elapsedDays: number;
    retentionDaysRequired: number;
    eligibleForPurge: boolean;
  }
  const [retentionCases, setRetentionCases] = useState<RetentionCaseSummary[]>([]);
  const [purgeCaseId, setPurgeCaseId] = useState('');
  const [purgePassword, setPurgePassword] = useState('');
  const [purgeTotp, setPurgeTotp] = useState('');
  const [purgeConfirmText, setPurgeConfirmText] = useState('');

  // Users Tab Filter State (with debounced query)
  const [userSearch, setUserSearch] = useState('');
  const [debouncedUserSearch, setDebouncedUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState('ALL');
  const [userStatusFilter, setUserStatusFilter] = useState('ALL');

  // Admin Reset User Password & Reset User 2FA Modal State
  const [resetPwUser, setResetPwUser] = useState<User | null>(null);
  const [resetPwCustom, setResetPwCustom] = useState('');
  const [resetPwResult, setResetPwResult] = useState<{ email: string; temporaryPassword: string } | null>(null);
  const [copiedTempPw, setCopiedTempPw] = useState(false);

  const [reset2faUser, setReset2faUser] = useState<User | null>(null);
  const [reset2faAdminPw, setReset2faAdminPw] = useState('');
  const [reset2faAdminTotp, setReset2faAdminTotp] = useState('');

  // SMTP Test State
  const [smtpTestRecipient, setSmtpTestRecipient] = useState(currentUser.email);

  // Exceptional Audited Single-Admin Transfer Modal / Panel State
  const [transferTargetId, setTransferTargetId] = useState('');
  const [transferPassword, setTransferPassword] = useState('');
  const [transferTotp, setTransferTotp] = useState('');
  const [transferDemoteRole, setTransferDemoteRole] = useState<UserRole>('Lead Forensic Analyst');
  const [transferPhrase, setTransferPhrase] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [actionBusyId, setActionBusyId] = useState<string | null>(null);
  const [feedbackBanner, setFeedbackBanner] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Add non-admin user modal state
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('Forensic Examiner / Expert Witness');
  const [agency, setAgency] = useState('Federal Digital Forensics Unit');

  // Activity Filters (with debounced keyword)
  const [filterUser, setFilterUser] = useState('ALL');
  const [filterAction, setFilterAction] = useState('ALL');
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedUserSearch(userSearch), 300);
    return () => clearTimeout(timer);
  }, [userSearch]);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearchTerm(searchTerm), 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  const loadOverviewAndConfig = useCallback(async (forceOverwriteConfig = false) => {
    setConfigLoadError(null);
    try {
      const [pendingList, rolesData, mData, cfg, retCases] = await Promise.all([
        api.getPendingUsers(),
        api.getAdminRoles().catch(() => []),
        api.getModelsStatus(),
        api.getSystemConfig(),
        api.getRetentionCases().catch(() => [])
      ]);

      if (Array.isArray(pendingList)) {
        setPendingApplicants(pendingList);
        setSelectedRolesByUserId((prev) => {
          const next = { ...prev };
          for (const u of pendingList) {
            if (!next[u.id]) {
              const reqRole = u.requestedRole as UserRole;
              next[u.id] = NON_ADMIN_USER_ROLES.includes(reqRole) ? reqRole : 'Forensic Examiner / Expert Witness';
            }
          }
          return next;
        });
      }
      if (Array.isArray(rolesData)) setRoleSummaries(rolesData);

      if (Array.isArray(mData?.models)) {
        setModelsStatus(mData.models);
      } else if (mData && typeof mData === 'object') {
        const parsed: ModelStatusItem[] = Object.entries(mData).map(([key, val]: [string, any]) => ({
          name: val?.name || key,
          role: val?.type || 'Forensic Module',
          architecture: val?.type || key,
          status: val?.status === 'AVAILABLE' ? 'AVAILABLE' : 'NOT_CONFIGURED',
          note: val?.description || ''
        }));
        setModelsStatus(parsed);
      }

      if (cfg && typeof cfg.verificationThreshold === 'number' && (forceOverwriteConfig || !configDirty)) {
        setSystemConfig({
          ...cfg,
          sessionTtlMinutes: cfg.sessionTtlMinutes ?? 480,
          idleLockMinutes: cfg.idleLockMinutes ?? 5
        });
      }
      if (Array.isArray(retCases)) setRetentionCases(retCases);
    } catch (err: any) {
      setConfigLoadError(err?.message || 'Failed to load server policy configuration.');
    }
  }, [configDirty]);

  const loadFilteredUsers = useCallback(async () => {
    try {
      const usersList = await api.getUsers({
        search: debouncedUserSearch,
        role: userRoleFilter,
        status: userStatusFilter
      });
      if (Array.isArray(usersList)) setUsers(usersList);
    } catch {
      setFeedbackBanner({ type: 'error', text: 'Failed to synchronize user directory.' });
    }
  }, [setUsers, debouncedUserSearch, userRoleFilter, userStatusFilter]);

  const loadFilteredActivity = useCallback(async () => {
    try {
      const actLogs = await api.getAdminActivity({
        action: filterAction,
        user: filterUser === 'ALL' ? '' : filterUser,
        search: debouncedSearchTerm,
        limit: 300
      });
      if (Array.isArray(actLogs)) setAuditActivities(actLogs);
    } catch {
      setFeedbackBanner({ type: 'error', text: 'Failed to synchronize activity logs.' });
    }
  }, [filterAction, filterUser, debouncedSearchTerm]);

  const loadAdminData = useCallback(async () => {
    setIsLoading(true);
    try {
      await Promise.all([loadOverviewAndConfig(false), loadFilteredUsers(), loadFilteredActivity()]);
    } finally {
      setIsLoading(false);
    }
  }, [loadOverviewAndConfig, loadFilteredUsers, loadFilteredActivity]);

  useEffect(() => {
    loadOverviewAndConfig(true);
  }, []);

  useEffect(() => {
    loadFilteredUsers();
  }, [loadFilteredUsers]);

  useEffect(() => {
    loadFilteredActivity();
  }, [loadFilteredActivity]);

  const pendingOnly = pendingApplicants.filter((u) => u.status === 'pending');
  const activeOperatorsForTransfer = users.filter(
    (u) => u.status === 'active' && u.role !== 'System Security Administrator'
  );

  const uniqueActivityUsers = Array.from(new Set(auditActivities.map((a) => a.user))).filter(Boolean);
  const filteredActivities = auditActivities.filter((act) => {
    const matchesStatus = filterStatus === 'ALL' || act.status === filterStatus;
    return matchesStatus;
  });

  const handleApproveApplicant = async (userObj: User) => {
    const assignedRole = selectedRolesByUserId[userObj.id] || 'Forensic Examiner / Expert Witness';
    setActionBusyId(userObj.id);
    setFeedbackBanner(null);
    try {
      const res = await api.approveUser(userObj.id, assignedRole);
      const smtpNote = res?.smtpConfigured
        ? res.emailDispatched
          ? ' Notification email dispatched via SMTP.'
          : ` SMTP dispatch note: ${res.emailError || 'failed'}.`
        : '';
      setFeedbackBanner({
        type: 'success',
        text: `Approved ${userObj.name} (${userObj.email}) with role '${assignedRole}'.${smtpNote}`
      });
      await loadAdminData();
    } catch (err: any) {
      setFeedbackBanner({ type: 'error', text: err?.message || 'Failed to approve registration.' });
    } finally {
      setActionBusyId(null);
    }
  };

  const handleRejectApplicant = async (userObj: User) => {
    const cleanReason = rejectionReasonInput.trim();
    if (!cleanReason) {
      setFeedbackBanner({ type: 'error', text: 'A clear written rejection reason is mandatory before confirming rejection.' });
      return;
    }
    setActionBusyId(userObj.id);
    setFeedbackBanner(null);
    try {
      await api.rejectUser(userObj.id, cleanReason);
      setRejectingUserId(null);
      setRejectionReasonInput('');
      setFeedbackBanner({ type: 'success', text: `Rejected application for ${userObj.name} (${userObj.email}).` });
      await loadAdminData();
    } catch (err: any) {
      setFeedbackBanner({ type: 'error', text: err?.message || 'Failed to reject registration.' });
    } finally {
      setActionBusyId(null);
    }
  };

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !password) return;
    setActionBusyId('CREATE_USER');
    setFeedbackBanner(null);
    try {
      const data = await api.createAdminUser({
        name: name.trim(),
        email: email.trim(),
        password,
        role,
        agency: agency.trim()
      });
      setIsAddUserOpen(false);
      setName('');
      setEmail('');
      setPassword('');
      setFeedbackBanner({ type: 'success', text: `Provisioned active account for ${data.user?.email} (${role}).` });
      await loadAdminData();
    } catch (err: any) {
      setFeedbackBanner({ type: 'error', text: err?.message || 'Failed to provision user account.' });
    } finally {
      setActionBusyId(null);
    }
  };

  const handleRoleChange = async (userObj: User, nextRole: UserRole) => {
    if (nextRole === userObj.role) return;
    setActionBusyId(userObj.id);
    setFeedbackBanner(null);
    try {
      await api.updateUserRole(userObj.id, nextRole);
      setFeedbackBanner({ type: 'success', text: `Updated ${userObj.email} role to '${nextRole}' and invalidated prior JWTs.` });
      await loadAdminData();
    } catch (err: any) {
      setFeedbackBanner({ type: 'error', text: err?.message || 'Role update failed.' });
    } finally {
      setActionBusyId(null);
    }
  };

  const handleStatusChange = async (userObj: User, nextStatus: 'active' | 'suspended') => {
    setActionBusyId(userObj.id);
    setFeedbackBanner(null);
    try {
      await api.updateUserStatus(userObj.id, nextStatus);
      setFeedbackBanner({
        type: 'success',
        text: `${userObj.email} status set to '${nextStatus}'${nextStatus !== 'active' ? ' (active sessions invalidated)' : ''}.`
      });
      await loadAdminData();
    } catch (err: any) {
      setFeedbackBanner({ type: 'error', text: err?.message || 'Account status update failed.' });
    } finally {
      setActionBusyId(null);
    }
  };

  const handleAdminResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetPwUser) return;
    setActionBusyId('ADMIN_RESET_PW');
    setFeedbackBanner(null);
    try {
      const res = await api.adminResetUserPassword(
        resetPwUser.id,
        resetPwCustom.trim() ? resetPwCustom.trim() : undefined
      );
      setResetPwResult({
        email: resetPwUser.email,
        temporaryPassword: res.temporaryPassword
      });
      setResetPwCustom('');
      setFeedbackBanner({
        type: 'success',
        text: `Issued one-time temporary password for ${resetPwUser.email}. Prior sessions invalidated; password rotation forced on next sign-in.`
      });
      await loadFilteredUsers();
    } catch (err: any) {
      setFeedbackBanner({ type: 'error', text: err?.message || 'Failed to reset user password.' });
    } finally {
      setActionBusyId(null);
    }
  };

  const handleAdminReset2fa = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reset2faUser) return;
    setActionBusyId('ADMIN_RESET_2FA');
    setFeedbackBanner(null);
    try {
      await api.adminResetUser2fa(reset2faUser.id, {
        currentPassword: reset2faAdminPw,
        totpCode: currentUser.twoFactorEnabled ? reset2faAdminTotp.trim() : undefined
      });
      setFeedbackBanner({
        type: 'success',
        text: `Cleared TOTP 2FA enrollment and invalidated active sessions for ${reset2faUser.email}.`
      });
      setReset2faUser(null);
      setReset2faAdminPw('');
      setReset2faAdminTotp('');
      await loadFilteredUsers();
    } catch (err: any) {
      setFeedbackBanner({ type: 'error', text: err?.message || 'Failed to reset user 2FA.' });
    } finally {
      setActionBusyId(null);
    }
  };

  const handleSaveSystemConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!systemConfig) return;
    setActionBusyId('SAVE_CONFIG');
    setFeedbackBanner(null);
    try {
      const data = await api.updateSystemConfig(systemConfig);
      setSystemConfig(data);
      setConfigDirty(false);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('alfadetect:config-updated', { detail: data }));
      }
      setFeedbackBanner({ type: 'success', text: 'System policy thresholds, session limits & retention settings persisted and audited.' });
    } catch (err: any) {
      setFeedbackBanner({ type: 'error', text: err?.message || 'Failed to save security configuration.' });
    } finally {
      setActionBusyId(null);
    }
  };

  const handleTestSmtp = async () => {
    setActionBusyId('TEST_SMTP');
    setFeedbackBanner(null);
    try {
      const res = await api.testSmtp(smtpTestRecipient.trim());
      setFeedbackBanner({ type: 'success', text: `SMTP test dispatch succeeded to ${res.recipient}.` });
    } catch (err: any) {
      setFeedbackBanner({ type: 'error', text: err?.message || 'SMTP test dispatch failed or SMTP not configured.' });
    } finally {
      setActionBusyId(null);
    }
  };

  const handleAdminTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionBusyId('TRANSFER_ADMIN');
    setFeedbackBanner(null);
    try {
      const res = await api.transferAdmin({
        targetUserId: transferTargetId,
        currentPassword: transferPassword,
        totpCode: currentUser.twoFactorEnabled ? transferTotp.trim() : undefined,
        demoteCurrentToRole: transferDemoteRole,
        confirmText: transferPhrase.trim()
      });
      setFeedbackBanner({
        type: 'success',
        text: res?.message || 'Authority transferred cleanly. Signing out...'
      });
      if (onSignOut) {
        await onSignOut();
      } else {
        clearAuthSession();
        setCurrentScreen('signin');
      }
    } catch (err: any) {
      setFeedbackBanner({ type: 'error', text: err?.message || 'Administrator authority transfer failed.' });
    } finally {
      setActionBusyId(null);
    }
  };

  const handlePurgeCase = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!purgeCaseId) return;
    setActionBusyId('PURGE_CASE');
    setFeedbackBanner(null);
    try {
      const res = await api.purgeCase(purgeCaseId, {
        currentPassword: purgePassword,
        totpCode: currentUser.twoFactorEnabled ? purgeTotp.trim() : undefined,
        confirmText: purgeConfirmText.trim()
      });
      setPurgeCaseId('');
      setPurgePassword('');
      setPurgeTotp('');
      setPurgeConfirmText('');
      setFeedbackBanner({
        type: 'success',
        text: res?.message || 'Retention-eligible case and audio files permanently purged with tombstone audit entry.'
      });
      await loadAdminData();
    } catch (err: any) {
      setFeedbackBanner({ type: 'error', text: err?.message || 'Retention-enforced case purge failed.' });
    } finally {
      setActionBusyId(null);
    }
  };

  const exportAuditLogs = async (format: 'json' | 'csv') => {
    setActionBusyId('EXPORT_LOGS');
    try {
      const allLogs: AuditLogEntry[] = await api.getAdminActivity({
        action: filterAction,
        user: filterUser === 'ALL' ? '' : filterUser,
        search: debouncedSearchTerm,
        limit: 10000
      });
      const exportRows = (Array.isArray(allLogs) ? allLogs : filteredActivities).filter(
        (act) => filterStatus === 'ALL' || act.status === filterStatus
      );
      const content =
        format === 'json'
          ? JSON.stringify(exportRows, null, 2)
          : buildSafeCsvContent(
              ['id', 'timestamp', 'user', 'action', 'resource', 'ipAddress', 'status', 'details'],
              exportRows.map((l) => [l.id, l.timestamp, l.user, l.action, l.resource, l.ipAddress, l.status, l.details || ''])
            );

      const blob = new Blob([content], { type: format === 'json' ? 'application/json' : 'text/csv;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `alfadetect-audit-logs-${new Date().toISOString().slice(0, 10)}.${format}`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err: any) {
      setFeedbackBanner({ type: 'error', text: err?.message || 'Audit log export failed.' });
    } finally {
      setActionBusyId(null);
    }
  };

  return (
    <div id="admin-panel-screen" className="p-4 sm:p-6 space-y-6 bg-[#F4F8F6] min-h-full text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-900/10 pb-5">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('dashboard')} label="Back to Dashboard" variant="pill" />
          </div>
          <div className="flex items-center space-x-2.5 flex-wrap gap-y-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center space-x-2 font-sans">
              <ShieldAlert className="w-6 h-6 text-emerald-700" />
              <span>System Administration & Clearance Governance</span>
            </h1>
            <span className="text-xs font-mono font-bold text-emerald-900 bg-emerald-100 border border-emerald-300 px-3 py-1 rounded-full shadow-xs">
              SOLE SYSTEM ADMINISTRATOR
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Registration approval queue, zero-trust RBAC assignment, single-admin transfer governance, and security policy thresholds
          </p>
        </div>

        <div className="flex items-center space-x-2 self-start sm:self-auto">
          <button
            onClick={loadAdminData}
            disabled={isLoading}
            className="px-3 py-2 bg-white hover:bg-slate-50 border border-emerald-900/15 text-slate-700 font-bold text-xs rounded-xl flex items-center space-x-1.5 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
          <button
            onClick={() => setIsAddUserOpen(true)}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-900/20 flex items-center space-x-1.5 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Provision Operator Account</span>
          </button>
        </div>
      </div>

      {feedbackBanner && (
        <div
          className={`p-3.5 rounded-2xl border text-xs flex items-center justify-between ${
            feedbackBanner.type === 'success'
              ? 'bg-[#F0FDF4] border-[#15803D]/30 text-[#15803D]'
              : 'bg-[#FEF2F2] border-[#B91C1C]/30 text-[#B91C1C]'
          }`}
        >
          <div className="flex items-center space-x-2 font-semibold">
            {feedbackBanner.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
            <span>{feedbackBanner.text}</span>
          </div>
          <button onClick={() => setFeedbackBanner(null)} className="p-1 opacity-70 hover:opacity-100 cursor-pointer">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex items-center space-x-1.5 bg-white border border-emerald-900/10 p-1.5 rounded-2xl overflow-x-auto max-w-4xl shadow-sm">
        {[
          { id: 'Pending', label: 'Pending Registrations', icon: UserPlus, badge: pendingOnly.length },
          { id: 'Users', label: 'User Accounts', icon: Users, badge: users.length },
          { id: 'Activity', label: 'Audit & Activity', icon: Activity },
          { id: 'Roles', label: 'RBAC & Admin Transfer', icon: ShieldCheck },
          { id: 'Models', label: 'AI Model Registry', icon: Cpu },
          { id: 'Security', label: 'Thresholds & SMTP', icon: Lock }
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
              {typeof tab.badge === 'number' && (
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                    activeTab === tab.id
                      ? 'bg-white/20 text-white'
                      : tab.id === 'Pending' && tab.badge > 0
                      ? 'bg-[#C88A2C] text-white'
                      : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: Pending Registration Approvals */}
      {activeTab === 'Pending' && (
        <div className="space-y-4">
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="border-b border-slate-100 pb-3">
              <h2 className="text-sm font-bold text-slate-900 flex items-center space-x-2">
                <Clock className="w-4 h-4 text-[#C88A2C]" />
                <span>New Registration Clearance Queue ({pendingOnly.length} Pending)</span>
              </h2>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Assign an operational forensic/legal role or decline with a mandatory written justification.
              </p>
            </div>

            {pendingApplicants.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500 bg-[#F8FAF9] rounded-2xl border border-[#E1EBE4]">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2 opacity-70" />
                <p className="font-bold text-slate-800">No Pending or Rejected Registration Applications</p>
                <p className="text-[11px] mt-1">All submitted institutional clearance applications have been processed.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {pendingApplicants.map((applicant) => {
                  const isBusy = actionBusyId === applicant.id;
                  const chosenRole =
                    selectedRolesByUserId[applicant.id] ||
                    (NON_ADMIN_USER_ROLES.includes(applicant.requestedRole as UserRole)
                      ? (applicant.requestedRole as UserRole)
                      : 'Forensic Examiner / Expert Witness');
                  return (
                    <div key={applicant.id} className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl space-y-3">
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                            <span className="font-bold text-sm text-slate-900">{applicant.name}</span>
                            <span className="font-mono text-xs text-emerald-800">{applicant.email}</span>
                            <span
                              className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                                applicant.status === 'pending'
                                  ? 'bg-[#FEF3C7] text-[#B2751E] border-[#C88A2C]/30'
                                  : 'bg-[#FEF2F2] text-[#B91C1C] border-[#B91C1C]/30'
                              }`}
                            >
                              {applicant.status.toUpperCase()}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-600 flex flex-wrap gap-x-4 gap-y-1 font-mono">
                            <span>Agency: <strong className="text-slate-800">{applicant.agency}</strong></span>
                            <span>Requested Role: <strong className="text-emerald-800">{applicant.requestedRole || applicant.role}</strong></span>
                            {applicant.certificationId && <span>Cert ID: {applicant.certificationId}</span>}
                            {applicant.createdAt && <span>Submitted: {applicant.createdAt}</span>}
                          </div>
                          {applicant.rejectionReason && (
                            <p className="text-[11px] text-[#B91C1C] font-mono">
                              Rejection Reason: {applicant.rejectionReason}
                            </p>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-2">
                          <select
                            aria-label={`Assign role for ${applicant.email}`}
                            value={chosenRole}
                            onChange={(e) =>
                              setSelectedRolesByUserId((prev) => ({
                                ...prev,
                                [applicant.id]: e.target.value as UserRole
                              }))
                            }
                            className="bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-medium text-slate-900"
                          >
                            {NON_ADMIN_USER_ROLES.map((r) => (
                              <option key={r} value={r}>
                                {r}
                              </option>
                            ))}
                          </select>

                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => handleApproveApplicant(applicant)}
                            className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl flex items-center space-x-1.5 cursor-pointer"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{applicant.status === 'rejected' ? 'Re-Approve' : 'Approve & Activate'}</span>
                          </button>

                          {applicant.status === 'pending' && (
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() => {
                                setRejectingUserId(rejectingUserId === applicant.id ? null : applicant.id);
                                setRejectionReasonInput('');
                              }}
                              className="px-3.5 py-2 bg-white hover:bg-[#FEF2F2] border border-[#B91C1C]/40 text-[#B91C1C] font-bold text-xs rounded-xl flex items-center space-x-1.5 cursor-pointer"
                            >
                              <Ban className="w-3.5 h-3.5" />
                              <span>Reject</span>
                            </button>
                          )}
                        </div>
                      </div>

                      {rejectingUserId === applicant.id && (
                        <div className="pt-3 border-t border-slate-200 flex flex-col sm:flex-row gap-2">
                          <input
                            type="text"
                            required
                            value={rejectionReasonInput}
                            onChange={(e) => setRejectionReasonInput(e.target.value)}
                            placeholder="Mandatory written rejection reason (audited & returned to applicant)..."
                            className="flex-1 bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900"
                          />
                          <button
                            type="button"
                            disabled={isBusy || !rejectionReasonInput.trim()}
                            onClick={() => handleRejectApplicant(applicant)}
                            className="px-4 py-2 bg-[#B91C1C] hover:bg-red-800 disabled:opacity-40 text-white font-bold text-xs rounded-xl cursor-pointer"
                          >
                            Confirm Rejection
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: Users Management Tab with Server-Backed Search & Filters */}
      {activeTab === 'Users' && (
        <div className="space-y-4">
          <div className="bg-white border border-emerald-900/10 p-4 rounded-2xl grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs shadow-sm">
            <input
              type="text"
              value={userSearch}
              onChange={(e) => setUserSearch(e.target.value)}
              placeholder="Search operator name, email, agency..."
              className="bg-slate-50 border border-slate-200 rounded-xl p-2 text-slate-900"
            />
            <select
              value={userRoleFilter}
              onChange={(e) => setUserRoleFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl p-2 text-slate-900 font-medium"
            >
              <option value="ALL">All Roles</option>
              {[...NON_ADMIN_USER_ROLES, 'System Security Administrator'].map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
            <select
              value={userStatusFilter}
              onChange={(e) => setUserStatusFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl p-2 text-slate-900 font-medium"
            >
              <option value="ALL">All Statuses</option>
              <option value="active">Active</option>
              <option value="pending">Pending</option>
              <option value="suspended">Suspended</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>

          <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-emerald-50/80 text-emerald-950 uppercase text-[10px] tracking-wider border-b border-emerald-900/10 font-bold">
                  <tr>
                    <th className="py-3 px-4">User</th>
                    <th className="py-3 px-4">Assigned Role</th>
                    <th className="py-3 px-4">Organization / Unit</th>
                    <th className="py-3 px-4">2FA & Last Login</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.map((u) => {
                    const rConfig = ROLE_CONFIGS[u.role];
                    const isSoleAdmin = u.role === 'System Security Administrator';
                    const isSelf = u.email.toLowerCase() === currentUser.email.toLowerCase();
                    const isBusy = actionBusyId === u.id;
                    return (
                      <tr key={u.id} className="hover:bg-emerald-50/40 transition-colors">
                        <td className="py-3.5 px-4">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 rounded-full bg-emerald-700 text-white text-xs font-bold flex items-center justify-center shadow-xs">
                              {u.avatar}
                            </div>
                            <div>
                              <span className="font-bold text-slate-900 block">
                                {u.name} {isSelf && <span className="text-[10px] text-emerald-700 font-mono">(You)</span>}
                              </span>
                              <span className="text-[10px] text-slate-500 font-mono">{u.email}</span>
                            </div>
                          </div>
                        </td>
                        <td className="py-3.5 px-4">
                          {isSoleAdmin ? (
                            <span className="text-[11px] font-bold px-2.5 py-1 rounded-lg border bg-emerald-900 text-emerald-100 border-emerald-700 inline-block">
                              System Security Administrator (Sole)
                            </span>
                          ) : (
                            <select
                              aria-label={`Role for ${u.email}`}
                              disabled={isSelf || isBusy}
                              value={u.role}
                              onChange={(e) => handleRoleChange(u, e.target.value as UserRole)}
                              className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border cursor-pointer disabled:opacity-60 ${
                                rConfig?.badgeBg || 'bg-slate-100'
                              } ${rConfig?.badgeText || 'text-slate-800'} ${rConfig?.badgeBorder || 'border-slate-200'}`}
                            >
                              {NON_ADMIN_USER_ROLES.map((r) => (
                                <option key={r} value={r}>
                                  {r}
                                </option>
                              ))}
                            </select>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-slate-600 font-medium">{u.agency}</td>
                        <td className="py-3.5 px-4 font-mono text-[10px] space-y-0.5">
                          <div>
                            {u.twoFactorEnabled ? (
                              <span className="text-emerald-700 font-bold">TOTP ACTIVE</span>
                            ) : (
                              <span className="text-slate-400">NO 2FA</span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-500">
                            {u.lastLoginAt ? `Login: ${u.lastLoginAt}` : 'Never signed in'}
                          </div>
                          {u.mustChangePassword && (
                            <span className="inline-block px-1.5 py-0.2 rounded bg-[#FEF3C7] text-[#B2751E] border border-[#C88A2C]/30 font-bold">
                              PW ROTATION REQ
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4">
                          <span
                            className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                              u.status === 'active'
                                ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                                : u.status === 'pending'
                                ? 'bg-[#FEF3C7] text-[#B2751E] border-[#C88A2C]/30'
                                : 'bg-[#FEF2F2] text-[#B91C1C] border-[#B91C1C]/30'
                            }`}
                          >
                            {u.status}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          {!isSelf && !isSoleAdmin && (
                            <div className="inline-flex flex-wrap items-center justify-end gap-1.5">
                              <button
                                type="button"
                                disabled={isBusy}
                                onClick={() => {
                                  setResetPwUser(u);
                                  setResetPwCustom('');
                                  setResetPwResult(null);
                                  setCopiedTempPw(false);
                                }}
                                className="px-2 py-1 text-[10px] font-bold border border-slate-300 text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer disabled:opacity-50"
                                title="Issue temporary password and force rotation"
                              >
                                Reset PW
                              </button>
                              {u.twoFactorEnabled && (
                                <button
                                  type="button"
                                  disabled={isBusy}
                                  onClick={() => {
                                    setReset2faUser(u);
                                    setReset2faAdminPw('');
                                    setReset2faAdminTotp('');
                                  }}
                                  className="px-2 py-1 text-[10px] font-bold border border-[#C88A2C]/40 text-[#B2751E] hover:bg-[#FEF3C7] rounded-lg cursor-pointer disabled:opacity-50"
                                  title="Clear user's TOTP 2FA recovery lock"
                                >
                                  Reset 2FA
                                </button>
                              )}
                              <button
                                disabled={isBusy}
                                onClick={() => handleStatusChange(u, u.status === 'active' ? 'suspended' : 'active')}
                                className={`px-2.5 py-1 text-[10px] font-bold border rounded-lg transition-all cursor-pointer disabled:opacity-50 ${
                                  u.status === 'active'
                                    ? 'border-[#B91C1C]/30 text-[#B91C1C] hover:bg-[#FEF2F2]'
                                    : 'border-emerald-300 text-emerald-800 hover:bg-emerald-50'
                                }`}
                              >
                                {u.status === 'active' ? 'Suspend' : 'Activate'}
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Real Audit Activity History & Export */}
      {activeTab === 'Activity' && (
        <div className="space-y-4">
          <div className="bg-white border border-emerald-900/10 p-4 rounded-2xl space-y-3 shadow-sm text-xs">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2">
              <span className="font-bold text-slate-900 flex items-center space-x-1.5">
                <Filter className="w-4 h-4 text-emerald-700" />
                <span>Live Administrative & Forensic Activity Feed</span>
              </span>
              <div className="flex items-center space-x-2">
                <span className="text-[10px] font-mono text-slate-500">
                  Showing {filteredActivities.length} persisted events
                </span>
                <button
                  type="button"
                  onClick={() => exportAuditLogs('csv')}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-[10px] rounded-lg flex items-center space-x-1 cursor-pointer"
                >
                  <Download className="w-3 h-3" />
                  <span>CSV</span>
                </button>
                <button
                  type="button"
                  onClick={() => exportAuditLogs('json')}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-[10px] rounded-lg flex items-center space-x-1 cursor-pointer"
                >
                  <Download className="w-3 h-3" />
                  <span>JSON</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Operator</label>
                <select
                  value={filterUser}
                  onChange={(e) => setFilterUser(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 text-xs text-slate-900 font-medium"
                >
                  <option value="ALL">All Operators</option>
                  {uniqueActivityUsers.map((u) => (
                    <option key={u} value={u}>
                      {u}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Action Type</label>
                <select
                  value={filterAction}
                  onChange={(e) => setFilterAction(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 text-xs text-slate-900 font-medium"
                >
                  <option value="ALL">All Actions</option>
                  {['LOGIN', 'CONFIG', 'UPLOAD', 'VERIFY', 'WRITE', 'SIGN', 'VIEW', 'DELETE'].map((a) => (
                    <option key={a} value={a}>
                      {a}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Outcome</label>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 text-xs text-slate-900 font-medium"
                >
                  <option value="ALL">All Outcomes</option>
                  <option value="SUCCESS">SUCCESS</option>
                  <option value="FAILED">FAILED</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Search Keyword</label>
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="IP, resource, user..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 text-xs text-slate-900"
                />
              </div>
            </div>
          </div>

          <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-emerald-50/80 text-emerald-950 uppercase text-[10px] tracking-wider border-b border-emerald-900/10 font-bold">
                  <tr>
                    <th className="py-3 px-4">Timestamp</th>
                    <th className="py-3 px-4">Operator</th>
                    <th className="py-3 px-4">Action</th>
                    <th className="py-3 px-4">Resource & Details</th>
                    <th className="py-3 px-4">IP Address</th>
                    <th className="py-3 px-4 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredActivities.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500">
                        No matching audit events recorded yet.
                      </td>
                    </tr>
                  ) : (
                    filteredActivities.map((act) => (
                      <tr key={act.id} className="hover:bg-emerald-50/40 transition-colors">
                        <td className="py-3 px-4 font-mono text-[11px] text-slate-600 whitespace-nowrap">
                          {act.timestamp}
                        </td>
                        <td className="py-3 px-4 font-mono text-xs font-semibold text-slate-900">{act.user}</td>
                        <td className="py-3 px-4">
                          <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
                            {act.action}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="font-semibold text-slate-900 block">{act.resource}</span>
                          {act.details && <span className="text-[10px] text-slate-500 font-mono">{act.details}</span>}
                        </td>
                        <td className="py-3 px-4 font-mono text-[11px]">{act.ipAddress}</td>
                        <td className="py-3 px-4 text-right">
                          <span
                            className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                              act.status === 'SUCCESS'
                                ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                                : 'bg-[#FEF2F2] text-[#B91C1C] border-[#B91C1C]/30'
                            }`}
                          >
                            {act.status}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: RBAC Matrix & Audited Sole-Administrator Transfer */}
      {activeTab === 'Roles' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.values(ROLE_CONFIGS).map((cfg) => {
              const live = roleSummaries.find((s) => s.role === cfg.role);
              return (
                <div key={cfg.role} className="bg-white border border-emerald-900/10 rounded-2xl p-5 space-y-3 shadow-sm text-xs">
                  <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                    <div>
                      <h3 className="font-bold text-slate-900 text-sm">{cfg.role}</h3>
                      {live && (
                        <span className="font-mono text-[10px] text-slate-500">
                          Active: <strong>{live.activeCount}</strong>
                          {live.maxAllowed ? ` / Max ${live.maxAllowed}` : ''} · Pending: {live.pendingCount}
                        </span>
                      )}
                    </div>
                    <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed">{cfg.description}</p>
                  <div className="space-y-1 pt-1">
                    <span className="text-[10px] font-bold uppercase text-slate-400 block">Authorized Capabilities</span>
                    <ul className="space-y-1 list-disc list-inside text-[11px] text-slate-700">
                      {cfg.permissionsSummary.map((p, idx) => (
                        <li key={idx}>{p}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Audited Atomic Sole-Administrator Transfer */}
          <div className="bg-white border border-[#B91C1C]/25 rounded-2xl p-6 space-y-4 shadow-sm text-xs">
            <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center space-x-2">
                  <ArrowRightLeft className="w-4 h-4 text-[#B91C1C]" />
                  <span>Exceptional Single-Administrator Authority Transfer</span>
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Atomically transfers sole System Security Administrator authority to another active operator and revokes all prior admin sessions. Never results in two active administrators.
                </p>
              </div>
              <span className="font-mono text-[10px] font-bold px-2.5 py-0.5 rounded bg-[#FEF2F2] text-[#B91C1C] border border-[#B91C1C]/30">
                ATOMIC & AUDITED
              </span>
            </div>

            {activeOperatorsForTransfer.length === 0 ? (
              <p className="text-xs text-slate-500 bg-slate-50 p-4 rounded-xl border border-slate-200">
                No eligible active non-administrator operators exist yet to receive authority transfer.
              </p>
            ) : (
              <form onSubmit={handleAdminTransfer} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Recipient Active Operator *</label>
                  <select
                    required
                    value={transferTargetId}
                    onChange={(e) => setTransferTargetId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-900"
                  >
                    <option value="">Select active operator...</option>
                    {activeOperatorsForTransfer.map((op) => (
                      <option key={op.id} value={op.id}>
                        {op.name} ({op.email}) — {op.role}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Your Post-Transfer Role *</label>
                  <select
                    value={transferDemoteRole}
                    onChange={(e) => setTransferDemoteRole(e.target.value as UserRole)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-900"
                  >
                    {NON_ADMIN_USER_ROLES.map((r) => (
                      <option key={r} value={r}>
                        {r}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Current Admin Password *</label>
                  <PasswordInput
                    required
                    value={transferPassword}
                    onChange={(e) => setTransferPassword(e.target.value)}
                    autoComplete="current-password"
                    className="bg-slate-50 border-slate-200 p-2.5 text-slate-900"
                  />
                </div>

                {currentUser.twoFactorEnabled && (
                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Your TOTP 2FA Code *</label>
                    <input
                      type="text"
                      required
                      maxLength={6}
                      value={transferTotp}
                      onChange={(e) => setTransferTotp(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="6-digit code"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-mono text-slate-900"
                    />
                  </div>
                )}

                <div className="md:col-span-2">
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                    Type Exact Confirmation Phrase: <span className="font-mono text-[#B91C1C]">TRANSFER_SYSTEM_ADMIN</span> *
                  </label>
                  <input
                    type="text"
                    required
                    value={transferPhrase}
                    onChange={(e) => setTransferPhrase(e.target.value)}
                    placeholder="TRANSFER_SYSTEM_ADMIN"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-mono text-slate-900"
                  />
                </div>

                <div className="md:col-span-2 flex justify-end">
                  <button
                    type="submit"
                    disabled={actionBusyId === 'TRANSFER_ADMIN' || transferPhrase !== 'TRANSFER_SYSTEM_ADMIN' || !transferTargetId}
                    className="px-5 py-2.5 bg-[#B91C1C] hover:bg-red-800 disabled:opacity-40 text-white font-bold rounded-xl cursor-pointer"
                  >
                    {actionBusyId === 'TRANSFER_ADMIN' ? 'Executing Atomic Transfer...' : 'Transfer Sole Admin Authority'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: Live AI Model Registry */}
      {activeTab === 'Models' && (
        <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4 shadow-sm text-xs">
          <div>
            <h3 className="font-bold text-sm text-slate-900">Forensic Engine & Neural Model Availability Registry</h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Live runtime capabilities reported by the enclave server (unconfigured neural weights are honestly marked unavailable).
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            {modelsStatus.map((m, idx) => (
              <div key={idx} className="p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-bold text-slate-900">{m.name}</span>
                  <span
                    className={`font-mono font-bold px-2 py-0.5 rounded text-[10px] ${
                      m.status === 'AVAILABLE'
                        ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                        : 'bg-[#FEF3C7] text-[#B2751E] border border-[#C88A2C]/30'
                    }`}
                  >
                    {m.status}
                  </span>
                </div>
                <span className="text-[11px] text-slate-600 block font-medium">{m.role}</span>
                <span className="text-[11px] font-mono text-slate-500 block">{m.architecture}</span>
                {m.note && (
                  <p className="text-[11px] text-slate-600 pt-2 border-t border-slate-200 leading-relaxed">{m.note}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 6: Security Thresholds, Retention & Live SMTP Test */}
      {activeTab === 'Security' && (
        <div className="space-y-6">
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-5 shadow-sm text-xs">
            <div>
              <h3 className="font-bold text-sm text-slate-900">Forensic Decision Thresholds, Session Policy & Retention Governance</h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Changes persist directly to `/api/admin/config` and govern server-side thresholds, session TTL, idle lock, and 2FA enforcement.
              </p>
            </div>

            {!systemConfig ? (
              <div className="p-6 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl text-center space-y-2">
                <p className="text-xs font-semibold text-slate-700">
                  {configLoadError || 'Loading institutional security configuration from enclave server...'}
                </p>
                {configLoadError && (
                  <button
                    type="button"
                    onClick={() => loadOverviewAndConfig(true)}
                    className="px-4 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-lg cursor-pointer"
                  >
                    Retry Loading Configuration
                  </button>
                )}
              </div>
            ) : (
              <form onSubmit={handleSaveSystemConfig} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                    Speaker Similarity Threshold (%)
                  </label>
                  <input
                    type="number"
                    min={50}
                    max={99}
                    value={systemConfig.verificationThreshold}
                    onChange={(e) => {
                      setConfigDirty(true);
                      setSystemConfig({ ...systemConfig, verificationThreshold: Number(e.target.value) });
                    }}
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                    Inconclusive Margin Band (±%)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={25}
                    value={systemConfig.inconclusiveBand}
                    onChange={(e) => {
                      setConfigDirty(true);
                      setSystemConfig({ ...systemConfig, inconclusiveBand: Number(e.target.value) });
                    }}
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                    Min Voiced Speech Duration (Seconds)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={120}
                    value={systemConfig.minSpeechDurationSec}
                    onChange={(e) => {
                      setConfigDirty(true);
                      setSystemConfig({ ...systemConfig, minSpeechDurationSec: Number(e.target.value) });
                    }}
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                    Evidence Retention Window (Days)
                  </label>
                  <input
                    type="number"
                    min={30}
                    max={36500}
                    value={systemConfig.retentionDaysEvidence}
                    onChange={(e) => {
                      setConfigDirty(true);
                      setSystemConfig({ ...systemConfig, retentionDaysEvidence: Number(e.target.value) });
                    }}
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                    Immutable Audit Log Retention (Days)
                  </label>
                  <input
                    type="number"
                    min={365}
                    max={36500}
                    value={systemConfig.retentionDaysLogs}
                    onChange={(e) => {
                      setConfigDirty(true);
                      setSystemConfig({ ...systemConfig, retentionDaysLogs: Number(e.target.value) });
                    }}
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                    Session Lifetime TTL (Minutes, 5–1440)
                  </label>
                  <input
                    type="number"
                    min={5}
                    max={1440}
                    value={systemConfig.sessionTtlMinutes ?? 480}
                    onChange={(e) => {
                      setConfigDirty(true);
                      setSystemConfig({ ...systemConfig, sessionTtlMinutes: Number(e.target.value) });
                    }}
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                    Terminal Idle Lock Timeout (Minutes, 1–120)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={120}
                    value={systemConfig.idleLockMinutes ?? 5}
                    onChange={(e) => {
                      setConfigDirty(true);
                      setSystemConfig({ ...systemConfig, idleLockMinutes: Number(e.target.value) });
                    }}
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 font-mono text-slate-900"
                  />
                </div>

                <div className="flex items-center space-x-2 pt-4">
                  <input
                    id="enforce-2fa-chk"
                    type="checkbox"
                    checked={systemConfig.enforceTwoFactor}
                    onChange={(e) => {
                      setConfigDirty(true);
                      setSystemConfig({ ...systemConfig, enforceTwoFactor: e.target.checked });
                    }}
                    className="rounded text-emerald-700"
                  />
                  <label htmlFor="enforce-2fa-chk" className="font-semibold text-slate-800 cursor-pointer">
                    Require Mandatory TOTP Two-Factor Authentication for All Operators
                  </label>
                </div>

                <div className="md:col-span-2 p-3.5 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl space-y-1">
                  <div className="flex items-center space-x-2">
                    <input
                      id="enable-gemini-advisory-chk"
                      type="checkbox"
                      checked={Boolean(systemConfig.enableGeminiAdvisory)}
                      onChange={(e) => {
                        setConfigDirty(true);
                        setSystemConfig({ ...systemConfig, enableGeminiAdvisory: e.target.checked });
                      }}
                      className="rounded text-emerald-700"
                    />
                    <label htmlFor="enable-gemini-advisory-chk" className="font-semibold text-slate-800 cursor-pointer">
                      Enable Optional External LLM Advisory Commentary (Gemini — Opt-In)
                    </label>
                  </div>
                  <p className="text-[11px] text-slate-500 pl-6">
                    Disabled by default for air-gapped / strict evidentiary privacy. When enabled, only numeric acoustic measurements and model flags are transmitted (never PII, case titles, or filenames), and output is stored strictly as non-evidentiary <code className="font-mono">aiAdvisory</code>.
                  </p>
                </div>

                <div className="md:col-span-2 flex justify-end pt-2">
                  <button
                    type="submit"
                    disabled={actionBusyId === 'SAVE_CONFIG'}
                    className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
                  >
                    {actionBusyId === 'SAVE_CONFIG' ? 'Saving...' : 'Save Security Policy'}
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Retention-Enforced Archived/Completed Case Purge Governance */}
          <div className="bg-white border border-[#B91C1C]/20 rounded-2xl p-6 space-y-4 shadow-sm text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-sm text-slate-900">
                  Retention-Enforced Archived Case Purge (Metadata Only)
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Irreversibly purges Archived or Completed dockets whose {systemConfig?.retentionDaysEvidence ?? 2555}-day evidence retention window has elapsed. Preserves an immutable tombstone audit record.
                </p>
              </div>
              <span className="font-mono text-[10px] font-bold px-2.5 py-0.5 rounded bg-[#FEF2F2] text-[#B91C1C] border border-[#B91C1C]/30">
                RETENTION GUARDED
              </span>
            </div>

            {retentionCases.length === 0 ? (
              <p className="text-xs text-slate-500 bg-slate-50 p-4 rounded-xl border border-slate-200">
                No Archived or Completed dockets currently exist in the registry.
              </p>
            ) : (
              <form onSubmit={handlePurgeCase} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                    Select Archived / Completed Case Docket *
                  </label>
                  <select
                    required
                    value={purgeCaseId}
                    onChange={(e) => setPurgeCaseId(e.target.value)}
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 text-slate-900"
                  >
                    <option value="">Select docket...</option>
                    {retentionCases.map((rc) => (
                      <option key={rc.id} value={rc.id} disabled={!rc.eligibleForPurge}>
                        {rc.id} ({rc.status}, updated {rc.updatedDate}, {rc.elapsedDays}d elapsed) {rc.eligibleForPurge ? '— ELIGIBLE FOR PURGE' : `— Retention hold (${rc.retentionDaysRequired}d required)`}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                    Admin Password *
                  </label>
                  <PasswordInput
                    required
                    value={purgePassword}
                    onChange={(e) => setPurgePassword(e.target.value)}
                    autoComplete="current-password"
                    className="bg-[#F8FAF9] border-[#E1EBE4] p-2.5 text-slate-900"
                  />
                </div>

                {currentUser.twoFactorEnabled && (
                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                      Your TOTP 2FA Code *
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={6}
                      value={purgeTotp}
                      onChange={(e) => setPurgeTotp(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="6-digit code"
                      className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 font-mono text-slate-900"
                    />
                  </div>
                )}

                <div className={currentUser.twoFactorEnabled ? 'md:col-span-2' : ''}>
                  <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                    Type Exact Phrase: <span className="font-mono text-[#B91C1C]">PURGE_ARCHIVED_CASE</span> *
                  </label>
                  <input
                    type="text"
                    required
                    value={purgeConfirmText}
                    onChange={(e) => setPurgeConfirmText(e.target.value)}
                    placeholder="PURGE_ARCHIVED_CASE"
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 font-mono text-slate-900"
                  />
                </div>

                <div className="md:col-span-2 flex justify-end">
                  <button
                    type="submit"
                    disabled={actionBusyId === 'PURGE_CASE' || !purgeCaseId || purgeConfirmText !== 'PURGE_ARCHIVED_CASE'}
                    className="px-5 py-2.5 bg-[#B91C1C] hover:bg-red-800 disabled:opacity-40 text-white font-bold text-xs rounded-xl cursor-pointer"
                  >
                    {actionBusyId === 'PURGE_CASE' ? 'Purging Case...' : 'Execute Retention Purge'}
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Live SMTP Delivery Test Panel */}
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4 shadow-sm text-xs">
            <div>
              <h3 className="font-bold text-sm text-slate-900 flex items-center space-x-2">
                <Mail className="w-4 h-4 text-emerald-700" />
                <span>SMTP Transport Verification (Nodemailer)</span>
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Tests real outbound email dispatch using configured SMTP_HOST / SMTP_PORT / SMTP_USER / SMTP_PASS environment variables. Never simulates delivery.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="email"
                value={smtpTestRecipient}
                onChange={(e) => setSmtpTestRecipient(e.target.value)}
                placeholder="recipient@agency.gov"
                className="flex-1 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl px-3.5 py-2 font-mono text-slate-900"
              />
              <button
                type="button"
                disabled={actionBusyId === 'TEST_SMTP'}
                onClick={handleTestSmtp}
                className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold rounded-xl cursor-pointer"
              >
                {actionBusyId === 'TEST_SMTP' ? 'Testing SMTP...' : 'Send Live Test Email'}
              </button>
            </div>
          </div>

          <div className="p-4 bg-[#032319] text-emerald-300 rounded-2xl space-y-1.5 font-mono text-xs shadow-inner">
            <div className="flex justify-between items-center border-b border-emerald-900/60 pb-2">
              <span className="font-bold text-white uppercase">CRYPTOGRAPHIC ENCLAVE STATUS</span>
              <span className="text-emerald-400 font-bold">scrypt + Ed25519 + AES-256-GCM + SHA-256</span>
            </div>
            <p>PASSWORD KDF: Node.js crypto.scryptSync (N=16384, r=8, p=1) + timingSafeEqual</p>
            <p>SIGNING & CUSTODY: Asymmetric Ed25519 Enclave Keypair + Chained SHA-256 Ledger</p>
            <p>THRESHOLD POLICY: {systemConfig?.thresholdVersion || 'Pending sync'} | LAST UPDATED BY: {systemConfig?.updatedBy || 'System Default'}</p>
          </div>
        </div>
      )}

      {/* Admin Reset User Password Modal */}
      {resetPwUser && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white border border-emerald-900/20 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-bold text-sm text-slate-900 flex items-center space-x-2">
                <KeyRound className="w-4 h-4 text-emerald-700" />
                <span>Reset Operator Password</span>
              </h3>
              <button onClick={() => setResetPwUser(null)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            {resetPwResult ? (
              <div className="space-y-3 text-xs">
                <div className="p-3 bg-[#F0FDF4] border border-[#15803D]/30 rounded-xl space-y-2">
                  <p className="font-bold text-[#15803D]">Temporary Password Issued for {resetPwResult.email}</p>
                  <p className="text-[11px] text-slate-600">
                    All active sessions for this user have been invalidated. The user will be forced to rotate this temporary password on next login.
                  </p>
                  <div className="flex items-center justify-between bg-white border border-emerald-200 rounded-lg p-2 font-mono text-xs text-slate-900">
                    <span className="break-all select-all">{resetPwResult.temporaryPassword}</span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText(resetPwResult.temporaryPassword);
                        setCopiedTempPw(true);
                      }}
                      className="ml-2 px-2 py-1 bg-emerald-50 text-emerald-800 rounded font-bold shrink-0 flex items-center space-x-1 cursor-pointer"
                    >
                      <Copy className="w-3 h-3" />
                      <span>{copiedTempPw ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setResetPwUser(null)}
                  className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl cursor-pointer"
                >
                  Done
                </button>
              </div>
            ) : (
              <form onSubmit={handleAdminResetPassword} className="space-y-3 text-xs">
                <p className="text-slate-600">
                  Issue a temporary password for <strong>{resetPwUser.name}</strong> ({resetPwUser.email}). Leave blank to auto-generate a 16-character cryptographic temporary password.
                </p>
                <div>
                  <label className="text-[11px] font-bold uppercase text-slate-500 block mb-1">
                    Custom Temporary Password (Optional)
                  </label>
                  <PasswordInput
                    value={resetPwCustom}
                    onChange={(e) => setResetPwCustom(e.target.value)}
                    placeholder="Leave blank to auto-generate strong temporary password"
                    showStrengthChecklist={resetPwCustom.length > 0}
                    emailForStrengthCheck={resetPwUser.email}
                    className="bg-slate-50 border-slate-200 p-2.5 text-slate-900"
                  />
                </div>
                <div className="flex justify-end space-x-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setResetPwUser(null)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={actionBusyId === 'ADMIN_RESET_PW'}
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-xl font-bold cursor-pointer"
                  >
                    {actionBusyId === 'ADMIN_RESET_PW' ? 'Issuing...' : 'Issue Temporary Password'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Admin Reset User 2FA Modal */}
      {reset2faUser && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white border border-[#C88A2C]/30 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-bold text-sm text-slate-900 flex items-center space-x-2">
                <ShieldAlert className="w-4 h-4 text-[#B2751E]" />
                <span>Reset Operator TOTP 2FA</span>
              </h3>
              <button onClick={() => setReset2faUser(null)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAdminReset2fa} className="space-y-3 text-xs">
              <p className="text-slate-600">
                Clearing 2FA for <strong>{reset2faUser.name}</strong> ({reset2faUser.email}) removes their TOTP secret and recovery codes and revokes active sessions.
              </p>
              <div>
                <label className="text-[11px] font-bold uppercase text-slate-500 block mb-1">
                  Your Admin Password *
                </label>
                <PasswordInput
                  required
                  value={reset2faAdminPw}
                  onChange={(e) => setReset2faAdminPw(e.target.value)}
                  autoComplete="current-password"
                  className="bg-slate-50 border-slate-200 p-2.5 text-slate-900"
                />
              </div>
              {currentUser.twoFactorEnabled && (
                <div>
                  <label className="text-[11px] font-bold uppercase text-slate-500 block mb-1">
                    Your Admin TOTP 2FA Code *
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={reset2faAdminTotp}
                    onChange={(e) => setReset2faAdminTotp(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="6-digit TOTP code"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-mono text-slate-900"
                  />
                </div>
              )}
              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setReset2faUser(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={actionBusyId === 'ADMIN_RESET_2FA'}
                  className="px-4 py-2 bg-[#B2751E] hover:bg-[#925E12] disabled:opacity-50 text-white rounded-xl font-bold cursor-pointer"
                >
                  {actionBusyId === 'ADMIN_RESET_2FA' ? 'Clearing...' : 'Confirm 2FA Reset'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Provision Non-Admin Operator Account Modal */}
      {isAddUserOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white border border-emerald-900/20 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-bold text-sm text-slate-900">Provision Active Operator Account</h3>
              <button onClick={() => setIsAddUserOpen(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddUser} className="space-y-3 text-xs">
              <div>
                <label className="text-[11px] font-bold uppercase text-slate-500 block mb-1">Full Official Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Agent Robert Thorne"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-900 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase text-slate-500 block mb-1">Agency Email *</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="r.thorne@forensics.gov"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-900 font-mono focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase text-slate-500 block mb-1">
                  Initial Password (12+ chars, A-z, 0-9, symbol) *
                </label>
                <PasswordInput
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="new-password"
                  placeholder="Min 12 chars strong password"
                  showStrengthChecklist
                  emailForStrengthCheck={email}
                  className="bg-slate-50 border-slate-200 p-2.5 text-slate-900 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase text-slate-500 block mb-1">Assigned Role (Non-Admin)</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-900 font-medium focus:outline-none focus:border-emerald-600"
                >
                  {NON_ADMIN_USER_ROLES.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-slate-500 mt-1">
                  Strictly one System Security Administrator may exist. Use Transfer Authority in the RBAC tab if handoff is required.
                </p>
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase text-slate-500 block mb-1">Organization / Agency</label>
                <input
                  type="text"
                  value={agency}
                  onChange={(e) => setAgency(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-900 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddUserOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={actionBusyId === 'CREATE_USER'}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-xl font-bold shadow-md shadow-emerald-900/20 cursor-pointer"
                >
                  {actionBusyId === 'CREATE_USER' ? 'Provisioning...' : 'Provision Active Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
