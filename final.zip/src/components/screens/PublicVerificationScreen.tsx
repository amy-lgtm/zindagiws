import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  FileCheck2,
  Search,
  RefreshCw,
  Clock,
  Fingerprint,
  Hash,
  Award
} from 'lucide-react';
import { ScreenId } from '../../types';
import { BackButton } from '../common/BackButton';

interface PublicVerificationScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  initialToken?: string;
}

export const PublicVerificationScreen: React.FC<PublicVerificationScreenProps> = ({
  setCurrentScreen,
  initialToken = ''
}) => {
  const [tokenInput, setTokenInput] = useState(initialToken);
  const [isLoading, setIsLoading] = useState(false);
  const [verificationResult, setVerificationResult] = useState<any>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [verificationSteps, setVerificationSteps] = useState<
    Array<{ step: string; status: 'pending' | 'success' | 'failed'; detail: string }>
  >([]);

  const executeVerification = async (tokenToVerify: string) => {
    if (!tokenToVerify.trim()) {
      setErrorMessage('Please enter a valid Report Verification Token issued with an exported ALFADetect report.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);
    setVerificationResult(null);

    setVerificationSteps([
      { step: '1. Token Format Verification', status: 'pending', detail: 'Validating verification token format' },
      { step: '2. Immutable Ledger Lookup', status: 'pending', detail: 'Querying cryptographic verification ledger' },
      { step: '3. Ed25519 Digital Seal & Canonical Payload Check', status: 'pending', detail: 'Validating enclave Ed25519 signature against public key' },
      { step: '4. Credential Re-Auth & Witness Record Audit', status: 'pending', detail: 'Auditing accredited examiner & analyst attestation' },
      { step: '5. Live Evidence SHA-256 Recalculation', status: 'pending', detail: 'Comparing stored audio bytes against certified digest' },
      { step: '6. Judicial Revocation Status Check', status: 'pending', detail: 'Checking court revocation and tamper flags' }
    ]);

    try {
      setVerificationSteps((prev) =>
        prev.map((s, i) => (i === 0 ? { ...s, status: 'success', detail: 'Token structure valid' } : s))
      );

      const response = await fetch(`/api/public/verify-report/${encodeURIComponent(tokenToVerify.trim())}`);
      const data = await response.json();

      if (response.ok && data.verified) {
        setVerificationSteps((prev) =>
          prev.map((s) => ({ ...s, status: 'success', detail: 'Verified & intact' }))
        );
        setVerificationResult(data);
      } else {
        setVerificationSteps((prev) =>
          prev.map((s, i) =>
            i === 0
              ? { ...s, status: 'success', detail: 'Token syntax parsed' }
              : { ...s, status: 'failed', detail: data.error || 'Verification proof failed' }
          )
        );
        setErrorMessage(data.error || 'Report verification failed. Token is invalid, revoked, or tampered.');
      }
    } catch {
      setErrorMessage('Network connection error: Unable to contact ALFADetect verification server.');
      setVerificationSteps((prev) =>
        prev.map((s) => ({ ...s, status: 'failed', detail: 'Server communication error' }))
      );
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (initialToken) {
      executeVerification(initialToken);
    }
  }, [initialToken]);

  return (
    <div id="public-verification-screen" className="min-h-screen bg-[#F4F8F6] text-slate-800 p-4 sm:p-6 md:p-10 font-sans">
      {/* Top Banner */}
      <div className="max-w-4xl mx-auto mb-6 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-800 flex items-center justify-center text-white shadow-md">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">ALFADetect</h1>
            <p className="text-xs text-slate-500 font-medium">Official Public Forensic Evidence Verification Portal</p>
          </div>
        </div>

        <BackButton
          onClick={() => {
            const hasAuth = typeof window !== 'undefined' && !!localStorage.getItem('auth_session_token');
            setCurrentScreen(hasAuth ? 'dashboard' : 'landing');
          }}
          label="Back"
          variant="pill"
        />
      </div>

      <div className="max-w-4xl mx-auto space-y-6">
        {/* Token Search Bar */}
        <div className="bg-white border border-emerald-900/15 rounded-3xl p-6 shadow-sm">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
            Enter Verification Token from Official ALFADetect Forensic Report
          </label>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-emerald-800/60 absolute left-3.5 top-3.5" />
              <input
                type="text"
                value={tokenInput}
                onChange={(e) => setTokenInput(e.target.value)}
                placeholder="Enter Verification Token (e.g. VRF-...)"
                className="w-full pl-10 pr-4 py-2.5 bg-[#F4F8F6] border border-emerald-900/20 rounded-xl text-sm font-mono focus:outline-hidden focus:ring-2 focus:ring-emerald-700 text-slate-900"
              />
            </div>
            <button
              onClick={() => executeVerification(tokenInput)}
              disabled={isLoading}
              className="px-6 py-2.5 bg-emerald-800 hover:bg-emerald-900 disabled:opacity-50 text-white rounded-xl text-xs font-bold tracking-wide shadow-md shadow-emerald-900/20 transition-all flex items-center justify-center space-x-2 shrink-0 cursor-pointer"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Verifying Proofs...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Verify Report Authenticity</span>
                </>
              )}
            </button>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px] text-slate-500 font-mono">
            <span>Tokens are cryptographically issued upon forensic report export.</span>
            <button
              type="button"
              onClick={() => {
                setTokenInput('VRF-INVALID-TOKEN');
                executeVerification('VRF-INVALID-TOKEN');
              }}
              className="px-2 py-0.5 bg-red-50 text-red-700 rounded-md border border-red-200 hover:bg-red-100 cursor-pointer"
            >
              Test Invalid Token Rejection
            </button>
          </div>
        </div>

        {/* Verification Progress Check */}
        {verificationSteps.length > 0 && (
          <div className="bg-white border border-emerald-900/15 rounded-3xl p-6 shadow-sm space-y-4">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Cryptographic Proof Verification Pipeline
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {verificationSteps.map((s, idx) => (
                <div
                  key={idx}
                  className={`p-3 rounded-2xl border flex items-start space-x-3 ${
                    s.status === 'success'
                      ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                      : s.status === 'failed'
                      ? 'bg-red-50/70 border-red-200 text-red-900'
                      : 'bg-slate-50 border-slate-200 text-slate-600'
                  }`}
                >
                  <div className="mt-0.5 shrink-0">
                    {s.status === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                    {s.status === 'failed' && <XCircle className="w-4 h-4 text-red-600" />}
                    {s.status === 'pending' && <Clock className="w-4 h-4 text-slate-400 animate-pulse" />}
                  </div>
                  <div>
                    <p className="text-xs font-semibold leading-tight">{s.step}</p>
                    <p className="text-[11px] opacity-80 font-mono mt-0.5">{s.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Result Verdict Card */}
        {verificationResult && (
          <div className="bg-white border-2 border-emerald-600 rounded-3xl p-8 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-emerald-100">
              <div className="flex items-center space-x-4">
                <div className="w-14 h-14 rounded-2xl bg-emerald-600 flex items-center justify-center text-white shadow-lg shadow-emerald-600/30">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-2xl font-extrabold tracking-tight text-emerald-900">✓ VERIFIED REPORT</span>
                    <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold uppercase rounded-md border border-emerald-300">
                      Ed25519 Signed
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">
                    This forensic analysis report matches the server ledger, Ed25519 digital signature, and live evidence SHA-256 digest.
                  </p>
                </div>
              </div>

              <div className="text-right font-mono text-xs text-slate-500 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <p className="text-[10px] uppercase font-bold text-slate-400">Verified Timestamp</p>
                <p className="font-semibold text-slate-800">{verificationResult.verificationTimestamp}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-[#F4F8F6] border border-emerald-900/10 space-y-2">
                <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-emerald-900">
                  <FileCheck2 className="w-4 h-4 text-emerald-700" />
                  <span>Report Identification</span>
                </div>
                <div className="space-y-1 text-xs">
                  <p className="text-slate-500">Report ID: <span className="font-mono font-bold text-slate-800">{verificationResult.reportId}</span></p>
                  <p className="text-slate-500">Case Docket: <span className="font-mono font-bold text-slate-800">{verificationResult.caseId}</span></p>
                  <p className="text-slate-500">Evidence File: <span className="font-mono text-slate-800">{verificationResult.evidenceFilename}</span></p>
                  <p className="text-slate-500">Evidence ID: <span className="font-mono text-slate-800">{verificationResult.evidenceId}</span></p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#F4F8F6] border border-emerald-900/10 space-y-2">
                <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-emerald-900">
                  <Award className="w-4 h-4 text-emerald-700" />
                  <span>Forensic Verdict & Confidence</span>
                </div>
                <div className="space-y-1 text-xs">
                  <p className="text-slate-500">
                    Verdict:{' '}
                    <span
                      className={`font-bold font-mono px-2 py-0.5 rounded-md ${
                        verificationResult.verdict === 'DEEPFAKE'
                          ? 'text-red-700 bg-red-100'
                          : verificationResult.verdict === 'AUTHENTIC'
                          ? 'text-emerald-800 bg-emerald-100'
                          : 'text-amber-800 bg-amber-100'
                      }`}
                    >
                      {verificationResult.verdict}
                    </span>
                  </p>
                  <p className="text-slate-500">
                    Ensemble Confidence:{' '}
                    <span className="font-bold text-slate-900 font-mono">
                      {typeof verificationResult.confidenceScore === 'number'
                        ? `${verificationResult.confidenceScore}%`
                        : verificationResult.confidenceScore}
                    </span>
                  </p>
                  <p className="text-slate-500">Lead Analyst: <span className="font-semibold text-slate-800">{verificationResult.leadAnalyst}</span></p>
                  <p className="text-slate-500">Signature Method: <span className="font-mono font-semibold text-slate-800">{verificationResult.signatureMethod || 'Ed25519'}</span></p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#F4F8F6] border border-emerald-900/10 space-y-2">
                <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-emerald-900">
                  <Fingerprint className="w-4 h-4 text-emerald-700" />
                  <span>Expert Witness Attestation</span>
                </div>
                <div className="space-y-1 text-xs">
                  <p className="text-slate-500">Witness / Signer: <span className="font-semibold text-slate-800">{verificationResult.expertWitness}</span></p>
                  <p className="text-slate-500">Accreditation: <span className="font-mono text-slate-800">{verificationResult.expertCertificationId}</span></p>
                  <p className="text-slate-500">Authentication Proof: <span className="font-bold text-emerald-700">{verificationResult.biometricVerificationStatus}</span></p>
                  <p className="text-slate-500">Signed Timestamp: <span className="font-mono text-slate-800">{verificationResult.signedAt}</span></p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#F4F8F6] border border-emerald-900/10 space-y-2">
                <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-emerald-900">
                  <Hash className="w-4 h-4 text-emerald-700" />
                  <span>Cryptographic Seal</span>
                </div>
                <div className="space-y-1 text-xs">
                  <p className="text-slate-500">Evidence SHA-256:</p>
                  <p className="font-mono text-[11px] text-slate-800 break-all bg-white p-1.5 rounded-md border border-emerald-900/10">
                    {verificationResult.evidenceSha256}
                  </p>
                  <p className="text-slate-500 mt-1">Canonical Payload Seal Digest:</p>
                  <p className="font-mono text-[11px] text-slate-800 break-all bg-white p-1.5 rounded-md border border-emerald-900/10">
                    {verificationResult.digitalSealHash}
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-900 flex items-start space-x-3">
              <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Public Verification Security Guarantee & Scientific Scope</p>
                <p className="text-emerald-800/90 text-[11px] mt-0.5 leading-relaxed">
                  This public verification seal confirms the authenticity, Ed25519 signature validity, and SHA-256 byte integrity of the forensic exhibit without exposing raw evidence audio, operator passwords, or confidential case notes. Reported automated acoustic scores remain probabilistic decision support—never standalone proof of speaker identity—and require accredited expert testimony under FRE 702.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Failed Result Card */}
        {errorMessage && (
          <div className="bg-white border-2 border-red-500 rounded-3xl p-8 shadow-xl space-y-4">
            <div className="flex items-center space-x-4">
              <div className="w-14 h-14 rounded-2xl bg-red-600 flex items-center justify-center text-white shadow-lg shadow-red-600/30">
                <XCircle className="w-8 h-8" />
              </div>
              <div>
                <h2 className="text-2xl font-extrabold tracking-tight text-red-900">✗ REPORT VERIFICATION FAILED</h2>
                <p className="text-xs text-slate-600 mt-0.5">
                  The provided token cannot be verified against the official forensic ledger.
                </p>
              </div>
            </div>

            <div className="p-4 bg-red-50 border border-red-200 rounded-2xl text-xs text-red-900">
              <p className="font-bold">Reason for Verification Failure:</p>
              <p className="text-red-800 mt-1">{errorMessage}</p>
            </div>

            <p className="text-[11px] text-slate-500">
              Please confirm you entered the exact token printed on an exported ALFADetect forensic report or contact the issuing agency.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
