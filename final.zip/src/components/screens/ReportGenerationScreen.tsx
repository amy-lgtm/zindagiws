import React, { useState, useEffect } from 'react';
import { jsPDF } from 'jspdf';
import {
  FileCheck2,
  Download,
  CheckCircle2,
  Printer,
  QrCode,
  Lock,
  Play,
  Pause,
  AlertTriangle,
  BadgeCheck,
  Copy,
  Check,
  X,
  ExternalLink,
  KeyRound,
  ShieldCheck
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip
} from 'recharts';
import {
  ScreenId,
  AudioEvidence,
  User,
  Case,
  DeepfakeAnalysisRecord,
  ChainOfCustodyEvent,
  ExpertReview,
  LegalReview,
  PublicReportVerificationRecord
} from '../../types';
import { api, authFetch, ApiError } from '../../utils/api';
import { speakAudioEvidence, stopAudioEvidence, playSuccessSound } from '../../utils/audioPlayer';
import { calculateFileSHA256, calculateStringSHA256, verifyHashMatch } from '../../utils/crypto';
import { BackButton } from '../common/BackButton';

interface ReportGenerationScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  selectedCaseId: string;
  activeEvidence: AudioEvidence;
  currentUser?: User;
}

function escapeHtml(value: unknown): string {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export const ReportGenerationScreen: React.FC<ReportGenerationScreenProps> = ({
  setCurrentScreen,
  selectedCaseId,
  activeEvidence,
  currentUser
}) => {
  const activeCaseId = selectedCaseId || '';

  const [format, setFormat] = useState<'pdf' | 'docx' | 'html'>('pdf');
  const [reportType, setReportType] = useState<'preliminary' | 'final'>('preliminary');
  const [isGenerating, setIsGenerating] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);
  const [exportSuccessToken, setExportSuccessToken] = useState<string | null>(null);
  const [isPlayingVoice, setIsPlayingVoice] = useState(false);
  const [activeSection, setActiveSection] = useState<string>('section-1');

  const [caseRecord, setCaseRecord] = useState<Case | null>(null);
  const [caseEvidenceList, setCaseEvidenceList] = useState<AudioEvidence[]>([]);
  const [selectedEvidenceId, setSelectedEvidenceId] = useState<string>(
    activeEvidence?.id && activeEvidence.id !== 'EV-INIT' ? activeEvidence.id : ''
  );
  const [analyses, setAnalyses] = useState<DeepfakeAnalysisRecord[]>([]);
  const [custodyEvents, setCustodyEvents] = useState<ChainOfCustodyEvent[]>([]);
  const [expertReviews, setExpertReviews] = useState<ExpertReview[]>([]);
  const [legalReview, setLegalReview] = useState<LegalReview | null>(null);
  const [publicReport, setPublicReport] = useState<PublicReportVerificationRecord | null>(null);

  // Hash Verification Modal State
  const [copiedHash, setCopiedHash] = useState(false);
  const [showHashVerifierModal, setShowHashVerifierModal] = useState(false);
  const [inputHashToTest, setInputHashToTest] = useState('');
  const [testHashResult, setTestHashResult] = useState<{ matches: boolean; computedHash: string } | null>(null);

  // QR Modal State
  const [showQrModal, setShowQrModal] = useState(false);
  const [isScanningQr, setIsScanningQr] = useState(false);
  const [qrCheckResult, setQrCheckResult] = useState<string | null>(null);

  useEffect(() => {
    if (!activeCaseId) return;
    let cancelled = false;

    async function loadReportArtifacts() {
      try {
        const [caseRes, evRes, anRes, cocRes, expRes, legRes, pubRes] = await Promise.all([
          authFetch(`/api/cases/${encodeURIComponent(activeCaseId)}`),
          authFetch(`/api/cases/${encodeURIComponent(activeCaseId)}/evidence`),
          authFetch(`/api/cases/${encodeURIComponent(activeCaseId)}/analyses`),
          authFetch(`/api/cases/${encodeURIComponent(activeCaseId)}/chain-of-custody`),
          authFetch(`/api/cases/${encodeURIComponent(activeCaseId)}/expert-reviews`),
          authFetch(`/api/cases/${encodeURIComponent(activeCaseId)}/legal-review`),
          authFetch(`/api/cases/${encodeURIComponent(activeCaseId)}/public-report`)
        ]);
        if (cancelled) return;

        if (caseRes.ok) setCaseRecord(await caseRes.json());
        if (evRes.ok) {
          const evList: AudioEvidence[] = await evRes.json();
          setCaseEvidenceList(evList);
          if (Array.isArray(evList) && evList.length > 0) {
            setSelectedEvidenceId((prev) =>
              prev && evList.some((e) => e.id === prev) ? prev : evList[0].id
            );
          }
        }
        if (anRes.ok) setAnalyses(await anRes.json());
        if (cocRes.ok) setCustodyEvents(await cocRes.json());
        if (expRes.ok) setExpertReviews(await expRes.json());
        if (legRes.ok) setLegalReview(await legRes.json());
        if (pubRes.ok) {
          const pubJson = await pubRes.json();
          setPublicReport(pubJson?.record || null);
        }
      } catch (err) {
        console.warn('Report generation data load note:', err);
      }
    }

    loadReportArtifacts();
    return () => {
      cancelled = true;
    };
  }, [activeCaseId]);

  const primaryEvidence =
    caseEvidenceList.find((e) => e.id === selectedEvidenceId) ||
    (activeEvidence?.id && activeEvidence.id !== 'EV-INIT' && activeEvidence.caseId === activeCaseId
      ? activeEvidence
      : null) ||
    caseEvidenceList[0] ||
    activeEvidence;

  const latestAnalysis =
    (primaryEvidence?.id && primaryEvidence.id !== 'EV-INIT'
      ? analyses.find((a) => a.evidenceId === primaryEvidence.id) || null
      : null) ||
    analyses[0] ||
    null;
  const approvedExpert = expertReviews.find((r) => r.status === 'Approved') || null;
  const certifiedExpert = approvedExpert || expertReviews[0] || null;
  const isFinalEligible = Boolean(approvedExpert && legalReview?.status === 'CERTIFIED');

  useEffect(() => {
    if (!isFinalEligible && reportType === 'final') {
      setReportType('preliminary');
    }
  }, [isFinalEligible, reportType]);

  const realEvidenceHash = primaryEvidence?.sha256Hash || '';
  const hasRealHash = /^[0-9a-fA-F]{64}$/.test(realEvidenceHash);
  const displayVerdict = caseRecord?.verdict || latestAnalysis?.verdict || 'INCONCLUSIVE';
  const confidenceValue =
    typeof latestAnalysis?.overallConfidence === 'number'
      ? `${latestAnalysis.overallConfidence}%`
      : 'INCONCLUSIVE (Pending Neural Weights)';

  const handleCopyHash = () => {
    if (!realEvidenceHash) return;
    navigator.clipboard.writeText(realEvidenceHash);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2500);
  };

  const handleTestHashMatch = async (textToHash: string) => {
    if (!textToHash || !hasRealHash) return;
    try {
      const computed =
        textToHash.length === 64 && /^[0-9a-fA-F]+$/.test(textToHash)
          ? textToHash.trim().toLowerCase()
          : await calculateStringSHA256(textToHash);
      setTestHashResult({ matches: verifyHashMatch(computed, realEvidenceHash), computedHash: computed });
    } catch {
      setTestHashResult({ matches: false, computedHash: 'Error calculating hash' });
    }
  };

  const handleFileHashTest = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !hasRealHash) return;
    try {
      const computed = await calculateFileSHA256(file);
      setTestHashResult({ matches: verifyHashMatch(computed, realEvidenceHash), computedHash: computed });
    } catch {
      setTestHashResult({ matches: false, computedHash: 'Failed to read file' });
    }
  };

  const handleVerifyIssuedToken = async () => {
    const token = publicReport?.token || exportSuccessToken;
    if (!token) {
      setQrCheckResult('No verification token has been issued yet. Export a forensic report first.');
      return;
    }
    setIsScanningQr(true);
    setQrCheckResult(null);
    try {
      const res = await fetch(`/api/public/verify-report/${encodeURIComponent(token)}`);
      const data = await res.json();
      if (res.ok && data.verified) {
        setQrCheckResult(`✓ Ledger Verified (${data.token}) — Ed25519 Seal & Evidence Intact`);
        playSuccessSound();
      } else {
        setQrCheckResult(data?.error || 'Verification token could not be confirmed.');
      }
    } catch {
      setQrCheckResult('Network error contacting verification registry.');
    } finally {
      setIsScanningQr(false);
    }
  };

  const handleOpenPublicPortal = () => {
    setShowQrModal(false);
    const activeToken = publicReport?.token || exportSuccessToken;
    if (activeToken && typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      url.searchParams.set('token', activeToken);
      url.searchParams.set('screen', 'public-verify');
      window.history.pushState({ screen: 'public-verify' }, '', url.toString());
    }
    setCurrentScreen('public-verify');
  };

  const handleToggleVoicePlayback = () => {
    if (isPlayingVoice) {
      stopAudioEvidence();
      setIsPlayingVoice(false);
    } else {
      setIsPlayingVoice(true);
      speakAudioEvidence(
        `Forensic evidence file ${primaryEvidence?.filename || 'Exhibit'} for docket ${activeCaseId}. Current verdict status: ${displayVerdict}.`,
        {
          audioUrl: primaryEvidence?.audioUrl,
          onEnd: () => setIsPlayingVoice(false)
        }
      );
    }
  };

  const scrollToSection = (id: string) => {
    setActiveSection(id);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const generatedTimestamp = new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const baseFileName = `ALFADetect_Report_${activeCaseId || 'CASE'}_${(primaryEvidence?.filename || 'evidence').replace(/\.[^/.]+$/, '')}`;

  const handleDownload = async () => {
    if (!activeCaseId) {
      setExportError('Select an active case docket before exporting a forensic report.');
      return;
    }
    setIsGenerating(true);
    setExportError(null);
    setExportSuccessToken(null);

    try {
      // Mandatory server-side integrity check, CoC check, ACL enforcement & Ed25519 token sealing
      const serverExport = await api.exportCaseReport(activeCaseId, {
        format: format.toUpperCase(),
        reportType
      });

      const manifest = serverExport?.manifest || {};
      const verifyToken: string = serverExport?.verifyToken || 'UNISSUED';
      const digitalSealHash: string = serverExport?.digitalSealHash || '';
      const digitalSignature: string = serverExport?.digitalSignature || '';
      const publicVerifyUrl =
        typeof window !== 'undefined'
          ? `${window.location.origin}/?screen=public-verify&token=${encodeURIComponent(verifyToken)}`
          : `?screen=public-verify&token=${encodeURIComponent(verifyToken)}`;

      setExportSuccessToken(verifyToken);
      setPublicReport((prev) => ({
        ...(prev || ({} as PublicReportVerificationRecord)),
        token: verifyToken,
        reportId: serverExport.reportId,
        caseId: activeCaseId,
        evidenceId: primaryEvidence?.id || '',
        evidenceFilename: primaryEvidence?.filename || '',
        evidenceSha256: realEvidenceHash,
        verdict: displayVerdict,
        confidenceScore: latestAnalysis?.overallConfidence ?? null,
        leadAnalyst: caseRecord?.analyst || currentUser?.name || '',
        expertWitness: approvedExpert?.expertName || currentUser?.name || '',
        expertCertificationId: approvedExpert?.certificationId || currentUser?.certificationId || 'PRELIMINARY',
        signedAt: manifest.generatedAt || generatedTimestamp,
        digitalSealHash,
        biometricVerified: false,
        biometricScore: null,
        biometricTechnology: reportType === 'final' ? 'Credential + Enclave Ed25519 Seal' : 'Preliminary Export Seal',
        revoked: false,
        status: 'VALID'
      }));

      const meas = latestAnalysis?.acousticMeasurements;

      if (format === 'pdf') {
        const doc = new jsPDF({ unit: 'pt', format: 'a4' });
        let y = 48;
        const line = (text: string, bold = false, size = 10) => {
          doc.setFont('helvetica', bold ? 'bold' : 'normal');
          doc.setFontSize(size);
          const wrapped = doc.splitTextToSize(text, 500);
          if (y + wrapped.length * (size + 4) > 780) {
            doc.addPage();
            y = 48;
          }
          doc.text(wrapped, 48, y);
          y += wrapped.length * (size + 4) + 4;
        };

        line('ALFADetect — OFFICIAL FORENSIC AUDIO EXAMINATION REPORT', true, 14);
        line(`Report ID: ${serverExport.reportId} | Type: ${serverExport.reportType}`, true, 9);
        line(`Generated: ${manifest.generatedAt || generatedTimestamp} | Docket: ${activeCaseId}`, false, 9);
        line(`Case Title: ${caseRecord?.title || 'Forensic Audio Examination'}`, false, 10);
        line(`Threshold Config: ${manifest.systemConfig?.thresholdVersion || 'v1.0'} (Score Threshold: ${manifest.systemConfig?.verificationThreshold ?? 'N/A'})`, false, 9);
        y += 8;

        line('1. EXECUTIVE SUMMARY & VERDICT', true, 11);
        line(`Verdict: ${displayVerdict} | Neural Confidence: ${confidenceValue}`);
        line('Decision-Support Notice: Probabilistic forensic indicators only — never standalone proof of identity or authorship.');
        line(`Lead Analyst: ${caseRecord?.analyst || currentUser?.name || 'Assigned Analyst'}`);
        line(`Exhibit File: ${primaryEvidence?.filename || 'None'} (${primaryEvidence?.fileSize || '0 MB'})`);
        if (primaryEvidence?.isDerivedCopy) {
          line(`Derived Lineage: Parent ${primaryEvidence.parentEvidenceId || 'Unknown'} (${primaryEvidence.processingOperation || 'Normalized Working Copy'})`);
        }
        line(`SHA-256 Digest: ${realEvidenceHash || 'Unavailable'}`);
        y += 6;

        line('2. MEASURED ACOUSTIC DSP TELEMETRY (NON-BIOMETRIC MEASUREMENT)', true, 11);
        if (meas) {
          line(`Mean F0: ${meas.f0MeanHz} Hz (Range ${meas.f0MinHz}-${meas.f0MaxHz} Hz) | Jitter: ${meas.jitterPercent}% | Shimmer: ${meas.shimmerPercent}%`);
          line(`HNR: ${meas.hnrDb} dB | Spectral Centroid: ${meas.spectralCentroidHz} Hz | Roll-Off: ${meas.spectralRollOffHz} Hz | Est. SNR: ${meas.estimatedSnrDb} dB`);
          if (latestAnalysis?.nonBiometricProfile) {
            const nbp = latestAnalysis.nonBiometricProfile;
            line(`VAD Active: ${Math.round(nbp.vadActiveRatio * 100)}% (${nbp.vadSegmentCount} segments) | Mel Bands: ${nbp.melBandsDb.length} | MFCC: ${nbp.mfccMean.length} dims | LFCC: ${nbp.lfccMean.length} dims`);
          }
        } else {
          line('Acoustic DSP measurements have not been recorded yet for this case.');
        }
        y += 6;

        line('3. AI & NEURAL CLASSIFIER AVAILABILITY DISCLOSURE', true, 11);
        if (latestAnalysis?.models?.length) {
          latestAnalysis.models.forEach((m) => {
            line(`- ${m.name}: ${m.status}${m.note ? ` (${m.note})` : ''}`);
          });
        } else {
          line('Neural classifier weights (CNN, BiLSTM, Wav2Vec2, ECAPA-TDNN) are MODEL_UNAVAILABLE in this runtime.');
        }
        line(`Scientific Limitations: ${manifest.scientificLimitations || ''}`, false, 8);
        y += 6;

        line('4. CHAIN OF CUSTODY LEDGER & INTEGRITY CHECK', true, 11);
        line(`CoC Ledger Integrity: ${manifest.chainOfCustodyVerification?.valid ? 'VALID' : 'UNVERIFIED'} (${custodyEvents.length} events)`);
        custodyEvents.slice(0, 12).forEach((ev) => {
          line(`#${ev.eventNumber} [${ev.timestamp}] ${ev.title} — ${ev.userName} (${ev.status})`);
        });
        y += 6;

        line('5. EXPERT CERTIFICATION, ED25519 SEAL & PUBLIC VERIFICATION', true, 11);
        if (approvedExpert) {
          line(`Expert Witness: ${approvedExpert.expertName} (${approvedExpert.certificationId})`);
          line(`Affidavit Signature: ${approvedExpert.digitalSignature}`);
        } else {
          line('Expert Witness Certification: Pending Approval');
        }
        line(`Legal Review Status: ${legalReview?.status || 'UNDER REVIEW'}`);
        line(`Public Verification Token: ${verifyToken}`);
        line(`Verification URL: ${publicVerifyUrl}`);
        line(`Report Seal Hash: ${digitalSealHash}`);
        line(`Enclave Signature: ${digitalSignature}`, false, 8);

        doc.save(`${baseFileName}.pdf`);
      } else {
        const htmlBody = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>${escapeHtml(baseFileName)}</title>
<style>body{font-family:system-ui,sans-serif;max-width:860px;margin:40px auto;color:#112217;line-height:1.5}
h1,h2{color:#0A3D24;border-bottom:1px solid #d1fae5;padding-bottom:4px}pre{background:#f8faf9;padding:12px;border:1px solid #e1ebe4;overflow:auto;white-space:pre-wrap;word-break:break-all}</style>
</head><body>
<h1>ALFADetect — Official Forensic Audio Analysis Report</h1>
<p><strong>Report ID:</strong> ${escapeHtml(serverExport.reportId)} | <strong>Classification:</strong> ${escapeHtml(serverExport.reportType)}</p>
<p><strong>Case Docket:</strong> ${escapeHtml(activeCaseId)} | <strong>Title:</strong> ${escapeHtml(caseRecord?.title || 'Forensic Audio Examination')}</p>
<p><strong>Generated:</strong> ${escapeHtml(manifest.generatedAt || generatedTimestamp)} | <strong>Threshold Profile:</strong> ${escapeHtml(manifest.systemConfig?.thresholdVersion || 'v1.0')}</p>
<p><strong>Verdict:</strong> ${escapeHtml(displayVerdict)} | <strong>Neural Confidence:</strong> ${escapeHtml(confidenceValue)}</p>
<p><strong>Decision-Support Caveat:</strong> Results represent probabilistic decision support only and never constitute standalone proof of identity or guilt.</p>
<h2>1. Evidence Exhibit, Lineage & SHA-256 Digest</h2>
<p><strong>File:</strong> ${escapeHtml(primaryEvidence?.filename || 'None')} (${escapeHtml(primaryEvidence?.duration || 'Unknown')})</p>
${primaryEvidence?.isDerivedCopy ? `<p><strong>Derived Lineage:</strong> Parent ${escapeHtml(primaryEvidence.parentEvidenceId || 'Unknown')} (${escapeHtml(primaryEvidence.processingOperation || 'Normalized Working Copy')})</p>` : ''}
<pre>${escapeHtml(realEvidenceHash || 'No SHA-256 hash recorded')}</pre>
<h2>2. Measured Acoustic DSP Parameters (non-biometric measurement)</h2>
<pre>${escapeHtml(meas ? JSON.stringify({ acousticMeasurements: meas, nonBiometricProfile: latestAnalysis?.nonBiometricProfile || null }, null, 2) : 'No DSP analysis run yet.')}</pre>
<h2>3. AI Model Status & Scientific Limitations</h2>
<p>${escapeHtml(manifest.scientificLimitations || '')}</p>
<h2>4. Chain of Custody (${custodyEvents.length} Events — ${manifest.chainOfCustodyVerification?.valid ? 'VALIDATED' : 'UNVERIFIED'})</h2>
<ul>${custodyEvents.map((e) => `<li>#${escapeHtml(e.eventNumber)} ${escapeHtml(e.timestamp)} — ${escapeHtml(e.title)} (${escapeHtml(e.userName)}) [${escapeHtml(e.status)}]</li>`).join('')}</ul>
<h2>5. Expert Witness & Legal Certification</h2>
<p><strong>Expert Witness:</strong> ${escapeHtml(approvedExpert ? `${approvedExpert.expertName} (${approvedExpert.certificationId})` : 'Pending')}</p>
<p><strong>Legal Admissibility Review:</strong> ${escapeHtml(legalReview?.status || 'UNDER REVIEW')}</p>
<p><strong>Public Verification Token:</strong> ${escapeHtml(verifyToken)}</p>
<p><strong>Public Verification URL:</strong> ${escapeHtml(publicVerifyUrl)}</p>
<pre>SEAL HASH: ${escapeHtml(digitalSealHash)}
SIGNATURE: ${escapeHtml(digitalSignature)}</pre>
</body></html>`;

        const blob = new Blob([htmlBody], {
          type: format === 'html' ? 'text/html;charset=utf-8' : 'application/msword'
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${baseFileName}.${format === 'html' ? 'html' : 'doc'}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }

      playSuccessSound();
    } catch (err: any) {
      if (err instanceof ApiError) {
        setExportError(err.message);
      } else {
        setExportError(err?.message || 'Report export failed during integrity or authorization validation.');
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const meas = latestAnalysis?.acousticMeasurements;
  const dspChartData = meas
    ? [
        { metric: 'Mean F0 (Hz)', value: meas.f0MeanHz },
        { metric: 'Voiced (%)', value: meas.voicedFractionPercent },
        { metric: 'HNR (dB)', value: meas.hnrDb },
        { metric: 'Est. SNR (dB)', value: meas.estimatedSnrDb },
        { metric: 'Jitter (%)', value: meas.jitterPercent },
        { metric: 'Shimmer (%)', value: meas.shimmerPercent }
      ]
    : [];

  const sectionsList = [
    { id: 'section-1', num: '1', title: 'Executive Summary' },
    { id: 'section-2', num: '2', title: 'Acoustic DSP Telemetry' },
    { id: 'section-3', num: '3', title: 'Evidence Audio Inspection' },
    { id: 'section-4', num: '4', title: 'Model & XAI Availability' },
    { id: 'section-5', num: '5', title: 'Chain of Custody' },
    { id: 'section-6', num: '6', title: 'Cryptographic Integrity' },
    { id: 'section-7', num: '7', title: 'Credential & Ed25519 Seal' }
  ];

  const activeToken = publicReport?.token || exportSuccessToken;

  return (
    <div id="report-generation-screen" className="flex flex-col lg:flex-row min-h-screen bg-[#F4F8F6] text-slate-800">
      {/* LEFT SIDEBAR */}
      <aside className="w-full lg:w-80 shrink-0 bg-white border-r border-emerald-900/10 p-5 flex flex-col justify-between space-y-6 shadow-sm z-20 print:hidden">
        <div className="space-y-6">
          <div className="border-b border-emerald-900/10 pb-4">
            <div className="flex items-center space-x-3 mb-2">
              <BackButton onClick={() => setCurrentScreen('legal-review')} label="Back to Legal Review" variant="pill" />
            </div>
            <div className="flex items-center space-x-2 text-emerald-700">
              <FileCheck2 className="w-6 h-6" />
              <h2 className="text-base font-bold text-slate-900 font-sans">Forensic Report Builder</h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">Court-Ready Judicial Document Generator</p>
          </div>

          {caseEvidenceList.length > 1 && (
            <div className="space-y-1.5">
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500">
                PRIMARY EXHIBIT SCOPE
              </label>
              <select
                value={selectedEvidenceId}
                onChange={(e) => setSelectedEvidenceId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 cursor-pointer"
              >
                {caseEvidenceList.map((ev) => (
                  <option key={ev.id} value={ev.id}>
                    {ev.id} — {ev.filename}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="space-y-2">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500">
              REPORT SECTIONS JUMP-NAV
            </label>
            <div className="space-y-1">
              {sectionsList.map((sec) => (
                <button
                  key={sec.id}
                  onClick={() => scrollToSection(sec.id)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium flex items-center justify-between transition-all cursor-pointer ${
                    activeSection === sec.id
                      ? 'bg-emerald-50 text-emerald-900 font-bold border border-emerald-300 shadow-xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <span className="flex items-center space-x-2 truncate">
                    <span className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300 flex items-center justify-center text-[10px] font-mono font-bold shrink-0">
                      {sec.num}
                    </span>
                    <span className="truncate">{sec.title}</span>
                  </span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 shrink-0 ml-1" />
                </button>
              ))}
            </div>
          </div>

          {/* Report Classification Type */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500">
              REPORT CLASSIFICATION
            </label>
            <div className="space-y-1.5 text-xs">
              <button
                type="button"
                onClick={() => setReportType('preliminary')}
                className={`w-full text-left p-2.5 rounded-xl border transition-all cursor-pointer ${
                  reportType === 'preliminary'
                    ? 'bg-emerald-50 border-emerald-400 text-emerald-950 font-bold'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <span className="block">Preliminary Investigative Report</span>
                <span className="text-[10px] font-normal text-slate-500">Pre-certification working dossier export</span>
              </button>

              <button
                type="button"
                disabled={!isFinalEligible}
                onClick={() => setReportType('final')}
                className={`w-full text-left p-2.5 rounded-xl border transition-all ${
                  !isFinalEligible
                    ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed'
                    : reportType === 'final'
                    ? 'bg-emerald-700 border-emerald-800 text-white font-bold cursor-pointer'
                    : 'bg-slate-50 border-slate-200 text-slate-700 cursor-pointer'
                }`}
              >
                <span className="block">Final Court-Certified Report (FRE 902)</span>
                <span className={`text-[10px] font-normal ${reportType === 'final' && isFinalEligible ? 'text-emerald-100' : 'text-slate-500'}`}>
                  {isFinalEligible
                    ? 'Approved Expert + Legal Certified unlocked'
                    : 'Requires Approved Expert + CERTIFIED Legal Review'}
                </span>
              </button>
            </div>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-100">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500">
              EXPORT FORMAT
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'pdf', label: 'PDF', note: 'jsPDF' },
                { id: 'docx', label: 'DOC', note: 'Word' },
                { id: 'html', label: 'HTML', note: 'Web' }
              ].map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setFormat(f.id as 'pdf' | 'docx' | 'html')}
                  className={`py-2 px-1 rounded-xl text-xs font-bold border transition-all text-center cursor-pointer ${
                    format === f.id
                      ? 'bg-emerald-700 border-emerald-700 text-white shadow-xs'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span>{f.label}</span>
                  <span className="block text-[8px] font-mono opacity-80">{f.note}</span>
                </button>
              ))}
            </div>
          </div>

          <div
            className={`p-3.5 rounded-2xl space-y-1.5 text-xs border ${
              approvedExpert
                ? 'bg-emerald-50 border-emerald-300'
                : 'bg-amber-50 border-amber-300'
            }`}
          >
            <div className="flex justify-between items-center">
              <span className="font-bold text-slate-900 flex items-center space-x-1.5">
                <KeyRound className="w-4 h-4 text-emerald-700" />
                <span>Credential & Ed25519 Seal</span>
              </span>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-white border border-slate-200">
                {approvedExpert ? '✓ SIGNED' : 'PENDING'}
              </span>
            </div>
            <p className="text-[10px] text-slate-600 leading-tight">
              {approvedExpert
                ? `Sealed by ${approvedExpert.expertName} (${approvedExpert.certificationId}).`
                : 'Complete Expert Validation credential re-authentication to seal this docket.'}
            </p>
          </div>
        </div>

        <div className="space-y-2 pt-4 border-t border-slate-100">
          {exportError && (
            <div className="p-2.5 bg-red-50 border border-red-200 rounded-xl text-[11px] text-red-800 font-medium">
              {exportError}
            </div>
          )}

          {exportSuccessToken && (
            <div className="p-2.5 bg-emerald-50 border border-emerald-300 rounded-xl text-[11px] text-emerald-900 font-mono font-bold">
              Token Sealed: {exportSuccessToken}
            </div>
          )}

          <button
            type="button"
            onClick={handleDownload}
            disabled={isGenerating}
            className="w-full py-3.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-900/20 transition-all flex flex-col items-center justify-center space-y-0.5 disabled:opacity-50 cursor-pointer"
          >
            <div className="flex items-center space-x-2">
              <Download className={`w-4 h-4 ${isGenerating ? 'animate-bounce' : ''}`} />
              <span>{isGenerating ? 'Verifying & Exporting...' : 'DOWNLOAD FORENSIC REPORT'}</span>
            </div>
            <span className="text-[9px] text-emerald-100 font-mono">
              Live SHA-256 + Ed25519 ({format.toUpperCase()})
            </span>
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl border border-slate-200 flex items-center justify-center space-x-2 transition-all cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Official Document</span>
          </button>
        </div>
      </aside>

      {/* DOCUMENT PREVIEW */}
      <main className="flex-1 p-4 sm:p-8 md:p-12 overflow-y-auto bg-[#F4F8F6] min-w-0">
        <div className="max-w-4xl mx-auto bg-white text-slate-900 border-2 border-emerald-800/40 rounded-2xl shadow-xl p-6 sm:p-12 space-y-10 font-sans print:p-0 print:border-none print:shadow-none">
          {/* Header Block */}
          <div className="border-b-2 border-slate-900 pb-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-mono font-bold tracking-widest text-emerald-800 uppercase block">
                  OFFICIAL JUDICIAL EVIDENCE RECORD // FRE 902(13)/(14)
                </span>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                  Forensic Audio Analysis Report
                </h1>
                <p className="text-sm font-semibold text-emerald-900 mt-1">
                  Docket #{activeCaseId || 'UNSELECTED'} — {caseRecord?.title || 'Forensic Audio Examination'}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowQrModal(true)}
                className="p-3 bg-emerald-50 hover:bg-emerald-100 border-2 border-emerald-300 rounded-2xl flex items-center space-x-3 transition-all cursor-pointer shrink-0 print:hidden"
              >
                <QrCode className="w-10 h-10 text-emerald-900" />
                <div className="text-left font-mono text-[9px] text-emerald-900">
                  <p className="font-bold">VERIFICATION LEDGER</p>
                  <p className="text-emerald-700 font-bold">
                    {activeToken ? activeToken : 'ISSUE ON EXPORT'}
                  </p>
                </div>
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 pt-3 border-t border-slate-200 text-xs font-mono">
              <div>
                <span className="text-[9px] text-slate-400 block uppercase font-bold">Case ID</span>
                <span className="font-bold text-slate-800">{activeCaseId || 'NONE'}</span>
              </div>
              <div>
                <span className="text-[9px] text-slate-400 block uppercase font-bold">Generated</span>
                <span className="font-bold text-slate-800">{generatedTimestamp.slice(0, 16)}</span>
              </div>
              <div>
                <span className="text-[9px] text-slate-400 block uppercase font-bold">Legal Status</span>
                <span className="font-bold text-emerald-800">{legalReview?.status || 'UNDER REVIEW'}</span>
              </div>
              <div>
                <span className="text-[9px] text-slate-400 block uppercase font-bold">Lead Analyst</span>
                <span className="font-bold text-slate-800 truncate block">
                  {caseRecord?.analyst || currentUser?.name || 'Unassigned'}
                </span>
              </div>
              <div>
                <span className="text-[9px] text-slate-400 block uppercase font-bold">Expert Witness</span>
                <span className="font-bold text-slate-800 truncate block">
                  {certifiedExpert ? certifiedExpert.expertName : 'Pending'}
                </span>
              </div>
              <div>
                <span className="text-[9px] text-slate-400 block uppercase font-bold">Verdict</span>
                <span className="font-bold text-emerald-900 bg-emerald-100 border border-emerald-300 px-1.5 py-0.5 rounded">
                  {displayVerdict}
                </span>
              </div>
            </div>
          </div>

          {/* 1. Executive Summary */}
          <section id="section-1" className="space-y-4 scroll-mt-6">
            <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2 border-b-2 border-slate-200 pb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-800 text-white flex items-center justify-center text-xs font-mono font-bold">
                1
              </span>
              <span>Executive Summary</span>
            </h2>

            <div
              className={`border-l-4 p-5 rounded-r-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-2xs ${
                displayVerdict === 'DEEPFAKE'
                  ? 'border-rose-600 bg-rose-50'
                  : displayVerdict === 'AUTHENTIC'
                  ? 'border-emerald-600 bg-emerald-50'
                  : 'border-amber-500 bg-amber-50'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="w-5 h-5 text-slate-800" />
                  <h3 className="text-base font-extrabold text-slate-900">
                    VERDICT: {displayVerdict}
                  </h3>
                </div>
                <p className="text-xs text-slate-700 font-medium">
                  {latestAnalysis?.note ||
                    'Neural classifier weights remain unconfigured; only verified acoustic DSP metrics and human expert determinations are reported.'}
                </p>
              </div>

              <div className="text-right shrink-0">
                <span className="text-sm font-extrabold text-slate-900 font-mono block">{confidenceValue}</span>
                <span className="text-[10px] font-mono text-slate-600 uppercase font-bold">Neural Confidence</span>
              </div>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed font-sans border-l-2 border-emerald-600 pl-4 py-1">
              Forensic examination of exhibit{' '}
              <code className="font-mono text-emerald-900 font-bold">
                {primaryEvidence?.filename || 'No exhibit selected'}
              </code>{' '}
              (duration: {primaryEvidence?.duration || 'Unknown'}, sample rate: {primaryEvidence?.sampleRate || 'Unknown'}).{' '}
              {certifiedExpert?.technicalAssessment || caseRecord?.description || ''}
            </p>
          </section>

          {/* 2. Acoustic DSP Telemetry */}
          <section id="section-2" className="space-y-4 scroll-mt-6">
            <div className="flex items-center justify-between border-b-2 border-slate-200 pb-2">
              <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
                <span className="w-6 h-6 rounded-full bg-emerald-800 text-white flex items-center justify-center text-xs font-mono font-bold">
                  2
                </span>
                <span>Measured Acoustic DSP Telemetry</span>
              </h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-900 border border-emerald-200">
                non-biometric measurement
              </span>
            </div>

            {meas ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                    <span className="text-[10px] text-slate-500 block font-sans">Mean F0</span>
                    <span className="text-sm font-bold text-slate-900">{meas.f0MeanHz} Hz</span>
                  </div>
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                    <span className="text-[10px] text-slate-500 block font-sans">Jitter / Shimmer</span>
                    <span className="text-sm font-bold text-slate-900">
                      {meas.jitterPercent}% / {meas.shimmerPercent}%
                    </span>
                  </div>
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                    <span className="text-[10px] text-slate-500 block font-sans">HNR / Est. SNR</span>
                    <span className="text-sm font-bold text-slate-900">
                      {meas.hnrDb} dB / {meas.estimatedSnrDb} dB
                    </span>
                  </div>
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                    <span className="text-[10px] text-slate-500 block font-sans">Spectral Centroid</span>
                    <span className="text-sm font-bold text-slate-900">{meas.spectralCentroidHz} Hz</span>
                  </div>
                </div>

                {latestAnalysis?.nonBiometricProfile && (
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-mono text-slate-700 flex flex-wrap justify-between gap-2">
                    <span>
                      VAD Active: {Math.round(latestAnalysis.nonBiometricProfile.vadActiveRatio * 100)}% (
                      {latestAnalysis.nonBiometricProfile.vadSegmentCount} segments)
                    </span>
                    <span>
                      Mel Bands: {latestAnalysis.nonBiometricProfile.melBandsDb.length} · MFCC: {latestAnalysis.nonBiometricProfile.mfccMean.length} dims · LFCC: {latestAnalysis.nonBiometricProfile.lfccMean.length} dims
                    </span>
                  </div>
                )}

                <div className="h-56 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={dspChartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#CBD5E1" />
                      <XAxis dataKey="metric" stroke="#64748B" fontSize={10} />
                      <YAxis stroke="#64748B" fontSize={10} />
                      <Tooltip />
                      <Bar dataKey="value" name="Measured DSP Value" fill="#047857" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            ) : (
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600">
                No acoustic DSP analysis has been recorded yet for this exhibit. Run AI & Acoustic Inspection to populate genuine measurements.
              </div>
            )}
          </section>

          {/* 3. Evidence Audio Inspection */}
          <section id="section-3" className="space-y-4 scroll-mt-6">
            <div className="flex items-center justify-between border-b-2 border-slate-200 pb-2">
              <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
                <span className="w-6 h-6 rounded-full bg-emerald-800 text-white flex items-center justify-center text-xs font-mono font-bold">
                  3
                </span>
                <span>Evidence Audio Exhibit Playback</span>
              </h2>

              <button
                type="button"
                onClick={handleToggleVoicePlayback}
                className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all cursor-pointer print:hidden"
              >
                {isPlayingVoice ? <Pause className="w-3.5 h-3.5 text-emerald-700" /> : <Play className="w-3.5 h-3.5 text-emerald-700" />}
                <span>{isPlayingVoice ? 'Pause Audio' : 'Play Evidence Exhibit'}</span>
              </button>
            </div>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono flex flex-wrap justify-between gap-2">
              <span>Exhibit ID: {primaryEvidence?.id || 'N/A'}</span>
              <span>Filename: {primaryEvidence?.filename || 'N/A'}</span>
              <span>Status: {primaryEvidence?.status || 'N/A'}</span>
              {primaryEvidence?.isDerivedCopy && (
                <span>
                  Derived From: {primaryEvidence.parentEvidenceId || 'Parent'} ({primaryEvidence.processingOperation || 'Normalized'})
                </span>
              )}
            </div>
          </section>

          {/* 4. Model & XAI Availability Disclosure */}
          <section id="section-4" className="space-y-4 scroll-mt-6">
            <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2 border-b-2 border-slate-200 pb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-800 text-white flex items-center justify-center text-xs font-mono font-bold">
                4
              </span>
              <span>Model & XAI Availability Disclosure</span>
            </h2>

            {latestAnalysis?.models?.length ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {latestAnalysis.models.map((mod, idx) => (
                  <div key={idx} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900">{mod.name}</span>
                      <span
                        className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                          mod.status === 'AVAILABLE'
                            ? 'bg-emerald-100 text-emerald-900'
                            : 'bg-amber-100 text-amber-900'
                        }`}
                      >
                        {mod.status}
                      </span>
                    </div>
                    {mod.note && <p className="text-[11px] text-slate-600">{mod.note}</p>}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-600 bg-slate-50 p-4 rounded-xl border border-slate-200">
                Deepfake neural classifier weights (CNN, BiLSTM, Wav2Vec2, ECAPA-TDNN) and TreeSHAP / Grad-CAM attribution maps are MODEL_UNAVAILABLE in this runtime environment and are never fabricated in this report.
              </p>
            )}
          </section>

          {/* 5. Chain of Custody */}
          <section id="section-5" className="space-y-4 scroll-mt-6">
            <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2 border-b-2 border-slate-200 pb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-800 text-white flex items-center justify-center text-xs font-mono font-bold">
                5
              </span>
              <span>Chain of Custody Ledger ({custodyEvents.length})</span>
            </h2>

            {custodyEvents.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border border-slate-200 rounded-xl overflow-hidden">
                  <thead className="bg-emerald-50 text-emerald-950 font-bold border-b border-emerald-200">
                    <tr>
                      <th className="p-2.5">#</th>
                      <th className="p-2.5">Timestamp</th>
                      <th className="p-2.5">Custodian</th>
                      <th className="p-2.5">Event</th>
                      <th className="p-2.5 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                    {custodyEvents.map((ev) => (
                      <tr key={ev.eventNumber}>
                        <td className="p-2.5 text-slate-500">#{ev.eventNumber}</td>
                        <td className="p-2.5 text-slate-600">{ev.timestamp}</td>
                        <td className="p-2.5 font-bold text-slate-800">{ev.userName}</td>
                        <td className="p-2.5 font-sans text-slate-700">{ev.title}</td>
                        <td className="p-2.5 text-right text-emerald-800 font-bold">{ev.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-xs text-slate-500 bg-slate-50 p-4 rounded-xl border border-slate-200">
                No custody events logged on this case docket yet.
              </p>
            )}
          </section>

          {/* 6. Cryptographic File Integrity */}
          <section id="section-6" className="space-y-4 scroll-mt-6">
            <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2 border-b-2 border-slate-200 pb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-800 text-white flex items-center justify-center text-xs font-mono font-bold">
                6
              </span>
              <span>Cryptographic File Integrity & SHA-256 Digest</span>
            </h2>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3 text-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <span className="font-bold text-slate-900 uppercase">SHA-256 EVIDENTIARY HASH</span>
                <div className="flex items-center space-x-2 print:hidden">
                  <button
                    type="button"
                    disabled={!hasRealHash}
                    onClick={handleCopyHash}
                    className="px-2.5 py-1 bg-white border border-slate-200 hover:border-emerald-500 disabled:opacity-50 rounded-lg font-mono text-[10px] text-slate-700 flex items-center space-x-1 cursor-pointer"
                  >
                    {copiedHash ? <Check className="w-3 h-3 text-emerald-700" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedHash ? 'Copied' : 'Copy Hash'}</span>
                  </button>
                  <button
                    type="button"
                    disabled={!hasRealHash}
                    onClick={() => setShowHashVerifierModal(true)}
                    className="px-2.5 py-1 bg-emerald-700 disabled:opacity-50 text-white rounded-lg font-mono text-[10px] font-bold cursor-pointer"
                  >
                    Verify Hash Match
                  </button>
                </div>
              </div>

              <div className="p-2.5 bg-white border border-slate-200 rounded-xl font-mono text-[11px] text-emerald-900 break-all font-bold">
                {realEvidenceHash || 'Original evidence SHA-256 digest unavailable — upload evidence first.'}
              </div>
            </div>
          </section>

          {/* 7. Digital Signature & Credential Re-Authentication */}
          <section id="section-7" className="space-y-4 scroll-mt-6">
            <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2 border-b-2 border-slate-200 pb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-800 text-white flex items-center justify-center text-xs font-mono font-bold">
                7
              </span>
              <span>Credential & Ed25519 Enclave Certification</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-1.5 text-xs">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-emerald-900">LEAD FORENSIC ANALYST</span>
                  <BadgeCheck className="w-4 h-4 text-emerald-700" />
                </div>
                <p className="font-semibold text-slate-800">
                  {caseRecord?.analyst || currentUser?.name || 'Unassigned'}
                </p>
                <p className="text-[11px] text-slate-600">{caseRecord?.agency || currentUser?.agency || ''}</p>
                <p className="text-[10px] font-mono text-emerald-800">
                  Docket Status: {caseRecord?.status || 'Active'}
                </p>
              </div>

              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-1.5 text-xs">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-emerald-900">EXPERT WITNESS CERTIFICATION</span>
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                </div>
                {approvedExpert ? (
                  <>
                    <p className="font-semibold text-slate-800">{approvedExpert.expertName}</p>
                    <p className="text-[11px] text-slate-600">
                      {approvedExpert.institution} ({approvedExpert.certificationId})
                    </p>
                    <p className="text-[10px] font-mono text-emerald-800">
                      Signed: {approvedExpert.signedAt}
                    </p>
                    <p className="font-mono text-[9px] text-slate-600 break-all">
                      SIG: {approvedExpert.digitalSignature}
                    </p>
                  </>
                ) : (
                  <p className="text-[11px] text-amber-800">
                    Pending accredited Expert Witness credential re-authentication & Ed25519 affidavit signature.
                  </p>
                )}
              </div>
            </div>
          </section>
        </div>
      </main>

      {/* Verification Ledger Modal */}
      {showQrModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white border-2 border-emerald-700 rounded-2xl p-6 max-w-sm w-full space-y-4 shadow-2xl text-slate-900">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-bold text-sm text-slate-900 flex items-center space-x-1.5">
                <QrCode className="w-4 h-4 text-emerald-700" />
                <span>Courtroom Ledger Authenticator</span>
              </h3>
              <button onClick={() => setShowQrModal(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-col items-center p-4 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-2 text-center">
              <div className="p-3 bg-white rounded-xl shadow-xs border border-emerald-300">
                <QrCode className="w-28 h-28 text-emerald-900" />
              </div>
              <span className="text-[10px] font-mono text-emerald-900 font-bold">
                DOCKET: {activeCaseId || 'UNSELECTED'}
              </span>
              <span className="text-[10px] font-mono text-slate-700 break-all">
                {activeToken ? `Token: ${activeToken}` : 'Export a report to issue a cryptographic token'}
              </span>
            </div>

            {qrCheckResult && (
              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-mono text-slate-800">
                {qrCheckResult}
              </div>
            )}

            <div className="space-y-2">
              <button
                type="button"
                onClick={handleOpenPublicPortal}
                className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Open Public Verification Portal →</span>
              </button>

              <button
                type="button"
                onClick={handleVerifyIssuedToken}
                disabled={isScanningQr}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                <span>{isScanningQr ? 'Querying Ledger...' : 'Verify Token Against Server Registry'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SHA-256 Verification Modal */}
      {showHashVerifierModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white border-2 border-emerald-700 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl text-slate-900">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-bold text-sm text-slate-900 flex items-center space-x-1.5">
                <Lock className="w-4 h-4 text-emerald-700" />
                <span>SHA-256 Hash Verification Engine</span>
              </h3>
              <button onClick={() => setShowHashVerifierModal(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Registered Evidence Hash</label>
                <input
                  type="text"
                  readOnly
                  value={realEvidenceHash}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 font-mono text-[10px] text-emerald-900 font-bold"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Compare Hash String</label>
                <input
                  type="text"
                  value={inputHashToTest}
                  onChange={(e) => {
                    setInputHashToTest(e.target.value);
                    handleTestHashMatch(e.target.value);
                  }}
                  placeholder="Paste SHA-256 hash..."
                  className="w-full bg-white border border-slate-200 rounded-xl p-2 font-mono text-[10px] text-slate-900 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase text-slate-500 block mb-1">Or Select File to Hash</label>
                <input
                  type="file"
                  onChange={handleFileHashTest}
                  className="w-full text-xs text-slate-600 file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-emerald-100 file:text-emerald-900 cursor-pointer"
                />
              </div>

              {testHashResult && (
                <div
                  className={`p-3 rounded-xl border text-xs space-y-1 ${
                    testHashResult.matches
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                      : 'bg-rose-50 border-rose-300 text-rose-900'
                  }`}
                >
                  <div className="flex items-center space-x-1.5 font-bold">
                    {testHashResult.matches ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-rose-700" />
                    )}
                    <span>
                      {testHashResult.matches ? '✓ Exact SHA-256 Match (0-Byte Deviation)' : '⚠ Hash Mismatch Detected!'}
                    </span>
                  </div>
                  <p className="font-mono text-[10px] truncate">Computed: {testHashResult.computedHash}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
