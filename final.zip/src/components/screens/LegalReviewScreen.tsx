import React, { useState, useEffect } from 'react';
import {
  Scale,
  CheckCircle2,
  AlertCircle,
  FileText,
  ShieldCheck,
  Hash,
  Clock,
  Send,
  MessageSquare,
  Info,
  AlertTriangle,
  RefreshCw
} from 'lucide-react';
import {
  ScreenId,
  User,
  LegalReview,
  LegalReviewItem,
  AudioEvidence,
  DeepfakeAnalysisRecord,
  ExpertReview,
  ChainOfCustodyEvent,
  Case
} from '../../types';
import { authFetch } from '../../utils/api';
import { canSubmitLegalReview } from '../../utils/rbac';
import { BackButton } from '../common/BackButton';

interface LegalReviewScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  selectedCaseId: string;
  currentUser: User;
}

export const LegalReviewScreen: React.FC<LegalReviewScreenProps> = ({
  setCurrentScreen,
  selectedCaseId,
  currentUser
}) => {
  const activeCaseId = selectedCaseId || '';
  const canEditLegal = canSubmitLegalReview(currentUser.role);

  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [legalReview, setLegalReview] = useState<LegalReview | null>(null);
  const [items, setItems] = useState<LegalReviewItem[]>([]);
  const [jurisdiction, setJurisdiction] = useState('Federal District Court');
  const [legalStatus, setLegalStatus] = useState<'UNDER REVIEW' | 'CERTIFIED' | 'REJECTED'>('UNDER REVIEW');
  const [notes, setNotes] = useState('');
  const [newNoteDraft, setNewNoteDraft] = useState('');

  const [caseRecord, setCaseRecord] = useState<Case | null>(null);
  const [evidenceList, setEvidenceList] = useState<AudioEvidence[]>([]);
  const [analyses, setAnalyses] = useState<DeepfakeAnalysisRecord[]>([]);
  const [expertReviews, setExpertReviews] = useState<ExpertReview[]>([]);
  const [custodyEvents, setCustodyEvents] = useState<ChainOfCustodyEvent[]>([]);

  useEffect(() => {
    if (!activeCaseId) return;
    let cancelled = false;

    async function loadCaseLegalArtifacts() {
      setIsLoading(true);
      setErrorMessage(null);
      try {
        const [revRes, caseRes, evRes, anRes, expRes, cocRes] = await Promise.all([
          authFetch(`/api/cases/${activeCaseId}/legal-review`),
          authFetch(`/api/cases/${activeCaseId}`),
          authFetch(`/api/cases/${activeCaseId}/evidence`),
          authFetch(`/api/cases/${activeCaseId}/analyses`),
          authFetch(`/api/cases/${activeCaseId}/expert-reviews`),
          authFetch(`/api/cases/${activeCaseId}/chain-of-custody`)
        ]);
        if (cancelled) return;

        if (revRes.ok) {
          const rev: LegalReview = await revRes.json();
          setLegalReview(rev);
          setItems(Array.isArray(rev.items) ? rev.items : []);
          setJurisdiction(rev.jurisdiction || 'Federal District Court');
          setLegalStatus(rev.status || 'UNDER REVIEW');
          setNotes(rev.notes || '');
        }
        if (caseRes.ok) setCaseRecord(await caseRes.json());
        if (evRes.ok) setEvidenceList(await evRes.json());
        if (anRes.ok) setAnalyses(await anRes.json());
        if (expRes.ok) setExpertReviews(await expRes.json());
        if (cocRes.ok) setCustodyEvents(await cocRes.json());
      } catch {
        if (!cancelled) setErrorMessage('Unable to synchronize legal admissibility artifacts from server.');
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    }

    loadCaseLegalArtifacts();
    return () => {
      cancelled = true;
    };
  }, [activeCaseId]);

  const completedCount = items.filter((i) => i.status === 'COMPLETE').length;
  const pendingCount = items.filter((i) => i.status === 'PENDING').length;
  const progressPercent = items.length > 0 ? Math.round((completedCount / items.length) * 100) : 0;

  const toggleItemStatus = (id: string) => {
    if (!canEditLegal) return;
    setItems((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, status: item.status === 'COMPLETE' ? 'PENDING' : 'COMPLETE' }
          : item
      )
    );
  };

  const persistLegalReview = async (
    nextStatus: 'UNDER REVIEW' | 'CERTIFIED' | 'REJECTED',
    overrideNotes?: string
  ) => {
    if (!activeCaseId || !canEditLegal) return;
    setIsSaving(true);
    setStatusMessage(null);
    setErrorMessage(null);

    try {
      const res = await authFetch(`/api/cases/${activeCaseId}/legal-review`, {
        method: 'POST',
        body: JSON.stringify({
          items,
          status: nextStatus,
          jurisdiction: jurisdiction.trim() || 'Federal District Court',
          notes: (overrideNotes !== undefined ? overrideNotes : notes).trim()
        })
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMessage(data?.error || 'Server rejected legal review update.');
        return;
      }
      setLegalReview(data);
      setLegalStatus(data.status);
      setStatusMessage(`Legal admissibility review saved (${data.status} — ${data.readinessProgress}).`);
    } catch {
      setErrorMessage('Network error saving legal review.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleAttachNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteDraft.trim() || !canEditLegal) return;
    const stamp = new Date().toISOString().replace('T', ' ').slice(0, 16) + ' UTC';
    const appended = notes
      ? `${notes}\n\n[${stamp} — ${currentUser.name}] ${newNoteDraft.trim()}`
      : `[${stamp} — ${currentUser.name}] ${newNoteDraft.trim()}`;
    setNotes(appended);
    setNewNoteDraft('');
    await persistLegalReview(legalStatus, appended);
  };

  const primaryEvidence = evidenceList[0];
  const latestAnalysis = analyses[0];
  const certifiedExpert = expertReviews.find((r) => r.status === 'Approved') || expertReviews[0];

  const getSupportingDetail = (label: string): string => {
    const lower = label.toLowerCase();
    if (lower.includes('chain of custody')) {
      return custodyEvents.length > 0
        ? `${custodyEvents.length} sequential ledger event(s) verified under FRE 901.`
        : 'No custody handoff events recorded on docket yet.';
    }
    if (lower.includes('sha-256') || lower.includes('bitstream')) {
      return primaryEvidence
        ? `File ${primaryEvidence.filename} hashed (${primaryEvidence.sha256Hash.slice(0, 16)}...) with status ${primaryEvidence.status}.`
        : 'No audio exhibit ingested or hashed yet.';
    }
    if (lower.includes('methodology') || lower.includes('analysis')) {
      return latestAnalysis
        ? `Analysis ${latestAnalysis.id} recorded (${latestAnalysis.verdict}). Limitations explicitly disclosed.`
        : 'Acoustic / AI pipeline analysis has not been executed yet.';
    }
    if (lower.includes('expert')) {
      return certifiedExpert
        ? `Review by ${certifiedExpert.expertName} (${certifiedExpert.certificationId}) — ${certifiedExpert.status}.`
        : 'Awaiting accredited expert witness certification.';
    }
    return 'Checked against FRE 702 / Daubert admissibility standard and NIST SP 800-86 guidance.';
  };

  return (
    <div id="legal-review-screen" className="p-4 sm:p-6 space-y-6 bg-[#F4F8F6] min-h-full text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-900/10 pb-5">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('expert-validation')} label="Back to Expert Review" variant="pill" />
          </div>
          <div className="flex items-center space-x-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 font-sans flex items-center space-x-2">
              <Scale className="w-6 h-6 text-emerald-700" />
              <span>Legal Review & Court Admissibility</span>
            </h1>
            <span className="text-xs font-mono font-bold text-emerald-900 bg-emerald-100 border border-emerald-300 px-3 py-1 rounded-full shadow-xs">
              DOCKET: {activeCaseId || 'UNSELECTED'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Judicial evidentiary review under Federal Rules of Evidence 702 & 902(13)/(14) and Daubert/Frye standards
          </p>
        </div>

        <button
          id="legal-generate-report-btn"
          onClick={() => setCurrentScreen('report-generation')}
          className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-900/20 flex items-center space-x-2 transition-all cursor-pointer"
        >
          <FileText className="w-4 h-4" />
          <span>Open Court-Ready Forensic Report →</span>
        </button>
      </div>

      {!activeCaseId && (
        <div className="p-6 bg-white border border-emerald-900/10 rounded-2xl text-center space-y-2 max-w-2xl mx-auto">
          <AlertTriangle className="w-6 h-6 text-amber-600 mx-auto" />
          <p className="text-xs font-bold text-slate-900">No Active Case Docket Selected</p>
          <p className="text-xs text-slate-500">Select or open a case docket in Case Management to conduct legal review.</p>
        </div>
      )}

      {errorMessage && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center space-x-2 max-w-6xl mx-auto">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {statusMessage && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-xl text-xs text-emerald-900 flex items-center space-x-2 max-w-6xl mx-auto">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-700" />
          <span className="font-semibold">{statusMessage}</span>
        </div>
      )}

      {activeCaseId && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 max-w-6xl mx-auto">
          {/* Left Column: Court Readiness Checklist */}
          <div className="lg:col-span-7 space-y-5">
            <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-5 shadow-sm">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
                <div>
                  <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center space-x-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-700" />
                    <span>Court Readiness Checklist & Proof Ledger</span>
                  </h2>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Synced with case evidence, custody ledger, and expert certification records
                  </p>
                </div>

                <div className="flex items-center space-x-2 font-mono text-xs">
                  {isLoading && <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-700" />}
                  <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-900 font-bold">
                    {completedCount} Complete
                  </span>
                  {pendingCount > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 font-bold">
                      {pendingCount} Pending
                    </span>
                  )}
                </div>
              </div>

              <div className="space-y-1.5 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-slate-700">Admissibility Readiness Score</span>
                  <span className="text-emerald-800 font-mono">{progressPercent}% Ready</span>
                </div>
                <div className="h-2.5 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${progressPercent}%` }}
                    className="h-full bg-emerald-600 rounded-full transition-all duration-300"
                  />
                </div>
              </div>

              <div className="space-y-3">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className={`p-4 rounded-xl border transition-all space-y-2 ${
                      item.status === 'COMPLETE'
                        ? 'bg-emerald-50/40 border-emerald-200/80 text-slate-900'
                        : 'bg-amber-50/40 border-amber-200 text-slate-900'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <span className="font-bold text-xs text-slate-900">{item.label}</span>
                      <button
                        type="button"
                        disabled={!canEditLegal}
                        onClick={() => toggleItemStatus(item.id)}
                        className={`shrink-0 ${canEditLegal ? 'cursor-pointer' : 'opacity-70 cursor-default'}`}
                      >
                        {item.status === 'COMPLETE' ? (
                          <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300 inline-flex items-center space-x-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-700 shrink-0" />
                            <span>COMPLETE</span>
                          </span>
                        ) : (
                          <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 inline-flex items-center space-x-1">
                            <Clock className="w-3 h-3 text-amber-700 shrink-0" />
                            <span>PENDING</span>
                          </span>
                        )}
                      </button>
                    </div>

                    <div className="bg-white/80 border border-slate-200/70 p-2.5 rounded-lg text-xs text-slate-700 flex items-start space-x-1.5">
                      <Info className="w-3.5 h-3.5 text-emerald-700 shrink-0 mt-0.5" />
                      <p className="text-[11px]">{getSupportingDetail(item.label)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Live Case Summary, Legal Determination & Notes */}
          <div className="lg:col-span-5 space-y-5">
            <div className="bg-white border border-emerald-900/10 rounded-2xl p-5 space-y-3 shadow-sm text-xs">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <h3 className="font-bold uppercase text-slate-900 flex items-center space-x-1.5">
                  <Hash className="w-4 h-4 text-emerald-700" />
                  <span>Evidentiary Status Summary</span>
                </h3>
                <span
                  className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                    legalStatus === 'CERTIFIED'
                      ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                      : legalStatus === 'REJECTED'
                      ? 'bg-rose-100 text-rose-900 border-rose-300'
                      : 'bg-amber-100 text-amber-900 border-amber-300'
                  }`}
                >
                  {legalStatus}
                </span>
              </div>

              <div className="space-y-2 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">Primary Evidence:</span>
                  <span className="font-bold text-slate-900 truncate max-w-[200px]">
                    {primaryEvidence ? primaryEvidence.filename : 'None ingested'}
                  </span>
                </div>
                <div className="flex justify-between font-mono">
                  <span className="text-slate-500">SHA-256:</span>
                  <span className="text-emerald-800 font-bold">
                    {primaryEvidence?.sha256Hash
                      ? `${primaryEvidence.sha256Hash.slice(0, 12)}...${primaryEvidence.sha256Hash.slice(-6)}`
                      : 'Unavailable'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Docket Verdict:</span>
                  <span className="font-bold text-slate-900">
                    {caseRecord?.verdict || latestAnalysis?.verdict || 'INCONCLUSIVE'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Expert Witness:</span>
                  <span className="font-bold text-emerald-800">
                    {certifiedExpert
                      ? `${certifiedExpert.expertName} (${certifiedExpert.status})`
                      : 'Pending Certification'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Assigned Counsel:</span>
                  <span className="font-semibold text-slate-800">
                    {legalReview?.legalCounsel || 'Pending Counsel'}
                  </span>
                </div>
                <p className="pt-2 border-t border-slate-100 text-[10px] text-amber-800 bg-amber-50 p-2 rounded-lg border border-amber-200 leading-relaxed">
                  <strong>Probabilistic Decision-Support Caveat:</strong> Automated AI detection & DSP telemetry constitute probabilistic decision support under FRE 702 and never stand alone as proof of identity or fabrication without accredited human expert evaluation.
                </p>
              </div>
            </div>

            <div className="bg-white border border-emerald-900/10 rounded-2xl p-5 space-y-3 shadow-sm text-xs">
              <h3 className="font-bold uppercase text-slate-900 border-b border-slate-100 pb-2">
                Prosecutor Determination & Jurisdiction
              </h3>

              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase text-slate-500 block">Jurisdiction</label>
                <input
                  type="text"
                  disabled={!canEditLegal}
                  value={jurisdiction}
                  onChange={(e) => setJurisdiction(e.target.value)}
                  className="w-full bg-[#F8FAF9] border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900"
                />
              </div>

              <div className="space-y-2 pt-1">
                <button
                  type="button"
                  disabled={!canEditLegal || isSaving}
                  onClick={() => persistLegalReview('CERTIFIED')}
                  className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center justify-center space-x-2 transition-all cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Approve & Certify for Court Admissibility</span>
                </button>

                <button
                  type="button"
                  disabled={!canEditLegal || isSaving}
                  onClick={() => persistLegalReview('REJECTED')}
                  className="w-full py-2.5 bg-rose-700 hover:bg-rose-800 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center justify-center space-x-2 transition-all cursor-pointer"
                >
                  <AlertCircle className="w-4 h-4" />
                  <span>Flag for Supplemental Findings</span>
                </button>

                <button
                  type="button"
                  disabled={!canEditLegal || isSaving}
                  onClick={() => persistLegalReview('UNDER REVIEW')}
                  className="w-full py-2 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 text-slate-700 text-xs font-bold rounded-xl transition-all cursor-pointer"
                >
                  Save Checklist Progress (Under Review)
                </button>
              </div>

              {!canEditLegal && (
                <p className="text-[10px] text-amber-800 bg-amber-50 p-2 rounded-lg border border-amber-200">
                  Read-Only View: Legal determination actions require Prosecutor / Legal Reviewer or Lead Forensic Analyst authorization.
                </p>
              )}
            </div>

            <div className="bg-white border border-emerald-900/10 rounded-2xl p-5 space-y-4 shadow-sm text-xs">
              <h3 className="font-bold uppercase text-slate-900 flex items-center space-x-2 border-b border-slate-100 pb-2">
                <MessageSquare className="w-4 h-4 text-emerald-700" />
                <span>Legal Review Notes & Pretrial Motions</span>
              </h3>

              {notes ? (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl whitespace-pre-wrap text-[11px] text-slate-700 max-h-48 overflow-y-auto">
                  {notes}
                </div>
              ) : (
                <p className="text-[11px] text-slate-400 italic">No legal review notes attached yet.</p>
              )}

              {canEditLegal && (
                <form onSubmit={handleAttachNote} className="space-y-2">
                  <textarea
                    rows={2}
                    value={newNoteDraft}
                    onChange={(e) => setNewNoteDraft(e.target.value)}
                    placeholder="Enter judicial review note or pretrial motion remarks..."
                    className="w-full bg-[#F8FAF9] border border-slate-200 rounded-xl p-2.5 text-xs text-slate-900 focus:outline-hidden focus:border-emerald-600 focus:bg-white"
                  />
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={isSaving || !newNoteDraft.trim()}
                      className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs flex items-center space-x-1.5 transition-all cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Attach Legal Review Note</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
