import React, { useState } from 'react';
import {
  Cpu,
  ShieldCheck,
  Sparkles,
  FileText,
  ArrowRight
} from 'lucide-react';
import { ScreenId } from '../../types';
import { BackButton } from '../common/BackButton';

interface WorkflowScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
}

export const WorkflowScreen: React.FC<WorkflowScreenProps> = ({ setCurrentScreen }) => {
  const [activeStepIndex, setActiveStepIndex] = useState(0);

  const features = [
    {
      icon: Cpu,
      title: 'Deterministic DSP + Modular AI Slots',
      description: 'Live physical DSP analysis (YIN F0 pitch contour, jitter, shimmer, HNR, STFT spectral features) paired with isolated adapter slots for external CNN, BiLSTM, and Wav2Vec2 classifiers when configured.',
      tag: 'DSP + AI Adapters'
    },
    {
      icon: ShieldCheck,
      title: 'ISO/IEC 27037 Cryptographic Custody',
      description: 'Immediate server-side SHA-256 evidence sealing on multipart ingest with hash-linked, Ed25519-signed custody ledger tracking for court-admissible chain of custody.',
      tag: 'ISO/IEC 27037'
    },
    {
      icon: Sparkles,
      title: 'Transparent XAI & Limitations Disclosure',
      description: 'Displays real acoustic anomaly intervals from measured F0 telemetry alongside honest MODEL_UNAVAILABLE disclosures whenever Grad-CAM or SHAP neural checkpoints are absent.',
      tag: 'Honest XAI'
    },
    {
      icon: FileText,
      title: 'Automated Judicial Reporting',
      description: 'Produces tamper-evident forensic reports conforming to FRE 902(13)/(14) backed by Ed25519 enclave signatures and live SHA-256 verification tokens.',
      tag: 'FRE 902 Verified'
    }
  ];

  const workflowSteps = [
    {
      step: '01',
      title: 'Evidence Ingestion & Cryptographic Seal',
      targetScreen: 'evidence' as ScreenId,
      description: 'Ingest raw WAV, FLAC, MP3, OGG, or M4A recordings via multipart upload. Magic-byte validation, SHA-256 sealing, and immutable ledger entry creation occur on ingest.',
      inputs: 'Raw Audio Waveform (16kHz-48kHz PCM), Case Docket Metadata',
      algorithms: 'SHA-256 Digest, Magic-Byte Header Check, Automated Hash-Linked Ledger',
      standard: 'ISO/IEC 27037 §6.3 / NIST SP 800-86',
      output: 'Sealed Evidence Record & Chain-of-Custody Block #1'
    },
    {
      step: '02',
      title: 'DSP Feature Extraction',
      targetScreen: 'pipeline' as ScreenId,
      description: 'Extracts physical acoustic telemetry including F0 fundamental pitch contour (YIN / Autocorrelation), jitter, shimmer, harmonics-to-noise ratio (HNR), spectral centroid, roll-off, and SNR.',
      inputs: 'Cryptographically Verified Audio Buffer',
      algorithms: 'STFT, Normalized Autocorrelation YIN, Pitch Perturbation & HNR Metrics',
      standard: 'IEEE Signal Processing Forensic Protocol',
      output: 'Verified Acoustic Measurements & Pitch Contour Telemetry'
    },
    {
      step: '03',
      title: 'Isolated AI Inference Adapters',
      targetScreen: 'detection-results' as ScreenId,
      description: 'Queries external CNN, BiLSTM, Wav2Vec2, and ECAPA-TDNN inference endpoints when configured. Reports explicit MODEL_UNAVAILABLE / INCONCLUSIVE states when weights are absent.',
      inputs: 'Verified Evidence File & Extracted DSP Telemetry',
      algorithms: 'CNN, BiLSTM, Wav2Vec2 Adapters (Fail-Closed Isolation)',
      standard: 'ASVspoof Protocol / Zero-Fabrication Audit Policy',
      output: 'Classifier Outputs or Explicit Unavailability Disclosure'
    },
    {
      step: '04',
      title: 'Acoustic & XAI Inspection',
      targetScreen: 'xai' as ScreenId,
      description: 'Presents time-aligned F0 pitch irregularities and spectral indicators alongside explicit status reporting for neural Grad-CAM and TreeSHAP attribution layers.',
      inputs: 'F0 Contour Series & Enclave Model Registry Status',
      algorithms: 'YIN Anomaly Flagging, Optional External Grad-CAM / SHAP Hooks',
      standard: 'Daubert Factor 2 / Transparent Limitations Policy',
      output: 'Auditable Spectrogram & Pitch Telemetry Breakdown'
    },
    {
      step: '05',
      title: 'Credential Re-Auth & Ed25519 Expert Signing',
      targetScreen: 'expert-validation' as ScreenId,
      description: 'Accredited forensic examiners review findings, complete mandatory SWGDE checklists, re-authenticate with password + optional TOTP 2FA, and seal the affidavit using an Ed25519 enclave signature.',
      inputs: 'Forensic Dossier + Password / RFC 6238 TOTP Verification',
      algorithms: 'Scrypt Password Re-Auth, RFC 6238 TOTP, Node Crypto Ed25519 Signing',
      standard: 'FRE Rule 702 (Expert Testimony) / CJIS Re-Auth Policy',
      output: 'Ed25519-Signed Expert Validation Affidavit'
    },
    {
      step: '06',
      title: 'Legal Review & Certified Docket Issue',
      targetScreen: 'report-generation' as ScreenId,
      description: 'Enforces live SHA-256 & chain-of-custody verification plus Expert & Legal signoff before issuing Final Court-Certified PDF/HTML/DOC reports with verifiable public tokens.',
      inputs: 'Signed Forensic Ledger + Live Evidence Digest Verification',
      algorithms: 'Live SHA-256 Re-Check, Ed25519 Report Sealing, Verification Token Registry',
      standard: 'Federal Rules of Evidence 902(13) & 902(14)',
      output: 'Court-Ready Forensic Report & Public Verification Token'
    }
  ];

  const currentStep = workflowSteps[activeStepIndex];

  return (
    <div id="workflow-screen" className="min-h-full bg-[#F4F8F6] text-slate-800 p-6 md:p-12 space-y-12">
      <div className="max-w-6xl mx-auto space-y-12">
        {/* Navigation Bar */}
        <div className="flex items-center justify-between">
          <BackButton onClick={() => setCurrentScreen('landing')} label="Back to Home" variant="pill" />
          <span className="text-[10px] font-mono text-[#54665C]">Platform Architecture & Forensic Flow</span>
        </div>

        {/* Header Section */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-2">
            <span className="px-3.5 py-1 bg-emerald-100 border border-emerald-300 text-emerald-950 text-xs font-bold uppercase tracking-widest rounded-lg shadow-2xs">
              National Security & Digital Forensic Enclave
            </span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-sans tracking-tight">
            Designed for Law Enforcement, Intelligence & Judicial Courts
          </h1>
          <p className="text-slate-600 text-sm max-w-2xl mx-auto leading-relaxed">
            ALFADetect combines reproducible digital signal processing, cryptographic chain-of-custody integrity, and strict judicial admissibility controls.
          </p>
        </div>

        {/* 4 Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {features.map((f, idx) => {
            const Icon = f.icon;
            return (
              <div
                key={idx}
                className="bg-white border border-emerald-900/10 rounded-2xl p-6 hover:border-emerald-500/50 transition-all space-y-4 shadow-sm group"
              >
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-800 group-hover:bg-emerald-700 group-hover:text-white transition-all">
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-[11px] font-mono font-semibold px-2.5 py-0.5 bg-slate-100 text-slate-700 border border-slate-200 rounded">
                    {f.tag}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 group-hover:text-emerald-800 transition-colors">
                  {f.title}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">{f.description}</p>
              </div>
            );
          })}
        </div>

        {/* Interactive Step-by-Step Process Explorer */}
        <div className="bg-white border border-emerald-900/10 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900">
                End-to-End Forensic Workflow Pipeline
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Click any stage to examine algorithmic processes, evidentiary standards, and audit checkpoints.
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 self-start sm:self-auto">
              Stage {activeStepIndex + 1} of {workflowSteps.length}
            </span>
          </div>

          {/* Stepper Navigation Pills */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
            {workflowSteps.map((ws, idx) => (
              <button
                key={idx}
                onClick={() => setActiveStepIndex(idx)}
                className={`p-3 rounded-xl text-left border transition-all cursor-pointer ${
                  activeStepIndex === idx
                    ? 'bg-emerald-700 border-emerald-800 text-white shadow-md'
                    : 'bg-[#F9FBFA] border-slate-200 hover:border-emerald-300 text-slate-700'
                }`}
              >
                <span className={`text-[11px] font-mono font-bold block ${activeStepIndex === idx ? 'text-emerald-200' : 'text-slate-400'}`}>
                  STEP {ws.step}
                </span>
                <span className="text-xs font-bold line-clamp-1 mt-0.5">
                  {ws.title.split(' ')[0]} {ws.title.split(' ')[1] || ''}
                </span>
              </button>
            ))}
          </div>

          {/* Detailed Inspector for Active Step */}
          <div className="bg-[#032319] border border-emerald-950/20 rounded-2xl p-6 text-white space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
              <div>
                <div className="flex items-center space-x-2 text-emerald-400 font-mono text-xs mb-1">
                  <span>PHASE {currentStep.step} SPECIFICATION</span>
                  <span>·</span>
                  <span className="text-emerald-300">{currentStep.standard}</span>
                </div>
                <h3 className="text-xl font-bold text-white">
                  {currentStep.title}
                </h3>
                <p className="text-xs text-emerald-100/80 mt-2 max-w-2xl leading-relaxed">
                  {currentStep.description}
                </p>
              </div>

              <button
                onClick={() => setCurrentScreen(currentStep.targetScreen)}
                className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-bold text-xs rounded-xl shadow-md transition-all flex items-center space-x-2 shrink-0 cursor-pointer self-start"
              >
                <span>Launch {currentStep.title.split('&')[0].trim()}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Technical Parameters Matrix */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-emerald-800/60 text-xs">
              <div className="p-3 bg-black/30 border border-emerald-800/40 rounded-xl space-y-1">
                <span className="text-[10px] text-emerald-400 font-mono uppercase block">Input Artifacts</span>
                <p className="text-emerald-100 font-medium">{currentStep.inputs}</p>
              </div>
              <div className="p-3 bg-black/30 border border-emerald-800/40 rounded-xl space-y-1">
                <span className="text-[10px] text-emerald-400 font-mono uppercase block">Algorithms & DSP</span>
                <p className="text-emerald-100 font-medium">{currentStep.algorithms}</p>
              </div>
              <div className="p-3 bg-black/30 border border-emerald-800/40 rounded-xl space-y-1">
                <span className="text-[10px] text-emerald-400 font-mono uppercase block">Judicial Output</span>
                <p className="text-emerald-100 font-medium">{currentStep.output}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom CTA Banner */}
        <div className="p-8 bg-[#032319] border border-emerald-950/20 rounded-3xl text-center space-y-4 shadow-xl">
          <h3 className="text-2xl font-bold text-white font-sans">
            Ready to Verify Audio Evidence Integrity?
          </h3>
          <p className="text-xs text-emerald-200/80 max-w-xl mx-auto leading-relaxed">
            Access the secure forensic enclave with your institutional credentials or submit evidence for verification.
          </p>
          <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => setCurrentScreen('signin')}
              className="px-6 py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-950 flex items-center space-x-2 transition-all cursor-pointer"
            >
              <span>Access Operator Enclave</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentScreen('dashboard')}
              className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl border border-white/20 transition-all cursor-pointer"
            >
              <span>View Active Dockets</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
