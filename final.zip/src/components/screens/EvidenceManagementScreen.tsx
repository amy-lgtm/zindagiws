import React, { useState, useRef, useEffect } from 'react';
import {
  Upload,
  Music,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Mic,
  CheckCircle,
  FileCheck,
  Shield,
  Layers,
  ArrowRight,
  Sparkles,
  Lock,
  FileText,
  AlertCircle,
  X,
  RefreshCw,
  Hash,
  AlertTriangle,
  FolderKanban,
  CheckCircle2,
  ShieldCheck,
  Cpu
} from 'lucide-react';
import { ScreenId, AudioEvidence, User, Case } from '../../types';
import { calculateFileSHA256 } from '../../utils/crypto';
import { encodeFloat32ToWavBuffer } from '../../utils/audioDsp';
import { speakAudioEvidence, stopAudioEvidence } from '../../utils/audioPlayer';
import { canUploadEvidence, isReadOnlyForensics, ROLE_CONFIGS } from '../../utils/rbac';
import { BackButton } from '../common/BackButton';
import { authFetch, api } from '../../utils/api';

interface EvidenceManagementScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  activeEvidence: AudioEvidence;
  setActiveEvidence: (ev: AudioEvidence) => void;
  currentUser: User;
  selectedCaseId?: string;
  cases?: Case[];
}

export const EvidenceManagementScreen: React.FC<EvidenceManagementScreenProps> = ({
  setCurrentScreen,
  activeEvidence,
  setActiveEvidence,
  currentUser,
  selectedCaseId,
  cases = []
}) => {
  const [activeCaseId, setActiveCaseId] = useState<string>(selectedCaseId || (cases[0]?.id || ''));
  const [caseEvidenceList, setCaseEvidenceList] = useState<AudioEvidence[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(252);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);

  // Staged Upload Flow States
  const [stagedFile, setStagedFile] = useState<File | null>(null);
  const [stagedMetadata, setStagedMetadata] = useState<{
    duration: string;
    sampleRate: string;
    channels: string;
    bitDepth: string;
    sha256Hash: string;
    sizeFormatted: string;
  } | null>(null);

  const [isProcessingStaged, setIsProcessingStaged] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isDerivingCopy, setIsDerivingCopy] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadSuccess, setUploadSuccess] = useState<string | null>(null);
  const [playbackError, setPlaybackError] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const userCanUpload = canUploadEvidence(currentUser.role);
  const isReadOnly = isReadOnlyForensics(currentUser.role);
  const roleConfig = ROLE_CONFIGS[currentUser.role];

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);

  // Sync activeCaseId when selectedCaseId changes
  useEffect(() => {
    if (selectedCaseId) {
      setActiveCaseId(selectedCaseId);
    } else if (cases.length > 0 && !activeCaseId) {
      setActiveCaseId(cases[0].id);
    }
  }, [selectedCaseId, cases]);

  // Load existing evidence from server
  useEffect(() => {
    async function loadEvidence() {
      try {
        const url = activeCaseId ? `/api/evidence?caseId=${encodeURIComponent(activeCaseId)}` : '/api/evidence';
        const res = await authFetch(url);
        if (res.ok) {
          const list = await res.json();
          if (Array.isArray(list)) {
            setCaseEvidenceList(list);
            if (list.length > 0 && (!activeEvidence.caseId || activeEvidence.id === 'EV-INIT')) {
              setActiveEvidence(list[0]);
            }
          }
        }
      } catch (err) {
        console.warn('Evidence list fetch notice:', err);
      }
    }
    loadEvidence();
  }, [activeCaseId]);

  // Synchronize audio playback
  const handleTogglePlay = () => {
    setPlaybackError(null);
    const nextState = !isPlaying;
    setIsPlaying(nextState);

    if (nextState) {
      const isSynthetic = activeEvidence.classification !== 'Authentic';
      const speechText = `Evidence sample ${activeEvidence.filename}. Status: ${
        activeEvidence.classification || 'Under Examination'
      }. Verified with SHA 256 hash digest.`;

      speakAudioEvidence(speechText, {
        isSynthetic,
        audioUrl: activeEvidence.audioUrl,
        onEnd: () => setIsPlaying(false),
        onError: (msg) => {
          setIsPlaying(false);
          setPlaybackError(msg);
        }
      });
    } else {
      stopAudioEvidence();
    }
  };

  // Non-destructive derived normalized WAV working copy (preserves original bytes & SHA-256)
  const handleDeriveNormalizedCopy = async () => {
    if (!activeEvidence?.id || activeEvidence.id === 'EV-INIT') return;
    setIsDerivingCopy(true);
    setUploadError(null);
    setUploadSuccess(null);
    try {
      const derived: AudioEvidence = await api.deriveEvidenceCopy(activeEvidence.id, { highPassHz: 80 });
      setCaseEvidenceList((prev) => [derived, ...prev.filter((item) => item.id !== derived.id)]);
      setActiveEvidence(derived);
      setUploadSuccess(
        `Non-destructive normalized working copy (${derived.id}) created from parent ${activeEvidence.id}. Original raw exhibit remains unaltered.`
      );
    } catch (err: any) {
      setUploadError(err?.message || 'Failed to derive normalized working copy.');
    } finally {
      setIsDerivingCopy(false);
    }
  };

  // Compute and draw real acoustic frequency/amplitude profile from active evidence audio when available
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let cancelled = false;

    const drawGridAndBars = (bars: number[] | null, label: string) => {
      ctx.fillStyle = '#062817';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const width = canvas.width;
      const height = canvas.height;

      // Subtle reference grid
      ctx.strokeStyle = 'rgba(200, 138, 44, 0.14)';
      ctx.lineWidth = 1;
      for (let y = 1; y < 4; y++) {
        const py = (height / 4) * y;
        ctx.beginPath();
        ctx.moveTo(0, py);
        ctx.lineTo(width, py);
        ctx.stroke();
      }

      if (!bars || bars.length === 0) {
        ctx.fillStyle = '#6EE7B7';
        ctx.font = '11px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(label, width / 2, height / 2 + 4);
        return;
      }

      const colWidth = width / bars.length;
      const rows = 16;
      const rowHeight = height / rows;

      for (let c = 0; c < bars.length; c++) {
        const level = Math.max(0.05, Math.min(1, bars[c]));
        const litRows = Math.round(level * rows);
        for (let r = 0; r < litRows; r++) {
          const ratio = r / rows;
          ctx.fillStyle = ratio > 0.78 ? '#C88A2C' : ratio > 0.45 ? '#15803D' : '#0A3D24';
          ctx.fillRect(c * colWidth + 0.5, height - (r + 1) * rowHeight + 0.5, Math.max(1, colWidth - 1.5), Math.max(1, rowHeight - 1.5));
        }
      }
    };

    if (!activeEvidence.audioUrl || activeEvidence.id === 'EV-INIT') {
      drawGridAndBars(null, 'Awaiting Exhibit Audio Bitstream');
      return;
    }

    drawGridAndBars(null, 'Decoding Audio Exhibit...');

    (async () => {
      try {
        const resp = activeEvidence.audioUrl!.startsWith('/api/')
          ? await authFetch(activeEvidence.audioUrl!)
          : await fetch(activeEvidence.audioUrl!);
        if (!resp.ok || cancelled) {
          if (!cancelled) drawGridAndBars(null, 'Audio stream stored on enclave (preview requires WAV/MP3 container)');
          return;
        }
        const buf = await resp.arrayBuffer();
        if (cancelled) return;
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const audioCtx = new AudioCtx();
        const decoded = await audioCtx.decodeAudioData(buf);
        if (cancelled) return;
        const pcm = decoded.getChannelData(0);
        const numBars = 64;
        const step = Math.max(1, Math.floor(pcm.length / numBars));
        const bars: number[] = [];
        let maxRms = 0.001;
        for (let b = 0; b < numBars; b++) {
          const start = b * step;
          const end = Math.min(pcm.length, start + step);
          let sumSq = 0;
          for (let i = start; i < end; i++) {
            sumSq += pcm[i] * pcm[i];
          }
          const rms = Math.sqrt(sumSq / Math.max(1, end - start));
          if (rms > maxRms) maxRms = rms;
          bars.push(rms);
        }
        const normalized = bars.map((v) => v / maxRms);
        drawGridAndBars(normalized, 'Acoustic Envelope');
      } catch {
        if (!cancelled) {
          drawGridAndBars(null, 'SHA-256 Sealed Exhibit (Browser PCM decode unavailable for container)');
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [activeEvidence.id, activeEvidence.audioUrl]);

  // Validate and Stage File for Upload
  const stageSelectedFile = async (file: File) => {
    setUploadError(null);
    setUploadSuccess(null);

    // 1. File presence check
    if (!file) return;

    // 2. Extension validation (WAV, MP3, FLAC, M4A, OGG)
    const validExtensions = ['.wav', '.mp3', '.flac', '.m4a', '.ogg'];
    const ext = '.' + file.name.split('.').pop()?.toLowerCase();
    if (!validExtensions.includes(ext)) {
      setUploadError(`Unsupported audio format (${ext}). Supported formats: WAV, MP3, FLAC, M4A, OGG.`);
      return;
    }

    // 3. 50 MB Maximum Size Validation
    const maxSizeBytes = 50 * 1024 * 1024;
    if (file.size > maxSizeBytes) {
      setUploadError(`File exceeds maximum allowed size of 50 MB (File size: ${(file.size / (1024 * 1024)).toFixed(2)} MB).`);
      return;
    }

    if (file.size <= 0) {
      setUploadError('Invalid empty file (0 bytes received).');
      return;
    }

    setIsProcessingStaged(true);
    setStagedFile(file);

    let durationFormatted = '00:30';
    let sampleRateStr = '44.1 kHz';
    let channelsStr = 'Stereo';

    try {
      if (typeof window !== 'undefined' && (window.AudioContext || (window as any).webkitAudioContext)) {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const arrayBuffer = await file.arrayBuffer();
        const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
        const durSec = audioBuffer.duration;
        const m = Math.floor(durSec / 60);
        const s = Math.floor(durSec % 60);
        durationFormatted = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
        sampleRateStr = `${(audioBuffer.sampleRate / 1000).toFixed(1)} kHz`;
        channelsStr = audioBuffer.numberOfChannels === 1 ? 'Mono' : 'Stereo';
      }
    } catch {
      // AudioContext decoding may fail on non-standard containers; retain safe defaults
    }

    try {
      const hash = await calculateFileSHA256(file);
      setStagedMetadata({
        duration: durationFormatted,
        sampleRate: sampleRateStr,
        channels: channelsStr,
        bitDepth: '16-bit PCM',
        sha256Hash: hash,
        sizeFormatted: `${(file.size / (1024 * 1024)).toFixed(2)} MB`
      });
    } catch (err) {
      setUploadError('Failed to calculate SHA-256 bitstream checksum for this file.');
    } finally {
      setIsProcessingStaged(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      stageSelectedFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      stageSelectedFile(file);
    }
  };

  const clearStagedFile = () => {
    setStagedFile(null);
    setStagedMetadata(null);
    setUploadError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Submit Staged Evidence to Server (50 MB binary multipart upload)
  const handleConfirmUpload = async () => {
    if (!stagedFile || !stagedMetadata) return;

    if (!activeCaseId) {
      setUploadError('Please select an active Case Docket to associate this evidence with.');
      return;
    }

    setIsUploading(true);
    setUploadError(null);
    setUploadSuccess(null);

    try {
      const formData = new FormData();
      formData.append('caseId', activeCaseId);
      formData.append('fileSize', stagedMetadata.sizeFormatted);
      formData.append('duration', stagedMetadata.duration);
      formData.append('sampleRate', stagedMetadata.sampleRate);
      formData.append('bitDepth', stagedMetadata.bitDepth);
      formData.append('channels', stagedMetadata.channels);
      formData.append('uploadedBy', currentUser.name);
      formData.append('audio', stagedFile, stagedFile.name);

      const serverEvidence: AudioEvidence = await api.uploadEvidenceMultipart(formData);
      setIsUploading(false);

      setActiveEvidence(serverEvidence);
      setCaseEvidenceList((prev) => [serverEvidence, ...prev.filter((item) => item.id !== serverEvidence.id)]);
      setUploadSuccess(`Evidence successfully ingested and sealed in Docket ${activeCaseId}. Evidence ID: ${serverEvidence.id}`);
      clearStagedFile();
    } catch (err: any) {
      setIsUploading(false);
      setUploadError(err?.message || 'Evidence upload rejected or forensic backend unavailable.');
    }
  };

  // Microphone recording — transcode captured container to genuine 16-bit PCM WAV when AudioContext succeeds
  const handleStartRecording = async () => {
    setUploadError(null);
    setUploadSuccess(null);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const rawMime = (mediaRecorder.mimeType || 'audio/webm').split(';')[0].trim();
        const rawBlob = new Blob(audioChunksRef.current, { type: rawMime });
        let recordedFile: File | null = null;

        try {
          const AudioCtx =
            window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
          if (AudioCtx) {
            const ctx = new AudioCtx();
            try {
              const arrayBuf = await rawBlob.arrayBuffer();
              const decoded = await ctx.decodeAudioData(arrayBuf);
              const length = decoded.length;
              const channels = decoded.numberOfChannels || 1;
              const mono = new Float32Array(length);
              for (let ch = 0; ch < channels; ch++) {
                const chData = decoded.getChannelData(ch);
                for (let i = 0; i < length; i++) {
                  mono[i] += chData[i] / channels;
                }
              }
              const wavBytes = encodeFloat32ToWavBuffer(mono, decoded.sampleRate);
              const wavBlob = new Blob([wavBytes], { type: 'audio/wav' });
              recordedFile = new File([wavBlob], `surveillance_intercept_${Date.now()}.wav`, {
                type: 'audio/wav'
              });
            } finally {
              ctx.close().catch(() => {});
            }
          }
        } catch {
          // Fall back to honest captured mime/extension if browser decode fails
        }

        if (!recordedFile) {
          const ext = rawMime.includes('ogg') ? 'ogg' : rawMime.includes('mp4') || rawMime.includes('m4a') ? 'm4a' : 'webm';
          recordedFile = new File([rawBlob], `surveillance_intercept_${Date.now()}.${ext}`, {
            type: rawMime
          });
        }

        stageSelectedFile(recordedFile);

        setIsRecording(false);
        setRecordingTime(0);
        clearInterval(timerRef.current);
      };

      mediaRecorder.start();
      setIsRecording(true);

      timerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
    } catch {
      setUploadError('Microphone capture access denied by browser environment.');
    }
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach((track) => track.stop());
    }
  };

  return (
    <div id="evidence-screen" className="p-6 space-y-6 bg-[#F8FAF9] min-h-full text-[#112217]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E1EBE4] pb-5">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('cases')} label="Back to Cases" variant="pill" />
          </div>
          <div className="flex items-center space-x-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-[#112217] font-serif-title">
              Evidence Management Locker
            </h1>
            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full border bg-[#FEF3C7] text-[#B2751E] border-[#C88A2C]/30 font-mono">
              {roleConfig?.shortLabel}
            </span>
          </div>
          <p className="text-xs text-[#54665C] mt-1">
            Forensic audio intake, real bitstream SHA-256 integrity sealing, and court-admissible custody tracking.
          </p>
        </div>

        {/* Docket Selector */}
        <div className="flex items-center space-x-2">
          {cases.length > 0 ? (
            <div className="flex items-center space-x-2">
              <span className="text-xs font-semibold text-[#54665C]">Associated Docket:</span>
              <select
                value={activeCaseId}
                onChange={(e) => setActiveCaseId(e.target.value)}
                className="px-3 py-1.5 bg-white border border-[#E1EBE4] rounded-xl text-xs font-mono font-bold text-[#0A3D24] shadow-xs cursor-pointer focus:outline-none focus:border-[#0A3D24]"
              >
                {cases.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.id}: {c.title.slice(0, 26)}
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <span className="text-xs font-mono font-bold text-[#0A3D24] bg-white border border-[#E1EBE4] px-3 py-1.5 rounded-xl shadow-xs">
              DOCKET: {activeCaseId || 'UNASSIGNED'}
            </span>
          )}
        </div>
      </div>

      {/* Read-Only Notice for Prosecutor / Legal Reviewer */}
      {isReadOnly && (
        <div className="p-3.5 bg-white border border-[#E1EBE4] border-l-4 border-l-[#0A3D24] rounded-2xl flex items-center justify-between text-xs shadow-xs">
          <div className="flex items-center space-x-2">
            <Shield className="w-4 h-4 text-[#0A3D24] shrink-0" />
            <p className="text-[#54665C]">
              <strong className="text-[#112217]">Read-Only Legal Reviewer Mode:</strong> You can inspect evidence audio, spectrograms, and cryptographic checksums. Uploading or modifying evidence requires Examiner or Lead Analyst clearance.
            </p>
          </div>
        </div>
      )}

      {/* Error & Success Banners */}
      {uploadError && (
        <div className="p-3.5 bg-[#FEF2F2] border border-[#B91C1C]/30 text-[#B91C1C] text-xs rounded-2xl flex items-start space-x-2 font-medium">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p>{uploadError}</p>
            {stagedFile && (
              <button
                onClick={handleConfirmUpload}
                className="mt-2 text-[11px] underline font-bold cursor-pointer hover:text-red-900"
              >
                Retry Evidence Upload →
              </button>
            )}
          </div>
        </div>
      )}

      {uploadSuccess && (
        <div className="p-3.5 bg-[#F0FDF4] border border-[#15803D]/30 text-[#15803D] text-xs rounded-2xl flex items-center space-x-2 font-medium">
          <CheckCircle className="w-4 h-4 shrink-0" />
          <span>{uploadSuccess}</span>
        </div>
      )}

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Upload & Live Record Locker */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Professional Staged Upload Area */}
          <div className="bg-white border border-[#E1EBE4] rounded-3xl p-6 space-y-5 shadow-xs">
            <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-3">
              <div className="flex items-center space-x-2">
                <Upload className="w-4 h-4 text-[#0A3D24]" />
                <h3 className="text-sm font-bold text-[#112217] font-serif-title">
                  Audio Evidence Intake & Bitstream Sealing
                </h3>
              </div>
              <span className="text-[10px] text-[#54665C] font-mono">Max 50 MB · WAV, MP3, FLAC, M4A</span>
            </div>

            {userCanUpload ? (
              <div className="space-y-4">
                {/* Drag & Drop Area */}
                {!stagedFile ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* File Upload Zone */}
                    <div
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      onClick={() => fileInputRef.current?.click()}
                      className={`border-2 border-dashed rounded-2xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
                        isDragOver
                          ? 'border-[#0A3D24] bg-[#F0FDF4]'
                          : 'border-[#E1EBE4] hover:border-[#0A3D24] bg-[#F8FAF9]'
                      }`}
                    >
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="audio/wav,audio/mp3,audio/mpeg,audio/flac,audio/x-m4a,audio/m4a,audio/ogg"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                      <div className="w-12 h-12 rounded-2xl bg-white border border-[#E1EBE4] flex items-center justify-center text-[#0A3D24] mb-3 shadow-xs">
                        <Music className="w-6 h-6" />
                      </div>
                      <p className="text-xs font-bold text-[#112217]">Select Evidence Audio File</p>
                      <p className="text-[10px] text-[#54665C] mt-1">
                        Drag and drop here, or browse local disk
                      </p>
                      <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-white border border-[#E1EBE4] text-[#54665C] mt-3">
                        WAV · MP3 · FLAC (Max 50MB)
                      </span>
                    </div>

                    {/* Microphone Capture Zone */}
                    <div className="border border-[#E1EBE4] bg-[#F8FAF9] rounded-2xl p-6 flex flex-col items-center justify-center text-center">
                      <div
                        className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-3 shadow-xs ${
                          isRecording
                            ? 'bg-[#B91C1C] text-white animate-pulse'
                            : 'bg-white border border-[#E1EBE4] text-[#112217]'
                        }`}
                      >
                        <Mic className="w-6 h-6" />
                      </div>
                      <p className="text-xs font-bold text-[#112217]">
                        {isRecording ? `Recording... (${recordingTime}s)` : 'Direct Audio Wiretap / Mic'}
                      </p>
                      <p className="text-[10px] text-[#54665C] mt-1 mb-3">
                        Capture audio stream directly from local microphone
                      </p>

                      {isRecording ? (
                        <button
                          onClick={handleStopRecording}
                          className="px-4 py-2 bg-[#B91C1C] hover:bg-red-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
                        >
                          Stop & Stage Evidence
                        </button>
                      ) : (
                        <button
                          onClick={handleStartRecording}
                          className="px-4 py-2 bg-[#0A3D24] hover:bg-[#062817] text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
                        >
                          Start Audio Intercept
                        </button>
                      )}
                    </div>
                  </div>
                ) : (
                  /* Staged File Confirmation Card */
                  <div className="p-5 bg-[#F8FAF9] border border-[#0A3D24]/30 rounded-2xl space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-xl bg-[#0A3D24] text-white flex items-center justify-center">
                          <Music className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-bold text-xs text-[#112217] truncate max-w-xs sm:max-w-md">
                            {stagedFile.name}
                          </p>
                          <p className="text-[11px] text-[#54665C] font-mono">
                            {stagedMetadata?.sizeFormatted || `${(stagedFile.size / (1024 * 1024)).toFixed(2)} MB`} · Ready for Ingest
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={clearStagedFile}
                        disabled={isUploading}
                        className="p-1 text-[#54665C] hover:text-[#B91C1C] rounded-lg cursor-pointer"
                        title="Remove file"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Metadata Preview */}
                    {stagedMetadata ? (
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] bg-white p-3 rounded-xl border border-[#E1EBE4]">
                        <div>
                          <span className="text-[#54665C] block text-[10px]">Duration:</span>
                          <span className="font-mono font-bold text-[#112217]">{stagedMetadata.duration}</span>
                        </div>
                        <div>
                          <span className="text-[#54665C] block text-[10px]">Sample Rate:</span>
                          <span className="font-mono font-bold text-[#112217]">{stagedMetadata.sampleRate}</span>
                        </div>
                        <div>
                          <span className="text-[#54665C] block text-[10px]">Channels:</span>
                          <span className="font-mono font-bold text-[#112217]">{stagedMetadata.channels}</span>
                        </div>
                        <div>
                          <span className="text-[#54665C] block text-[10px]">Bit Depth:</span>
                          <span className="font-mono font-bold text-[#112217]">{stagedMetadata.bitDepth}</span>
                        </div>
                      </div>
                    ) : (
                      <div className="text-[11px] text-[#54665C] italic">Calculating audio metadata and SHA-256...</div>
                    )}

                    {stagedMetadata?.sha256Hash && (
                      <div className="p-2.5 bg-white border border-[#E1EBE4] rounded-xl text-[10px] font-mono text-[#54665C] break-all">
                        <strong className="text-[#0A3D24] block mb-0.5">Calculated SHA-256 Bitstream Hash:</strong>
                        {stagedMetadata.sha256Hash}
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-2 border-t border-[#E1EBE4]">
                      <button
                        onClick={clearStagedFile}
                        disabled={isUploading}
                        className="px-3 py-2 text-xs font-semibold text-[#54665C] hover:text-[#112217] cursor-pointer"
                      >
                        Change File
                      </button>

                      <button
                        onClick={handleConfirmUpload}
                        disabled={isUploading || isProcessingStaged}
                        className="px-5 py-2.5 bg-[#0A3D24] hover:bg-[#062817] disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs flex items-center space-x-2 transition-all cursor-pointer"
                      >
                        {isUploading ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            <span>Sealing & Ingesting to Enclave...</span>
                          </>
                        ) : (
                          <>
                            <ShieldCheck className="w-3.5 h-3.5 text-[#C88A2C]" />
                            <span>Ingest to Evidence Locker</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-6 bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl text-center space-y-2">
                <Lock className="w-8 h-8 text-[#54665C] mx-auto opacity-60" />
                <p className="text-xs font-bold text-[#112217]">Evidence Ingestion Restricted</p>
                <p className="text-[11px] text-[#54665C] max-w-sm mx-auto">
                  Only Lead Forensic Analysts and Forensic Examiners hold clearance to ingest new evidence items.
                </p>
              </div>
            )}
          </div>

          {/* Active Evidence Audio Player Card */}
          <div className="bg-white border border-[#E1EBE4] rounded-3xl p-6 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-3">
              <div className="flex items-center space-x-2">
                <Music className="w-4 h-4 text-[#0A3D24]" />
                <span className="font-mono text-xs font-bold text-[#112217]">
                  {activeEvidence.filename}
                </span>
              </div>
              <span className="text-[10px] px-2 py-0.5 bg-[#F0FDF4] text-[#15803D] border border-[#15803D]/30 rounded font-mono font-bold">
                {activeEvidence.sha256Hash ? 'SHA-256 SEALED' : 'AWAITING INGEST'}
              </span>
            </div>

            {/* Spectrogram Canvas */}
            <div className="relative rounded-2xl overflow-hidden border border-[#E1EBE4]">
              <canvas
                ref={canvasRef}
                width={500}
                height={130}
                className="w-full h-32 block bg-[#062817]"
              />
              <div className="absolute top-2 left-2 px-2 py-0.5 bg-black/60 rounded text-[9px] font-mono text-emerald-300">
                Real Exhibit RMS Amplitude Envelope
              </div>
            </div>

            {playbackError && (
              <div className="p-3 bg-[#FEF2F2] border border-[#B91C1C]/30 text-[#B91C1C] text-xs rounded-xl flex items-center space-x-2 font-medium">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{playbackError}</span>
              </div>
            )}

            {/* Player Controls */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <div className="flex items-center space-x-3">
                <button
                  onClick={handleTogglePlay}
                  className="p-2.5 bg-[#0A3D24] hover:bg-[#062817] text-white rounded-xl shadow-xs transition-colors cursor-pointer"
                  title={isPlaying ? 'Pause Audio' : 'Play Audio Evidence'}
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                </button>
                <div className="text-xs font-mono text-[#54665C]">
                  <span>{activeEvidence.duration || '00:00'}</span>
                </div>
                {userCanUpload &&
                  activeEvidence.id !== 'EV-INIT' &&
                  activeEvidence.status !== 'Failed' &&
                  activeEvidence.filename.toLowerCase().endsWith('.wav') && (
                    <button
                      onClick={handleDeriveNormalizedCopy}
                      disabled={isDerivingCopy}
                      className="px-3 py-1.5 bg-[#F0FDF4] hover:bg-[#E1EBE4] border border-[#0A3D24]/30 text-[#0A3D24] font-bold text-[11px] rounded-xl flex items-center space-x-1.5 transition-colors cursor-pointer disabled:opacity-50"
                      title="Creates a separate normalized working WAV copy linked to this original exhibit without mutating original bytes"
                    >
                      <Layers className="w-3.5 h-3.5 text-[#C88A2C]" />
                      <span>{isDerivingCopy ? 'Deriving Copy...' : 'Create Normalized Working Copy'}</span>
                    </button>
                  )}
              </div>

              <div className="text-right text-xs">
                <span className="text-[10px] text-[#54665C] block">Sample Rate</span>
                <span className="font-mono font-bold text-[#112217]">
                  {activeEvidence.sampleRate || '44.1 kHz'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Ingested Evidence Locker Table & Case Context */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border border-[#E1EBE4] rounded-3xl p-6 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-3">
              <div className="flex items-center space-x-2">
                <FolderKanban className="w-4 h-4 text-[#0A3D24]" />
                <h3 className="text-sm font-bold text-[#112217] font-serif-title">
                  Docket Evidence Items ({caseEvidenceList.length})
                </h3>
              </div>
              <span className="text-[10px] font-mono text-[#54665C]">
                Case: {activeCaseId || 'GENERAL'}
              </span>
            </div>

            {caseEvidenceList.length === 0 ? (
              <div className="p-8 text-center bg-[#F8FAF9] rounded-2xl border border-[#E1EBE4] space-y-2">
                <FileText className="w-6 h-6 text-[#54665C] mx-auto opacity-60" />
                <p className="text-xs font-bold text-[#112217]">No Audio Evidence Files</p>
                <p className="text-[11px] text-[#54665C]">
                  Stage and ingest a WAV/MP3 recording on the left to begin forensic examination.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[420px] overflow-y-auto">
                {caseEvidenceList.map((ev) => {
                  const isSelected = activeEvidence.id === ev.id;
                  return (
                    <div
                      key={ev.id}
                      onClick={() => setActiveEvidence(ev)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer text-xs space-y-1.5 ${
                        isSelected
                          ? 'bg-[#F0FDF4] border-[#0A3D24] shadow-xs'
                          : 'bg-[#F8FAF9] border-[#E1EBE4] hover:border-[#0A3D24]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center space-x-1.5">
                          <span className="font-mono font-bold text-[#0A3D24] text-[11px]">{ev.id}</span>
                          {ev.isDerivedCopy && (
                            <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-[#FEF3C7] text-[#B2751E] border border-[#C88A2C]/30">
                              DERIVED COPY
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-white border border-[#E1EBE4] font-mono text-[#54665C]">
                          {ev.fileSize}
                        </span>
                      </div>
                      <p className="font-bold text-[#112217] truncate">{ev.filename}</p>
                      {ev.parentEvidenceId && (
                        <p className="text-[10px] font-mono text-[#B2751E]">
                          Parent Exhibit: {ev.parentEvidenceId}
                        </p>
                      )}
                      <div className="flex items-center justify-between text-[10px] text-[#54665C]">
                        <span>{ev.channels} · {ev.duration}</span>
                        <span className="font-mono text-[#0A3D24] truncate max-w-[120px]">
                          {ev.sha256Hash ? `${ev.sha256Hash.slice(0, 8)}...` : 'Unsealed'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Downstream Navigation CTA */}
            {activeEvidence.id !== 'EV-INIT' && (
              <div className="pt-2 border-t border-[#E1EBE4]">
                <button
                  onClick={() => setCurrentScreen('pipeline')}
                  className="w-full py-2.5 bg-[#0A3D24] hover:bg-[#062817] text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center space-x-2 transition-all cursor-pointer"
                >
                  <Cpu className="w-4 h-4 text-[#C88A2C]" />
                  <span>Send to AI Analysis Pipeline</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>

          {/* Active Item Metadata Enclave Card */}
          <div className="bg-white border border-[#E1EBE4] rounded-3xl p-6 space-y-3 shadow-xs text-xs">
            <h4 className="font-bold text-[#112217] uppercase tracking-wider text-[11px] font-serif-title">
              Active Evidence Specifications
            </h4>
            <div className="space-y-2 text-[#54665C]">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span>Ingest Timestamp:</span>
                <span className="font-mono text-[#112217]">{activeEvidence.uploadTimestamp}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span>Ingested By:</span>
                <span className="font-semibold text-[#112217]">{activeEvidence.uploadedBy || 'Investigator'}</span>
              </div>
              {activeEvidence.isDerivedCopy && (
                <>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span>Lineage (Parent Exhibit):</span>
                    <span className="font-mono font-bold text-[#B2751E]">
                      {activeEvidence.parentEvidenceId || 'Derived Working Copy'}
                    </span>
                  </div>
                  {activeEvidence.processingOperation && (
                    <div className="py-1 border-b border-slate-100">
                      <span className="block text-[10px] uppercase font-bold text-[#54665C]">Derivation Operation:</span>
                      <span className="font-mono text-[10px] text-[#112217]">{activeEvidence.processingOperation}</span>
                    </div>
                  )}
                </>
              )}
              <div className="space-y-1 py-1">
                <span className="block text-[10px] uppercase font-bold text-[#54665C]">SHA-256 Checksum:</span>
                <p className="font-mono text-[10px] bg-[#F8FAF9] p-2 rounded-lg border border-[#E1EBE4] text-[#112217] break-all select-all">
                  {activeEvidence.sha256Hash || 'Unavailable — ingest file to compute bitstream digest'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
