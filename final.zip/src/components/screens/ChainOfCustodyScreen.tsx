import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  CheckCircle2,
  User as UserIcon,
  Clock,
  Hash,
  Copy,
  Check,
  RefreshCw,
  AlertCircle,
  FileText,
  Link2
} from 'lucide-react';
import { ScreenId, User } from '../../types';
import { BackButton } from '../common/BackButton';
import { api, authFetch } from '../../utils/api';

interface PersistedCustodyEvent {
  id: string;
  caseId: string;
  evidenceId?: string;
  eventNumber: number;
  title: string;
  actorRole: string;
  status: 'VERIFIED' | 'PENDING';
  timestamp: string;
  userName: string;
  ipAddress: string;
  digitalSignature: string;
  prevBlockHash?: string;
  blockHash: string;
  hashAtEvent?: string;
  details?: string;
}

interface ChainVerificationResult {
  valid: boolean;
  checkedCount: number;
  brokenAtEvent?: number;
  reason?: string;
}

interface ChainOfCustodyScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  selectedCaseId: string;
  currentUser: User;
}

export const ChainOfCustodyScreen: React.FC<ChainOfCustodyScreenProps> = ({
  setCurrentScreen,
  selectedCaseId
}) => {
  const [chainEvents, setChainEvents] = useState<PersistedCustodyEvent[]>([]);
  const [chainVerification, setChainVerification] = useState<ChainVerificationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copiedHashIndex, setCopiedHashIndex] = useState<number | null>(null);

  const loadCustodyEvents = useCallback(async () => {
    if (!selectedCaseId) {
      setChainEvents([]);
      setChainVerification(null);
      return;
    }
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const [eventsRes, verifyData] = await Promise.all([
        authFetch(`/api/cases/${encodeURIComponent(selectedCaseId)}/chain-of-custody`),
        api.verifyChainOfCustody(selectedCaseId).catch(() => null)
      ]);
      if (!eventsRes.ok) {
        const data = await eventsRes.json().catch(() => null);
        setErrorMsg(data?.error || `Failed to load chain of custody ledger (${eventsRes.status}).`);
        return;
      }
      const list = await eventsRes.json();
      setChainEvents(Array.isArray(list) ? list : []);
      if (verifyData && typeof verifyData.valid === 'boolean') {
        setChainVerification(verifyData);
      } else {
        setChainVerification(null);
      }
    } catch {
      setErrorMsg('Unable to retrieve immutable chain of custody events from forensic server.');
    } finally {
      setIsLoading(false);
    }
  }, [selectedCaseId]);

  useEffect(() => {
    loadCustodyEvents();
  }, [loadCustodyEvents]);

  const copyHash = (hash: string, idx: number) => {
    if (!hash) return;
    navigator.clipboard.writeText(hash);
    setCopiedHashIndex(idx);
    setTimeout(() => setCopiedHashIndex(null), 2000);
  };

  return (
    <div id="chain-of-custody-screen" className="p-4 sm:p-6 space-y-6 bg-[#F4F8F6] min-h-full text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-900/10 pb-5">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('evidence')} label="Back to Evidence" variant="pill" />
          </div>
          <div className="flex items-center space-x-2.5 flex-wrap gap-y-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 font-sans flex items-center space-x-2">
              <ShieldCheck className="w-6 h-6 text-emerald-700" />
              <span>Immutable Chain of Custody Ledger</span>
            </h1>
            <span className="text-xs font-mono font-bold text-emerald-900 bg-emerald-100 border border-emerald-300 px-3 py-1 rounded-full shadow-xs">
              DOCKET: {selectedCaseId || 'UNSELECTED'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            ISO/IEC 27037 append-only hash-linked & Ed25519-sealed custody ledger
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 px-3.5 py-1.5 bg-emerald-50 border border-emerald-300 rounded-xl text-emerald-950 shadow-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-700" />
            <span className="text-xs font-mono font-bold">
              {chainEvents.length} RECORDED EVENT{chainEvents.length === 1 ? '' : 'S'}
            </span>
          </div>
          <button
            onClick={loadCustodyEvents}
            disabled={isLoading}
            className="px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl flex items-center space-x-1.5 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
          <button
            onClick={() => setCurrentScreen('pipeline')}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-900/20 transition-all cursor-pointer"
          >
            <span>Run AI Pipeline →</span>
          </button>
        </div>
      </div>

      {/* Live Cryptographic Chain Verification Banner */}
      {selectedCaseId && chainVerification && (
        <div
          className={`max-w-5xl mx-auto p-4 rounded-2xl border-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-xs ${
            chainVerification.valid
              ? 'bg-emerald-50 border-emerald-400 text-emerald-950'
              : 'bg-rose-50 border-rose-500 text-rose-950'
          }`}
        >
          <div className="flex items-start space-x-3">
            {chainVerification.valid ? (
              <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
            ) : (
              <ShieldAlert className="w-5 h-5 text-rose-700 shrink-0 mt-0.5" />
            )}
            <div>
              <p className="font-bold uppercase tracking-wider">
                {chainVerification.valid
                  ? `Cryptographic Hash Chain Validated (${chainVerification.checkedCount} Block${chainVerification.checkedCount === 1 ? '' : 's'} Linked)`
                  : `TAMPER ALERT: Chain Integrity Broken at Event #${chainVerification.brokenAtEvent ?? 'Unknown'}`}
              </p>
              <p className="text-[11px] opacity-85 mt-0.5">
                {chainVerification.valid
                  ? 'Every custody block links deterministically to its predecessor hash and passes Ed25519 enclave signature verification.'
                  : chainVerification.reason || 'A block hash or digital signature failed cryptographic verification.'}
              </p>
            </div>
          </div>
          <span
            className={`text-[10px] font-mono font-bold px-2.5 py-1 rounded-full border shrink-0 self-start sm:self-center ${
              chainVerification.valid
                ? 'bg-emerald-100 border-emerald-300 text-emerald-900'
                : 'bg-rose-100 border-rose-300 text-rose-900'
            }`}
          >
            {chainVerification.valid ? 'LEDGER INTACT' : 'INTEGRITY VIOLATION'}
          </span>
        </div>
      )}

      {errorMsg && (
        <div className="p-3.5 bg-[#FEF2F2] border border-[#B91C1C]/30 text-[#B91C1C] text-xs rounded-2xl flex items-center space-x-2 font-medium max-w-5xl mx-auto">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Sequential Immutable Events Stream */}
      <div className="space-y-4 max-w-5xl mx-auto">
        {!selectedCaseId ? (
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-10 text-center space-y-2 shadow-sm">
            <FileText className="w-8 h-8 text-emerald-700 mx-auto opacity-60" />
            <p className="text-sm font-bold text-slate-900">No Active Case Docket Selected</p>
            <p className="text-xs text-slate-500">Select or create a forensic case docket first to inspect its custody events.</p>
          </div>
        ) : chainEvents.length === 0 ? (
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-10 text-center space-y-2 shadow-sm">
            <ShieldCheck className="w-8 h-8 text-emerald-700 mx-auto opacity-60" />
            <p className="text-sm font-bold text-slate-900">No Custody Events Recorded for {selectedCaseId}</p>
            <p className="text-xs text-slate-500">
              Custody events are automatically inscribed when evidence is uploaded, hash-verified, expert-certified, or legally reviewed.
            </p>
          </div>
        ) : (
          chainEvents.map((evt, idx) => (
            <div
              key={evt.id || evt.eventNumber}
              className="bg-white border border-emerald-900/10 hover:border-emerald-500/40 rounded-2xl p-5 space-y-4 shadow-sm transition-all"
            >
              {/* Top Event Title Bar */}
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex items-center space-x-3">
                  <div className="w-7 h-7 rounded-full bg-emerald-700 text-white font-mono font-bold text-xs flex items-center justify-center shadow-xs">
                    #{evt.eventNumber}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">{evt.title}</h3>
                    <span className="text-[10px] font-mono text-emerald-800 font-bold">
                      ACTOR ROLE: {evt.actorRole} {evt.id ? `· ID: ${evt.id}` : ''}
                    </span>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <span
                    className={`text-[10px] font-bold px-2.5 py-1 rounded-full border flex items-center space-x-1 ${
                      evt.status === 'VERIFIED'
                        ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                        : 'bg-[#FEF3C7] text-[#B2751E] border-[#C88A2C]/30'
                    }`}
                  >
                    <CheckCircle2 className="w-3 h-3" />
                    <span>{evt.status}</span>
                  </span>
                </div>
              </div>

              {/* Event Metadata */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase block">Case & Evidence</span>
                  <span className="font-mono text-emerald-900 font-bold block mt-0.5">{evt.caseId}</span>
                  <span className="text-[11px] text-slate-600 font-mono block">{evt.evidenceId || 'Case-Level Seal'}</span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase block">Timestamp (UTC)</span>
                  <span className="font-mono text-slate-700 flex items-center space-x-1 mt-0.5 font-medium">
                    <Clock className="w-3 h-3 text-emerald-700 shrink-0" />
                    <span>{evt.timestamp}</span>
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">IP: {evt.ipAddress}</span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase block">Recorded Operator</span>
                  <span className="font-bold text-emerald-950 flex items-center space-x-1 mt-0.5">
                    <UserIcon className="w-3 h-3 text-emerald-700 shrink-0" />
                    <span className="truncate">{evt.userName}</span>
                  </span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase block">Chain Linkage</span>
                  <span className="font-mono text-slate-700 font-bold block mt-0.5 truncate" title={evt.blockHash}>
                    {evt.blockHash}
                  </span>
                  {evt.prevBlockHash && (
                    <span className="text-[10px] font-mono text-slate-400 flex items-center space-x-1 truncate" title={evt.prevBlockHash}>
                      <Link2 className="w-3 h-3 shrink-0" />
                      <span className="truncate">Prev: {evt.prevBlockHash}</span>
                    </span>
                  )}
                </div>
              </div>

              {evt.details && (
                <p className="text-xs text-slate-600 bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 leading-relaxed">
                  {evt.details}
                </p>
              )}

              {/* SHA-256 & Digital Signature */}
              <div className="p-3 bg-[#032319] border border-emerald-950/20 rounded-xl space-y-1">
                <div className="flex justify-between items-center text-[10px] font-mono">
                  <span className="text-emerald-400 font-bold uppercase flex items-center space-x-1">
                    <Hash className="w-3.5 h-3.5 text-emerald-400" />
                    <span>EVIDENCE SHA-256 AT EVENT</span>
                  </span>
                  {evt.hashAtEvent && (
                    <button
                      type="button"
                      onClick={() => copyHash(evt.hashAtEvent!, idx)}
                      className="px-2 py-0.5 bg-emerald-800 hover:bg-emerald-700 text-white rounded text-[10px] flex items-center space-x-1 transition-colors cursor-pointer"
                    >
                      {copiedHashIndex === idx ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-300" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3 text-emerald-300" />
                          <span>Copy Full Hash</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
                <p className="font-mono text-emerald-300 text-xs break-all leading-relaxed pt-0.5 select-all">
                  {evt.hashAtEvent || evt.blockHash}
                </p>
                <div className="flex flex-wrap justify-between items-center gap-2 text-[10px] font-mono text-emerald-400/80 pt-1 border-t border-emerald-900/50">
                  <span className="break-all">DIGITAL SEAL: {evt.digitalSignature}</span>
                  <span className="text-emerald-300 font-bold shrink-0">BLOCK: {evt.blockHash}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
