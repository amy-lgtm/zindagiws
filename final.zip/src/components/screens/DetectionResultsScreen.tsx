import React, { useState, useEffect } from 'react';
import {
  Target,
  FileText,
  Sparkles,
  Clock,
  Cpu,
  Pause,
  Activity,
  CheckCircle2,
  Play,
  AlertTriangle
} from 'lucide-react';
import { ScreenId, AudioEvidence, User, F0AnalysisResult, DeepfakeAnalysisRecord } from '../../types';
import { speakAudioEvidence, stopAudioEvidence } from '../../utils/audioPlayer';
import { BackButton } from '../common/BackButton';
import { authFetch } from '../../utils/api';
import { analyzeAudioFileF0 } from '../../utils/pitchExtractor';

interface DetectionResultsScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  selectedCaseId: string;
  activeEvidence: AudioEvidence;
  setActiveEvidence?: (ev: AudioEvidence) => void;
  currentUser: User;
}

export const DetectionResultsScreen: React.FC<DetectionResultsScreenProps> = ({
  setCurrentScreen,
  selectedCaseId,
  activeEvidence,
  setActiveEvidence,
  currentUser
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [f0Result, setF0Result] = useState<F0AnalysisResult | null>(null);
  const [modelStatus, setModelStatus] = useState<Record<string, any> | null>(null);
  const [analyses, setAnalyses] = useState<DeepfakeAnalysisRecord[]>([]);
  const [caseEvidenceList, setCaseEvidenceList] = useState<AudioEvidence[]>([]);

  const targetCaseId = selectedCaseId || activeEvidence.caseId;

  useEffect(() => {
    let isMounted = true;

    async function loadF0() {
      if (activeEvidence.audioUrl) {
        try {
          const res = await analyzeAudioFileF0(activeEvidence.audioUrl);
          if (isMounted) setF0Result(res);
        } catch (err) {
          console.warn('Audio F0 analysis notice:', err);
        }
      } else {
        if (isMounted) setF0Result(null);
      }
    }

    async function loadModelStatus() {
      try {
        const res = await authFetch('/api/ai/models-status');
        if (res.ok) {
          const data = await res.json();
          if (isMounted) setModelStatus(data);
        }
      } catch (err) {
        console.warn('Model status fetch notice:', err);
      }
    }

    async function loadAnalyses() {
      if (!targetCaseId) {
        if (isMounted) setAnalyses([]);
        return;
      }
      try {
        const evFilter =
          activeEvidence?.id && activeEvidence.id !== 'EV-INIT'
            ? `?evidenceId=${encodeURIComponent(activeEvidence.id)}`
            : '';
        const [anRes, evRes] = await Promise.all([
          authFetch(`/api/cases/${encodeURIComponent(targetCaseId)}/analyses${evFilter}`),
          authFetch(`/api/cases/${encodeURIComponent(targetCaseId)}/evidence`)
        ]);
        if (anRes.ok) {
          const data = await anRes.json();
          if (isMounted && Array.isArray(data)) {
            setAnalyses(data);
          }
        }
        if (evRes.ok) {
          const evData = await evRes.json();
          if (isMounted && Array.isArray(evData)) {
            setCaseEvidenceList(evData);
          }
        }
      } catch (err) {
        console.warn('Analyses fetch notice:', err);
      }
    }

    loadF0();
    loadModelStatus();
    loadAnalyses();

    return () => {
      isMounted = false;
    };
  }, [activeEvidence, targetCaseId]);

  const handleTogglePlayAudio = () => {
    if (isPlayingAudio) {
      stopAudioEvidence();
      setIsPlayingAudio(false);
    } else {
      setIsPlayingAudio(true);
      speakAudioEvidence('Questioned audio evidence exhibit.', {
        audioUrl: activeEvidence.audioUrl,
        onEnd: () => setIsPlayingAudio(false)
      });
    }
  };

  const latestAnalysis =
    activeEvidence?.id && activeEvidence.id !== 'EV-INIT'
      ? analyses.find((a) => a.evidenceId === activeEvidence.id) || null
      : analyses[0] || null;

  const isPending =
    !latestAnalysis &&
    (!activeEvidence.classification ||
      activeEvidence.classification === 'Pending Analysis' ||
      activeEvidence.classification === 'Under Evaluation');

  const realAnomalies = f0Result?.irregularRegions || [];

  const bitstreamIntegrityLabel =
    activeEvidence.status === 'Failed'
      ? 'INTEGRITY FAILED'
      : activeEvidence.status === 'Verified'
      ? 'INTEGRITY VERIFIED'
      : activeEvidence.sha256Hash
      ? `${activeEvidence.status.toUpperCase()} (SHA-256 SEALED)`
      : 'UNHASHED';

  const metricsF0 =
    f0Result?.isAvailable && f0Result.avgF0 > 0
      ? `${f0Result.avgF0} Hz`
      : latestAnalysis?.pipelineMetrics?.f0MeanHz != null
      ? `${latestAnalysis.pipelineMetrics.f0MeanHz} Hz`
      : 'N/A (Audio unavailable)';

  const metricsJitter =
    f0Result?.isAvailable
      ? `${f0Result.jitterPercent}%`
      : latestAnalysis?.pipelineMetrics?.jitterPercent != null
      ? `${latestAnalysis.pipelineMetrics.jitterPercent}%`
      : 'Pending';

  const metricsVoicedOrHnr =
    f0Result?.isAvailable
      ? `Voiced: ${f0Result.voicedFraction}%`
      : latestAnalysis?.pipelineMetrics?.hnrDb != null
      ? `HNR: ${latestAnalysis.pipelineMetrics.hnrDb} dB`
      : 'Awaiting DSP';

  const verdictLabel =
    latestAnalysis?.verdict || activeEvidence.classification || 'INCONCLUSIVE';

  return (
    <div id="detection-results-screen" className="p-4 sm:p-6 space-y-6 bg-[#F4F8F6] min-h-full text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-900/10 pb-5">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('pipeline')} label="Back to Pipeline" variant="pill" />
          </div>
          <div className="flex items-center space-x-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 font-sans flex items-center space-x-2">
              <Target className="w-6 h-6 text-emerald-700" />
              <span>Multi-Model Detection Results</span>
            </h1>
            <span className="text-xs font-mono font-bold text-emerald-900 bg-emerald-100 border border-emerald-300 px-3 py-1 rounded-full shadow-xs">
              DOCKET: {targetCaseId || 'UNASSIGNED'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Forensic analysis summary & acoustic anomaly breakdown for <strong className="text-slate-800">{activeEvidence.filename}</strong>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {caseEvidenceList.length > 1 && setActiveEvidence && (
            <select
              value={activeEvidence.id}
              onChange={(e) => {
                const nextEv = caseEvidenceList.find((ev) => ev.id === e.target.value);
                if (nextEv) setActiveEvidence(nextEv);
              }}
              className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 shadow-xs cursor-pointer"
            >
              {caseEvidenceList.map((ev) => (
                <option key={ev.id} value={ev.id}>
                  {ev.id} — {ev.filename}
                </option>
              ))}
            </select>
          )}
          <button
            id="results-explain-btn"
            onClick={() => setCurrentScreen('xai')}
            className="px-4 py-2 bg-white hover:bg-emerald-50 border border-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center space-x-2 shadow-xs transition-all cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-emerald-700" />
            <span>Explain AI Reasoning (XAI)</span>
          </button>
          <button
            id="results-generate-report-btn"
            onClick={() => setCurrentScreen('report-generation')}
            className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-900/20 flex items-center space-x-2 transition-all cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>Generate Forensic Report</span>
          </button>
        </div>
      </div>

      {isPending ? (
        <div className="bg-white border border-emerald-900/10 rounded-2xl p-8 text-center space-y-4 shadow-sm">
          <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-800 flex items-center justify-center mx-auto border border-emerald-200">
            <Cpu className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h2 className="text-base font-bold text-slate-900">Awaiting AI Pipeline Execution</h2>
            <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
              Evidence exhibit <strong className="text-slate-800">{activeEvidence.filename}</strong> has not yet been processed by the forensic detection pipeline.
            </p>
          </div>
          <div className="flex items-center justify-center space-x-3 pt-2">
            <button
              onClick={() => setCurrentScreen('pipeline')}
              className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-900/20 flex items-center space-x-2 transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Execute AI Pipeline</span>
            </button>
            {activeEvidence.audioUrl && (
              <button
                onClick={handleTogglePlayAudio}
                className="px-4 py-2.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center space-x-2 transition-all cursor-pointer"
              >
                {isPlayingAudio ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{isPlayingAudio ? 'Pause Audio' : 'Listen to Evidence'}</span>
              </button>
            )}
          </div>
        </div>
      ) : (
        <>
          {/* Top 3 Score Cards Row */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div className="md:col-span-5 bg-white border border-emerald-900/10 rounded-2xl p-6 flex items-center justify-between shadow-sm relative overflow-hidden">
              <div className="space-y-2">
                <span className="text-[11px] font-bold uppercase text-slate-400 tracking-wider">
                  FORENSIC CLASSIFICATION
                </span>
                <div className="flex items-baseline space-x-2">
                  <span className="text-2xl font-extrabold text-slate-900 tracking-tight">
                    {verdictLabel}
                  </span>
                </div>
                <span className="text-xs font-bold text-slate-600 block">
                  {latestAnalysis?.overallConfidence != null
                    ? `Confidence: ${latestAnalysis.overallConfidence}%`
                    : 'Neural confidence: N/A (Human Expert Validation Required)'}
                </span>
              </div>

              {activeEvidence.audioUrl && (
                <button
                  onClick={handleTogglePlayAudio}
                  className="w-14 h-14 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white flex items-center justify-center shadow-md cursor-pointer transition-transform hover:scale-105 shrink-0"
                >
                  {isPlayingAudio ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-0.5" />}
                </button>
              )}
            </div>

            <div className="md:col-span-3 bg-white border border-emerald-900/10 rounded-2xl p-6 flex flex-col justify-between shadow-sm">
              <span className="text-[11px] font-bold uppercase text-slate-400 tracking-wider">
                EVIDENCE BITSTREAM STATUS
              </span>
              <div>
                <p
                  className={`text-sm font-bold font-mono ${
                    activeEvidence.status === 'Failed' ? 'text-rose-700' : 'text-emerald-800'
                  }`}
                >
                  {bitstreamIntegrityLabel}
                </p>
                <span className="text-[10px] text-slate-500 block mt-1 truncate">
                  SHA-256: {activeEvidence.sha256Hash ? `${activeEvidence.sha256Hash.slice(0, 16)}...` : 'Unavailable'}
                </span>
              </div>
            </div>

            <div className="md:col-span-4 bg-white border border-emerald-900/10 rounded-2xl p-6 flex flex-col justify-between shadow-sm">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] font-bold uppercase text-slate-400 tracking-wider">
                  DSP ACOUSTIC EXTRACTION
                </span>
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                  non-biometric measurement
                </span>
              </div>
              <div>
                <p className="text-base font-extrabold text-slate-900 font-mono">
                  F0 Mean: {metricsF0}
                </p>
                <span className="text-xs font-bold text-emerald-800 block mt-1">
                  Jitter: {metricsJitter} &bull; {metricsVoicedOrHnr}
                </span>
                {latestAnalysis?.nonBiometricProfile && (
                  <span className="text-[10px] font-mono text-slate-500 block mt-1">
                    VAD Active: {Math.round(latestAnalysis.nonBiometricProfile.vadActiveRatio * 100)}% ({latestAnalysis.nonBiometricProfile.vadSegmentCount} segs) · {latestAnalysis.nonBiometricProfile.mfccMean.length} MFCC
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="p-3.5 bg-white border-l-4 border-l-amber-500 border border-emerald-900/10 rounded-xl text-xs text-slate-700">
            <strong className="text-slate-900">Probabilistic Decision Support Notice:</strong> Algorithmic confidence scores and acoustic measurements assist qualified examiners and are never conclusive proof of authenticity, synthesis, or speaker identity.
          </div>

          {latestAnalysis?.note && (
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-900 flex items-start space-x-2.5">
              <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Objective Pipeline Notice ({latestAnalysis.analyzedAt})</p>
                <p className="text-[11px] mt-0.5 leading-relaxed">{latestAnalysis.note}</p>
              </div>
            </div>
          )}

          {/* Individual Architecture Model Verdicts */}
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4 shadow-sm">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 border-b border-slate-100 pb-3 flex items-center justify-between">
              <span>Model Architecture & Engine Status</span>
              <span className="text-xs text-slate-500 font-mono">SWGDE Forensic Validation</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {modelStatus ? (
                Object.entries(modelStatus).map(([key, item]: [string, any]) => {
                  const isAvailable = item.status === 'AVAILABLE';
                  const runEntry = latestAnalysis?.models?.find(
                    (m) => m.key === key || m.name.toLowerCase().includes(item.name.split(' ')[0].toLowerCase())
                  );
                  return (
                    <div key={key} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                      <span className="text-xs font-bold text-slate-900 block truncate" title={item.name}>
                        {item.name}
                      </span>
                      <div className="flex items-center justify-between">
                        <span
                          className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded border ${
                            isAvailable
                              ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                              : 'bg-amber-50 text-amber-800 border-amber-200'
                          }`}
                        >
                          {runEntry?.status || item.status}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-500 leading-snug">
                        {runEntry?.note || item.description}
                      </p>
                    </div>
                  );
                })
              ) : (
                <div className="col-span-full p-4 text-center text-xs text-slate-500">
                  Loading live enclave model status...
                </div>
              )}
            </div>
          </div>

          {/* Detected Acoustic & Spectral Anomalies Section */}
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 flex items-center space-x-2">
                  <Activity className="w-4 h-4 text-emerald-700" />
                  <span>Detected Acoustic & Spectral Discontinuities</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Physical pitch disruptions, flatline vocoder patterns, and laryngeal frequency irregularities
                </p>
              </div>
              <span className="text-xs font-mono font-bold text-slate-700 bg-slate-100 border border-slate-200 px-2.5 py-1 rounded-lg self-start sm:self-auto">
                {realAnomalies.length} DISCONTINUITIES IDENTIFIED
              </span>
            </div>

            {realAnomalies.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {realAnomalies.map((anom, idx) => (
                  <div
                    key={idx}
                    className="p-4 bg-[#032319] border border-emerald-950/20 rounded-2xl space-y-3 text-xs shadow-sm"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase block">
                          Acoustic Discontinuity
                        </span>
                        <h3 className="font-bold text-white text-sm">{anom.type}</h3>
                      </div>
                      <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded border uppercase bg-amber-900/90 text-amber-200 border-amber-500/50">
                        {anom.severity}
                      </span>
                    </div>

                    <p className="text-slate-300 text-[11px] leading-relaxed">
                      {anom.description}
                    </p>

                    <div className="pt-2 border-t border-emerald-900/60 flex items-center justify-between text-[10px] font-mono text-emerald-300">
                      <div className="flex items-center space-x-1.5">
                        <Clock className="w-3 h-3 text-emerald-400" />
                        <span>Location: <strong className="text-white">{anom.timeRange}</strong></span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 bg-slate-50 border border-dashed border-slate-200 rounded-xl text-center space-y-1">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 mx-auto" />
                <p className="text-xs font-bold text-slate-800">
                  {f0Result?.isAvailable
                    ? 'No Severe Pitch Discontinuities Detected in Decoded Audio'
                    : 'Acoustic Discontinuity Scan Requires Decodable Audio Stream'}
                </p>
                <p className="text-[11px] text-slate-500">
                  {f0Result?.isAvailable
                    ? 'Fundamental frequency tracking shows standard biological phonatory continuity across voiced speech frames.'
                    : f0Result?.unavailableReason || 'Select an audio exhibit with decodable PCM stream to inspect discontinuities.'}
                </p>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};
