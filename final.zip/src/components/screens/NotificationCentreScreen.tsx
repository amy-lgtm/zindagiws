import React from 'react';
import { Bell, AlertTriangle, CheckCircle2, Info, Check } from 'lucide-react';
import { ScreenId, NotificationItem, User } from '../../types';
import { BackButton } from '../common/BackButton';
import { authFetch } from '../../utils/api';
import { isScreenAllowed } from '../../utils/rbac';

interface NotificationCentreScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  notifications: NotificationItem[];
  setNotifications: React.Dispatch<React.SetStateAction<NotificationItem[]>>;
  setSelectedCaseId: (id: string) => void;
  currentUser: User;
}

export const NotificationCentreScreen: React.FC<NotificationCentreScreenProps> = ({
  setCurrentScreen,
  notifications,
  setNotifications,
  setSelectedCaseId,
  currentUser
}) => {
  const canInspectDetectionResults = isScreenAllowed(currentUser.role, 'detection-results');
  const canOpenAuditLog = isScreenAllowed(currentUser.role, 'audit-log');
  const markAllRead = async () => {
    setNotifications(notifications.map((n) => ({ ...n, read: true })));
    try {
      await authFetch('/api/notifications/read-all', { method: 'POST' });
    } catch {
      // ignore transient network errors
    }
  };

  const markSingleRead = async (id: string) => {
    setNotifications(
      notifications.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
    try {
      await authFetch(`/api/notifications/${encodeURIComponent(id)}/read`, { method: 'PATCH' });
    } catch {
      // ignore transient network errors
    }
  };

  const handleNotifClick = (n: NotificationItem) => {
    markSingleRead(n.id);
    if (n.title.toLowerCase().includes('registration') && isScreenAllowed(currentUser.role, 'admin-panel')) {
      setCurrentScreen('admin-panel');
    } else if (n.caseId && canInspectDetectionResults) {
      setSelectedCaseId(n.caseId);
      setCurrentScreen('detection-results');
    } else if (canOpenAuditLog) {
      setCurrentScreen('audit-log');
    }
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div id="notification-centre-screen" className="p-6 space-y-6 bg-[#F4F8F6] min-h-full text-slate-800">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-900/10 pb-5">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('dashboard')} label="Back to Dashboard" variant="pill" />
          </div>
          <div className="flex items-center space-x-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center space-x-2">
              <Bell className="w-6 h-6 text-emerald-700" />
              <span>Security Notification Centre</span>
            </h1>
            {unreadCount > 0 && (
              <span className="text-xs font-mono font-bold text-rose-800 bg-rose-100 border border-rose-300 px-2.5 py-0.5 rounded-full">
                {unreadCount} unread
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time security alerts, registration reviews, analysis completions, and case updates
          </p>
        </div>

        <button
          onClick={markAllRead}
          disabled={unreadCount === 0}
          className="px-4 py-2 bg-white hover:bg-emerald-50 disabled:opacity-50 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl flex items-center space-x-2 shadow-xs transition-all self-start sm:self-auto cursor-pointer"
        >
          <Check className="w-4 h-4 text-emerald-700" />
          <span>Mark All as Read</span>
        </button>
      </div>

      {/* Notification Cards List */}
      <div className="space-y-3 max-w-4xl mx-auto">
        {notifications.length === 0 ? (
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-10 text-center space-y-2 shadow-sm">
            <Bell className="w-8 h-8 text-emerald-700 mx-auto opacity-60" />
            <p className="text-sm font-bold text-slate-900">No Security Notifications</p>
            <p className="text-xs text-slate-500">
              System alerts, pending registration notices, and forensic pipeline updates will appear here.
            </p>
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              onClick={() => handleNotifClick(n)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start justify-between space-x-4 shadow-xs ${
                !n.read
                  ? 'bg-white border-l-4 border-l-emerald-600 border-emerald-900/10'
                  : 'bg-white/80 border-slate-200 opacity-80 hover:opacity-100'
              }`}
            >
              <div className="flex items-start space-x-3.5">
                <div
                  className={`p-2.5 rounded-xl mt-0.5 shrink-0 ${
                    n.severity === 'critical'
                      ? 'bg-rose-100 text-rose-700 border border-rose-200'
                      : n.severity === 'success'
                      ? 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                      : n.severity === 'warning'
                      ? 'bg-amber-100 text-amber-700 border border-amber-200'
                      : 'bg-sky-100 text-sky-700 border border-sky-200'
                  }`}
                >
                  {n.severity === 'critical' ? (
                    <AlertTriangle className="w-5 h-5" />
                  ) : n.severity === 'success' ? (
                    <CheckCircle2 className="w-5 h-5" />
                  ) : (
                    <Info className="w-5 h-5" />
                  )}
                </div>

                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <h3 className="text-xs font-bold text-slate-900">{n.title}</h3>
                    {n.caseId && (
                      <span className="text-[9px] font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        {n.caseId}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">{n.description}</p>
                  <span className="text-[10px] text-slate-400 font-mono block pt-1">{n.timestamp}</span>
                </div>
              </div>

              <div className="shrink-0">
                <span className="text-[10px] font-bold text-emerald-700 hover:text-emerald-800">
                  {n.caseId && canInspectDetectionResults
                    ? 'Inspect Case →'
                    : n.caseId && canOpenAuditLog
                    ? 'Audit Trail →'
                    : !n.read
                    ? 'Mark Read →'
                    : 'Read'}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
