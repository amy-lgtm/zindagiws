import React, { useState, useEffect } from 'react';
import {
  Settings,
  User as UserIcon,
  Lock,
  Shield,
  Bell,
  Sun,
  Moon,
  Monitor,
  HardDrive,
  CheckCircle2,
  Save,
  Info,
  Mail,
  KeyRound,
  Copy,
  AlertTriangle
} from 'lucide-react';
import { ScreenId, User } from '../../types';
import { ROLE_CONFIGS } from '../../utils/rbac';
import { playSuccessSound } from '../../utils/audioPlayer';
import { BackButton } from '../common/BackButton';
import { PasswordInput } from '../common/PasswordInput';
import { api } from '../../utils/api';

interface SettingsScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  currentUser: User;
  setCurrentUser: React.Dispatch<React.SetStateAction<User>>;
  initialTab?: 'Account' | '2FA' | 'Notifications' | 'Appearance' | 'Retention';
  forcedTwoFactorSetup?: boolean;
  onTwoFactorVerified?: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  setCurrentScreen,
  currentUser,
  setCurrentUser,
  initialTab = 'Account',
  forcedTwoFactorSetup = false,
  onTwoFactorVerified
}) => {
  const [activeTab, setActiveTab] = useState<'Account' | '2FA' | 'Notifications' | 'Appearance' | 'Retention'>(
    forcedTwoFactorSetup ? '2FA' : initialTab
  );

  // Account Profile State
  const [name, setName] = useState(currentUser.name);
  const [agency, setAgency] = useState(currentUser.agency);
  const [department, setDepartment] = useState(currentUser.department || '');
  const [phone, setPhone] = useState(currentUser.phone || '');
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');

  // Verified Email Change State
  const [newEmailInput, setNewEmailInput] = useState('');
  const [emailChangePassword, setEmailChangePassword] = useState('');
  const [emailChangePendingTarget, setEmailChangePendingTarget] = useState<string | null>(null);
  const [emailChangeCode, setEmailChangeCode] = useState('');

  // Real TOTP 2FA State hydrated from /api/settings/2fa/status
  const [twoFactorEnabled, setTwoFactorEnabled] = useState<boolean>(Boolean(currentUser.twoFactorEnabled));
  const [recoveryCodesRemaining, setRecoveryCodesRemaining] = useState<number>(0);
  const [smtpConfigured, setSmtpConfigured] = useState<boolean>(false);
  const [totpSetupData, setTotpSetupData] = useState<{ secret: string; otpauthUri: string } | null>(null);
  const [totpVerifyCode, setTotpVerifyCode] = useState('');
  const [copiedSecret, setCopiedSecret] = useState(false);
  const [revealedRecoveryCodes, setRevealedRecoveryCodes] = useState<string[] | null>(null);
  const [disablePassword, setDisablePassword] = useState('');
  const [disableTotpCode, setDisableTotpCode] = useState('');

  // Notifications State hydrated from server user preferences
  const [notifications, setNotifications] = useState({
    emailAlerts: currentUser.notificationPreferences?.emailAlerts ?? true,
    securityCritical: currentUser.notificationPreferences?.securityCritical ?? true,
    caseUpdates: currentUser.notificationPreferences?.caseUpdates ?? true,
    reportCertifications: currentUser.notificationPreferences?.reportCertifications ?? true,
    tamperAlerts: currentUser.notificationPreferences?.tamperAlerts ?? true
  });

  // Appearance State hydrated from server user preferences
  const [themeMode, setThemeMode] = useState<'system' | 'light' | 'dark'>(
    currentUser.themePreference || 'light'
  );

  // Retention Policy State hydrated from /api/admin/config
  const [retentionDaysEvidence, setRetentionDaysEvidence] = useState<number>(2555);
  const [retentionDaysLogs, setRetentionDaysLogs] = useState<number>(3650);

  const [isSaving, setIsSaving] = useState(false);
  const [savedBanner, setSavedBanner] = useState('');
  const [accountError, setAccountError] = useState<string | null>(null);

  const isAdmin = currentUser.role === 'System Security Administrator';
  const roleConfig = ROLE_CONFIGS[currentUser.role];

  useEffect(() => {
    setName(currentUser.name);
    setAgency(currentUser.agency);
    setDepartment(currentUser.department || '');
    setPhone(currentUser.phone || '');
    setTwoFactorEnabled(Boolean(currentUser.twoFactorEnabled));
    if (currentUser.themePreference) setThemeMode(currentUser.themePreference);
    if (currentUser.notificationPreferences) {
      setNotifications((prev) => ({ ...prev, ...currentUser.notificationPreferences }));
    }
  }, [currentUser]);

  useEffect(() => {
    if (forcedTwoFactorSetup && !twoFactorEnabled) {
      setActiveTab('2FA');
    }
  }, [forcedTwoFactorSetup, twoFactorEnabled]);

  const loadSecurityAndConfig = async () => {
    try {
      const [twoFa, cfg] = await Promise.all([
        api.get2faStatus().catch(() => null),
        api.getSystemConfig().catch(() => null)
      ]);
      if (twoFa) {
        setTwoFactorEnabled(Boolean(twoFa.enabled));
        setRecoveryCodesRemaining(Number(twoFa.recoveryCodesRemaining || 0));
        setSmtpConfigured(Boolean(twoFa.smtpConfigured));
      }
      if (cfg) {
        if (typeof cfg.retentionDaysEvidence === 'number') setRetentionDaysEvidence(cfg.retentionDaysEvidence);
        if (typeof cfg.retentionDaysLogs === 'number') setRetentionDaysLogs(cfg.retentionDaysLogs);
      }
    } catch {}
  };

  useEffect(() => {
    loadSecurityAndConfig();
  }, []);

  const triggerSaveNotification = (msg: string) => {
    playSuccessSound();
    setSavedBanner(msg);
    setTimeout(() => setSavedBanner(''), 4500);
  };

  const syncUser = (updatedUser: User) => {
    setCurrentUser(updatedUser);
    localStorage.setItem('deepfake_detector_user', JSON.stringify(updatedUser));
  };

  const handleSaveAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setAccountError(null);

    if (newPass) {
      if (!currentPass) {
        setAccountError('Current password is required to authorize password change.');
        return;
      }
      if (newPass !== confirmPass) {
        setAccountError('New password and confirm password do not match.');
        return;
      }
    }

    setIsSaving(true);
    try {
      const profileData = await api.updateProfile({ name, agency, department, phone });
      if (profileData?.user) syncUser(profileData.user);

      if (newPass) {
        await api.changePassword({ currentPassword: currentPass, newPassword: newPass });
        setCurrentPass('');
        setNewPass('');
        setConfirmPass('');
      }

      triggerSaveNotification(
        newPass
          ? 'Profile saved and password rotated securely (previous JWT sessions invalidated).'
          : 'Account profile information persisted to forensic directory.'
      );
    } catch (err: any) {
      setAccountError(err?.message || 'Unable to save profile updates.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleRequestEmailChange = async () => {
    setAccountError(null);
    if (!newEmailInput.trim() || !emailChangePassword) {
      setAccountError('Provide both new email address and current password.');
      return;
    }
    setIsSaving(true);
    try {
      const res = await api.requestEmailChange({
        newEmail: newEmailInput.trim(),
        currentPassword: emailChangePassword
      });
      setEmailChangePendingTarget(res.pendingEmail || newEmailInput.trim());
      setEmailChangePassword('');
      triggerSaveNotification(res.message || 'Verification code dispatched via SMTP.');
    } catch (err: any) {
      setAccountError(err?.message || 'Unable to send email verification code.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleConfirmEmailChange = async () => {
    setAccountError(null);
    if (!emailChangeCode.trim()) {
      setAccountError('Enter the verification code emailed to your new address.');
      return;
    }
    setIsSaving(true);
    try {
      const res = await api.confirmEmailChange(emailChangeCode.trim());
      if (res?.user) syncUser(res.user);
      setEmailChangePendingTarget(null);
      setNewEmailInput('');
      setEmailChangeCode('');
      triggerSaveNotification('Email updated and session token rotated.');
    } catch (err: any) {
      setAccountError(err?.message || 'Verification code rejected.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleStartTotpSetup = async () => {
    setAccountError(null);
    setRevealedRecoveryCodes(null);
    setIsSaving(true);
    try {
      const res = await api.setup2fa();
      setTotpSetupData({ secret: res.secret, otpauthUri: res.otpauthUri });
      setTotpVerifyCode('');
    } catch (err: any) {
      setAccountError(err?.message || 'Failed to generate TOTP secret.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleVerifyTotpSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setAccountError(null);
    setIsSaving(true);
    try {
      const res = await api.verify2faSetup(totpVerifyCode.trim());
      setTotpSetupData(null);
      setTotpVerifyCode('');
      setTwoFactorEnabled(true);
      if (Array.isArray(res?.recoveryCodes)) {
        setRevealedRecoveryCodes(res.recoveryCodes);
        setRecoveryCodesRemaining(res.recoveryCodes.length);
      }
      if (res?.user) syncUser(res.user);
      if (onTwoFactorVerified) onTwoFactorVerified();
      triggerSaveNotification('RFC 6238 TOTP Two-Factor Authentication enabled. Store your recovery codes safely.');
    } catch (err: any) {
      setAccountError(err?.message || 'Failed to verify 6-digit TOTP code.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDisableTotp = async (e: React.FormEvent) => {
    e.preventDefault();
    setAccountError(null);
    setIsSaving(true);
    try {
      const res = await api.disable2fa({
        currentPassword: disablePassword,
        totpCode: disableTotpCode.trim()
      });
      setTwoFactorEnabled(false);
      setRecoveryCodesRemaining(0);
      setDisablePassword('');
      setDisableTotpCode('');
      if (res?.user) syncUser(res.user);
      triggerSaveNotification('TOTP Two-Factor Authentication disabled for this account.');
    } catch (err: any) {
      setAccountError(err?.message || 'Unable to disable 2FA.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveNotifications = async (e: React.FormEvent) => {
    e.preventDefault();
    setAccountError(null);
    setIsSaving(true);
    try {
      const data = await api.updateProfile({ notificationPreferences: notifications });
      if (data?.user) syncUser(data.user);
      triggerSaveNotification('Notification & security alert routing saved to profile.');
    } catch (err: any) {
      setAccountError(err?.message || 'Failed to save notification preferences.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSelectTheme = async (pref: 'light' | 'dark' | 'system', title: string) => {
    setAccountError(null);
    setThemeMode(pref);
    syncUser({ ...currentUser, themePreference: pref });
    try {
      const data = await api.updateProfile({ themePreference: pref });
      if (data?.user) syncUser(data.user);
      triggerSaveNotification(`Appearance theme saved and applied: ${title}`);
    } catch (err: any) {
      setAccountError(err?.message || 'Failed to save theme preference to server.');
    }
  };

  const handleSaveRetention = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) {
      setAccountError('Only System Security Administrators may modify institutional retention windows.');
      return;
    }
    setAccountError(null);
    setIsSaving(true);
    try {
      await api.updateSystemConfig({ retentionDaysEvidence, retentionDaysLogs });
      triggerSaveNotification('Evidence and audit-log retention windows persisted and audited.');
    } catch (err: any) {
      setAccountError(err?.message || 'Failed to update retention policy.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div id="settings-screen" className="p-4 sm:p-6 space-y-6 bg-[#F4F8F6] min-h-full text-slate-800">
      <div className="border-b border-emerald-900/10 pb-5">
        {!forcedTwoFactorSetup && (
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('dashboard')} label="Back to Dashboard" variant="pill" />
          </div>
        )}
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center space-x-2 font-sans">
          <Settings className="w-6 h-6 text-emerald-700" />
          <span>Account & Platform Settings</span>
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Manage personal profile credentials, RFC 6238 TOTP two-factor authentication, notification routing, theme, and retention compliance
        </p>
      </div>

      {forcedTwoFactorSetup && !twoFactorEnabled && (
        <div className="max-w-4xl p-4 bg-[#FEF3C7] border border-[#C88A2C] rounded-2xl text-xs text-[#925E12] flex items-start space-x-2.5 shadow-sm">
          <Shield className="w-4 h-4 shrink-0 mt-0.5 text-[#B2751E]" />
          <div>
            <p className="font-bold">Mandatory Two-Factor Authentication Enrollment Required</p>
            <p className="mt-0.5">
              System security policy requires active TOTP two-factor authentication before accessing cases, evidence, or administration consoles. Complete TOTP enrollment below to unlock your session.
            </p>
          </div>
        </div>
      )}

      {savedBanner && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs rounded-xl flex items-center space-x-2 shadow-xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
          <span className="font-bold">{savedBanner}</span>
        </div>
      )}

      {accountError && (
        <div className="max-w-4xl p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{accountError}</span>
          </div>
          <button type="button" onClick={() => setAccountError(null)} className="text-red-700 font-bold ml-2 hover:underline cursor-pointer">
            Dismiss
          </button>
        </div>
      )}

      {/* Tabs Navigation */}
      <div className="flex items-center space-x-1.5 bg-white border border-emerald-900/10 p-1.5 rounded-2xl overflow-x-auto max-w-4xl shadow-sm">
        {[
          { id: 'Account', label: 'Account Profile', icon: UserIcon },
          { id: '2FA', label: 'Two-Factor Authentication', icon: Shield },
          { id: 'Notifications', label: 'Notifications & Alerts', icon: Bell },
          { id: 'Appearance', label: 'Appearance & Theme', icon: Sun },
          { id: 'Retention', label: 'Data Retention & Archival', icon: HardDrive }
        ].map((tab) => {
          const Icon = tab.icon;
          const lockedOut = forcedTwoFactorSetup && !twoFactorEnabled && tab.id !== '2FA';
          return (
            <button
              key={tab.id}
              type="button"
              disabled={lockedOut}
              onClick={() => {
                if (lockedOut) return;
                setAccountError(null);
                setActiveTab(tab.id as any);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 whitespace-nowrap cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
                activeTab === tab.id
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      <div className="max-w-4xl">
        {/* TAB 1: Account Profile */}
        {activeTab === 'Account' && (
          <div className="space-y-6">
            <form onSubmit={handleSaveAccount} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-6 shadow-sm">
              <div className="flex items-center space-x-4 border-b border-slate-100 pb-5">
                <div className="w-16 h-16 rounded-full bg-emerald-700 text-white font-extrabold text-xl flex items-center justify-center border-2 border-emerald-300 shadow-md">
                  {currentUser.avatar}
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">{currentUser.name}</h3>
                  <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border inline-block mt-1 ${roleConfig?.badgeBg} ${roleConfig?.badgeText} ${roleConfig?.badgeBorder}`}>
                    {currentUser.role}
                  </span>
                  <p className="text-xs text-slate-500 font-medium mt-1">
                    {currentUser.agency} {department ? `· ${department}` : ''}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block text-[11px] font-bold uppercase text-slate-500 mb-1">Full Legal Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 focus:outline-none focus:border-emerald-600 shadow-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase text-slate-500 mb-1">
                    Current Institutional Email
                  </label>
                  <input
                    type="email"
                    disabled
                    readOnly
                    value={currentUser.email}
                    className="w-full bg-slate-100 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-600 cursor-not-allowed shadow-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase text-slate-500 mb-1">Assigned Organization / Agency</label>
                  <input
                    type="text"
                    value={agency}
                    onChange={(e) => setAgency(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 focus:outline-none focus:border-emerald-600 shadow-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase text-slate-500 mb-1">Department / Unit</label>
                  <input
                    type="text"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    placeholder="e.g. Digital Multimedia Forensics"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 focus:outline-none focus:border-emerald-600 shadow-xs"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold uppercase text-slate-500 mb-1">Secure Direct Line / Phone (Optional)</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Not configured"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 focus:outline-none focus:border-emerald-600 shadow-xs"
                  />
                </div>
              </div>

              {/* Change Password Section */}
              <div className="border-t border-slate-100 pt-4 space-y-3 text-xs">
                <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
                  <Lock className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Change Password (12+ chars, Upper/Lower/Number/Special)</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-start">
                  <PasswordInput
                    id="settings-current-pass"
                    autoComplete="current-password"
                    placeholder="Current Password"
                    value={currentPass}
                    onChange={(e) => setCurrentPass(e.target.value)}
                    inputClassName="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-600"
                  />
                  <PasswordInput
                    id="settings-new-pass"
                    autoComplete="new-password"
                    placeholder="New Password"
                    value={newPass}
                    onChange={(e) => setNewPass(e.target.value)}
                    showStrengthChecklist={Boolean(newPass)}
                    emailForStrengthCheck={currentUser.email}
                    inputClassName="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-600"
                  />
                  <PasswordInput
                    id="settings-confirm-pass"
                    autoComplete="new-password"
                    placeholder="Confirm New Password"
                    value={confirmPass}
                    onChange={(e) => setConfirmPass(e.target.value)}
                    inputClassName="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-600"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-900/20 transition-all flex items-center space-x-1.5 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{isSaving ? 'Persisting...' : 'Save Account Profile'}</span>
                </button>
              </div>
            </form>

            {/* Verified Email Change Section */}
            <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4 shadow-sm text-xs">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h4 className="font-bold text-slate-900 flex items-center space-x-1.5">
                    <Mail className="w-4 h-4 text-emerald-700" />
                    <span>Verified Institutional Email Change</span>
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Requires password confirmation and live SMTP verification code dispatched to the new address.
                  </p>
                </div>
                <span
                  className={`font-mono text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                    smtpConfigured
                      ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                      : 'bg-amber-50 text-amber-800 border-amber-300'
                  }`}
                >
                  {smtpConfigured ? 'SMTP CONFIGURED' : 'SMTP NOT CONFIGURED'}
                </span>
              </div>

              {!emailChangePendingTarget ? (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <input
                    type="email"
                    autoComplete="email"
                    placeholder="New Institutional Email"
                    value={newEmailInput}
                    onChange={(e) => setNewEmailInput(e.target.value)}
                    className="bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-slate-900 font-mono"
                  />
                  <PasswordInput
                    id="settings-email-change-pw"
                    autoComplete="current-password"
                    placeholder="Confirm Current Password"
                    value={emailChangePassword}
                    onChange={(e) => setEmailChangePassword(e.target.value)}
                    inputClassName="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-600"
                  />
                  <button
                    type="button"
                    disabled={isSaving}
                    onClick={handleRequestEmailChange}
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold rounded-xl cursor-pointer"
                  >
                    Send Verification Code
                  </button>
                </div>
              ) : (
                <div className="flex flex-col sm:flex-row gap-3 items-center">
                  <span className="text-slate-600">
                    Enter 6-digit code sent to <strong>{emailChangePendingTarget}</strong>:
                  </span>
                  <input
                    type="text"
                    maxLength={6}
                    value={emailChangeCode}
                    onChange={(e) => setEmailChangeCode(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="6-digit code"
                    className="bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 font-mono text-slate-900"
                  />
                  <button
                    type="button"
                    disabled={isSaving}
                    onClick={handleConfirmEmailChange}
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl cursor-pointer"
                  >
                    Confirm New Email
                  </button>
                  <button
                    type="button"
                    onClick={() => setEmailChangePendingTarget(null)}
                    className="px-3 py-2 text-slate-500 hover:text-slate-800 font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: Real Two-Factor Authentication */}
        {activeTab === '2FA' && (
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-6 shadow-sm text-xs">
            <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">RFC 6238 TOTP Two-Factor Authentication</h3>
                <p className="text-slate-500 text-[11px] mt-0.5">
                  Real time-based one-time password enrollment encrypted at rest with AES-256-GCM
                </p>
              </div>
              <span
                className={`font-mono font-bold text-[10px] px-2.5 py-1 rounded-full border ${
                  twoFactorEnabled
                    ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                    : 'bg-amber-50 text-amber-800 border-amber-300'
                }`}
              >
                {twoFactorEnabled ? `ENABLED (${recoveryCodesRemaining} recovery codes left)` : 'NOT ENROLLED'}
              </span>
            </div>

            {revealedRecoveryCodes && (
              <div className="p-4 bg-[#FEF3C7] border border-[#C88A2C]/40 rounded-2xl space-y-2">
                <p className="font-bold text-[#925E12] flex items-center space-x-1.5">
                  <KeyRound className="w-4 h-4" />
                  <span>Save Your Single-Use Recovery Codes (Shown Once Only)</span>
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-[11px]">
                  {revealedRecoveryCodes.map((c) => (
                    <div key={c} className="bg-white/90 border border-[#C88A2C]/30 rounded-lg px-2.5 py-1.5 text-center font-bold text-[#112217]">
                      {c}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {!twoFactorEnabled && !totpSetupData && (
              <div className="p-5 bg-slate-50 border border-slate-200 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="font-bold text-slate-900 text-sm block">Enroll Authenticator App (TOTP)</span>
                  <p className="text-slate-600 text-xs">
                    Generates a real Base32 secret for Google Authenticator, Microsoft Authenticator, or 1Password.
                  </p>
                </div>
                <button
                  type="button"
                  disabled={isSaving}
                  onClick={handleStartTotpSetup}
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shrink-0 cursor-pointer"
                >
                  Begin TOTP Setup
                </button>
              </div>
            )}

            {totpSetupData && (
              <form onSubmit={handleVerifyTotpSetup} className="p-5 bg-emerald-50/70 border border-emerald-300 rounded-2xl space-y-4">
                <h4 className="font-bold text-slate-900 text-sm">Verify Authenticator App Enrollment</h4>
                <div className="space-y-2 bg-white p-4 rounded-xl border border-emerald-200">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase text-slate-500">Manual Base32 Secret</span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText(totpSetupData.secret).catch(() => undefined);
                        setCopiedSecret(true);
                        setTimeout(() => setCopiedSecret(false), 2500);
                      }}
                      className="text-[10px] font-bold text-emerald-700 flex items-center space-x-1 cursor-pointer"
                    >
                      <Copy className="w-3 h-3" />
                      <span>{copiedSecret ? 'Copied!' : 'Copy Secret'}</span>
                    </button>
                  </div>
                  <p className="font-mono text-sm font-bold text-slate-900 break-all">{totpSetupData.secret}</p>
                  <p className="text-[10px] font-mono text-slate-500 break-all">{totpSetupData.otpauthUri}</p>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 items-end">
                  <div className="flex-1">
                    <label className="text-[10px] font-bold uppercase text-slate-600 block mb-1">
                      Enter 6-Digit Code from Authenticator App
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={6}
                      value={totpVerifyCode}
                      onChange={(e) => setTotpVerifyCode(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="123456"
                      className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 font-mono text-slate-900"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl cursor-pointer"
                  >
                    Verify & Activate 2FA
                  </button>
                  <button
                    type="button"
                    onClick={() => setTotpSetupData(null)}
                    className="px-4 py-2.5 bg-white border border-slate-200 text-slate-600 font-bold rounded-xl cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}

            {twoFactorEnabled && (
              <form onSubmit={handleDisableTotp} className="p-5 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                <h4 className="font-bold text-slate-900">Disable TOTP Two-Factor Authentication</h4>
                <p className="text-[11px] text-slate-500">
                  Disabling TOTP requires both your current password and a valid TOTP or recovery code.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <PasswordInput
                    id="settings-disable-2fa-pw"
                    autoComplete="current-password"
                    required
                    value={disablePassword}
                    onChange={(e) => setDisablePassword(e.target.value)}
                    placeholder="Current Password"
                    inputClassName="w-full bg-white border border-slate-200 rounded-xl py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-600"
                  />
                  <input
                    type="text"
                    required
                    value={disableTotpCode}
                    onChange={(e) => setDisableTotpCode(e.target.value)}
                    placeholder="6-digit TOTP or Recovery Code"
                    className="bg-white border border-slate-200 rounded-xl px-3.5 py-2 font-mono text-slate-900"
                  />
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="px-4 py-2 bg-[#B91C1C] hover:bg-red-800 text-white font-bold rounded-xl cursor-pointer"
                  >
                    Disable TOTP 2FA
                  </button>
                </div>
              </form>
            )}

            {/* Honest status of non-integrated external 2FA channels */}
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <span className="text-[10px] font-bold uppercase text-slate-400 block">Alternative Hardware / Telecom Channels</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 opacity-75 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800">FIDO2 / WebAuthn Security Key</span>
                    <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-slate-200 text-slate-700">NOT CONFIGURED</span>
                  </div>
                  <p className="text-[10px] text-slate-500">Server-side WebAuthn RP attestation ceremony is not provisioned.</p>
                </div>
                <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 opacity-75 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800">SMS / Telecom OTP Gateway</span>
                    <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-slate-200 text-slate-700">NOT CONFIGURED</span>
                  </div>
                  <p className="text-[10px] text-slate-500">External SMS gateway provider credentials are not configured.</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: Notifications */}
        {activeTab === 'Notifications' && (
          <form onSubmit={handleSaveNotifications} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-6 shadow-sm text-xs">
            <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Notification & Security Alert Routing</h3>
                <p className="text-slate-500 text-[11px] mt-0.5">
                  Configure in-enclave alerts and SMTP dispatch eligibility
                </p>
              </div>
              <span
                className={`text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full border ${
                  smtpConfigured
                    ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                    : 'bg-amber-50 text-amber-800 border-amber-300'
                }`}
              >
                {smtpConfigured ? 'SMTP EMAIL READY' : 'IN-APP ONLY (SMTP NOT CONFIGURED)'}
              </span>
            </div>

            <div className="space-y-3">
              {[
                { key: 'emailAlerts', title: 'Institutional Email Notifications', desc: 'Dispatch eligible approval and case alerts when SMTP is configured.' },
                { key: 'securityCritical', title: 'Critical Security & Lockout Alerts', desc: 'Alert on failed-login lockouts and session security events.' },
                { key: 'caseUpdates', title: 'Evidence Ingestion & Analysis Alerts', desc: 'Notify when forensic evidence or acoustic processing updates occur.' },
                { key: 'reportCertifications', title: 'Expert Witness & Legal Seals', desc: 'Notify when authorized examiners sign off on evidentiary reports.' },
                { key: 'tamperAlerts', title: 'Tamper & Hash Inconsistency Warning', desc: 'Immediate critical alert if any live SHA-256 evidence checksum mismatches.' }
              ].map((item) => (
                <div key={item.key} className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-900 block text-xs">{item.title}</span>
                    <span className="text-[11px] text-slate-500">{item.desc}</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={(notifications as any)[item.key]}
                      onChange={(e) => setNotifications({ ...notifications, [item.key]: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-700"></div>
                  </label>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                disabled={isSaving}
                className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-900/20 transition-all flex items-center space-x-1.5 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Saving...' : 'Save Notification Settings'}</span>
              </button>
            </div>
          </form>
        )}

        {/* TAB 4: Appearance & Theme */}
        {activeTab === 'Appearance' && (
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-6 shadow-sm text-xs">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="text-sm font-bold text-slate-900">Enclave Theme Appearance (Persisted)</h3>
              <p className="text-slate-500 text-[11px] mt-0.5">
                Light theme remains visually identical to the national green & white specification; Dark and System follow your preference persistently.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { id: 'light', title: 'National White & Green (Default)', desc: 'High-contrast emerald & white canvas optimized for court presentation.', icon: Sun },
                { id: 'dark', title: 'Forensic Lab Dark Mode', desc: 'Dark emerald canvas for low-light audio laboratory environments.', icon: Moon },
                { id: 'system', title: 'Follow System Settings', desc: 'Automatically adapt to operating system color-scheme preference.', icon: Monitor }
              ].map((t) => (
                <button
                  type="button"
                  key={t.id}
                  onClick={() => handleSelectTheme(t.id as any, t.title)}
                  className={`text-left p-4 rounded-2xl border cursor-pointer transition-all space-y-2 ${
                    themeMode === t.id
                      ? 'bg-emerald-50 border-emerald-500 shadow-sm text-slate-900'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-emerald-300'
                  }`}
                >
                  <div className="w-8 h-8 rounded-xl bg-emerald-700 text-white flex items-center justify-center">
                    <t.icon className="w-4 h-4" />
                  </div>
                  <span className="font-bold text-xs block">{t.title}</span>
                  <p className="text-[10px] text-slate-500 leading-normal">{t.desc}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: Data Retention & Archival Policy */}
        {activeTab === 'Retention' && (
          <form onSubmit={handleSaveRetention} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-6 shadow-sm text-xs">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="text-sm font-bold text-slate-900">Evidence & Audit-Log Retention Policies</h3>
              <p className="text-slate-500 text-[11px] mt-0.5">
                ISO/IEC 27037 Digital Evidence Handling and CJIS Security Policy 5.9 Retention Schedules
              </p>
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-1 text-emerald-950">
                <div className="flex items-center space-x-2 font-bold text-xs">
                  <Info className="w-4 h-4 text-emerald-700" />
                  <span>Statutory Retention Compliance Notice</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Under Federal Criminal Procedure Rule 16 and SWGDE recommendations, audio deepfake evidentiary recordings and cryptographic hash ledgers must be retained until final disposition of judicial proceedings plus appellate period.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase text-slate-500 mb-1">Evidence Retention Window (Days)</label>
                  <select
                    disabled={!isAdmin}
                    value={String(retentionDaysEvidence)}
                    onChange={(e) => setRetentionDaysEvidence(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:outline-none focus:border-emerald-600 disabled:opacity-60"
                  >
                    {[1825, 2555, 3650].includes(retentionDaysEvidence) ? null : (
                      <option value={String(retentionDaysEvidence)}>
                        Custom Policy ({retentionDaysEvidence.toLocaleString()} Days)
                      </option>
                    )}
                    <option value="1825">5 Years (1,825 Days — Standard Misdemeanor)</option>
                    <option value="2555">7 Years (2,555 Days — Federal Felony Standard)</option>
                    <option value="3650">10 Years (3,650 Days — National Security)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase text-slate-500 mb-1">Audit-Log Retention Policy (Days)</label>
                  <select
                    disabled={!isAdmin}
                    value={String(retentionDaysLogs)}
                    onChange={(e) => setRetentionDaysLogs(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:outline-none focus:border-emerald-600 disabled:opacity-60"
                  >
                    {[3650, 7300].includes(retentionDaysLogs) ? null : (
                      <option value={String(retentionDaysLogs)}>
                        Custom Policy ({retentionDaysLogs.toLocaleString()} Days)
                      </option>
                    )}
                    <option value="3650">10 Years Immutable (3,650 Days)</option>
                    <option value="7300">20 Years WORM Archival (7,300 Days)</option>
                  </select>
                </div>
              </div>

              {!isAdmin && (
                <p className="text-[11px] text-amber-800 bg-amber-50 border border-amber-200 rounded-xl p-3 font-medium">
                  Read-Only: Only the System Security Administrator can alter institutional evidence and audit retention windows.
                </p>
              )}
            </div>

            {isAdmin && (
              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-900/20 transition-all flex items-center space-x-1.5 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{isSaving ? 'Saving...' : 'Save Retention Policies'}</span>
                </button>
              </div>
            )}
          </form>
        )}
      </div>
    </div>
  );
};
