import React, { useState, useEffect } from 'react';
import {
  Activity,
  AlertTriangle,
  Play,
  Pause,
  Scale,
  RefreshCw,
  Sparkles,
  FolderKanban,
  BarChart3,
  FileAudio,
  FileText
} from 'lucide-react';
import {
  ScreenId,
  User,
  AudioEvidence,
  Case,
  F0AnalysisResult,
  ReferenceVoiceSample,
  VoiceDisguiseAnalysisResult
} from '../../types';
import { BackButton } from '../common/BackButton';
import { authFetch } from '../../utils/api';
import { analyzeAudioFileF0 } from '../../utils/pitchExtractor';
import { speakAudioEvidence, stopAudioEvidence } from '../../utils/audioPlayer';

interface VoiceDisguiseScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  selectedCaseId: string;
  activeEvidence: AudioEvidence;
  currentUser: User;
  cases?: Case[];
}

export const VoiceDisguiseScreen: React.FC<VoiceDisguiseScreenProps> = ({
  setCurrentScreen,
  selectedCaseId,
  activeEvidence,
  cases = []
}) => {
  const [activeCaseId, setActiveCaseId] = useState<string>(selectedCaseId || cases[0]?.id || '');
  const [caseEvidenceList, setCaseEvidenceList] = useState<AudioEvidence[]>([]);
  const [selectedEvidenceId, setSelectedEvidenceId] = useState<string>(
    activeEvidence?.id && activeEvidence.id !== 'EV-INIT' ? activeEvidence.id : ''
  );
  const [referenceList, setReferenceList] = useState<ReferenceVoiceSample[]>([]);
  const [selectedReferenceId, setSelectedReferenceId] = useState<string>('');
  const [expertNotes, setExpertNotes] = useState<string>('');

  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [, setF0Data] = useState<F0AnalysisResult | null>(null);
  const [analysisResult, setAnalysisResult] = useState<VoiceDisguiseAnalysisResult | null>(null);
  const [pastAnalyses, setPastAnalyses] = useState<VoiceDisguiseAnalysisResult[]>([]);

  useEffect(() => {
    if (selectedCaseId) {
      setActiveCaseId(selectedCaseId);
    }
  }, [selectedCaseId]);

  useEffect(() => {
    if (!activeCaseId) return;

    let cancelled = false;
    async function loadCaseData() {
      try {
        const [evRes, refRes, disRes] = await Promise.all([
          authFetch(`/api/cases/${activeCaseId}/evidence`),
          authFetch(`/api/cases/${activeCaseId}/references`),
          authFetch(`/api/cases/${activeCaseId}/voice-disguise`)
        ]);

        if (cancelled) return;

        if (evRes.ok) {
          const evList: AudioEvidence[] = await evRes.json();
          if (Array.isArray(evList)) {
            setCaseEvidenceList(evList);
            const resolvedEvId =
              selectedEvidenceId && evList.some((e) => e.id === selectedEvidenceId)
                ? selectedEvidenceId
                : evList[0]?.id || '';
            setSelectedEvidenceId(resolvedEvId);

            if (disRes.ok) {
              const analyses: VoiceDisguiseAnalysisResult[] = await disRes.json();
              if (Array.isArray(analyses)) {
                setPastAnalyses(analyses);
                setAnalysisResult(
                  resolvedEvId ? analyses.find((a) => a.evidenceId === resolvedEvId) || null : null
                );
              }
            }
          }
        } else if (disRes.ok) {
          const analyses: VoiceDisguiseAnalysisResult[] = await disRes.json();
          if (Array.isArray(analyses)) {
            setPastAnalyses(analyses);
            setAnalysisResult(null);
          }
        }

        if (refRes.ok) {
          const refs: ReferenceVoiceSample[] = await refRes.json();
          if (Array.isArray(refs)) {
            setReferenceList(refs);
          }
        }
      } catch (err) {
        console.warn('Voice disguise screen data sync note:', err);
      }
    }

    loadCaseData();
    return () => {
      cancelled = true;
    };
  }, [activeCaseId]);

  // Keep analysisResult strictly aligned with the selected exhibit
  useEffect(() => {
    if (!selectedEvidenceId) {
      setAnalysisResult(null);
      return;
    }
    const matching = pastAnalyses.find((a) => a.evidenceId === selectedEvidenceId) || null;
    setAnalysisResult(matching);
  }, [selectedEvidenceId, pastAnalyses]);

  const selectedEvidence =
    caseEvidenceList.find((e) => e.id === selectedEvidenceId) ||
    (activeEvidence?.id && activeEvidence.id !== 'EV-INIT' ? activeEvidence : null);

  const handleRunAnalysis = async () => {
    if (!selectedEvidence) {
      setActionError('Please select an audio evidence file to inspect.');
      return;
    }
    if (!activeCaseId) {
      setActionError('Please select a case docket first.');
      return;
    }

    setActionError(null);
    setIsAnalyzing(true);
    setAnalysisResult(null);

    try {
      if (selectedEvidence.audioUrl) {
        const f0Res = await analyzeAudioFileF0(selectedEvidence.audioUrl);
        setF0Data(f0Res);
      }

      const res = await authFetch('/api/voice-analysis/condition', {
        method: 'POST',
        body: JSON.stringify({
          caseId: activeCaseId,
          evidenceId: selectedEvidence.id,
          referenceId: selectedReferenceId || undefined,
          expertNotes: expertNotes.trim() || undefined
        })
      });

      if (res.ok) {
        const data: VoiceDisguiseAnalysisResult = await res.json();
        setAnalysisResult(data);
        setPastAnalyses((prev) => [data, ...prev.filter((p) => p.id !== data.id)]);
      } else {
        const err = await res.json().catch(() => null);
        setActionError(err?.error || 'Voice condition analysis failed.');
      }
    } catch {
      setActionError('Network error connecting to voice condition analysis server.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleTogglePlay = () => {
    if (isPlayingAudio) {
      stopAudioEvidence();
      setIsPlayingAudio(false);
    } else {
      setIsPlayingAudio(true);
      speakAudioEvidence('Questioned voice audio segment for condition and disguise evaluation.', {
        audioUrl: selectedEvidence?.audioUrl,
        onEnd: () => setIsPlayingAudio(false)
      });
    }
  };

  const m = analysisResult?.acousticMeasurements;

  return (
    <div id="voice-disguise-screen" className="p-4 sm:p-6 space-y-6 bg-[#F8FAF9] min-h-full text-[#112217]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E1EBE4] pb-5">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <BackButton onClick={() => setCurrentScreen('evidence')} label="Back to Evidence" variant="pill" />
          </div>
          <div className="flex items-center space-x-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-[#112217] font-serif-title flex items-center space-x-2">
              <Activity className="w-6 h-6 text-[#0A3D24]" />
              <span>Voice Condition & Disguise Analysis</span>
            </h1>
            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full border bg-[#FEF3C7] text-[#B2751E] border-[#C88A2C]/30 font-mono">
              SWGDE / FRE 702
            </span>
          </div>
          <p className="text-xs text-[#54665C] mt-1">
            Multi-hypothesis forensic examination distinguishing acute vocal strain, intentional physical disguise, and AI vocoder manipulation.
          </p>
        </div>

        {/* Case Selector */}
        <div className="flex items-center space-x-2">
          <FolderKanban className="w-4 h-4 text-[#0A3D24]" />
          <select
            value={activeCaseId}
            onChange={(e) => setActiveCaseId(e.target.value)}
            className="px-3 py-1.5 bg-white border border-[#E1EBE4] rounded-xl text-xs font-bold text-[#112217] shadow-xs cursor-pointer focus:outline-hidden"
          >
            {cases.length === 0 ? (
              <option value="">No Cases Enrolled</option>
            ) : (
              cases.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.id} — {c.title.slice(0, 32)}
                </option>
              ))
            )}
          </select>
        </div>
      </div>

      {/* Action Error Banner */}
      {actionError && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-2xl flex items-center justify-between text-xs text-red-800 shadow-xs">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            <span className="font-medium">{actionError}</span>
          </div>
          <button
            onClick={() => setActionError(null)}
            className="text-red-700 hover:text-red-900 font-bold ml-3 px-2 py-0.5 rounded-md hover:bg-red-100 transition-colors cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Forensic Framework Explanation Card */}
      <div className="p-4 bg-white border-l-4 border-l-[#C88A2C] border border-[#E1EBE4] rounded-2xl flex items-start space-x-3 text-xs shadow-xs">
        <Scale className="w-5 h-5 text-[#C88A2C] shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="text-[#112217] font-bold">Multi-Hypothesis Acoustic Differential Protocol</p>
          <p className="text-[#54665C] leading-relaxed">
            Per forensic acoustics methodology, abnormal vocal patterns should not be assumed to indicate intentional deception or synthesis without evaluating competing physical explanations. This module inspects genuine fundamental frequency perturbations, harmonic-to-noise ratio, spectral roll-off, and optional baseline reference comparisons against 5 competing hypotheses.
          </p>
        </div>
      </div>

      {/* Evidence & Reference Selection Card */}
      <div className="bg-white border border-[#E1EBE4] rounded-2xl p-5 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E1EBE4] pb-3">
          <div>
            <h3 className="text-sm font-bold text-[#112217] font-serif-title">
              Target Evidence & Baseline Exemplar
            </h3>
            <p className="text-xs text-[#54665C]">
              Select the audio exhibit (and optional reference exemplar) to submit for genuine DSP analysis
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {caseEvidenceList.length > 0 && (
              <select
                value={selectedEvidenceId}
                onChange={(e) => setSelectedEvidenceId(e.target.value)}
                className="px-3 py-1.5 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl text-xs font-bold text-[#112217] cursor-pointer"
              >
                {caseEvidenceList.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.id} — {e.filename}
                  </option>
                ))}
              </select>
            )}

            <select
              value={selectedReferenceId}
              onChange={(e) => setSelectedReferenceId(e.target.value)}
              className="px-3 py-1.5 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl text-xs font-bold text-[#112217] cursor-pointer"
            >
              <option value="">No Baseline Reference (Single-Recording)</option>
              {referenceList.map((r) => (
                <option key={r.id} value={r.id}>
                  Ref: {r.subjectName} ({r.conditionTag})
                </option>
              ))}
            </select>
          </div>
        </div>

        {selectedEvidence ? (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <FileAudio className="w-4 h-4 text-[#0A3D24]" />
                  <span className="font-bold text-xs text-[#112217]">{selectedEvidence.filename}</span>
                  <span className="text-[10px] font-mono text-[#0A3D24] bg-[#F0FDF4] px-2 py-0.5 rounded border border-[#E1EBE4]">
                    {selectedEvidence.id}
                  </span>
                </div>
                <div className="flex items-center space-x-4 text-[11px] text-[#54665C]">
                  <span>Duration: <strong>{selectedEvidence.duration}</strong></span>
                  <span>Sample Rate: <strong>{selectedEvidence.sampleRate}</strong></span>
                  <span>Channels: <strong>{selectedEvidence.channels}</strong></span>
                </div>
              </div>

              <div className="flex items-center space-x-3 shrink-0">
                <button
                  onClick={handleTogglePlay}
                  className="px-4 py-2 bg-[#0A3D24] hover:bg-[#062817] text-white text-xs font-bold rounded-xl flex items-center space-x-2 cursor-pointer shadow-xs transition-all"
                >
                  {isPlayingAudio ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{isPlayingAudio ? 'Pause Audio' : 'Play Audio'}</span>
                </button>

                <button
                  id="run-voice-disguise-analysis-btn"
                  onClick={handleRunAnalysis}
                  disabled={isAnalyzing}
                  className="px-5 py-2 bg-[#C88A2C] hover:bg-[#B2751E] disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center space-x-2 cursor-pointer shadow-md transition-all"
                >
                  {isAnalyzing ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Analyzing...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Run Multi-Hypothesis Analysis</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase text-[#54665C] flex items-center space-x-1">
                <FileText className="w-3 h-3" />
                <span>Examiner Contextual Notes (Optional)</span>
              </label>
              <input
                type="text"
                value={expertNotes}
                onChange={(e) => setExpertNotes(e.target.value)}
                placeholder="e.g. Subject reported upper respiratory congestion; recorded over cellular channel..."
                className="w-full px-3 py-2 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl text-xs text-[#112217] focus:outline-hidden focus:border-[#0A3D24]"
              />
            </div>
          </div>
        ) : (
          <div className="p-6 bg-[#F8FAF9] border border-dashed border-[#E1EBE4] rounded-xl text-center space-y-2">
            <AlertTriangle className="w-6 h-6 text-[#D97706] mx-auto" />
            <p className="text-xs font-bold text-[#112217]">No Audio Evidence Selected</p>
            <p className="text-[11px] text-[#54665C]">
              Upload audio evidence in Evidence Management to evaluate voice conditions and potential disguise.
            </p>
            <button
              onClick={() => setCurrentScreen('evidence')}
              className="mt-2 px-3.5 py-1.5 bg-[#0A3D24] text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
            >
              Go to Evidence Locker
            </button>
          </div>
        )}
      </div>

      {/* Analysis Results View */}
      {analysisResult && m && (
        <div className="space-y-6">
          {/* Summary Banner */}
          <div className="bg-white border border-[#E1EBE4] rounded-2xl p-5 space-y-3 shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#0A3D24] font-bold">
                FORENSIC EXAMINATION SUMMARY
              </span>
              <span
                className={`text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full border ${
                  analysisResult.audioQualityStatus === 'Sufficient for analysis'
                    ? 'bg-[#F0FDF4] text-[#15803D] border-[#15803D]/20'
                    : analysisResult.audioQualityStatus === 'Marginal'
                    ? 'bg-amber-50 text-amber-800 border-amber-300'
                    : 'bg-red-50 text-red-700 border-red-200'
                }`}
              >
                {analysisResult.audioQualityStatus}
              </span>
            </div>
            <p className="text-xs text-[#112217] leading-relaxed">{analysisResult.overallSummary}</p>
            {analysisResult.referenceFilename && (
              <p className="text-[11px] font-mono text-[#0A3D24]">
                Baseline Reference Compared: <strong>{analysisResult.referenceFilename}</strong>
              </p>
            )}
          </div>

          {/* Physical Acoustic Measurements Table */}
          <div className="bg-white border border-[#E1EBE4] rounded-2xl p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-[#E1EBE4] pb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#112217] flex items-center space-x-1.5">
                <BarChart3 className="w-4 h-4 text-[#0A3D24]" />
                <span>Extracted Physical Speech Parameters</span>
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#F0FDF4] text-[#0A3D24] border border-[#15803D]/20">
                non-biometric measurement (Server DSP)
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
              <div className="p-3 bg-[#F8FAF9] rounded-xl border border-[#E1EBE4] space-y-1">
                <span className="text-[10px] text-[#54665C] block uppercase font-sans">Mean Pitch (F0)</span>
                <span className="text-base font-black text-[#112217]">{m.f0MeanHz} Hz</span>
                <span className="text-[10px] text-[#54665C] block font-sans">
                  Range: {m.f0MinHz} - {m.f0MaxHz} Hz
                </span>
              </div>

              <div className="p-3 bg-[#F8FAF9] rounded-xl border border-[#E1EBE4] space-y-1">
                <span className="text-[10px] text-[#54665C] block uppercase font-sans">Jitter / Shimmer</span>
                <span className="text-base font-black text-[#112217]">{m.jitterPercent}%</span>
                <span className="text-[10px] text-[#54665C] block font-sans">
                  Shimmer: {m.shimmerPercent}% | HNR: {m.hnrDb} dB
                </span>
              </div>

              <div className="p-3 bg-[#F8FAF9] rounded-xl border border-[#E1EBE4] space-y-1">
                <span className="text-[10px] text-[#54665C] block uppercase font-sans">Voiced Fraction</span>
                <span className="text-base font-black text-[#112217]">{m.voicedFractionPercent}%</span>
                <span className="text-[10px] text-[#54665C] block font-sans">
                  Voiced Duration: {m.speechDurationSec}s
                </span>
              </div>

              <div className="p-3 bg-[#F8FAF9] rounded-xl border border-[#E1EBE4] space-y-1">
                <span className="text-[10px] text-[#54665C] block uppercase font-sans">Upper Rolloff Cutoff</span>
                <span className="text-base font-black text-[#112217]">
                  {(m.spectralRollOffHz / 1000).toFixed(1)} kHz
                </span>
                <span className="text-[10px] text-[#54665C] block font-sans">
                  Centroid: {m.spectralCentroidHz} Hz | SNR: {m.estimatedSnrDb} dB
                </span>
              </div>
            </div>
          </div>

          {/* 5-Hypothesis Comparative Evaluation Matrix */}
          <div className="bg-white border border-[#E1EBE4] rounded-2xl p-5 space-y-4 shadow-xs">
            <div>
              <h3 className="text-sm font-bold text-[#112217] font-serif-title flex items-center space-x-2">
                <Scale className="w-4 h-4 text-[#0A3D24]" />
                <span>5-Hypothesis Forensic Evaluation Matrix</span>
              </h3>
              <p className="text-xs text-[#54665C]">
                Objective assessment against competing physiological, environmental, and synthetic hypotheses
              </p>
            </div>

            <div className="space-y-3">
              {analysisResult.hypotheses.map((hyp, idx) => {
                const isSupported = hyp.likelihood === 'Supported by acoustic data';
                const isInconclusive = hyp.likelihood === 'Inconclusive';
                const isContraindicated = hyp.likelihood === 'Contraindicated';

                return (
                  <div
                    key={idx}
                    className={`p-4 rounded-xl border transition-all ${
                      isSupported
                        ? 'bg-[#FFFBEB] border-amber-300'
                        : isInconclusive
                        ? 'bg-slate-50 border-slate-300'
                        : isContraindicated
                        ? 'bg-[#F0FDF4]/60 border-emerald-200'
                        : 'bg-[#F8FAF9] border-[#E1EBE4]'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-mono font-bold text-[#54665C]">H{idx + 1}.</span>
                        <h4 className="text-xs font-bold text-[#112217]">{hyp.hypothesis}</h4>
                      </div>
                      <span
                        className={`text-[10px] font-bold font-mono px-2.5 py-0.5 rounded-full border shrink-0 ${
                          isSupported
                            ? 'bg-[#C88A2C] text-white border-[#C88A2C]'
                            : isInconclusive
                            ? 'bg-slate-700 text-white border-slate-700'
                            : isContraindicated
                            ? 'bg-[#0A3D24] text-white border-[#0A3D24]'
                            : 'bg-slate-200 text-slate-700 border-slate-300'
                        }`}
                      >
                        {hyp.likelihood}
                      </span>
                    </div>

                    <p className="text-xs text-[#54665C] leading-relaxed mb-2.5">{hyp.findings}</p>

                    <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
                      <span className="text-[#54665C] font-bold">Observed Indicators:</span>
                      {hyp.supportingFeatures.map((feat, fIdx) => (
                        <span
                          key={fIdx}
                          className="bg-white text-[#112217] px-2 py-0.5 rounded border border-[#E1EBE4] font-mono"
                        >
                          {feat}
                        </span>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Scientific Limitations & Legal Notice Card */}
          <div className="bg-white border border-[#E1EBE4] rounded-2xl p-5 space-y-3 shadow-xs">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#112217] flex items-center space-x-1.5">
              <Scale className="w-4 h-4 text-[#0A3D24]" />
              <span>Scientific Limitations & Expert Witness Notice</span>
            </h3>
            <p className="text-xs text-[#54665C] leading-relaxed">
              {analysisResult.scientificLimitations}{' '}
              <strong>Probabilistic Decision Support Only:</strong> Differential acoustic hypotheses provide structured examination cues and never constitute medical diagnosis or proof of speaker identity.
            </p>
            <div className="pt-2 flex items-center justify-between text-xs border-t border-[#E1EBE4]">
              <span className="text-[10px] text-[#54665C] font-mono">
                Analyzed at: {analysisResult.analyzedAt}
              </span>
              <button
                onClick={() => setCurrentScreen('report-generation')}
                className="px-3.5 py-1.5 bg-[#0A3D24] text-white font-bold rounded-xl shadow-xs text-xs cursor-pointer"
              >
                Export to Forensic Report →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Past Analyses */}
      {pastAnalyses.length > 0 && (
        <div className="bg-white border border-[#E1EBE4] rounded-2xl p-5 space-y-3 shadow-xs">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#112217]">
            Recorded Voice Condition Findings in Docket ({pastAnalyses.length})
          </h3>

          <div className="divide-y divide-slate-100">
            {pastAnalyses.map((item) => (
              <div
                key={item.id}
                onClick={() => setAnalysisResult(item)}
                className="py-2.5 flex items-center justify-between text-xs cursor-pointer hover:bg-[#F8FAF9] px-2 rounded-lg transition-colors"
              >
                <div>
                  <span className="font-mono font-bold text-[#0A3D24]">{item.id}</span>
                  <span className="text-[#54665C] ml-2">File: {item.questionedFilename}</span>
                  <span className="text-[10px] text-[#54665C] block">{item.analyzedAt}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="text-[10px] font-mono bg-[#F0FDF4] text-[#15803D] px-2 py-0.5 rounded">
                    {item.audioQualityStatus}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
