import React, { useState, useEffect, useRef } from 'react';
import {
  Shield,
  Lock,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  KeyRound,
  ShieldCheck,
  RefreshCw,
  Clock,
  AlertTriangle,
  Mail,
  Building2,
  FileCheck,
  X,
  UserCheck,
  ShieldAlert
} from 'lucide-react';
import { ScreenId, UserRole, User } from '../../types';
import { playNotificationChime, playSuccessSound, playKeyClickSound } from '../../utils/audioPlayer';
import { BackButton } from '../common/BackButton';
import { PasswordInput } from '../common/PasswordInput';
import { RegistrationPanel } from './RequestAccessScreen';
import { api } from '../../utils/api';

export interface LoginMeta {
  twoFactorEnrollmentRequired?: boolean;
  mustChangePassword?: boolean;
  sessionPolicy?: {
    sessionTtlMinutes?: number;
    idleLockMinutes?: number;
  };
}

interface SignInScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  setCurrentUserRole?: (role: UserRole) => void;
  onLoginSuccess?: (user?: User, meta?: LoginMeta) => void;
  onPendingEmailDetected?: (email: string) => void;
  defaultAuthTab?: 'signin' | 'create';
  initialEmail?: string;
  sessionNotice?: string | null;
  onClearSessionNotice?: () => void;
}

export const SignInScreen: React.FC<SignInScreenProps> = ({
  setCurrentScreen,
  setCurrentUserRole,
  onLoginSuccess,
  onPendingEmailDetected,
  defaultAuthTab = 'signin',
  initialEmail = '',
  sessionNotice,
  onClearSessionNotice
}) => {
  const [setupStatus, setSetupStatus] = useState<{
    checked: boolean;
    needsAdminSetup: boolean;
    requiresInitToken: boolean;
    smtpConfigured: boolean;
  }>({ checked: false, needsAdminSetup: false, requiresInitToken: false, smtpConfigured: false });

  // Unified Auth Tab & Sign-In Mode
  const [authTab, setAuthTab] = useState<'signin' | 'create'>(defaultAuthTab);
  const [loginMode, setLoginMode] = useState<'user' | 'admin'>('user');

  // First-Run Sole Admin Setup State
  const [setupName, setSetupName] = useState('');
  const [setupEmail, setSetupEmail] = useState('');
  const [setupAgency, setSetupAgency] = useState('ALFADetect Security Operations');
  const [setupDept, setSetupDept] = useState('Information Security & Governance');
  const [setupPassword, setSetupPassword] = useState('');
  const [setupConfirmPassword, setSetupConfirmPassword] = useState('');
  const [setupInitToken, setSetupInitToken] = useState('');

  // Auth Step: 1 = Email/Password, 2 = TOTP / Recovery Code Challenge
  const [authStep, setAuthStep] = useState<1 | 2>(1);
  const [challengeToken, setChallengeToken] = useState<string>('');
  const [useRecoveryMode, setUseRecoveryMode] = useState(false);
  const [recoveryCodeInput, setRecoveryCodeInput] = useState('');

  const [email, setEmail] = useState(initialEmail);
  const [password, setPassword] = useState('');

  const [emailError, setEmailError] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);

  // Forgot / Reset Password Modal State
  const [showForgotPasswordModal, setShowForgotPasswordModal] = useState(false);
  const [forgotStep, setForgotStep] = useState<'REQUEST' | 'RESET' | 'DONE'>('REQUEST');
  const [forgotEmail, setForgotEmail] = useState('');
  const [resetTokenInput, setResetTokenInput] = useState('');
  const [resetNewPassword, setResetNewPassword] = useState('');
  const [resetConfirmPassword, setResetConfirmPassword] = useState('');
  const [resetTotpCode, setResetTotpCode] = useState('');
  const [forgotError, setForgotError] = useState<string | null>(null);
  const [forgotInfo, setForgotInfo] = useState<string | null>(null);
  const [isResetting, setIsResetting] = useState(false);

  // 6-digit TOTP inputs
  const [totpDigits, setTotpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [challengeTimer, setChallengeTimer] = useState<number>(300);

  const [errorMsg, setErrorMsg] = useState('');
  const [roleModeMismatchCode, setRoleModeMismatchCode] = useState<'USE_ADMIN_SIGN_IN' | 'ADMIN_MODE_REQUIRED_NON_ADMIN' | null>(null);
  const [accountNotice, setAccountNotice] = useState<{
    code: 'PENDING_APPROVAL' | 'ACCOUNT_REJECTED' | 'ACCOUNT_SUSPENDED';
    message: string;
    requestedRole?: string;
    rejectionReason?: string;
  } | null>(null);
  const [successMsg, setSuccessMsg] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  const digitInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    setAuthTab(defaultAuthTab);
  }, [defaultAuthTab]);

  useEffect(() => {
    if (initialEmail) {
      setEmail(initialEmail);
    }
  }, [initialEmail]);

  // Check URL for ?resetToken=... on load
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const tokenParam = params.get('resetToken');
    if (tokenParam && tokenParam.trim()) {
      setResetTokenInput(tokenParam.trim());
      setForgotStep('RESET');
      setShowForgotPasswordModal(true);
    }
  }, []);

  // Check whether the enclave already has its sole System Security Administrator & SMTP status
  useEffect(() => {
    let active = true;
    api
      .getSetupStatus()
      .then((res) => {
        if (!active) return;
        setSetupStatus({
          checked: true,
          needsAdminSetup: Boolean(res.needsAdminSetup),
          requiresInitToken: Boolean(res.requiresInitToken),
          smtpConfigured: Boolean(res.smtpConfigured)
        });
      })
      .catch(() => {
        if (!active) return;
        setSetupStatus({
          checked: true,
          needsAdminSetup: false,
          requiresInitToken: false,
          smtpConfigured: false
        });
      });
    return () => {
      active = false;
    };
  }, []);

  // Countdown for 5-minute 2FA challenge validity
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (authStep === 2 && challengeTimer > 0) {
      interval = setInterval(() => {
        setChallengeTimer((prev) => {
          if (prev <= 1) {
            setErrorMsg('2FA challenge expired (5-minute timeout). Please return to Step 1 and sign in again.');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [authStep, challengeTimer]);

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // First-Run Sole System Security Administrator Bootstrap
  const handleInitAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!setupName.trim() || !setupEmail.trim() || !setupPassword) {
      setErrorMsg('Full Name, Institutional Email, and Strong Password are required.');
      return;
    }
    const localPart = setupEmail.trim().toLowerCase().split('@')[0];
    if (
      setupPassword.length < 12 ||
      !/[A-Z]/.test(setupPassword) ||
      !/[a-z]/.test(setupPassword) ||
      !/\d/.test(setupPassword) ||
      !/[^A-Za-z0-9]/.test(setupPassword) ||
      (localPart && localPart.length >= 3 && setupPassword.toLowerCase().includes(localPart))
    ) {
      setErrorMsg(
        'Password must be 12+ chars with uppercase, lowercase, number, special symbol, and must not contain your email username.'
      );
      return;
    }
    if (setupPassword !== setupConfirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    setIsVerifying(true);
    try {
      const res = await api.initAdmin({
        name: setupName.trim(),
        email: setupEmail.trim(),
        password: setupPassword,
        agency: setupAgency.trim() || undefined,
        department: setupDept.trim() || undefined,
        initToken: setupInitToken.trim() || undefined
      });
      playSuccessSound();
      setEmail(setupEmail.trim());
      setPassword('');
      setSetupPassword('');
      setSetupConfirmPassword('');
      setSetupInitToken('');
      setLoginMode('admin');
      setSetupStatus((prev) => ({
        ...prev,
        checked: true,
        needsAdminSetup: false,
        requiresInitToken: false
      }));
      setSuccessMsg(
        res?.message ||
          'Sole System Security Administrator initialized and locked. Sign in with your new credentials.'
      );
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to initialize sole System Security Administrator.');
    } finally {
      setIsVerifying(false);
    }
  };

  // Step 1: Submit Email & Password
  const handleStep1Submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setEmailError(null);
    setPasswordError(null);
    setErrorMsg('');
    setSuccessMsg('');
    setRoleModeMismatchCode(null);
    setAccountNotice(null);
    if (onClearSessionNotice) onClearSessionNotice();

    let hasError = false;
    const trimmedEmail = email.trim();
    if (!trimmedEmail) {
      setEmailError('Email address is required.');
      hasError = true;
    } else if (!trimmedEmail.includes('@') || !trimmedEmail.includes('.')) {
      setEmailError('Please enter a valid official institutional email address (e.g., analyst@agency.gov).');
      hasError = true;
    }

    if (!password) {
      setPasswordError('Password is required.');
      hasError = true;
    }

    if (hasError) return;

    setIsVerifying(true);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: trimmedEmail, password, loginMode })
      });

      const data = await response.json().catch(() => null);
      setIsVerifying(false);

      if (!response.ok) {
        if (
          data?.code === 'PENDING_APPROVAL' ||
          data?.code === 'ACCOUNT_REJECTED' ||
          data?.code === 'ACCOUNT_SUSPENDED'
        ) {
          setAccountNotice({
            code: data.code,
            message: data.error,
            requestedRole: data.requestedRole,
            rejectionReason: data.rejectionReason
          });
          if (onPendingEmailDetected) onPendingEmailDetected(trimmedEmail);
        } else if (
          data?.code === 'USE_ADMIN_SIGN_IN' ||
          data?.code === 'ADMIN_MODE_REQUIRED_NON_ADMIN'
        ) {
          setRoleModeMismatchCode(data.code);
          setErrorMsg(data.error);
        } else {
          setErrorMsg(
            data?.error ||
              'Authentication failed: Unable to verify credentials with forensic enclave authority.'
          );
        }
        return;
      }

      if (data?.status === 'AUTHENTICATED' && data.sessionToken) {
        localStorage.setItem('auth_session_token', data.sessionToken);
        if (data.user) {
          localStorage.setItem('deepfake_detector_user', JSON.stringify(data.user));
          if (setCurrentUserRole && data.user.role) {
            setCurrentUserRole(data.user.role as UserRole);
          }
        }
        playSuccessSound();
        if (onLoginSuccess) {
          onLoginSuccess(data.user, {
            twoFactorEnrollmentRequired: Boolean(data.twoFactorEnrollmentRequired),
            mustChangePassword: Boolean(data.mustChangePassword),
            sessionPolicy: data.sessionPolicy
          });
        }
        setCurrentScreen('dashboard');
        return;
      }

      if (data?.status === 'TWO_FACTOR_REQUIRED' && data.challengeToken) {
        setChallengeToken(data.challengeToken);
        setAuthStep(2);
        setUseRecoveryMode(false);
        setTotpDigits(['', '', '', '', '', '']);
        setRecoveryCodeInput('');
        setChallengeTimer(300);
        setErrorMsg('');
        setSuccessMsg(data.message || 'Enter the 6-digit TOTP code from your Authenticator App.');
        playNotificationChime();
        setTimeout(() => digitInputRefs.current[0]?.focus(), 150);
        return;
      }

      setErrorMsg('Unexpected response from authentication server.');
    } catch {
      setIsVerifying(false);
      setErrorMsg(
        'Authentication service currently unavailable: Could not establish a connection to the forensic backend server.'
      );
    }
  };

  const handleDigitChange = (index: number, value: string) => {
    if (challengeTimer <= 0) return;

    const val = value.replace(/[^0-9]/g, '');
    if (!val) {
      const next = [...totpDigits];
      next[index] = '';
      setTotpDigits(next);
      return;
    }

    playKeyClickSound();
    const lastChar = val.slice(-1);
    const next = [...totpDigits];
    next[index] = lastChar;
    setTotpDigits(next);

    if (index < 5 && lastChar) {
      digitInputRefs.current[index + 1]?.focus();
    }

    if (index === 5 && lastChar) {
      const fullCode = next.join('');
      if (fullCode.length === 6) {
        executeServer2faVerification(fullCode);
      }
    }
  };

  const handleDigitKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !totpDigits[index] && index > 0) {
      digitInputRefs.current[index - 1]?.focus();
    }
  };

  const executeServer2faVerification = async (codeOverride?: string) => {
    const codeToVerify = useRecoveryMode
      ? recoveryCodeInput.trim()
      : codeOverride || totpDigits.join('');

    if (challengeTimer <= 0) {
      setErrorMsg('2FA challenge window expired. Please sign in again.');
      return;
    }
    if (!codeToVerify || (!useRecoveryMode && codeToVerify.length < 6)) {
      setErrorMsg(
        useRecoveryMode
          ? 'Please enter a valid single-use recovery code (e.g. ALFA-XXXX-XXXX).'
          : 'Please enter all 6 digits from your Authenticator App.'
      );
      return;
    }

    setErrorMsg('');
    setIsVerifying(true);
    try {
      const data = await api.verify2faLogin(challengeToken, codeToVerify, loginMode);
      playSuccessSound();
      if (data?.sessionToken) {
        localStorage.setItem('auth_session_token', data.sessionToken);
      }
      if (data?.user) {
        localStorage.setItem('deepfake_detector_user', JSON.stringify(data.user));
        if (setCurrentUserRole && data.user.role) {
          setCurrentUserRole(data.user.role as UserRole);
        }
      }
      if (onLoginSuccess) {
        onLoginSuccess(data?.user, {
          twoFactorEnrollmentRequired: Boolean(data?.twoFactorEnrollmentRequired),
          mustChangePassword: Boolean(data?.mustChangePassword),
          sessionPolicy: data?.sessionPolicy
        });
      }
      setCurrentScreen('dashboard');
    } catch (err: any) {
      setErrorMsg(err?.message || 'Invalid 2FA verification code.');
    } finally {
      setIsVerifying(false);
    }
  };

  const openForgotModal = () => {
    setForgotEmail(email.trim());
    setForgotError(null);
    setForgotInfo(null);
    setForgotStep('REQUEST');
    setResetNewPassword('');
    setResetConfirmPassword('');
    setResetTotpCode('');
    setShowForgotPasswordModal(true);
  };

  const handleRequestPasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError(null);
    setForgotInfo(null);
    const clean = forgotEmail.trim();
    if (!clean || !clean.includes('@')) {
      setForgotError('Enter a valid institutional email address.');
      return;
    }
    setIsResetting(true);
    try {
      const res = await api.forgotPassword(clean);
      setForgotInfo(
        res?.message ||
          'If an active account matches that address, password reset instructions have been sent via email.'
      );
      setForgotStep('RESET');
    } catch (err: any) {
      setForgotError(err?.message || 'Unable to process password reset request.');
    } finally {
      setIsResetting(false);
    }
  };

  const handleCompletePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError(null);
    setForgotInfo(null);
    if (!resetTokenInput.trim()) {
      setForgotError('Reset token is required.');
      return;
    }
    if (!resetNewPassword) {
      setForgotError('New password is required.');
      return;
    }
    if (resetNewPassword !== resetConfirmPassword) {
      setForgotError('New passwords do not match.');
      return;
    }
    setIsResetting(true);
    try {
      const res = await api.resetPassword({
        token: resetTokenInput.trim(),
        newPassword: resetNewPassword,
        totpCode: resetTotpCode.trim() || undefined
      });
      playSuccessSound();
      setForgotInfo(res?.message || 'Password reset succeeded. You may now sign in with your new password.');
      setForgotStep('DONE');
      if (forgotEmail.trim()) {
        setEmail(forgotEmail.trim());
      }
      setSuccessMsg('Password reset completed. Sign in with your new credentials.');
      if (typeof window !== 'undefined' && window.location.search.includes('resetToken=')) {
        const url = new URL(window.location.href);
        url.searchParams.delete('resetToken');
        window.history.replaceState({}, '', url.pathname + url.search);
      }
    } catch (err: any) {
      setForgotError(err?.message || 'Password reset failed. Verify the reset token and password requirements.');
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <div id="signin-screen" className="min-h-full bg-[#F8FAF9] text-[#112217] flex items-center justify-center p-4 sm:p-6 md:p-10">
      <div className="w-full max-w-4xl bg-white border border-[#E1EBE4] rounded-3xl overflow-hidden shadow-xl grid grid-cols-1 lg:grid-cols-12">
        {/* Left Panel: ALFADetect Forensic Enclave Branding */}
        <div className="lg:col-span-5 bg-[#062817] p-8 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-[#0A3D24] text-white">
          <div className="space-y-6">
            <div className="flex items-center space-x-3">
              <div className="w-11 h-11 rounded-2xl bg-[#0A3D24] flex items-center justify-center text-white shadow-lg border border-[#C88A2C]/30">
                <Shield className="w-6 h-6 text-[#C88A2C]" />
              </div>
              <div>
                <span className="text-base font-extrabold tracking-tight block font-serif-title">ALFADetect</span>
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#C88A2C] font-bold">
                  NATIONAL FORENSIC ENCLAVE
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <h2 className="text-xl font-bold tracking-tight text-white font-serif-title">
                {setupStatus.needsAdminSetup
                  ? 'Initial Enclave Authority Bootstrap'
                  : authTab === 'create'
                  ? 'Operator Clearance Request'
                  : loginMode === 'admin'
                  ? 'Administrator Governance Access'
                  : 'Secure Operator Authentication'}
              </h2>
              <p className="text-xs text-emerald-200/80 leading-relaxed">
                {setupStatus.needsAdminSetup
                  ? 'Initialize the strictly single System Security Administrator account to govern clearance approvals and security policy.'
                  : authTab === 'create'
                  ? 'Apply for accredited forensic analyst, expert witness, or legal reviewer access. All accounts start pending administrator review.'
                  : loginMode === 'admin'
                  ? 'Dedicated authentication channel for the single System Security Administrator governing user approvals, policy, and audit logs.'
                  : 'Cryptographic authentication portal for accredited forensic laboratories, federal prosecutors, and judiciary personnel.'}
              </p>
            </div>

            <div className="space-y-3 pt-3 border-t border-emerald-900/50 text-xs">
              <div className="flex items-center space-x-2.5 text-emerald-200">
                <ShieldCheck className="w-4 h-4 text-[#C88A2C] shrink-0" />
                <span>Single System Security Administrator Governance</span>
              </div>
              <div className="flex items-center space-x-2.5 text-emerald-200">
                <Building2 className="w-4 h-4 text-[#C88A2C] shrink-0" />
                <span>Digital Audio Evidence Preservation</span>
              </div>
              <div className="flex items-center space-x-2.5 text-emerald-200">
                <FileCheck className="w-4 h-4 text-[#C88A2C] shrink-0" />
                <span>Ed25519 Chained Custody Ledger</span>
              </div>
              <div className="flex items-center space-x-2.5 text-emerald-200">
                <KeyRound className="w-4 h-4 text-[#C88A2C] shrink-0" />
                <span>SHA-256 Bitstream Integrity Sealing</span>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-emerald-900/50 text-[10px] text-emerald-400/70 font-mono flex items-center justify-between">
            <span>ENCLAVE: ED25519</span>
            <span>ZERO-TRUST JWT</span>
          </div>
        </div>

        {/* Right Panel: First-Run Setup OR Unified Sign In / Create Account */}
        <div className="lg:col-span-7 p-8 sm:p-10 flex flex-col justify-center space-y-5">
          <div className="flex items-center justify-between">
            <BackButton onClick={() => setCurrentScreen('landing')} label="Back to Portal" variant="pill" />
            {!setupStatus.needsAdminSetup && (
              <button
                type="button"
                onClick={() => setCurrentScreen('pending-approval')}
                className="text-[11px] font-semibold text-[#0A3D24] hover:text-[#062817] cursor-pointer"
              >
                Check Approval Status
              </button>
            )}
          </div>

          {setupStatus.needsAdminSetup ? (
            <>
              <div className="space-y-1">
                <div className="inline-flex items-center space-x-1.5 text-[10px] font-mono font-bold uppercase px-2.5 py-0.5 rounded bg-[#FEF3C7] text-[#B2751E] border border-[#C88A2C]/30 mb-1">
                  <UserCheck className="w-3 h-3" />
                  <span>First-Run Setup — Single Administrator Policy</span>
                </div>
                <h2 className="text-2xl font-bold tracking-tight text-[#112217] font-serif-title">
                  Initialize Sole System Administrator
                </h2>
                <p className="text-xs text-[#54665C]">
                  Once created, public administrator initialization permanently locks. All future operators register via Create Account and await your approval.
                </p>
              </div>

              {errorMsg && (
                <div className="p-3 bg-[#FEF2F2] border border-[#B91C1C]/30 text-[#B91C1C] text-xs rounded-xl flex items-start space-x-2 font-medium">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <form onSubmit={handleInitAdminSubmit} className="space-y-3 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="setup-admin-name" className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                      Full Legal Name *
                    </label>
                    <input
                      id="setup-admin-name"
                      type="text"
                      autoComplete="name"
                      required
                      value={setupName}
                      onChange={(e) => setSetupName(e.target.value)}
                      placeholder="Director / Security Officer"
                      className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 text-[#112217]"
                    />
                  </div>
                  <div>
                    <label htmlFor="setup-admin-email" className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                      Official Email *
                    </label>
                    <input
                      id="setup-admin-email"
                      type="email"
                      autoComplete="email"
                      required
                      value={setupEmail}
                      onChange={(e) => setSetupEmail(e.target.value)}
                      placeholder="secadmin@forensics.gov"
                      className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 text-[#112217] font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="setup-admin-agency" className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                      Agency
                    </label>
                    <input
                      id="setup-admin-agency"
                      type="text"
                      autoComplete="organization"
                      value={setupAgency}
                      onChange={(e) => setSetupAgency(e.target.value)}
                      className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 text-[#112217]"
                    />
                  </div>
                  <div>
                    <label htmlFor="setup-admin-dept" className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                      Department
                    </label>
                    <input
                      id="setup-admin-dept"
                      type="text"
                      value={setupDept}
                      onChange={(e) => setSetupDept(e.target.value)}
                      className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 text-[#112217]"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <label htmlFor="setup-admin-pw" className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                      Strong Password *
                    </label>
                    <PasswordInput
                      id="setup-admin-pw"
                      autoComplete="new-password"
                      required
                      value={setupPassword}
                      onChange={(e) => setSetupPassword(e.target.value)}
                      placeholder="Minimum 12 characters"
                      showStrengthChecklist
                      emailForStrengthCheck={setupEmail}
                      inputClassName="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl py-2.5 text-xs text-[#112217] focus:outline-none focus:border-[#0A3D24] focus:bg-white"
                    />
                  </div>
                  <div>
                    <label htmlFor="setup-admin-pw-confirm" className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                      Confirm Password *
                    </label>
                    <PasswordInput
                      id="setup-admin-pw-confirm"
                      autoComplete="new-password"
                      required
                      value={setupConfirmPassword}
                      onChange={(e) => setSetupConfirmPassword(e.target.value)}
                      placeholder="Re-enter strong password"
                      inputClassName="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl py-2.5 text-xs text-[#112217] focus:outline-none focus:border-[#0A3D24] focus:bg-white"
                    />
                  </div>
                </div>

                {setupStatus.requiresInitToken && (
                  <div>
                    <label htmlFor="setup-init-token" className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                      Server Initialization Token (ADMIN_INIT_TOKEN) *
                    </label>
                    <PasswordInput
                      id="setup-init-token"
                      autoComplete="off"
                      required
                      value={setupInitToken}
                      onChange={(e) => setSetupInitToken(e.target.value)}
                      placeholder="Enter ADMIN_INIT_TOKEN from server environment"
                      inputClassName="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl py-2.5 font-mono text-xs text-[#112217] focus:outline-none focus:border-[#0A3D24] focus:bg-white"
                    />
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isVerifying}
                  className="w-full py-3 bg-[#0A3D24] hover:bg-[#062817] disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center space-x-2 cursor-pointer"
                >
                  {isVerifying ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Initializing Sole Administrator...</span>
                    </>
                  ) : (
                    <>
                      <span>Initialize Sole System Administrator</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </>
          ) : (
            <>
              {/* Unified Auth Screen Tabs: Sign In | Create Account */}
              {authStep === 1 && (
                <div className="grid grid-cols-2 bg-[#F1F5F9] p-1 rounded-xl border border-[#E1EBE4]" role="tablist">
                  <button
                    type="button"
                    role="tab"
                    aria-selected={authTab === 'signin'}
                    onClick={() => {
                      setAuthTab('signin');
                      setErrorMsg('');
                      setRoleModeMismatchCode(null);
                    }}
                    className={`py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      authTab === 'signin'
                        ? 'bg-white text-[#0A3D24] shadow-xs'
                        : 'text-[#54665C] hover:text-[#112217]'
                    }`}
                  >
                    Sign In
                  </button>
                  <button
                    type="button"
                    role="tab"
                    aria-selected={authTab === 'create'}
                    onClick={() => {
                      setAuthTab('create');
                      setErrorMsg('');
                      setSuccessMsg('');
                      setAccountNotice(null);
                      setRoleModeMismatchCode(null);
                    }}
                    className={`py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      authTab === 'create'
                        ? 'bg-white text-[#0A3D24] shadow-xs'
                        : 'text-[#54665C] hover:text-[#112217]'
                    }`}
                  >
                    Create Account
                  </button>
                </div>
              )}

              {authTab === 'create' && authStep === 1 ? (
                <RegistrationPanel
                  initialEmail={email}
                  onSwitchToSignIn={(prefillEmail, notice) => {
                    if (prefillEmail) setEmail(prefillEmail);
                    setAuthTab('signin');
                    setAuthStep(1);
                    setErrorMsg('');
                    if (notice) setSuccessMsg(notice);
                  }}
                  onOpenPendingStatus={(pendingEmail) => {
                    if (pendingEmail && onPendingEmailDetected) onPendingEmailDetected(pendingEmail);
                    setCurrentScreen('pending-approval');
                  }}
                  onRegistrationSubmitted={onPendingEmailDetected}
                />
              ) : (
                <>
                  {sessionNotice && (
                    <div className="p-3 bg-[#FEF3C7] border border-[#C88A2C]/40 text-[#925E12] text-xs rounded-xl flex items-center justify-between space-x-2 font-semibold">
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4 shrink-0" />
                        <span>{sessionNotice}</span>
                      </div>
                      {onClearSessionNotice && (
                        <button
                          type="button"
                          onClick={onClearSessionNotice}
                          className="text-[#925E12] hover:underline text-[11px] font-bold cursor-pointer"
                        >
                          Dismiss
                        </button>
                      )}
                    </div>
                  )}

                  <div className="space-y-1">
                    {authStep === 1 && (
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                        <div className="inline-flex rounded-xl border border-[#E1EBE4] bg-[#F8FAF9] p-0.5 text-[11px]">
                          <button
                            type="button"
                            onClick={() => {
                              setLoginMode('user');
                              setErrorMsg('');
                              setRoleModeMismatchCode(null);
                            }}
                            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                              loginMode === 'user'
                                ? 'bg-[#0A3D24] text-white shadow-xs'
                                : 'text-[#54665C] hover:text-[#112217]'
                            }`}
                          >
                            Standard User Sign-In
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setLoginMode('admin');
                              setErrorMsg('');
                              setRoleModeMismatchCode(null);
                            }}
                            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center space-x-1 cursor-pointer ${
                              loginMode === 'admin'
                                ? 'bg-[#B2751E] text-white shadow-xs'
                                : 'text-[#54665C] hover:text-[#112217]'
                            }`}
                          >
                            <ShieldAlert className="w-3 h-3" />
                            <span>Administrator Sign-In</span>
                          </button>
                        </div>
                      </div>
                    )}

                    <h2 className="text-2xl font-bold tracking-tight text-[#112217] font-serif-title">
                      {authStep === 2
                        ? 'Authenticator App Verification (TOTP)'
                        : loginMode === 'admin'
                        ? 'System Security Administrator Sign-In'
                        : 'Operator Sign In'}
                    </h2>
                    <p className="text-xs text-[#54665C]">
                      {authStep === 2
                        ? 'Enter the 6-digit TOTP code from your enrolled Authenticator App or a recovery code.'
                        : loginMode === 'admin'
                        ? 'Restricted strictly to the sole active System Security Administrator account.'
                        : 'Enter your institutional credentials to authenticate your session.'}
                    </p>
                  </div>

                  {authStep === 1 && loginMode === 'admin' && (
                    <div className="p-3 bg-[#FEF3C7]/70 border border-[#C88A2C]/40 text-[#925E12] text-[11px] rounded-xl flex items-start space-x-2">
                      <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-[#B2751E]" />
                      <span>
                        <strong>Administrator Governance Mode:</strong> Separation-of-duties policy grants access to user approvals, security configuration, and immutable audit monitoring without access to raw case evidence.
                      </span>
                    </div>
                  )}

                  {accountNotice && (
                    <div
                      className={`p-3.5 text-xs rounded-xl border space-y-2 ${
                        accountNotice.code === 'PENDING_APPROVAL'
                          ? 'bg-[#FEF3C7] border-[#C88A2C]/40 text-[#925E12]'
                          : 'bg-[#FEF2F2] border-[#B91C1C]/30 text-[#B91C1C]'
                      }`}
                    >
                      <div className="flex items-start space-x-2 font-semibold">
                        <Clock className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>{accountNotice.message}</span>
                      </div>
                      {accountNotice.requestedRole && (
                        <p className="text-[11px] font-mono">Requested Role: {accountNotice.requestedRole}</p>
                      )}
                      {accountNotice.rejectionReason && (
                        <p className="text-[11px] font-mono">Reason: {accountNotice.rejectionReason}</p>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          if (onPendingEmailDetected && email.trim()) onPendingEmailDetected(email.trim());
                          setCurrentScreen('pending-approval');
                        }}
                        className="text-[11px] font-bold underline cursor-pointer"
                      >
                        Open Account Approval Status Tracker →
                      </button>
                    </div>
                  )}

                  {errorMsg && (
                    <div className="p-3 bg-[#FEF2F2] border border-[#B91C1C]/30 text-[#B91C1C] text-xs rounded-xl space-y-2 font-medium">
                      <div className="flex items-start space-x-2">
                        <AlertTriangle className="w-4 h-4 text-[#B91C1C] shrink-0 mt-0.5" />
                        <span>{errorMsg}</span>
                      </div>
                      {roleModeMismatchCode === 'USE_ADMIN_SIGN_IN' && (
                        <button
                          type="button"
                          onClick={() => {
                            setLoginMode('admin');
                            setRoleModeMismatchCode(null);
                            setErrorMsg('');
                          }}
                          className="ml-6 px-3 py-1 bg-[#B2751E] text-white font-bold text-[11px] rounded-lg cursor-pointer"
                        >
                          Switch to Administrator Sign-In Mode →
                        </button>
                      )}
                      {roleModeMismatchCode === 'ADMIN_MODE_REQUIRED_NON_ADMIN' && (
                        <button
                          type="button"
                          onClick={() => {
                            setLoginMode('user');
                            setRoleModeMismatchCode(null);
                            setErrorMsg('');
                          }}
                          className="ml-6 px-3 py-1 bg-[#0A3D24] text-white font-bold text-[11px] rounded-lg cursor-pointer"
                        >
                          Switch to Standard User Sign-In Mode →
                        </button>
                      )}
                    </div>
                  )}

                  {successMsg && (
                    <div className="p-3 bg-[#F0FDF4] border border-[#15803D]/30 text-[#15803D] text-xs rounded-xl flex items-center space-x-2 font-medium">
                      <CheckCircle className="w-4 h-4 text-[#15803D] shrink-0" />
                      <span>{successMsg}</span>
                    </div>
                  )}

                  {authStep === 1 ? (
                    <form onSubmit={handleStep1Submit} className="space-y-4 text-xs">
                      <div className="space-y-1">
                        <label htmlFor="signin-email" className="text-[11px] font-bold uppercase text-[#54665C] block">
                          Institutional Agency Email
                        </label>
                        <div className="relative">
                          <Mail className="w-4 h-4 text-[#54665C] absolute left-3 top-3 pointer-events-none" />
                          <input
                            id="signin-email"
                            type="email"
                            autoComplete="email"
                            value={email}
                            onChange={(e) => {
                              setEmail(e.target.value);
                              if (emailError) setEmailError(null);
                            }}
                            placeholder={loginMode === 'admin' ? 'secadmin@agency.gov' : 'analyst@agency.gov'}
                            aria-invalid={!!emailError}
                            className={`w-full bg-[#F8FAF9] border rounded-xl pl-9 pr-3 py-2.5 text-[#112217] text-xs font-mono transition-colors focus:outline-none focus:bg-white ${
                              emailError ? 'border-[#B91C1C] focus:border-[#B91C1C]' : 'border-[#E1EBE4] focus:border-[#0A3D24]'
                            }`}
                          />
                        </div>
                        {emailError && (
                          <p className="text-[11px] text-[#B91C1C] font-medium flex items-center space-x-1 mt-1">
                            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                            <span>{emailError}</span>
                          </p>
                        )}
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <label htmlFor="signin-password" className="text-[11px] font-bold uppercase text-[#54665C]">
                            Password / Enclave Credential
                          </label>
                          <button
                            type="button"
                            onClick={openForgotModal}
                            className="text-[11px] text-[#0A3D24] hover:text-[#062817] font-semibold cursor-pointer"
                          >
                            Forgot password?
                          </button>
                        </div>
                        <PasswordInput
                          id="signin-password"
                          autoComplete="current-password"
                          value={password}
                          onChange={(e) => {
                            setPassword(e.target.value);
                            if (passwordError) setPasswordError(null);
                          }}
                          placeholder="••••••••••••"
                          error={passwordError || undefined}
                          leftIcon={<Lock className="w-4 h-4 text-[#54665C]" />}
                          inputClassName={`w-full bg-[#F8FAF9] border rounded-xl py-2.5 text-[#112217] text-xs transition-colors focus:outline-none focus:bg-white ${
                            passwordError ? 'border-[#B91C1C] focus:border-[#B91C1C]' : 'border-[#E1EBE4] focus:border-[#0A3D24]'
                          }`}
                        />
                      </div>

                      <div className="p-3 bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl text-[11px] text-[#54665C] leading-relaxed">
                        <strong className="text-[#0A3D24]">Cryptographic Access Control:</strong> Sessions issue time-limited signed JWTs + HttpOnly Strict cookies with token revocation and brute-force lockout protection.
                      </div>

                      <div className="flex items-center justify-between text-xs pt-1">
                        <span className="text-[11px] text-[#54665C]">New to ALFADetect?</span>
                        <button
                          type="button"
                          onClick={() => {
                            setAuthTab('create');
                            setErrorMsg('');
                            setRoleModeMismatchCode(null);
                          }}
                          className="text-[#0A3D24] hover:text-[#062817] font-bold cursor-pointer"
                        >
                          Create Account (Pending Admin Approval) →
                        </button>
                      </div>

                      <button
                        type="submit"
                        disabled={isVerifying}
                        className={`w-full py-3 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center space-x-2 transition-all mt-2 cursor-pointer ${
                          loginMode === 'admin'
                            ? 'bg-[#B2751E] hover:bg-[#925E12]'
                            : 'bg-[#0A3D24] hover:bg-[#062817]'
                        }`}
                      >
                        {isVerifying ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            <span>Verifying Credentials on Server...</span>
                          </>
                        ) : (
                          <>
                            <span>
                              {loginMode === 'admin' ? 'Authenticate as Administrator' : 'Authenticate Session'}
                            </span>
                            <ArrowRight className="w-4 h-4" />
                          </>
                        )}
                      </button>
                    </form>
                  ) : (
                    <div className="space-y-5">
                      <div className="p-3.5 bg-[#F0FDF4] border border-[#15803D]/30 rounded-2xl flex items-start space-x-3 text-xs text-[#15803D]">
                        <KeyRound className="w-5 h-5 text-[#15803D] shrink-0 mt-0.5" />
                        <div>
                          <p className="font-semibold">TOTP Multi-Factor Challenge Active</p>
                          <p className="text-[11px] text-[#54665C] mt-0.5">
                            Account: <strong>{email}</strong> · Enter your 6-digit Authenticator code or switch to a single-use recovery code.
                          </p>
                        </div>
                      </div>

                      {!useRecoveryMode ? (
                        <div className="flex justify-between gap-2 max-w-sm mx-auto">
                          {totpDigits.map((digit, idx) => (
                            <input
                              key={idx}
                              ref={(el) => {
                                digitInputRefs.current[idx] = el;
                              }}
                              type="text"
                              inputMode="numeric"
                              autoComplete="one-time-code"
                              maxLength={1}
                              value={digit}
                              onChange={(e) => handleDigitChange(idx, e.target.value)}
                              onKeyDown={(e) => handleDigitKeyDown(idx, e)}
                              className="w-12 h-14 bg-[#F8FAF9] border-2 border-[#E1EBE4] focus:border-[#0A3D24] rounded-xl text-center text-xl font-mono font-bold text-[#112217] focus:outline-hidden shadow-2xs"
                            />
                          ))}
                        </div>
                      ) : (
                        <div className="max-w-sm mx-auto space-y-1">
                          <label htmlFor="signin-recovery-code" className="text-[10px] font-bold uppercase text-[#54665C] block">
                            Single-Use Recovery Code
                          </label>
                          <input
                            id="signin-recovery-code"
                            type="text"
                            autoComplete="one-time-code"
                            value={recoveryCodeInput}
                            onChange={(e) => setRecoveryCodeInput(e.target.value.toUpperCase())}
                            placeholder="ALFA-XXXX-XXXX"
                            className="w-full bg-[#F8FAF9] border-2 border-[#E1EBE4] focus:border-[#0A3D24] rounded-xl px-4 py-3 text-center text-sm font-mono font-bold text-[#112217]"
                          />
                        </div>
                      )}

                      <div className="flex items-center justify-between text-xs text-[#54665C] font-mono">
                        <span>
                          Challenge expires: <strong className="text-[#112217]">{formatTimer(challengeTimer)}</strong>
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setUseRecoveryMode(!useRecoveryMode);
                            setErrorMsg('');
                          }}
                          className="text-[#0A3D24] font-bold hover:underline cursor-pointer"
                        >
                          {useRecoveryMode ? 'Use 6-Digit TOTP' : 'Use Recovery Code'}
                        </button>
                      </div>

                      <div className="flex items-center space-x-3 pt-2 border-t border-[#E1EBE4]">
                        <button
                          type="button"
                          onClick={() => {
                            setAuthStep(1);
                            setChallengeToken('');
                            setErrorMsg('');
                          }}
                          className="w-1/2 py-2.5 bg-white border border-[#E1EBE4] hover:bg-slate-50 text-[#112217] font-bold text-xs rounded-xl cursor-pointer"
                        >
                          Back
                        </button>
                        <button
                          type="button"
                          onClick={() => executeServer2faVerification()}
                          disabled={isVerifying}
                          className="w-1/2 py-2.5 bg-[#0A3D24] hover:bg-[#062817] disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center space-x-2 cursor-pointer"
                        >
                          {isVerifying ? (
                            <>
                              <RefreshCw className="w-4 h-4 animate-spin" />
                              <span>Verifying...</span>
                            </>
                          ) : (
                            <span>Complete Sign In</span>
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                </>
              )}
            </>
          )}
        </div>
      </div>

      {/* Password Recovery Modal (Real SMTP Reset Flow + Honest Unconfigured SMTP Notice) */}
      {showForgotPasswordModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-[#E1EBE4] shadow-2xl space-y-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-[#FEF3C7] text-[#B2751E] flex items-center justify-center">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#112217] font-serif-title">
                    Password Recovery
                  </h3>
                  <p className="text-[11px] text-[#54665C]">
                    {setupStatus.smtpConfigured
                      ? 'Single-use email recovery token (15-minute expiry)'
                      : 'Administrator-managed credential reset'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                aria-label="Close password recovery"
                onClick={() => setShowForgotPasswordModal(false)}
                className="text-[#54665C] hover:text-[#112217] p-1 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {forgotError && (
              <div className="p-3 bg-[#FEF2F2] border border-[#B91C1C]/30 text-[#B91C1C] text-xs rounded-xl flex items-start space-x-2 font-medium">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{forgotError}</span>
              </div>
            )}

            {forgotInfo && (
              <div className="p-3 bg-[#F0FDF4] border border-[#15803D]/30 text-[#15803D] text-xs rounded-xl flex items-start space-x-2 font-medium">
                <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{forgotInfo}</span>
              </div>
            )}

            {!setupStatus.smtpConfigured && forgotStep === 'REQUEST' ? (
              <div className="space-y-4">
                <div className="p-3.5 bg-[#FEF3C7]/60 border border-[#C88A2C]/40 rounded-xl text-xs text-[#7A4F10] leading-relaxed">
                  Email-based password resets are currently unavailable because outbound SMTP is not configured on this enclave server. Contact your <strong>System Security Administrator</strong> to issue a temporary reset credential (which will require an immediate password change on sign-in).
                </div>
                <div className="flex justify-between items-center gap-2 pt-2 border-t border-[#E1EBE4]">
                  <button
                    type="button"
                    onClick={() => setForgotStep('RESET')}
                    className="text-[11px] font-semibold text-[#0A3D24] hover:underline cursor-pointer"
                  >
                    Already have a reset token?
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowForgotPasswordModal(false)}
                    className="px-4 py-2 bg-[#0A3D24] text-white font-bold text-xs rounded-xl hover:bg-[#062817] cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              </div>
            ) : forgotStep === 'REQUEST' ? (
              <form onSubmit={handleRequestPasswordReset} className="space-y-3 text-xs">
                <p className="text-[#54665C] leading-relaxed">
                  Enter your institutional email address to receive a single-use password reset token valid for 15 minutes.
                </p>
                <div>
                  <label htmlFor="forgot-email" className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                    Institutional Email *
                  </label>
                  <input
                    id="forgot-email"
                    type="email"
                    autoComplete="email"
                    required
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    placeholder="operator@agency.gov"
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 text-[#112217] font-mono focus:outline-none focus:border-[#0A3D24]"
                  />
                </div>
                <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#E1EBE4]">
                  <button
                    type="button"
                    onClick={() => setForgotStep('RESET')}
                    className="text-[11px] font-semibold text-[#0A3D24] hover:underline cursor-pointer"
                  >
                    I already have a token
                  </button>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowForgotPasswordModal(false)}
                      className="px-3 py-2 bg-white border border-[#E1EBE4] text-[#112217] font-bold text-xs rounded-xl hover:bg-slate-50 cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isResetting}
                      className="px-4 py-2 bg-[#0A3D24] text-white font-bold text-xs rounded-xl hover:bg-[#062817] disabled:opacity-50 cursor-pointer"
                    >
                      {isResetting ? 'Sending...' : 'Send Reset Email'}
                    </button>
                  </div>
                </div>
              </form>
            ) : forgotStep === 'RESET' ? (
              <form onSubmit={handleCompletePasswordReset} className="space-y-3 text-xs">
                <div>
                  <label htmlFor="reset-token-input" className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                    Reset Token *
                  </label>
                  <input
                    id="reset-token-input"
                    type="text"
                    required
                    value={resetTokenInput}
                    onChange={(e) => setResetTokenInput(e.target.value)}
                    placeholder="Paste single-use token from email"
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 font-mono text-xs text-[#112217] focus:outline-none focus:border-[#0A3D24]"
                  />
                </div>
                <div>
                  <label htmlFor="reset-new-password" className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                    New Password *
                  </label>
                  <PasswordInput
                    id="reset-new-password"
                    autoComplete="new-password"
                    required
                    value={resetNewPassword}
                    onChange={(e) => setResetNewPassword(e.target.value)}
                    placeholder="Minimum 12 characters"
                    showStrengthChecklist
                    emailForStrengthCheck={forgotEmail || email}
                    inputClassName="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl py-2.5 text-xs text-[#112217] focus:outline-none focus:border-[#0A3D24]"
                  />
                </div>
                <div>
                  <label htmlFor="reset-confirm-password" className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                    Confirm New Password *
                  </label>
                  <PasswordInput
                    id="reset-confirm-password"
                    autoComplete="new-password"
                    required
                    value={resetConfirmPassword}
                    onChange={(e) => setResetConfirmPassword(e.target.value)}
                    placeholder="Re-enter new password"
                    inputClassName="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl py-2.5 text-xs text-[#112217] focus:outline-none focus:border-[#0A3D24]"
                  />
                </div>
                <div>
                  <label htmlFor="reset-totp-code" className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                    2FA TOTP or Recovery Code (Required if 2FA enabled)
                  </label>
                  <input
                    id="reset-totp-code"
                    type="text"
                    autoComplete="one-time-code"
                    value={resetTotpCode}
                    onChange={(e) => setResetTotpCode(e.target.value)}
                    placeholder="6-digit TOTP or recovery code (leave blank if not enrolled)"
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl p-2.5 font-mono text-xs text-[#112217] focus:outline-none focus:border-[#0A3D24]"
                  />
                </div>
                <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#E1EBE4]">
                  <button
                    type="button"
                    onClick={() => setForgotStep('REQUEST')}
                    className="text-[11px] font-semibold text-[#54665C] hover:text-[#112217] cursor-pointer"
                  >
                    ← Back
                  </button>
                  <button
                    type="submit"
                    disabled={isResetting}
                    className="px-4 py-2 bg-[#0A3D24] text-white font-bold text-xs rounded-xl hover:bg-[#062817] disabled:opacity-50 cursor-pointer"
                  >
                    {isResetting ? 'Updating...' : 'Reset Password'}
                  </button>
                </div>
              </form>
            ) : (
              <div className="flex justify-end pt-2 border-t border-[#E1EBE4]">
                <button
                  type="button"
                  onClick={() => setShowForgotPasswordModal(false)}
                  className="px-5 py-2 bg-[#0A3D24] text-white font-bold text-xs rounded-xl hover:bg-[#062817] cursor-pointer"
                >
                  Return to Sign In
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
