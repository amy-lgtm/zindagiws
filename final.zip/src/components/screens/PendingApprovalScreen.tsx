import React, { useState } from 'react';
import {
  Clock,
  CheckCircle2,
  XCircle,
  AlertOctagon,
  KeyRound,
  ShieldAlert,
  WifiOff,
  ArrowRight,
  RefreshCw,
  Mail,
  Shield,
  HelpCircle,
  Lock
} from 'lucide-react';
import { ScreenId, User } from '../../types';
import { BackButton } from '../common/BackButton';
import { PasswordInput } from '../common/PasswordInput';
import { api } from '../../utils/api';

export type AccountStatusType =
  | 'pending'
  | 'approved'
  | 'rejected'
  | 'suspended'
  | 'expired'
  | 'access-denied'
  | 'integration-unavailable';

interface PendingApprovalScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  initialStatus?: AccountStatusType;
  userEmail?: string;
  currentUser?: User;
}

export const PendingApprovalScreen: React.FC<PendingApprovalScreenProps> = ({
  setCurrentScreen,
  initialStatus = 'pending',
  userEmail = '',
  currentUser
}) => {
  const [status, setStatus] = useState<AccountStatusType>(initialStatus);
  const [emailQuery, setEmailQuery] = useState(userEmail || currentUser?.email || '');
  const [passwordQuery, setPasswordQuery] = useState('');
  const [isChecking, setIsChecking] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [statusDetails, setStatusDetails] = useState<{
    requestedRole?: string;
  } | null>(null);

  const checkLiveStatus = async (targetEmail?: string) => {
    const query = (targetEmail ?? emailQuery).trim();
    if (!query || !passwordQuery) {
      setStatusMessage('Enter both your registered institutional email and password to check clearance status.');
      return;
    }
    setIsChecking(true);
    setStatusMessage(null);
    setStatusDetails(null);

    try {
      const data = await api.checkPendingStatus(query, passwordQuery);

      if (data?.status === 'active') {
        setStatus('approved');
        setStatusDetails({ requestedRole: data.requestedRole });
        setStatusMessage('Your account is approved and active. Proceed to Sign In with your credentials.');
      } else if (data?.status === 'rejected') {
        setStatus('rejected');
        setStatusDetails({ requestedRole: data.requestedRole });
        setStatusMessage('Application rejected by System Security Administrator. Contact your agency liaison for details.');
      } else if (data?.status === 'suspended' || data?.status === 'inactive') {
        setStatus('suspended');
        setStatusMessage(`Account status is '${data.status}'. Contact a System Security Administrator.`);
      } else {
        setStatus('pending');
        setStatusDetails({ requestedRole: data?.requestedRole });
        setStatusMessage(
          `Your registration (Requested Role: ${data?.requestedRole || 'Operator'}) is awaiting System Security Administrator approval.`
        );
      }
    } catch (err: any) {
      if (err?.status === 401 || err?.status === 400 || err?.status === 429) {
        setStatusMessage(err.message || 'Unable to verify credentials.');
      } else {
        setStatus('integration-unavailable');
        setStatusMessage('Authentication service is currently disconnected. Unable to reach enclave verification authority.');
      }
    } finally {
      setIsChecking(false);
    }
  };

  React.useEffect(() => {
    if (userEmail && userEmail.trim()) {
      setEmailQuery(userEmail);
    }
  }, [userEmail]);

  const statusConfigs: Record<
    AccountStatusType,
    {
      title: string;
      subtitle: string;
      icon: React.ElementType;
      badge: string;
      badgeStyle: string;
      cardBorder: string;
      iconColor: string;
      description: string;
      nextActionLabel: string;
      nextAction: () => void;
    }
  > = {
    pending: {
      title: 'Registration Pending Approval',
      subtitle: 'Official Examiner Clearance Workflow',
      icon: Clock,
      badge: 'AWAITING ADMIN REVIEW',
      badgeStyle: 'bg-[#FEF3C7] text-[#B2751E] border-[#C88A2C]/30',
      cardBorder: 'border-[#C88A2C]/40',
      iconColor: 'text-[#C88A2C]',
      description:
        'Your registration docket has been received. In compliance with Federal Digital Forensics Standards and Enclave RBAC policies, access to evidence lockers, AI models, and legal dockets requires credential authorization by a System Security Administrator.',
      nextActionLabel: 'Return to Sign In',
      nextAction: () => setCurrentScreen('signin')
    },
    approved: {
      title: 'Operator Account Approved',
      subtitle: 'Enclave Clearance Confirmed',
      icon: CheckCircle2,
      badge: 'ACTIVE & CERTIFIED',
      badgeStyle: 'bg-[#F0FDF4] text-[#15803D] border-[#15803D]/30',
      cardBorder: 'border-[#15803D]/40',
      iconColor: 'text-[#15803D]',
      description:
        'Your security clearance and institutional affiliation have been verified. You may proceed to authenticate and enter the protected forensic workspace.',
      nextActionLabel: 'Proceed to Sign In',
      nextAction: () => setCurrentScreen('signin')
    },
    rejected: {
      title: 'Clearance Application Rejected',
      subtitle: 'Review Decision Notice',
      icon: XCircle,
      badge: 'APPLICATION REJECTED',
      badgeStyle: 'bg-[#FEF2F2] text-[#B91C1C] border-[#B91C1C]/30',
      cardBorder: 'border-[#B91C1C]/40',
      iconColor: 'text-[#B91C1C]',
      description:
        'The security authority was unable to verify the provided institutional affiliation, agency email, or professional certification. For inquiries, contact your agency forensics liaison.',
      nextActionLabel: 'Submit Revised Request',
      nextAction: () => setCurrentScreen('request-access')
    },
    suspended: {
      title: 'Enclave Access Suspended',
      subtitle: 'Security Restriction Enacted',
      icon: AlertOctagon,
      badge: 'ACCOUNT SUSPENDED',
      badgeStyle: 'bg-[#FEF2F2] text-[#B91C1C] border-[#B91C1C]/30',
      cardBorder: 'border-[#B91C1C]/40',
      iconColor: 'text-[#B91C1C]',
      description:
        'Access to the ALFADetect forensic environment has been administratively locked. Contact the designated System Security Administrator or Chief of Digital Forensics to request credential re-evaluation.',
      nextActionLabel: 'Back to Home',
      nextAction: () => setCurrentScreen('landing')
    },
    expired: {
      title: 'Session Authentication Expired',
      subtitle: 'Zero-Trust Security Timeout',
      icon: KeyRound,
      badge: 'SESSION EXPIRED',
      badgeStyle: 'bg-slate-100 text-slate-700 border-slate-300',
      cardBorder: 'border-slate-300',
      iconColor: 'text-slate-600',
      description:
        'Your cryptographic authorization ticket has expired due to session inactivity or enclave policy timeout. Re-authentication is required to resume evidence analysis.',
      nextActionLabel: 'Sign In Again',
      nextAction: () => setCurrentScreen('signin')
    },
    'access-denied': {
      title: 'Restricted Access — Clearance Required',
      subtitle: 'Role-Based Enclave Boundary',
      icon: ShieldAlert,
      badge: 'ACCESS DENIED',
      badgeStyle: 'bg-[#FEF2F2] text-[#B91C1C] border-[#B91C1C]/30',
      cardBorder: 'border-[#B91C1C]/40',
      iconColor: 'text-[#B91C1C]',
      description:
        'Your current assigned role does not hold the necessary security clearance to execute this action. Actions are strictly partitioned across Investigators, Forensic Examiners, Legal Reviewers, and Administrators.',
      nextActionLabel: 'Go to Dashboard',
      nextAction: () => setCurrentScreen('dashboard')
    },
    'integration-unavailable': {
      title: 'Authentication Service Offline',
      subtitle: 'Enclave Gateway Unreachable',
      icon: WifiOff,
      badge: 'SERVICE DISCONNECTED',
      badgeStyle: 'bg-amber-50 text-amber-800 border-amber-300',
      cardBorder: 'border-amber-300',
      iconColor: 'text-amber-600',
      description:
        'The backend authentication enclave service is currently unreachable or not running on port 3000. Features requiring server-side authentication and persistent database storage are temporarily offline.',
      nextActionLabel: 'Retry Status Check',
      nextAction: () => checkLiveStatus()
    }
  };

  const currentConfig = statusConfigs[status] || statusConfigs.pending;
  const StatusIcon = currentConfig.icon;

  return (
    <div className="min-h-full bg-[#F8FAF9] p-6 flex flex-col justify-center items-center text-[#112217]">
      <div className="w-full max-w-xl space-y-6">
        <div className="flex items-center justify-between">
          <BackButton onClick={() => setCurrentScreen('landing')} label="Back to Home" variant="pill" />
          <span className="text-[11px] font-mono font-semibold text-[#54665C]">
            ALFADetect Account Verification
          </span>
        </div>

        {/* Status Card */}
        <div className={`bg-white border ${currentConfig.cardBorder} rounded-3xl p-8 shadow-sm space-y-6 relative overflow-hidden`}>
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center space-x-3.5">
              <div className={`w-12 h-12 rounded-2xl bg-[#F8FAF9] border border-[#E1EBE4] flex items-center justify-center ${currentConfig.iconColor}`}>
                <StatusIcon className="w-6 h-6" />
              </div>
              <div>
                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${currentConfig.badgeStyle}`}>
                  {currentConfig.badge}
                </span>
                <h1 className="text-xl font-bold text-[#112217] mt-1 font-serif-title">
                  {currentConfig.title}
                </h1>
                <p className="text-xs text-[#54665C]">{currentConfig.subtitle}</p>
              </div>
            </div>
          </div>

          <p className="text-sm text-[#54665C] leading-relaxed bg-[#F8FAF9] p-4 rounded-2xl border border-[#E1EBE4]">
            {currentConfig.description}
          </p>

          {statusMessage && (
            <div className="p-3.5 bg-[#FEF3C7] border border-[#C88A2C]/30 text-[#B2751E] rounded-xl text-xs space-y-1.5">
              <div className="flex items-center space-x-2 font-semibold">
                <HelpCircle className="w-4 h-4 shrink-0" />
                <span>{statusMessage}</span>
              </div>
              {statusDetails?.requestedRole && (
                <div className="pl-6 text-[11px] font-mono space-y-0.5 text-[#7A4F10]">
                  <p>Requested Role: {statusDetails.requestedRole}</p>
                </div>
              )}
            </div>
          )}

          {/* Authenticated Status Check Form (A7) */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              checkLiveStatus();
            }}
            className="space-y-3 pt-2 border-t border-[#E1EBE4]"
          >
            <label className="text-xs font-bold text-[#112217] block">
              Check Clearance Status (Requires Registered Email & Password)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div className="relative">
                <Mail className="w-4 h-4 text-[#54665C] absolute left-3 top-3" />
                <input
                  type="email"
                  required
                  value={emailQuery}
                  onChange={(e) => setEmailQuery(e.target.value)}
                  placeholder="examiner@agency.gov"
                  className="w-full pl-9 pr-3 py-2.5 text-xs bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl text-[#112217] placeholder-slate-400 focus:outline-none focus:border-[#0A3D24] focus:bg-white"
                />
              </div>
              <div>
                <PasswordInput
                  id="pending-status-password"
                  autoComplete="current-password"
                  required
                  value={passwordQuery}
                  onChange={(e) => setPasswordQuery(e.target.value)}
                  placeholder="Your account password"
                  leftIcon={<Lock className="w-4 h-4 text-[#54665C]" />}
                  inputClassName="w-full py-2.5 text-xs bg-[#F8FAF9] border border-[#E1EBE4] rounded-xl text-[#112217] placeholder-slate-400 focus:outline-none focus:border-[#0A3D24] focus:bg-white"
                />
              </div>
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={isChecking || !emailQuery.trim() || !passwordQuery}
                className="px-4 py-2.5 bg-[#0A3D24] hover:bg-[#062817] disabled:opacity-50 text-white font-bold text-xs rounded-xl flex items-center space-x-1.5 transition-colors cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin' : ''}`} />
                <span>{isChecking ? 'Verifying...' : 'Check Status'}</span>
              </button>
            </div>
          </form>

          {/* Action Row */}
          <div className="flex items-center justify-between pt-4 border-t border-[#E1EBE4]">
            <button
              onClick={() => setCurrentScreen('landing')}
              className="text-xs font-semibold text-[#54665C] hover:text-[#0A3D24] cursor-pointer"
            >
              Public Home
            </button>
            <button
              onClick={currentConfig.nextAction}
              className="px-5 py-2.5 bg-[#0A3D24] hover:bg-[#062817] text-white font-bold text-xs rounded-xl shadow-xs flex items-center space-x-2 transition-all cursor-pointer"
            >
              <span>{currentConfig.nextActionLabel}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Regulatory & Institutional Notice */}
        <div className="p-4 bg-white border border-[#E1EBE4] rounded-2xl flex items-center space-x-3 text-xs text-[#54665C]">
          <Shield className="w-4 h-4 text-[#0A3D24] shrink-0" />
          <span>
            Access to deepfake forensic evidence is restricted to authorized personnel in compliance with digital evidence preservation protocols.
          </span>
        </div>
      </div>
    </div>
  );
};
