import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  Cpu,
  AlertTriangle,
  Info,
  CheckCircle2,
  Server
} from 'lucide-react';
import { ScreenId, User } from '../../types';
import { BackButton } from '../common/BackButton';
import { authFetch } from '../../utils/api';

interface ModelComparisonScreenProps {
  setCurrentScreen: (screen: ScreenId) => void;
  currentUser: User;
}

interface TargetArchitectureSpec {
  key: string;
  modelName: string;
  role: string;
  inputRepresentation: string;
  executionMode: string;
}

const TARGET_ARCHITECTURES: TargetArchitectureSpec[] = [
  {
    key: 'acousticDsp',
    modelName: 'DSP Pitch & Spectral Engine (Autocorrelation / YIN / STFT)',
    role: 'Deterministic Acoustic Feature Extraction',
    inputRepresentation: '16kHz–48kHz Decoded PCM Waveform',
    executionMode: 'Local Node.js / WebAudio Server Enclave'
  },
  {
    key: 'cnnVocoder',
    modelName: 'CNN Mel-Spectrogram Vocoder Detector',
    role: 'Spectral Artifact & Vocoder Anomaly Classifier',
    inputRepresentation: '128-Band Log-Mel Spectrogram',
    executionMode: 'External PyTorch Inference Endpoint (ALFADETECT_AI_SERVICE_URL)'
  },
  {
    key: 'bilstmTemporal',
    modelName: 'BiLSTM Acoustic Temporal Sequence Classifier',
    role: 'Temporal Prosody & Pitch Transition Classifier',
    inputRepresentation: 'Frame-Level MFCC / LFCC Sequences',
    executionMode: 'External PyTorch Inference Endpoint (ALFADETECT_AI_SERVICE_URL)'
  },
  {
    key: 'wav2vec2',
    modelName: 'Wav2Vec2 Transformer Forensic Classifier',
    role: 'Self-Supervised Latent Representation Classifier',
    inputRepresentation: 'Raw 16kHz Waveform Embeddings',
    executionMode: 'External PyTorch Inference Endpoint (ALFADETECT_AI_SERVICE_URL)'
  },
  {
    key: 'ecapaTdnn',
    modelName: 'ECAPA-TDNN Speaker Biometric Encoder',
    role: 'Speaker Identity Cosine-Similarity Scoring',
    inputRepresentation: 'Speaker Embedding Vectors (Questioned vs Reference)',
    executionMode: 'External Biometric Endpoint (ALFADETECT_SPEAKER_SERVICE_URL)'
  },
  {
    key: 'xaiGradCamShap',
    modelName: 'Grad-CAM & TreeSHAP Neural Explainability',
    role: 'Neural Activation Heatmap & Feature Attribution',
    inputRepresentation: 'Classifier Gradients & Feature Contributions',
    executionMode: 'External PyTorch XAI Endpoint (ALFADETECT_AI_SERVICE_URL)'
  }
];

export const ModelComparisonScreen: React.FC<ModelComparisonScreenProps> = ({ setCurrentScreen }) => {
  const [modelsStatus, setModelsStatus] = useState<Record<string, any> | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    async function loadStatus() {
      try {
        const res = await authFetch('/api/ai/models-status');
        if (res.ok) {
          const data = await res.json();
          setModelsStatus(data);
        } else {
          setLoadError(`Unable to fetch model registry status (${res.status}).`);
        }
      } catch {
        setLoadError('Network error querying enclave model deployment status.');
      }
    }
    loadStatus();
  }, []);

  return (
    <div id="model-comparison-screen" className="p-6 space-y-6 bg-[#F4F8F6] min-h-full text-slate-800">
      {/* Header */}
      <div className="border-b border-emerald-900/10 pb-5">
        <div className="flex items-center space-x-3 mb-1">
          <BackButton onClick={() => setCurrentScreen('detection-results')} label="Back to Results" variant="pill" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center space-x-2">
          <BarChart3 className="w-6 h-6 text-emerald-700" />
          <span>Model Runtime Registry & Integration Status</span>
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Live forensic runtime deployment verification for DSP analyzers and optional external neural inference adapters.
        </p>
      </div>

      {loadError && (
        <div className="p-3.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-800 font-medium">
          {loadError}
        </div>
      )}

      {/* Live Enclave Deployment Status */}
      <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 flex items-center space-x-2">
            <Cpu className="w-4 h-4 text-emerald-700" />
            <span>Live Enclave Model Deployment Registry</span>
          </h2>
          <span className="text-[10px] font-mono text-emerald-900 font-bold bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
            GET /api/ai/models-status
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          {modelsStatus ? (
            Object.entries(modelsStatus).map(([key, m]: [string, any]) => {
              const isAvailable = m.status === 'AVAILABLE';
              return (
                <div key={key} className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-slate-900">{m.name}</span>
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border shrink-0 ${
                        isAvailable
                          ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                          : 'bg-amber-100 text-amber-900 border-amber-300'
                      }`}
                    >
                      {isAvailable ? 'AVAILABLE' : 'MODEL_UNAVAILABLE'}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 block">{m.type}</span>
                  <p className="text-[11px] text-slate-600 leading-snug">{m.description}</p>
                </div>
              );
            })
          ) : (
            <div className="col-span-full p-4 text-center text-xs text-slate-500">
              Loading enclave model availability...
            </div>
          )}
        </div>

        <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start space-x-2">
          <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
          <span>
            Neural classification, biometric speaker encoding (ECAPA-TDNN), and neural XAI attribution (Grad-CAM / SHAP) explicitly report{' '}
            <strong>MODEL_UNAVAILABLE</strong> until trained PyTorch weights and Python inference endpoints are configured. ALFADetect never fabricates benchmark percentages or classification metrics when checkpoints are absent.
          </span>
        </div>
      </div>

      {/* Honest Model Architecture Matrix (Zero Synthetic Metrics) */}
      <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900">
              Target Forensic Engine & Benchmark Disclosure
            </h2>
            <p className="text-[11px] text-slate-500 flex items-center space-x-1 mt-0.5">
              <Info className="w-3.5 h-3.5 text-slate-400" />
              <span>Evaluated benchmark scores remain N/A until trained model checkpoints run on a verified validation split.</span>
            </p>
          </div>
          <span className="text-[10px] font-mono text-slate-700 font-bold bg-slate-100 px-2.5 py-1 rounded border border-slate-200">
            Strict No-Fabrication Policy Active
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-emerald-50/80 text-emerald-950 uppercase text-[10px] tracking-wider border-b border-emerald-900/10 font-bold">
              <tr>
                <th className="py-3 px-4">Engine / Architecture</th>
                <th className="py-3 px-4">Forensic Role</th>
                <th className="py-3 px-4">Input Representation</th>
                <th className="py-3 px-4">Runtime Target</th>
                <th className="py-3 px-4">Measured Benchmark</th>
                <th className="py-3 px-4 text-right">Enclave Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {TARGET_ARCHITECTURES.map((spec) => {
                const liveEntry = modelsStatus?.[spec.key];
                const isDeployed = liveEntry?.status === 'AVAILABLE';
                const isDsp = spec.key === 'acousticDsp';
                return (
                  <tr key={spec.key} className="hover:bg-emerald-50/40 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-slate-900">{spec.modelName}</td>
                    <td className="py-3.5 px-4 text-slate-600">{spec.role}</td>
                    <td className="py-3.5 px-4 font-mono text-[11px] text-slate-700">{spec.inputRepresentation}</td>
                    <td className="py-3.5 px-4 text-[11px] text-slate-600">{spec.executionMode}</td>
                    <td className="py-3.5 px-4 font-mono text-[11px]">
                      {isDsp ? (
                        <span className="text-emerald-800 font-bold flex items-center space-x-1">
                          <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                          <span>Deterministic DSP</span>
                        </span>
                      ) : isDeployed ? (
                        <span className="text-emerald-800 font-bold">Remote Endpoint Active</span>
                      ) : (
                        <span className="text-slate-500">N/A (Awaiting Checkpoint)</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <span
                        className={`text-[10px] font-bold font-mono px-2.5 py-0.5 rounded-full border ${
                          isDeployed
                            ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                            : 'bg-amber-50 text-amber-800 border-amber-300'
                        }`}
                      >
                        {isDeployed ? 'AVAILABLE' : 'MODEL_UNAVAILABLE'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 flex items-start space-x-3">
          <Server className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold text-slate-800">External Python / PyTorch Service Integration</p>
            <p className="text-[11px] leading-relaxed">
              Configure <code className="font-mono bg-white px-1 py-0.5 rounded border border-slate-200">ALFADETECT_AI_SERVICE_URL</code> and{' '}
              <code className="font-mono bg-white px-1 py-0.5 rounded border border-slate-200">ALFADETECT_SPEAKER_SERVICE_URL</code> to connect FastAPI/PyTorch inference containers exposing <code className="font-mono">/predict/cnn</code>, <code className="font-mono">/predict/bilstm</code>, <code className="font-mono">/predict/wav2vec2</code>, and ECAPA-TDNN embedding comparison.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
