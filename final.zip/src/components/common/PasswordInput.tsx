import React, { useState, useId } from 'react';
import { Eye, EyeOff, CheckCircle2, Circle } from 'lucide-react';

export interface PasswordRequirementStatus {
  id: string;
  label: string;
  met: boolean;
}

export function evaluatePasswordRequirements(password: string, email?: string): PasswordRequirementStatus[] {
  const val = typeof password === 'string' ? password : '';
  const localPart = email ? String(email).split('@')[0]?.trim().toLowerCase() : '';
  const hasLongLocalPart = Boolean(localPart && localPart.length >= 3);

  const items: PasswordRequirementStatus[] = [
    { id: 'length', label: 'At least 12 characters', met: val.length >= 12 },
    { id: 'upper', label: 'Uppercase letter (A-Z)', met: /[A-Z]/.test(val) },
    { id: 'lower', label: 'Lowercase letter (a-z)', met: /[a-z]/.test(val) },
    { id: 'digit', label: 'Number (0-9)', met: /[0-9]/.test(val) },
    { id: 'special', label: 'Special character (!@#$...)', met: /[^A-Za-z0-9]/.test(val) }
  ];

  if (hasLongLocalPart) {
    items.push({
      id: 'no-email',
      label: 'Does not contain email username',
      met: val.length > 0 && !val.toLowerCase().includes(localPart)
    });
  }

  return items;
}

export const PasswordStrengthChecklist: React.FC<{
  password: string;
  email?: string;
  className?: string;
}> = ({ password, email, className = '' }) => {
  const checks = evaluatePasswordRequirements(password, email);

  return (
    <div
      className={`mt-2 p-2.5 rounded-lg bg-[#F8FAF9] border border-[#E2E8F0] grid grid-cols-1 sm:grid-cols-2 gap-1.5 ${className}`}
      aria-live="polite"
    >
      {checks.map((item) => (
        <div
          key={item.id}
          className={`flex items-center space-x-1.5 text-[11px] font-medium ${
            item.met ? 'text-[#0A3D24]' : 'text-[#64748B]'
          }`}
        >
          {item.met ? (
            <CheckCircle2 className="w-3.5 h-3.5 text-[#16A34A] shrink-0" />
          ) : (
            <Circle className="w-3.5 h-3.5 text-[#94A3B8] shrink-0" />
          )}
          <span>{item.label}</span>
        </div>
      ))}
    </div>
  );
};

export interface PasswordInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: string;
  error?: string;
  leftIcon?: React.ReactNode;
  containerClassName?: string;
  inputClassName?: string;
  showStrengthChecklist?: boolean;
  emailForStrengthCheck?: string;
  buttonClassName?: string;
}

export const PasswordInput: React.FC<PasswordInputProps> = ({
  id,
  label,
  error,
  leftIcon,
  containerClassName = '',
  inputClassName = '',
  showStrengthChecklist = false,
  emailForStrengthCheck,
  buttonClassName = '',
  value,
  disabled,
  ...rest
}) => {
  const [visible, setVisible] = useState(false);
  const generatedId = useId();
  const inputId = id || generatedId;
  const valStr = typeof value === 'string' ? value : value !== undefined ? String(value) : '';

  const baseInputClasses = inputClassName
    ? inputClassName
    : 'w-full py-2.5 bg-[#F8FAF9] border border-[#CBD5E1] rounded-lg text-sm text-[#0F172A] focus:outline-none focus:border-[#0A3D24] focus:bg-white transition-colors';

  const paddingClasses = `${leftIcon ? 'pl-10' : 'pl-3'} pr-10`;

  return (
    <div className={containerClassName}>
      {label && (
        <label
          htmlFor={inputId}
          className="block text-[11px] font-bold text-[#475569] uppercase tracking-wider mb-1.5"
        >
          {label}
        </label>
      )}
      <div className="relative flex items-center">
        {leftIcon && (
          <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 flex items-center">
            {leftIcon}
          </span>
        )}
        <input
          {...rest}
          id={inputId}
          type={visible ? 'text' : 'password'}
          value={value}
          disabled={disabled}
          aria-invalid={Boolean(error)}
          className={`${baseInputClasses} ${paddingClasses}`}
        />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          disabled={disabled}
          aria-label={visible ? 'Hide password' : 'Show password'}
          aria-pressed={visible}
          title={visible ? 'Hide password' : 'Show password'}
          className={`absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-md text-[#64748B] hover:text-[#0A3D24] hover:bg-black/5 focus:outline-none focus:ring-2 focus:ring-[#0A3D24]/40 transition-colors disabled:opacity-40 ${buttonClassName}`}
        >
          {visible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
        </button>
      </div>
      {error && <p className="mt-1 text-xs font-medium text-[#DC2626]">{error}</p>}
      {showStrengthChecklist && (
        <PasswordStrengthChecklist password={valStr} email={emailForStrengthCheck} />
      )}
    </div>
  );
};
