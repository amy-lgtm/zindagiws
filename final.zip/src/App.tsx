import React, { useState, useEffect } from 'react';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { AccessDeniedView } from './components/common/AccessDeniedView';

import { LandingScreen } from './components/screens/LandingScreen';
import { WorkflowScreen } from './components/screens/WorkflowScreen';
import { SignInScreen, LoginMeta } from './components/screens/SignInScreen';
import { RequestAccessScreen } from './components/screens/RequestAccessScreen';
import { DashboardScreen } from './components/screens/DashboardScreen';
import { CaseManagementScreen } from './components/screens/CaseManagementScreen';
import { EvidenceManagementScreen } from './components/screens/EvidenceManagementScreen';
import { ChainOfCustodyScreen } from './components/screens/ChainOfCustodyScreen';
import { HashIntegrityScreen } from './components/screens/HashIntegrityScreen';
import { AiPipelineScreen } from './components/screens/AiPipelineScreen';
import { DetectionResultsScreen } from './components/screens/DetectionResultsScreen';
import { SpeakerVerificationScreen } from './components/screens/SpeakerVerificationScreen';
import { VoiceDisguiseScreen } from './components/screens/VoiceDisguiseScreen';
import { ModelComparisonScreen } from './components/screens/ModelComparisonScreen';
import { ExplainableAiScreen } from './components/screens/ExplainableAiScreen';
import { ExpertValidationScreen } from './components/screens/ExpertValidationScreen';
import { LegalReviewScreen } from './components/screens/LegalReviewScreen';
import { ReportGenerationScreen } from './components/screens/ReportGenerationScreen';
import { AuditLogScreen } from './components/screens/AuditLogScreen';
import { NotificationCentreScreen } from './components/screens/NotificationCentreScreen';
import { AdminPanelScreen } from './components/screens/AdminPanelScreen';
import { SettingsScreen } from './components/screens/SettingsScreen';
import { PublicVerificationScreen } from './components/screens/PublicVerificationScreen';
import { PendingApprovalScreen } from './components/screens/PendingApprovalScreen';

import { Shield, Lock, KeyRound, AlertCircle, CheckCircle2, ShieldAlert, Sparkles } from 'lucide-react';

import {
  ScreenId,
  UserRole,
  User,
  Case,
  AudioEvidence,
  NotificationItem,
  ExpertReview
} from './types';

import { authFetch, api } from './utils/api';
import { stopAudioEvidence } from './utils/audioPlayer';
import { BackButton } from './components/common/BackButton';
import { PasswordInput } from './components/common/PasswordInput';
import { isScreenAllowed } from './utils/rbac';

const INITIAL_GUEST_USER: User = {
  id: '',
  name: 'Unauthenticated Operator',
  email: '',
  role: 'Lead Forensic Analyst',
  agency: 'National Forensics Institute',
  avatar: '?',
  status: 'inactive',
  casesCount: 0
};

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenId>(() => {
    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      const token = urlParams.get('token');
      const scr = urlParams.get('screen') as ScreenId;
      if (token || scr === 'public-verify') return 'public-verify';
      if (scr) return scr;
    }
    return 'landing';
  });
  const [historyStack, setHistoryStack] = useState<ScreenId[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  // Security & Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return !!localStorage.getItem('auth_session_token');
    }
    return false;
  });
  const [isLocked, setIsLocked] = useState(false);
  const [unlockPassword, setUnlockPassword] = useState('');
  const [unlockTotp, setUnlockTotp] = useState('');
  const [unlockError, setUnlockError] = useState('');
  const [isUnlocking, setIsUnlocking] = useState(false);

  // Forced Initial Password Change state (A8)
  const [forceCurPw, setForceCurPw] = useState('');
  const [forceNewPw, setForceNewPw] = useState('');
  const [forceConfirmPw, setForceConfirmPw] = useState('');
  const [forcePwError, setForcePwError] = useState('');
  const [isRotatingForcedPw, setIsRotatingForcedPw] = useState(false);

  // App-wide state: Clean initial states (No unintended sample user or mock case pollution)
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('deepfake_detector_user');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch (e) {}
      }
    }
    return INITIAL_GUEST_USER;
  });

  const [cases, setCases] = useState<Case[]>([]);
  const [selectedCaseId, setSelectedCaseId] = useState<string>('');
  const [pendingApprovalEmail, setPendingApprovalEmail] = useState<string>('');
  const [activeEvidence, setActiveEvidence] = useState<AudioEvidence>({
    id: 'EV-INIT',
    caseId: '',
    filename: 'No active evidence selected',
    fileSize: '0 MB',
    duration: '00:00',
    sampleRate: '44.1 kHz',
    bitDepth: '16-bit',
    channels: 'Stereo',
    sha256Hash: '',
    uploadTimestamp: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
    uploadedBy: 'None',
    status: 'Uploaded'
  });
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [isNewCaseModalOpen, setIsNewCaseModalOpen] = useState(false);
  const [expertReviews, setExpertReviews] = useState<ExpertReview[]>([]);
  const [selectedExpertId, setSelectedExpertId] = useState<string>('');
  const [twoFactorEnrollmentRequired, setTwoFactorEnrollmentRequired] = useState<boolean>(false);
  const [idleLockMinutes, setIdleLockMinutes] = useState<number>(5);
  const [sessionNotice, setSessionNotice] = useState<string | null>(null);
  const [signInPrefillEmail, setSignInPrefillEmail] = useState<string>('');

  // Synchronize Navigation with Browser History
  const navigateTo = (screen: ScreenId, replace = false) => {
    if (!replace && screen !== currentScreen) {
      setHistoryStack((prev) => [...prev, currentScreen]);
    }
    setCurrentScreen(screen);
    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      url.searchParams.set('screen', screen);
      if (replace) {
        window.history.replaceState({ screen }, '', url.toString());
      } else {
        window.history.pushState({ screen }, '', url.toString());
      }
    }
  };

  const navigateBack = () => {
    if (historyStack.length > 0) {
      const nextStack = [...historyStack];
      const prev = nextStack.pop()!;
      setHistoryStack(nextStack);
      setCurrentScreen(prev);
      if (typeof window !== 'undefined') {
        const url = new URL(window.location.href);
        url.searchParams.set('screen', prev);
        window.history.pushState({ screen: prev }, '', url.toString());
      }
    } else {
      const fallback: ScreenId = isAuthenticated ? 'dashboard' : 'landing';
      setCurrentScreen(fallback);
      if (typeof window !== 'undefined') {
        const url = new URL(window.location.href);
        url.searchParams.set('screen', fallback);
        window.history.pushState({ screen: fallback }, '', url.toString());
      }
    }
  };

  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      const target = event.state?.screen || new URLSearchParams(window.location.search).get('screen');
      if (target && isScreenAllowed(currentUser.role, target as ScreenId)) {
        setCurrentScreen(target as ScreenId);
      } else {
        setCurrentScreen(isAuthenticated ? 'dashboard' : 'landing');
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [isAuthenticated, currentUser.role]);

  // Automatic Session Idle Lock Security (Configurable Admin Policy, Default 5-Minute Inactivity)
  useEffect(() => {
    let idleTimer: ReturnType<typeof setTimeout>;
    const timeoutMs = Math.max(1, idleLockMinutes || 5) * 60 * 1000;
    const resetIdleTimer = () => {
      clearTimeout(idleTimer);
      if (isAuthenticated && !isLocked) {
        idleTimer = setTimeout(() => {
          setIsLocked(true);
        }, timeoutMs);
      }
    };

    window.addEventListener('mousemove', resetIdleTimer);
    window.addEventListener('keydown', resetIdleTimer);
    window.addEventListener('click', resetIdleTimer);

    resetIdleTimer();

    return () => {
      clearTimeout(idleTimer);
      window.removeEventListener('mousemove', resetIdleTimer);
      window.removeEventListener('keydown', resetIdleTimer);
      window.removeEventListener('click', resetIdleTimer);
    };
  }, [isAuthenticated, isLocked, idleLockMinutes]);

  // Apply persisted light / dark / system theme preference cleanly across document
  useEffect(() => {
    const pref: 'light' | 'dark' | 'system' =
      currentUser?.themePreference ||
      ((typeof window !== 'undefined' && localStorage.getItem('alfadetect_theme')) as any) ||
      'light';

    if (typeof window === 'undefined') return;
    localStorage.setItem('alfadetect_theme', pref);

    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const apply = () => {
      const useDark = pref === 'dark' || (pref === 'system' && media.matches);
      document.documentElement.classList.toggle('dark', useDark);
    };
    apply();

    if (pref === 'system') {
      media.addEventListener('change', apply);
      return () => media.removeEventListener('change', apply);
    }
  }, [currentUser?.themePreference]);

  const resetClientSessionState = (targetScreen: ScreenId = 'signin', preserveNotice = false) => {
    stopAudioEvidence();
    localStorage.removeItem('auth_session_token');
    localStorage.removeItem('deepfake_detector_user');
    setIsAuthenticated(false);
    setIsLocked(false);
    setUnlockPassword('');
    setUnlockTotp('');
    setUnlockError('');
    setSearchQuery('');
    setIsNewCaseModalOpen(false);
    setForceCurPw('');
    setForceNewPw('');
    setForceConfirmPw('');
    setForcePwError('');
    setCurrentUser(INITIAL_GUEST_USER);
    setCases([]);
    setSelectedCaseId('');
    setActiveEvidence({
      id: 'EV-INIT',
      caseId: '',
      filename: 'No active evidence selected',
      fileSize: '0 MB',
      duration: '00:00',
      sampleRate: '44.1 kHz',
      bitDepth: '16-bit',
      channels: 'Stereo',
      sha256Hash: '',
      uploadTimestamp: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
      uploadedBy: 'None',
      status: 'Uploaded'
    });
    setExpertReviews([]);
    setSelectedExpertId('');
    setPendingApprovalEmail('');
    setTwoFactorEnrollmentRequired(false);
    setIdleLockMinutes(5);
    setUsers([]);
    setNotifications([]);
    setHistoryStack([]);
    if (!preserveNotice) {
      setSessionNotice(null);
    }
    navigateTo(targetScreen, true);
  };

  // Global 401/disabled-account session expiry listener & live admin config policy sync
  useEffect(() => {
    const onSessionExpired = (event: Event) => {
      const detail = (event as CustomEvent<{ message?: string }>).detail;
      setSessionNotice(detail?.message || 'Session expired, please sign in again.');
      resetClientSessionState('signin', true);
    };

    const onConfigUpdated = (event: Event) => {
      const detail = (event as CustomEvent<Record<string, any>>).detail;
      if (detail && typeof detail.idleLockMinutes === 'number') {
        setIdleLockMinutes(detail.idleLockMinutes);
      }
      if (detail && typeof detail.enforceTwoFactor === 'boolean') {
        setTwoFactorEnrollmentRequired(Boolean(detail.enforceTwoFactor && !currentUser.twoFactorEnabled));
      }
    };

    window.addEventListener('alfadetect:session-expired', onSessionExpired);
    window.addEventListener('alfadetect:config-updated', onConfigUpdated);
    return () => {
      window.removeEventListener('alfadetect:session-expired', onSessionExpired);
      window.removeEventListener('alfadetect:config-updated', onConfigUpdated);
    };
  }, [currentUser.twoFactorEnabled]);

  // Verify active session (Bearer or HttpOnly cookie) with backend on startup and auth transition
  useEffect(() => {
    async function loadEnrolledUsers() {
      try {
        const res = await authFetch('/api/users');
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) {
            setUsers(data);
          }
        }
      } catch (err) {
        console.warn('Users directory sync note:', err);
      }
    }

    async function loadCases() {
      try {
        const res = await authFetch('/api/cases');
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) {
            setCases(data);
            if (data.length > 0) {
              setSelectedCaseId((prev) => prev || data[0].id);
            }
          }
        }
      } catch (err) {
        console.warn('Cases sync note:', err);
      }
    }

    async function loadNotifications() {
      try {
        const res = await authFetch('/api/notifications');
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) {
            setNotifications(data);
          }
        }
      } catch (err) {
        console.warn('Notifications sync note:', err);
      }
    }

    async function checkAuthSession() {
      const hadLocalToken = Boolean(localStorage.getItem('auth_session_token'));
      try {
        const res = await authFetch('/api/auth/me');
        if (res.ok) {
          const data = await res.json();
          if (data.authenticated && data.user) {
            setCurrentUser(data.user);
            localStorage.setItem('deepfake_detector_user', JSON.stringify(data.user));
            const needs2fa = Boolean(data.twoFactorEnrollmentRequired && !data.user.twoFactorEnabled);
            setTwoFactorEnrollmentRequired(needs2fa);
            if (typeof data.sessionPolicy?.idleLockMinutes === 'number') {
              setIdleLockMinutes(data.sessionPolicy.idleLockMinutes);
            }
            setIsAuthenticated(true);

            // Only fetch operational data once forced password rotation & mandatory 2FA are satisfied
            if (!data.user.mustChangePassword && !needs2fa) {
              loadCases();
              if (data.user.role === 'System Security Administrator') {
                loadEnrolledUsers();
              }
              loadNotifications();
            }
            return;
          }
        }
        if (hadLocalToken || isAuthenticated) {
          resetClientSessionState('signin', false);
        }
      } catch (err) {
        console.warn('Session verification note:', err);
      }
    }

    checkAuthSession();
  }, [isAuthenticated]);

  // Redirect already-authenticated operators off signin / request-access screens
  useEffect(() => {
    if (isAuthenticated && (currentScreen === 'signin' || currentScreen === 'request-access')) {
      navigateTo(
        twoFactorEnrollmentRequired && !currentUser.twoFactorEnabled ? 'settings' : 'dashboard',
        true
      );
    }
  }, [isAuthenticated, currentScreen, twoFactorEnrollmentRequired, currentUser.twoFactorEnabled]);

  const handleLoginSuccess = (user?: User, meta?: LoginMeta) => {
    if (user) {
      setCurrentUser(user);
      localStorage.setItem('deepfake_detector_user', JSON.stringify(user));
    }
    const needs2fa = Boolean(meta?.twoFactorEnrollmentRequired && !user?.twoFactorEnabled);
    setTwoFactorEnrollmentRequired(needs2fa);
    if (typeof meta?.sessionPolicy?.idleLockMinutes === 'number') {
      setIdleLockMinutes(meta.sessionPolicy.idleLockMinutes);
    }
    setSessionNotice(null);
    setSignInPrefillEmail('');
    setIsAuthenticated(true);
    navigateTo(needs2fa ? 'settings' : 'dashboard', true);
  };

  // New registrations NEVER auto-login — capture email for PendingApprovalScreen status lookup
  const handleRegistrationSubmitted = (submittedEmail: string) => {
    setPendingApprovalEmail(submittedEmail);
  };

  const handleRegisterExpert = (newExpert: ExpertReview) => {
    setExpertReviews((prev) => [newExpert, ...prev.filter((e) => e.id !== newExpert.id)]);
    setSelectedExpertId(newExpert.id);
  };

  const handleSignOut = async () => {
    try {
      await authFetch('/api/auth/logout', { method: 'POST' });
    } catch {}
    resetClientSessionState('signin', false);
  };

  const handleLockSession = () => {
    setIsLocked(true);
  };

  const handleUnlockSession = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!unlockPassword) {
      setUnlockError('Please enter your account password to unlock.');
      return;
    }
    setIsUnlocking(true);
    setUnlockError('');

    try {
      const res = await authFetch('/api/auth/reauth', {
        method: 'POST',
        body: JSON.stringify({
          password: unlockPassword,
          totpCode: currentUser.twoFactorEnabled ? unlockTotp.trim() : undefined
        })
      });
      const data = await res.json();
      if (res.ok && data.unlocked) {
        setIsLocked(false);
        setUnlockPassword('');
        setUnlockTotp('');
        setUnlockError('');
      } else if (res.status === 423 || data?.lockedOut) {
        const lockMessage = data?.error || 'Account locked due to repeated failed unlock attempts. Session terminated.';
        setSessionNotice(lockMessage);
        resetClientSessionState('signin', true);
      } else {
        setUnlockError(data.error || 'Authentication failed: Invalid credentials.');
      }
    } catch {
      setUnlockError('Connection error during re-authentication.');
    } finally {
      setIsUnlocking(false);
    }
  };

  const handleForcedPasswordRotation = async (e: React.FormEvent) => {
    e.preventDefault();
    setForcePwError('');
    if (!forceCurPw || !forceNewPw) {
      setForcePwError('Temporary password and new password are required.');
      return;
    }
    if (forceNewPw !== forceConfirmPw) {
      setForcePwError('New password and confirmation do not match.');
      return;
    }
    setIsRotatingForcedPw(true);
    try {
      const res = await api.changePassword({ currentPassword: forceCurPw, newPassword: forceNewPw });
      const updatedUser: User = res?.user || { ...currentUser, mustChangePassword: false };
      setCurrentUser(updatedUser);
      localStorage.setItem('deepfake_detector_user', JSON.stringify(updatedUser));
      setForceCurPw('');
      setForceNewPw('');
      setForceConfirmPw('');
      // Re-trigger /api/auth/me hydration now that mustChangePassword is false
      const meRes = await authFetch('/api/auth/me');
      if (meRes.ok) {
        const meData = await meRes.json();
        const needs2fa = Boolean(meData?.twoFactorEnrollmentRequired && !updatedUser.twoFactorEnabled);
        setTwoFactorEnrollmentRequired(needs2fa);
        if (needs2fa) navigateTo('settings', true);
      }
    } catch (err: any) {
      setForcePwError(err?.message || 'Password rotation failed.');
    } finally {
      setIsRotatingForcedPw(false);
    }
  };

  // Mandatory 2FA enrollment gate: blocks workspace navigation until TOTP is verified when policy enforces 2FA
  const isForced2faGate =
    isAuthenticated &&
    !currentUser.mustChangePassword &&
    twoFactorEnrollmentRequired &&
    !currentUser.twoFactorEnabled;

  // Full-screen pages without sidebar (landing, signin, request-access, workflow, public-verify, pending-approval)
  const isFullScreenPage =
    !isAuthenticated ||
    isForced2faGate ||
    currentScreen === 'landing' ||
    currentScreen === 'workflow' ||
    currentScreen === 'signin' ||
    currentScreen === 'request-access' ||
    currentScreen === 'pending-approval' ||
    currentScreen === 'public-verify';

  // Check RBAC permission for currently targeted screen
  const isTargetScreenAllowed = isScreenAllowed(currentUser.role, currentScreen);

  return (
    <div className="min-h-screen bg-[#F4F8F6] text-slate-900 flex flex-col font-sans selection:bg-emerald-600 selection:text-white antialiased">
      
      {/* Top Security & Classification Bar - National Green & White */}
      <div className="bg-[#032319] border-b border-[#083D2D] px-4 py-1 flex justify-between items-center text-[10px] font-mono text-emerald-300 select-none z-50">
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="text-emerald-300 font-bold uppercase tracking-wider">
            NATIONAL FORENSICS // FRE 902(13)/(14) SELF-AUTHENTICATING // CUI
          </span>
        </div>
        <div className="hidden sm:flex items-center space-x-4 text-emerald-400/90 font-medium">
          {isAuthenticated ? (
            <span>ROLE: <strong className="text-white">{currentUser.role}</strong></span>
          ) : (
            <span>STATUS: <strong className="text-white">Not signed in</strong></span>
          )}
          <span>ISO/IEC 27037 FORENSIC CHAIN OF CUSTODY</span>
          <span className="text-emerald-300 font-bold">ED25519 / SHA-256 AUDIT ENCLAVE</span>
        </div>
      </div>

      {/* Top Navigation Bar */}
      {!isFullScreenPage && (
        <Navbar
          currentScreen={currentScreen}
          setCurrentScreen={navigateTo}
          currentUser={currentUser}
          users={users}
          cases={cases}
          setSelectedCaseId={setSelectedCaseId}
          notifications={notifications}
          toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
          isSidebarOpen={isSidebarOpen}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          onLockSession={handleLockSession}
          onSignOut={handleSignOut}
          idleLockSeconds={idleLockMinutes * 60}
        />
      )}

      {/* Non-Dismissible Forced Initial Password Change Modal (A8) */}
      {isAuthenticated && currentUser.mustChangePassword && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#0A3D24]/20 rounded-3xl max-w-md w-full p-8 space-y-5 shadow-2xl">
            <div className="w-14 h-14 bg-[#FEF3C7] border border-[#C88A2C]/30 rounded-2xl flex items-center justify-center text-[#B2751E] mx-auto shadow-md">
              <KeyRound className="w-7 h-7" />
            </div>

            <div className="text-center">
              <h3 className="text-xl font-bold text-[#112217] font-serif-title">Mandatory Password Rotation</h3>
              <p className="text-xs text-[#54665C] mt-1 leading-relaxed">
                Your account was provisioned with an administrator-issued temporary password. Set a personal strong password (12+ chars, A-z, 0-9, symbol, excluding your email) to unlock enclave access.
              </p>
            </div>

            {forcePwError && (
              <p className="text-xs text-[#B91C1C] font-mono bg-[#FEF2F2] p-2.5 rounded-xl border border-[#B91C1C]/30">
                {forcePwError}
              </p>
            )}

            <form onSubmit={handleForcedPasswordRotation} className="space-y-3 text-xs">
              <div>
                <label className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                  Current / Temporary Password *
                </label>
                <PasswordInput
                  required
                  value={forceCurPw}
                  onChange={(e) => setForceCurPw(e.target.value)}
                  autoComplete="current-password"
                  className="bg-[#F8FAF9] border-[#E1EBE4] px-3.5 py-2.5 text-[#112217]"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                  New Personal Password (12+ chars, A-z, 0-9, symbol) *
                </label>
                <PasswordInput
                  required
                  value={forceNewPw}
                  onChange={(e) => setForceNewPw(e.target.value)}
                  autoComplete="new-password"
                  showStrengthChecklist
                  emailForStrengthCheck={currentUser.email}
                  className="bg-[#F8FAF9] border-[#E1EBE4] px-3.5 py-2.5 text-[#112217]"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase text-[#54665C] block mb-1">
                  Confirm New Password *
                </label>
                <PasswordInput
                  required
                  value={forceConfirmPw}
                  onChange={(e) => setForceConfirmPw(e.target.value)}
                  autoComplete="new-password"
                  className="bg-[#F8FAF9] border-[#E1EBE4] px-3.5 py-2.5 text-[#112217]"
                />
              </div>

              <div className="flex space-x-3 pt-2">
                <button
                  type="button"
                  onClick={handleSignOut}
                  className="flex-1 py-2.5 bg-white hover:bg-slate-50 border border-[#E1EBE4] text-[#54665C] font-bold text-xs rounded-xl cursor-pointer"
                >
                  Sign Out
                </button>
                <button
                  type="submit"
                  disabled={isRotatingForcedPw}
                  className="flex-1 py-2.5 bg-[#0A3D24] hover:bg-[#062817] disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer"
                >
                  {isRotatingForcedPw ? 'Updating...' : 'Save & Continue'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Session Lock Modal */}
      {isLocked && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#0A3D24]/20 rounded-3xl max-w-md w-full p-8 space-y-6 text-center shadow-2xl">
            <div className="w-14 h-14 bg-[#F0FDF4] border border-[#15803D]/30 rounded-2xl flex items-center justify-center text-[#0A3D24] mx-auto shadow-md">
              <Lock className="w-7 h-7" />
            </div>

            <div>
              <h3 className="text-xl font-bold text-[#112217] font-serif-title">Forensic Terminal Locked</h3>
              <p className="text-xs text-[#54665C] mt-1 leading-relaxed">
                Re-enter your account credentials to resume the active forensic session for <strong className="text-[#112217]">{currentUser.name}</strong> ({currentUser.role}).
              </p>
            </div>

            {unlockError && (
              <p className="text-xs text-[#B91C1C] font-mono bg-[#FEF2F2] p-2.5 rounded-xl border border-[#B91C1C]/30 text-left">
                {unlockError}
              </p>
            )}

            <form onSubmit={handleUnlockSession} className="space-y-4">
              <div className="text-left space-y-1">
                <label className="text-[11px] font-bold uppercase text-[#54665C]">Account Password</label>
                <PasswordInput
                  required
                  value={unlockPassword}
                  onChange={(e) => setUnlockPassword(e.target.value)}
                  autoComplete="current-password"
                  placeholder="Enter your account password"
                  className="bg-[#F8FAF9] border-[#E1EBE4] rounded-2xl px-4 py-3 text-sm text-[#112217] focus:outline-hidden focus:border-[#0A3D24]"
                />
              </div>

              {currentUser.twoFactorEnabled && (
                <div className="text-left space-y-1">
                  <label className="text-[11px] font-bold uppercase text-[#54665C]">Authenticator App TOTP Code</label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={unlockTotp}
                    onChange={(e) => setUnlockTotp(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="6-digit TOTP code"
                    className="w-full bg-[#F8FAF9] border border-[#E1EBE4] rounded-2xl px-4 py-2.5 text-sm font-mono text-[#112217] focus:outline-hidden focus:border-[#0A3D24]"
                  />
                </div>
              )}

              <div className="flex space-x-3 pt-2">
                <button
                  type="button"
                  onClick={handleSignOut}
                  className="flex-1 py-2.5 bg-white hover:bg-slate-50 border border-[#E1EBE4] text-[#54665C] font-bold text-xs rounded-xl transition-colors cursor-pointer"
                >
                  Sign Out
                </button>
                <button
                  type="submit"
                  disabled={isUnlocking}
                  className="flex-1 py-2.5 bg-[#0A3D24] hover:bg-[#062817] disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer"
                >
                  {isUnlocking ? 'Verifying...' : 'Unlock Session'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        {/* Persistent National Forest Green Sidebar */}
        {!isFullScreenPage && (
          <Sidebar
            currentScreen={currentScreen}
            setCurrentScreen={navigateTo}
            isOpen={isSidebarOpen}
            currentUser={currentUser}
            unreadNotificationsCount={notifications.filter((n) => !n.read).length}
          />
        )}

        {/* Main Content Router View */}
        <main className="flex-1 overflow-y-auto min-w-0 bg-[#F4F8F6]">
          {isForced2faGate ? (
            <div className="max-w-5xl mx-auto p-4 sm:p-6 space-y-4">
              <div className="px-4 py-3.5 bg-[#FEF3C7] border border-[#C88A2C]/40 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs text-[#925E12] shadow-xs">
                <div className="flex items-center space-x-2.5">
                  <ShieldAlert className="w-5 h-5 text-[#B2751E] shrink-0" />
                  <div>
                    <strong className="block text-[#78490A]">Mandatory Two-Factor Authentication Required</strong>
                    <span>Institutional security policy enforces RFC 6238 TOTP enrollment before accessing any operational screens.</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleSignOut}
                  className="px-3.5 py-2 bg-white hover:bg-slate-50 border border-[#C88A2C]/40 text-[#925E12] font-bold rounded-xl text-xs cursor-pointer"
                >
                  Sign Out
                </button>
              </div>

              <SettingsScreen
                setCurrentScreen={navigateTo}
                currentUser={currentUser}
                setCurrentUser={setCurrentUser}
                initialTab="2FA"
                forcedTwoFactorSetup={true}
                onTwoFactorVerified={() => {
                  setTwoFactorEnrollmentRequired(false);
                  navigateTo('dashboard', true);
                }}
              />
            </div>
          ) : !isAuthenticated && currentScreen !== 'landing' && currentScreen !== 'workflow' && currentScreen !== 'request-access' && currentScreen !== 'pending-approval' && currentScreen !== 'public-verify' ? (
            <SignInScreen
              setCurrentScreen={navigateTo}
              onLoginSuccess={handleLoginSuccess}
              onPendingEmailDetected={(pendingMail) => setPendingApprovalEmail(pendingMail)}
              initialEmail={signInPrefillEmail}
              sessionNotice={sessionNotice}
              onClearSessionNotice={() => setSessionNotice(null)}
            />
          ) : !isFullScreenPage && !isTargetScreenAllowed ? (
            /* RBAC Access Denied Route Guard */
            <AccessDeniedView
              screenId={currentScreen}
              currentUserRole={currentUser.role}
              setCurrentScreen={navigateTo}
            />
          ) : (
            <>
              {currentScreen === 'landing' && (
                <LandingScreen setCurrentScreen={navigateTo} />
              )}

              {currentScreen === 'workflow' && (
                <WorkflowScreen setCurrentScreen={navigateTo} />
              )}

              {currentScreen === 'signin' && (
                <SignInScreen
                  setCurrentScreen={navigateTo}
                  onLoginSuccess={handleLoginSuccess}
                  onPendingEmailDetected={(pendingMail) => setPendingApprovalEmail(pendingMail)}
                  initialEmail={signInPrefillEmail}
                  sessionNotice={sessionNotice}
                  onClearSessionNotice={() => setSessionNotice(null)}
                />
              )}

              {currentScreen === 'request-access' && (
                <RequestAccessScreen
                  setCurrentScreen={navigateTo}
                  onRegisterExpert={handleRegisterExpert}
                  setSelectedExpertId={setSelectedExpertId}
                  onRegistrationSubmitted={handleRegistrationSubmitted}
                  onDuplicateEmailSignIn={(mail, msg) => {
                    setSignInPrefillEmail(mail);
                    setSessionNotice(msg || null);
                  }}
                />
              )}

              {currentScreen === 'dashboard' && (
                <DashboardScreen
                  setCurrentScreen={navigateTo}
                  setSelectedCaseId={setSelectedCaseId}
                  cases={cases}
                  currentUser={currentUser}
                  onOpenNewCaseModal={() => {
                    navigateTo('cases');
                    setIsNewCaseModalOpen(true);
                  }}
                />
              )}

              {currentScreen === 'cases' && (
                <CaseManagementScreen
                  setCurrentScreen={navigateTo}
                  setSelectedCaseId={setSelectedCaseId}
                  cases={cases}
                  setCases={setCases}
                  isNewCaseModalOpen={isNewCaseModalOpen}
                  setIsNewCaseModalOpen={setIsNewCaseModalOpen}
                  currentUser={currentUser}
                />
              )}

              {currentScreen === 'evidence' && (
                <EvidenceManagementScreen
                  setCurrentScreen={navigateTo}
                  activeEvidence={activeEvidence}
                  setActiveEvidence={setActiveEvidence}
                  currentUser={currentUser}
                  selectedCaseId={selectedCaseId}
                  cases={cases}
                />
              )}

              {currentScreen === 'chain-of-custody' && (
                <ChainOfCustodyScreen
                  setCurrentScreen={navigateTo}
                  selectedCaseId={selectedCaseId}
                  currentUser={currentUser}
                />
              )}

              {currentScreen === 'hash-integrity' && (
                <HashIntegrityScreen
                  setCurrentScreen={navigateTo}
                  activeEvidence={activeEvidence}
                  setActiveEvidence={setActiveEvidence}
                  currentUser={currentUser}
                />
              )}

              {currentScreen === 'pipeline' && (
                <AiPipelineScreen
                  setCurrentScreen={navigateTo}
                  activeEvidence={activeEvidence}
                  setActiveEvidence={setActiveEvidence}
                  currentUser={currentUser}
                />
              )}

              {currentScreen === 'detection-results' && (
                <DetectionResultsScreen
                  setCurrentScreen={navigateTo}
                  selectedCaseId={selectedCaseId}
                  activeEvidence={activeEvidence}
                  setActiveEvidence={setActiveEvidence}
                  currentUser={currentUser}
                />
              )}

              {currentScreen === 'speaker-verification' && (
                <SpeakerVerificationScreen
                  setCurrentScreen={navigateTo}
                  selectedCaseId={selectedCaseId}
                  activeEvidence={activeEvidence}
                  currentUser={currentUser}
                  cases={cases}
                />
              )}

              {currentScreen === 'voice-disguise' && (
                <VoiceDisguiseScreen
                  setCurrentScreen={navigateTo}
                  selectedCaseId={selectedCaseId}
                  activeEvidence={activeEvidence}
                  currentUser={currentUser}
                  cases={cases}
                />
              )}

              {currentScreen === 'model-comparison' && (
                <ModelComparisonScreen
                  setCurrentScreen={navigateTo}
                  currentUser={currentUser}
                />
              )}

              {currentScreen === 'xai' && (
                <ExplainableAiScreen
                  setCurrentScreen={navigateTo}
                  selectedCaseId={selectedCaseId}
                  activeEvidence={activeEvidence}
                  setActiveEvidence={setActiveEvidence}
                  audioEvidenceUrl={activeEvidence.audioUrl}
                  currentUser={currentUser}
                />
              )}

              {currentScreen === 'expert-validation' && (
                <ExpertValidationScreen
                  setCurrentScreen={navigateTo}
                  selectedCaseId={selectedCaseId}
                  currentUser={currentUser}
                  expertReviews={expertReviews}
                  setExpertReviews={setExpertReviews}
                  onRegisterExpert={handleRegisterExpert}
                  initialSelectedExpertId={selectedExpertId}
                />
              )}

              {currentScreen === 'legal-review' && (
                <LegalReviewScreen
                  setCurrentScreen={navigateTo}
                  selectedCaseId={selectedCaseId}
                  currentUser={currentUser}
                />
              )}

              {currentScreen === 'report-generation' && (
                <ReportGenerationScreen
                  setCurrentScreen={navigateTo}
                  selectedCaseId={selectedCaseId}
                  activeEvidence={activeEvidence}
                  currentUser={currentUser}
                />
              )}

              {currentScreen === 'public-verify' && (
                <PublicVerificationScreen
                  setCurrentScreen={navigateTo}
                  initialToken={
                    typeof window !== 'undefined'
                      ? new URLSearchParams(window.location.search).get('token') || undefined
                      : undefined
                  }
                />
              )}

              {currentScreen === 'pending-approval' && (
                <PendingApprovalScreen
                  setCurrentScreen={navigateTo}
                  userEmail={pendingApprovalEmail}
                  currentUser={currentUser}
                />
              )}

              {currentScreen === 'audit-log' && (
                <AuditLogScreen
                  setCurrentScreen={navigateTo}
                  currentUser={currentUser}
                />
              )}

              {currentScreen === 'notifications' && (
                <NotificationCentreScreen
                  setCurrentScreen={navigateTo}
                  notifications={notifications}
                  setNotifications={setNotifications}
                  setSelectedCaseId={setSelectedCaseId}
                  currentUser={currentUser}
                />
              )}

              {currentScreen === 'admin-panel' && (
                <AdminPanelScreen
                  setCurrentScreen={navigateTo}
                  currentUser={currentUser}
                  users={users}
                  setUsers={setUsers}
                  onSignOut={handleSignOut}
                />
              )}

              {currentScreen === 'settings' && (
                <SettingsScreen
                  setCurrentScreen={navigateTo}
                  currentUser={currentUser}
                  setCurrentUser={setCurrentUser}
                />
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
